﻿using System;
using UnityEngine;
using UnityEngine.XR;
using Object = UnityEngine.Object;
using BepInEx;
using GorillaLocomotion;
using Photon.Pun;

namespace Prism.Utility
{
    public class GunLib
    {
        public static bool isShootingRight = false;
        public static bool isShootingLeft = false;
        public class BezierCurveRenderer : MonoBehaviour
        {
            public Vector3[] controlPoints = new Vector3[3];
            public int numberOfPoints = 100;
            void FixedUpdate()
            {
                DrawBezierCurve();
            }
            private void DrawBezierCurve()
            {
                LineRenderer lineRenderer = GetComponent<LineRenderer>();
                lineRenderer.positionCount = numberOfPoints;

                for (int i = 0; i < numberOfPoints; i++)
                {
                    float t = i / (float)(numberOfPoints - 1);
                    Vector3 position = CalculateBezierPoint(t, controlPoints[0], controlPoints[1], controlPoints[2]);
                    lineRenderer.SetPosition(i, position);
                }
            }

            private Vector3 CalculateBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2)
            {
                float u = 1 - t;
                float tt = t * t;
                float uu = u * u;
                Vector3 point = uu * p0;
                point += 2 * u * t * p1;
                point += tt * p2;
                return point;
            }
        }

        public class GunLibData
        {
            public VRRig lockedPlayer { get; set; }

            public bool isShooting { get; set; }

            public bool isLocked { get; set; }

            public Vector3 hitPosition { get; set; }

            public bool isTriggered { get; set; }

            public float startTime { get; set; }

            public GunLibData(bool stateTriggered, bool triggy, bool foundPlayer, VRRig player = null, Vector3 hitpos = new Vector3())
            {
                lockedPlayer = player;
                isShooting = stateTriggered;
                isLocked = foundPlayer;
                hitPosition = hitpos;
                isTriggered = triggy;
            }
        }

        static GameObject pointer;
        public static LineRenderer lr;
        static BezierCurveRenderer CurveRenderer;
        static GunLibData data = new GunLibData(false, false, false);

        public static void GunCleanUp()
        {
            isShootingRight = false;
            isShootingRight = false;
            if (pointer == null || lr == null) { return; }
            Object.Destroy(pointer);
            pointer = null;
            Object.Destroy(lr.gameObject);
            lr = null;
            Object.Destroy(CurveRenderer.gameObject);
            CurveRenderer = null;
            data = new GunLibData(false, false, false);
        }

        public static Color32 Red = new Color32(255, 0, 68, 190);
        public static Color32 Green = new Color32(0, 255, 195, 190);
        public static Color32 Blue = new Color32(0, 34, 255, 190);

        static Vector3 GetMiddle(Vector3 vecc)
        {
            return new Vector3(vecc.x / 2f, vecc.y / 2f, vecc.z / 2f);
        }

        static Vector3 CalculateBending(Vector3 currentPos, Vector3 fixedPos)
        {
            float distance = Vector3.Distance(currentPos, fixedPos);

            float adjustedSpeed = 45 * Mathf.Clamp01(distance / 5);

            return Vector3.MoveTowards(currentPos, fixedPos, adjustedSpeed * Time.deltaTime);
        }

        static Vector3 CalculateBendingEndRope(Vector3 currentPos, Vector3 fixedPos)
        {
            float distance = Vector3.Distance(currentPos, fixedPos);

            if (distance > 5)
            {
                currentPos = Vector3.MoveTowards(currentPos, fixedPos, 5 - 0.01f);
            }

            float adjustedSpeed = 35 * Mathf.Clamp01(distance / 5);

            return Vector3.MoveTowards(currentPos, fixedPos, adjustedSpeed * Time.deltaTime);

        }

        public static GunLibData ShootBending()
        {
            try
            {
                if (XRSettings.isDeviceActive)
                {
                    data.isShooting = InputHandler.RightGrip;
                    data.isTriggered = InputHandler.RightTrig;
                    if (data.isShooting)
                    {
                        isShootingRight = true;
                        RaycastHit hit;
                        Renderer pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out hit, float.PositiveInfinity, ~(1 << 15 | 1 << 3)) && pointer == null)
                        {
                            pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            GameObject.Destroy(pointer.GetComponent<Rigidbody>());
                            GameObject.Destroy(pointer.GetComponent<SphereCollider>());
                            pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                            pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                            pr.material.color = Red;
                            pr.material.shader = Shader.Find("GUI/Text Shader");
                        }
                        if (lr == null)
                        {
                            var lrob = new GameObject("line");
                            lr = lrob.AddComponent<LineRenderer>();
                            lr.endWidth = 0.01f;
                            lr.startWidth = 0.01f;
                            lr.material.shader = Shader.Find("GUI/Text Shader");
                            CurveRenderer = lrob.AddComponent<BezierCurveRenderer>();
                            CurveRenderer.controlPoints[1] = GorillaLocomotion.Player.Instance.headCollider.transform.position;
                        }
                        data.hitPosition = hit.point;
                        CurveRenderer.controlPoints[1] = CalculateBending(CurveRenderer.controlPoints[1], GetMiddle(Player.Instance.rightControllerTransform.transform.position + data.hitPosition));
                        CurveRenderer.controlPoints[0] = Player.Instance.rightControllerTransform.transform.position;
                        CurveRenderer.controlPoints[2] = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                        pointer.transform.position = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                        VRRig rig = hit.collider.GetComponentInParent<VRRig>();
                        if (rig != null)
                        {
                            if (data.isTriggered)
                            {
                                data.lockedPlayer = rig;
                                data.isLocked = true;
                                pr.material.color = Blue;
                                lr.startColor = Blue;
                                lr.endColor = Blue;
                            }
                            else
                            {
                                lr.startColor = Green;
                                lr.endColor = Green;
                                pr.material.color = Green;
                                data.isLocked = false;
                                GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 3, GorillaTagger.Instance.tagHapticDuration / 2);
                            }
                        }

                    }
                    else
                    {
                        GunCleanUp();
                    }
                    return data;
                }
                else
                {
                    RaycastHit hit;
                    data.isShooting = true;
                    data.isTriggered = BepInEx.UnityInput.Current.GetMouseButton(0);
                    Renderer pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                    Ray ray = GameObject.Find("Shoulder Camera").activeSelf ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition);
                    if (Physics.Raycast(ray.origin, ray.direction, out hit, float.PositiveInfinity, ~(1 << 15 | 1 << 3)) && pointer == null)
                    {
                        pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        GameObject.Destroy(pointer.GetComponent<Rigidbody>());
                        GameObject.Destroy(pointer.GetComponent<SphereCollider>());
                        pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                        pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                        pr.material.color = Red;
                        pr.material.shader = Shader.Find("GUI/Text Shader");
                        data.startTime = Time.time;
                    }
                    if (lr == null)
                    {
                        var lrob = new GameObject("line");
                        lr = lrob.AddComponent<LineRenderer>();
                        lr.endWidth = 0.01f;
                        lr.startWidth = 0.01f;
                        lr.material.shader = Shader.Find("GUI/Text Shader");
                        CurveRenderer = lrob.AddComponent<BezierCurveRenderer>();
                        CurveRenderer.controlPoints[1] = GorillaLocomotion.Player.Instance.headCollider.transform.position;
                    }
                    data.hitPosition = hit.point;
                    CurveRenderer.controlPoints[1] = CalculateBending(CurveRenderer.controlPoints[1], GetMiddle(Player.Instance.headCollider.transform.position + data.hitPosition));
                    CurveRenderer.controlPoints[0] = Player.Instance.headCollider.transform.position;
                    CurveRenderer.controlPoints[2] = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                    pointer.transform.position = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                    VRRig rig = hit.collider.GetComponentInParent<VRRig>();
                    if (rig != null)
                    {
                        if (data.isTriggered)
                        {
                            data.isLocked = true;
                            lr.startColor = Blue;
                            lr.endColor = Blue;
                            pr.material.color = Blue;
                        }
                        else
                        {
                            data.isLocked = false;
                            lr.startColor = Green;
                            lr.endColor = Green;
                            pr.material.color = Green;
                        }
                    }
                    else
                    {
                        data.isLocked = false;
                        lr.startColor = Red;
                        lr.endColor = Red;
                        pr.material.color = Red;
                    }
                    return data;
                }
            }
            catch (Exception ex) { Debug.Log(ex.ToString()); return null; }
        }

        public static GunLibData ShootLockedBending()
        {
            try
            {
                RaycastHit hit;
                if (XRSettings.isDeviceActive)
                {
                    data.isShooting = InputHandler.RightGrip;
                    data.isTriggered = InputHandler.RightTrig;
                    if (data.isShooting)
                    {
                        isShootingRight = true;
                        Renderer pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                        if (data.lockedPlayer == null && !data.isLocked)
                        {
                            if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out hit, float.PositiveInfinity, ~(1 << 15 | 1 << 3)) && pointer == null)
                            {
                                pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                GameObject.Destroy(pointer.GetComponent<Rigidbody>());
                                GameObject.Destroy(pointer.GetComponent<SphereCollider>());
                                pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                                pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                                pr.material.color = Red;
                                pr.material.shader = Shader.Find("GUI/Text Shader");
                            }
                            if (lr == null)
                            {
                                var lrob = new GameObject("line");
                                lr = lrob.AddComponent<LineRenderer>();
                                lr.endWidth = 0.01f;
                                lr.startWidth = 0.01f;
                                lr.material.shader = Shader.Find("GUI/Text Shader");
                                CurveRenderer = lrob.AddComponent<BezierCurveRenderer>();
                                CurveRenderer.controlPoints[1] = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                            }
                            data.hitPosition = hit.point;
                            CurveRenderer.controlPoints[1] = CalculateBending(CurveRenderer.controlPoints[1], GetMiddle(Player.Instance.rightControllerTransform.transform.position + data.hitPosition));
                            CurveRenderer.controlPoints[0] = Player.Instance.rightControllerTransform.transform.position;
                            CurveRenderer.controlPoints[2] = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                            pointer.transform.position = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                            VRRig vrrig = hit.collider.GetComponentInParent<VRRig>();
                            if (vrrig != null)
                            {
                                if (data.isTriggered && !vrrig.isOfflineVRRig)
                                {
                                    data.lockedPlayer = vrrig;
                                    data.isLocked = true;
                                    lr.startColor = Blue;
                                    lr.endColor = Blue;
                                    pr.material.color = Blue;
                                }
                                else
                                {
                                    data.isLocked = false;
                                    lr.startColor = Green;
                                    lr.endColor = Green;
                                    pr.material.color = Green;
                                    GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2, GorillaTagger.Instance.tagHapticDuration / 2);
                                }
                            }
                            else
                            {
                                data.isLocked = false;
                                lr.startColor = Red;
                                lr.endColor = Red;
                                pr.material.color = Red;
                            }
                        }

                        if (data.isTriggered && data.lockedPlayer != null)
                        {
                            data.isLocked = true;
                            data.hitPosition = data.lockedPlayer.transform.position;
                            CurveRenderer.controlPoints[1] = CalculateBending(CurveRenderer.controlPoints[1], GetMiddle(Player.Instance.rightControllerTransform.transform.position + data.hitPosition));
                            CurveRenderer.controlPoints[0] = Player.Instance.rightControllerTransform.transform.position;
                            CurveRenderer.controlPoints[2] = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                            pointer.transform.position = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                            lr.startColor = Blue;
                            lr.endColor = Blue;
                            pr.material.color = Blue;
                        }
                        else if (data.lockedPlayer != null)
                        {
                            data.isLocked = false;
                            data.lockedPlayer = null;
                            lr.startColor = Red;
                            lr.endColor = Red;
                            pr.material.color = Red;
                        }
                    }
                    else
                    {
                        GunCleanUp();
                    }
                    return data;
                }
                else
                {
                    data.isShooting = BepInEx.UnityInput.Current.GetMouseButton(1);
                    data.isTriggered = BepInEx.UnityInput.Current.GetMouseButton(0);
                    if (data.isShooting)
                    {
                        Renderer pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                        if (data.lockedPlayer == null && !data.isLocked)
                        {
                            Ray ray = GameObject.Find("Shoulder Camera").activeSelf ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition);
                            if (Physics.Raycast(ray.origin, ray.direction, out hit, float.PositiveInfinity, ~(1 << 15 | 1 << 3)) && pointer == null)
                            {
                                pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                GameObject.Destroy(pointer.GetComponent<Rigidbody>());
                                GameObject.Destroy(pointer.GetComponent<SphereCollider>());
                                pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                                pr = pointer != null ? pointer.GetComponent<Renderer>() : null;
                                pr.material.color = Red;
                                pr.material.shader = Shader.Find("GUI/Text Shader");

                            }
                            if (lr == null)
                            {
                                var lrob = new GameObject("line");
                                lr = lrob.AddComponent<LineRenderer>();
                                lr.endWidth = 0.01f;
                                lr.startWidth = 0.01f;
                                lr.material.shader = Shader.Find("GUI/Text Shader");
                                CurveRenderer = lrob.AddComponent<BezierCurveRenderer>();
                                CurveRenderer.controlPoints[1] = GorillaLocomotion.Player.Instance.headCollider.transform.position;
                            }
                            data.hitPosition = hit.point;
                            CurveRenderer.controlPoints[1] = CalculateBending(CurveRenderer.controlPoints[1], GetMiddle(Player.Instance.headCollider.transform.position + data.hitPosition));
                            CurveRenderer.controlPoints[0] = Player.Instance.headCollider.transform.position;
                            CurveRenderer.controlPoints[2] = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                            pointer.transform.position = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                            VRRig vrrig = hit.collider.GetComponentInParent<VRRig>();
                            if (vrrig != null && data.lockedPlayer == null)
                            {
                                if (data.isTriggered && !vrrig.isOfflineVRRig)
                                {
                                    data.lockedPlayer = vrrig;
                                    data.isLocked = true;
                                }
                                else
                                {
                                    data.isLocked = false;
                                    lr.startColor = Green;
                                    lr.endColor = Green;
                                    pr.material.color = Green;
                                }
                            }
                            else
                            {
                                data.isLocked = false;
                                lr.startColor = Red;
                                lr.endColor = Red;
                                pr.material.color = Red;
                            }
                        }
                        if (pr != null)
                        {
                            if (data.isTriggered && data.lockedPlayer != null)
                            {
                                data.hitPosition = data.lockedPlayer.transform.position;
                                CurveRenderer.controlPoints[1] = CalculateBending(CurveRenderer.controlPoints[1], GetMiddle(Player.Instance.rightControllerTransform.transform.position + data.hitPosition));
                                CurveRenderer.controlPoints[0] = Player.Instance.headCollider.transform.position;
                                CurveRenderer.controlPoints[2] = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                                pointer.transform.position = CalculateBendingEndRope(CurveRenderer.controlPoints[2], data.hitPosition);
                                data.isLocked = true;
                                lr.startColor = Blue;
                                lr.endColor = Blue;
                                pr.material.color = Blue;
                            }
                            else if (data.lockedPlayer != null)
                            {
                                data.isLocked = false;
                                data.lockedPlayer = null;
                                lr.startColor = Red;
                                lr.endColor = Red;
                                pr.material.color = Red;
                            }
                        }
                    }
                    else
                    {
                        GunCleanUp();
                    }
                    return data;
                }
            }
            catch (Exception ex) { Debug.Log(ex.ToString()); return null; }
        }
    }
}
