﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

namespace Prism.Utility
{
	public class WriteProtection : MonoBehaviour
	{
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern IntPtr OpenProcess(uint processAccess, bool bInheritHandle, int processId);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool EnumProcessModules(IntPtr hProcess, [Out] IntPtr[] lphModule, uint cb, out uint lpcbNeeded);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern uint GetModuleFileNameEx(IntPtr hProcess, IntPtr hModule, [Out] StringBuilder lpBaseName, int nSize);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hObject);

		private void Start()
		{
			this._initialModules = this.GetProcessModules();
			base.InvokeRepeating("CheckForInjectedModules", 0f, 5f);
		}

		private IntPtr[] GetProcessModules()
		{
			Process currentProcess = Process.GetCurrentProcess();
			IntPtr intPtr = OpenProcess(1040U, false, currentProcess.Id);
			IntPtr[] array;
			if (intPtr == IntPtr.Zero)
			{
				UnityEngine.Debug.Log("Failed to open process for module enumeration.");
				array = null;
			}
			else
			{
				IntPtr[] array2 = new IntPtr[1024];
				uint num;
				if (EnumProcessModules(intPtr, array2, (uint)(IntPtr.Size * array2.Length), out num))
				{
					int num2 = (int)((ulong)num / (ulong)((long)IntPtr.Size));
					Array.Resize<IntPtr>(ref array2, num2);
				}
				else
				{
					UnityEngine.Debug.Log("Failed to enumerate process modules.");
					array2 = null;
				}
				CloseHandle(intPtr);
				array = array2;
			}
			return array;
		}

		public static void isModified(string injectedModule)
		{
			foreach (string text in injectedModules)
			{
				if (injectedModule.Contains(text) || injectedModule == text)
				{
					Application.Quit();
					Environment.FailFast("ff");
				}
			}
		}

		private void CheckForInjectedModules()
		{
			IntPtr[] processModules = this.GetProcessModules();
			if (processModules != null || this._initialModules != null)
			{
				foreach (IntPtr intPtr in processModules)
				{
					if (Array.IndexOf<IntPtr>(this._initialModules, intPtr) < 0)
					{
						StringBuilder stringBuilder = new StringBuilder(255);
						GetModuleFileNameEx(Process.GetCurrentProcess().Handle, intPtr, stringBuilder, 255);
						isModified(stringBuilder.ToString());
					}
				}
			}
		}

		private const uint PROCESS_QUERY_INFORMATION = 1024U;

		private const uint PROCESS_VM_READ = 16U;

		private const int MaxModuleNameLength = 255;

		private IntPtr[] _initialModules;

		private static List<string> injectedModules = new List<string> {
			"C:\\Windows\\SYSTEM32\\webio.dll",
			"C:\\Windows\\SYSTEM32\\schannel.DLL",
			"C:\\Windows\\SYSTEM32\\mskeyprotect.dll",
			"C:\\Windows\\SYSTEM32\\NTASN1.dll",
			"C:\\Windows\\SYSTEM32\\ncrypt.dll",
			"C:\\Windows\\SYSTEM32\\ncryptsslp.dll",
			"C:\\Windows\\SYSTEM32\\DPAPI.DLL" };
	}
}