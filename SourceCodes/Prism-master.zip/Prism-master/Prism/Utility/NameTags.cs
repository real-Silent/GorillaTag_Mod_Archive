﻿using System.Linq;
using Photon.Pun;
using Photon.Realtime;
using Prism.Mods;
using Prism.Patches;
using UnityEngine;
using UnityEngine.UI;
using Object = UnityEngine.Object;
namespace Prism.Utility
{
	internal class NameTags : MonoBehaviour
    {
        private VRRig myRig;

        private Player myPlayer;

        private Text userName;

        public void OnDisable()
		{
			if (this.userName != null)
			{
				Destroy(this.userName.gameObject);
				Destroy(this);
			}
		}

		private void DestroyNameTag()
		{
			if (this.userName != null && this.userName.gameObject != null)
			{
				this.userName.text = " ";
			}
			if (this != null)
			{
				Object.Destroy(this);
			}
			if (base.gameObject != null)
			{
				Object.Destroy(this.userName.gameObject);
			}
		}

		private void LateUpdate()
		{
			if (!PhotonNetwork.InRoom)
			{
				this.DestroyNameTag();
			}
			else
			{
				if (this.userName == null && GhostHandler.OnEnable.nameTags)
				{
					this.myRig = base.GetComponent<VRRig>();
					this.myPlayer = PrismUtils.GrabPhotonView(this.myRig).Owner;
					this.userName = Object.Instantiate<Text>(this.myRig.playerText, this.myRig.playerText.transform.parent);
				}
				else
				{
					if (this.myRig == null || !GhostHandler.OnEnable.nameTags || !PhotonNetwork.PlayerList.Contains(this.myPlayer))
					{
						this.DestroyNameTag();
						return;
					}
					this.userName.color = VisualMods.getColorForESP(this.myRig);
					this.userName.text = this.myPlayer.NickName;
				}
				this.userName.transform.localPosition = new Vector3(32.025f, 222f, -16.5f);
				this.userName.transform.localScale = new Vector3(6f, 6f, 6f);
				this.userName.transform.eulerAngles = new Vector3(0f, GameObject.Find("Main Camera").transform.eulerAngles.y, 0f);
			}
		}
	}
}