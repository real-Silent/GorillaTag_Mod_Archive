﻿using Prism.WristMenu;
using UnityEngine;
using System.Net.Http;
using System.Net.Http.Headers;
using System;
using System.Net;

namespace Prism.Utility
{
	public class ThemeManager : MonoBehaviour
	{
        public void LateUpdate()
        {
            var buttonInfoArray = Settings.GetButtonInfoByPage(ModHandler.Category.MenuPrefs)?.ToArray();
            if (buttonInfoArray == null || buttonInfoArray.Length == 0)
            {
                return;
            }

            var buttonHandler = buttonInfoArray[0];
            if (buttonHandler == null)
            {
                return;
            }

            if (Themes == null || Themes.Length <= (int)buttonHandler.settingIndex)
            {
                return;
            }

            strobeColor.color = Color32.Lerp(currentTheme.startColor, currentTheme.endColor, Mathf.PingPong(Time.time, 1f));

            if (Themes[(int)buttonHandler.settingIndex] != currentTheme)
            {
                currentTheme = Themes[(int)buttonHandler.settingIndex];
                MenuHandler.RedrawMenu();
            }
        }
        public static Color32 originalColor;

		public static Material strobeColor = new Material(Shader.Find("GorillaTag/UberShader"));

		public static Font COCFont;

		public static Font GothicFont = Font.CreateDynamicFontFromOSFont("MS Gothic", 16);

		public static Font Verdana = Font.CreateDynamicFontFromOSFont("Verdana", 16);

        public static Color32 gPurp = new Color32(145, 48, byte.MaxValue, byte.MaxValue);


		public static Theme[] Themes = new Theme[]
		{
				new Theme("Dark", null, new Color(0.1f, 0.1f, 0.1f), new Color(0.1f, 0.1f, 0.1f), new Color(0.2f, 0.2f, 0.2f), new Color(0.3f, 0.3f, 0.3f), new Color(0.2f, 0.2f, 0.2f), new Color(0f, 255f, 255f)),
				new Theme("BubbleGum", null, new Color(0, 1, 1, 1), new Color(0, 0.8f, 1, 1), new Color(1, 0.5f, 1, 1), new Color(0, 0.8f, 1, 1), new Color(1, 0.5f, 0.7f, 1), Color.white),
				new Theme("Interstellar", null, gPurp, Color.black, Color.black, gPurp, Color.black, Color.white),		
				new Theme("Paradox", null, new Color(0.27f, 0.27f, 0.27f), new Color(0.45f, 1, 0.7f), Color.black, new Color(0f, 0.43f, 0f), Color.black, Color.white),
		};


        public static Theme currentTheme = Themes[0];


		public enum ButtonType
		{
			Background,
			OffButton,
			OnButton,
			Outline
		}

		public class Theme
		{
			public string themeName { get; set; }

			public Color32 startColor { get; set; }

			public Color32 endColor { get; set; }

			public Color32 offColor { get; set; }

			public Color32 onColor { get; set; }

			public Color32 outLineColor { get; set; }

			public Color32 textColor { get; set; }

            public Texture2D menuTexture { get; set; }

            public Theme(string themeName, Texture2D menuTexture, Color32 startColor, Color32 endColor, Color32 offColor, Color32 onColor, Color32 outLineColor, Color32 textColor)
			{
				this.themeName = themeName;
				this.startColor = startColor;
				this.endColor = endColor;
				this.offColor = offColor;
				this.onColor = onColor;
				this.outLineColor = outLineColor;
				this.textColor = textColor;
                this.menuTexture = menuTexture;
            }
		}

		public class ColorChanger : MonoBehaviour
		{
			public void Update()
			{
				if (base.GetComponent<Renderer>())
				{
					if (this.whichColor == ButtonType.Background)
					{
						if (currentTheme.menuTexture != null)
						{
							base.GetComponent<Renderer>().material.mainTexture = currentTheme.menuTexture;
						}
						else
						{
							base.GetComponent<Renderer>().material = strobeColor;
						}
                    }
					if (this.whichColor == ButtonType.OffButton)
					{
						base.GetComponent<Renderer>().material.color = currentTheme.offColor;
					}
					if (this.whichColor == ButtonType.OnButton)
					{
						base.GetComponent<Renderer>().material.color = currentTheme.onColor;
					}
					if (this.whichColor == ButtonType.Outline)
					{
						base.GetComponent<Renderer>().material.color = currentTheme.outLineColor;
					}
				}
				else
				{
					Destroy(base.gameObject);
				}
			}

			public ButtonType whichColor;
		}
	}
}
