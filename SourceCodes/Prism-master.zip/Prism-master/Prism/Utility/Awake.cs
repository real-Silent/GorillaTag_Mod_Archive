﻿using GorillaLocomotion;
using HarmonyLib;
using UnityEngine;

namespace Prism.Utility
{
	[HarmonyPatch(typeof(Player), "Awake")]
	internal class Awake
	{
		internal static void Postfix()
		{
			if (!Injection.isInjecting)
			{
				if (!GameObject.Find("[Prism]"))
				{
					Injection.InitializeLoader("YES");
				}
			}
		}
	}
}
