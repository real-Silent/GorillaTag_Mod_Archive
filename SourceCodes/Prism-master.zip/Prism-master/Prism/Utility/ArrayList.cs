﻿using System.Collections.Generic;
using System.Linq;
using Prism.WristMenu;
using UnityEngine;

namespace Prism.Utility
{
    internal class ArrayList : MonoBehaviour
    {
        private static List<string> modsEnabled = new List<string>();

        private static GUIStyle modStyle;

        private static Texture2D outlineTexture;

        private static Color currentColor;

        private void Start()
        {
            if (modStyle == null)
            {
                modStyle = new GUIStyle
                {
                    fontSize = 14,
                    alignment = TextAnchor.MiddleRight,
                    normal = new GUIStyleState
                    {
                        textColor = Color.white
                    }
                };
            }
            outlineTexture = new Texture2D(1, 1);
            outlineTexture.SetPixel(0, 0, ThemeManager.currentTheme.startColor);
            outlineTexture.Apply();
            RefreshModsList();
        }

        private void Update()
        {
            currentColor = Variables.Rainbow();
        }

        private void OnGUI()
        {
            float watermarkHeight = 35f;
            float num = watermarkHeight;

            GUIStyle watermarkStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleRight,
                fontSize = 30,
                fontStyle = FontStyle.Bold,
                normal = { textColor = ThemeManager.strobeColor.color }
            };
            GUI.Label(new Rect(Screen.width - 210f, 0, 200f, watermarkHeight - 5), "Prism", watermarkStyle);

            foreach (string text in modsEnabled)
            {
                Vector2 vector = modStyle.CalcSize(new GUIContent(text));
                Rect rect = new Rect(Screen.width - vector.x - 20f, num, vector.x + 10f, vector.y + 5f);
                DrawOutlinedText(rect, text, ThemeManager.strobeColor.color);

                Rect rectToRight = new Rect(rect.x + rect.width + 5, rect.y, 4f, rect.height);
                DrawRect(rectToRight, ThemeManager.currentTheme.startColor);

                num += vector.y + 10f;
            }
        }

        public static void RefreshModsList()
        {
            GatherEnabledMods();
            modsEnabled = modsEnabled.OrderByDescending((string mod) => mod.Length).ToList<string>();
        }

        private static void GatherEnabledMods()
        {
            modsEnabled.Clear();
            foreach (ButtonHandler buttonHandler in ModHandler.buttons)
            {
                if (buttonHandler == null)
                {
                    Debug.LogWarning("Found a null button in Prism.buttons");
                }
                else
                {
                    if (buttonHandler.isToggled)
                    {
                        modsEnabled.Add(buttonHandler.text);
                    }
                }
            }
        }

        private static void DrawOutlinedText(Rect position, string text, Color outlineColor)
        {
            Color textColor = modStyle.normal.textColor;
            modStyle.normal.textColor = outlineColor;
            GUI.Label(new Rect(position.x - 1f, position.y - 1f, position.width, position.height), text, modStyle);
            GUI.Label(new Rect(position.x + 1f, position.y - 1f, position.width, position.height), text, modStyle);
            GUI.Label(new Rect(position.x - 1f, position.y + 1f, position.width, position.height), text, modStyle);
            GUI.Label(new Rect(position.x + 1f, position.y + 1f, position.width, position.height), text, modStyle);
            modStyle.normal.textColor = textColor;
            GUI.Label(position, text, modStyle);
        }

        private static void DrawRect(Rect rect, Color color)
        {
            Color originalColor = GUI.color;
            GUI.color = color;
            GUI.DrawTexture(rect, outlineTexture);
            GUI.color = originalColor;
        }
    }
}
