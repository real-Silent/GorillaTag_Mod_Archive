﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using HarmonyLib;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Prism.Patches;
using Prism.WristMenu;
using UnityEngine;
using BepInEx;
using Photon.Pun;

namespace Prism.Utility
{
    [BepInPlugin(GUID, Name, Version)]
    internal class CoolThing : BaseUnityPlugin
    {
        private CoolThing()
        {
            new Harmony("com.prism.porno").PatchAll(Assembly.GetExecutingAssembly());
            instance = this;
        }

        internal const string GUID = "com.prism.porno";

        internal const string Name = "Prism Solutions";

        internal const string Version = "4.0.0";

        public static CoolThing instance;
    }

    public class Injection
	{
        public static bool isInjecting = false;

        public static bool Authenticated = false;

        public static Harmony harmony = null;

        public static string key = string.Empty;

        internal static string sessionTicket;

        private const uint TOKEN_QUERY = 8U;

        private enum TOKEN_INFORMATION_CLASS
        {
            TokenUser = 1
        }

        public struct TOKEN_USER
        {
            public Injection.SID_AND_ATTRIBUTES User;
        }

        public struct SID_AND_ATTRIBUTES
        {
            public IntPtr Sid;

            public int Attributes;
        }
        public static void Inject()
		{
			isInjecting = true;
			if (FatalError("error9", false) != "PLEASEDONT")
			{
				Environment.FailFast("bye");
				Application.Quit();
			}
			if (!string.IsNullOrEmpty(Assembly.GetExecutingAssembly().Location))
			{
				if (FatalError("error15", true) != "FGEW(UHW(*EFHJ(W*EHF(h")
				{
					Environment.FailFast("bye");
					Application.Quit();
				}
				FatalError("Nope", true);
				Environment.FailFast("bye");
				Application.Quit();
			}
			else
			{
				if (IsVM())
				{
					if (FatalError("error15", true) != "FGEW(UHW(*EFHJ(W*EHF(h")
					{
						Environment.FailFast("bye");
						Application.Quit();
					}
					FatalError("Nope", true);
					Environment.FailFast("bye");
					Application.Quit();
				}
				else
				{
					if (Authenticate() == "AGREE")
					{
						string text2 = "YES";//i cant load menu
						InitializeLoader(text2);
						harmony = new Harmony("com.prism.porno");
						harmony.PatchAll();
					}
					else
					{
						if (FatalError("error2", true) == "CRASH")
						{
							Environment.FailFast("bye");
							Application.Quit();
						}
					}
				}
			}
		}

        private class AuthenticationResponse
        {
            public string SessionId { get; set; }
        }



        public static string Authenticate()
        {
            if (FatalError("error1", false) != "PLEASEDONT")
            {
                Environment.FailFast("bye");
                Application.Quit();
            }

            string keyFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Prism", "key.txt");

            if (!File.Exists(keyFilePath))
            {
                Authenticated = false;
                FatalError("No Key File!", true);
                return "DONT";
            }

            key = File.ReadAllText(keyFilePath);
            string currentProcessUserSID = GetCurrentProcessUserSID();
			string ipAddress = new WebClient().DownloadString("https://api.ipify.org/");
            string url = "http://45.55.74.63:3000/authenticate";

            var payload = new
            {
                key = key,
                hwid = currentProcessUserSID,
                ip = ipAddress
            };

            StringContent stringContent = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
            HttpClient httpClient = new HttpClient();

            try
            {
                HttpResponseMessage result = httpClient.PostAsync(url, stringContent).Result;
                string resultContent = result.Content.ReadAsStringAsync().Result;

                if (!result.IsSuccessStatusCode || !resultContent.ToLower().Contains("true"))
                {
                    Authenticated = false;
                    FatalError("Authentication Failed: " + resultContent, true);
                    return "DONT";
                }
                else
                {
                    var response = JsonConvert.DeserializeObject<AuthenticationResponse>(resultContent);
                    Injection.sessionTicket = response.SessionId;
                    Authenticated = true;
                    return "AGREE";
                }
            }
            catch (Exception ex)
            {
                Authenticated = false;
                FatalError("Error contacting authentication server: " + ex.Message, true);
                return "DONT";
            }
            return "DONT";
        }
		public static string GetKeyIfValid()
		{
			if (string.IsNullOrEmpty(key) || key == "")
			{
				return "NO KEY";
			}
			return key;
		}
		public static string GetSessionIfValid()
		{
            if (string.IsNullOrEmpty(sessionTicket) || sessionTicket == "")
            {
                return "NO TICKET";
            }
            return sessionTicket;
        }
        public static int currentUsers = 9999;
        public static string Ping()
        {
            currentUsers = 9999;
            GetCurrentUserCount();
            if (!Authenticated || string.IsNullOrEmpty(sessionTicket) || string.IsNullOrEmpty(key))
            {
                FatalError("Not authenticated ", true);
                return "DONT";
            }

            string text4 = "http://45.55.74.63:3000/ping";

			string currentRoom = "";

			if (PhotonNetwork.InRoom)
			{
				currentRoom = PhotonNetwork.CurrentRoom.Name;
			}
			else
			{
				currentRoom = "NO ROOM";
            }
            var anonymousType = new
            {
                sessionId = sessionTicket,
                currentRoom = currentRoom
            };

            StringContent stringContent = new StringContent(JsonConvert.SerializeObject(anonymousType), Encoding.UTF8, "application/json");
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage result;

            try
            {
                result = httpClient.PostAsync(text4, stringContent).Result;
            }
            catch (Exception ex)
            {
                FatalError("Error contacting authentication server: " + ex.Message, true);
                return "DONT";
            }

            string resultContent = result.Content.ReadAsStringAsync().Result;

            if (!result.IsSuccessStatusCode || !resultContent.ToLower().Contains("true"))
            {
                FatalError("Auth Check Failed", true);
                return "DONT";
            }
            else
            {
                return "AGREE";
            }

            return "DONT";
        }

        public static int GetCurrentUserCount()
        {
			if (currentUsers == 9999)
			{
				if (Injection.isInjecting && !(Environment.UserName.Contains("belan") || Environment.UserName.Contains("kingofnetflix")))
				{
					if (!Authenticated || string.IsNullOrEmpty(sessionTicket) || string.IsNullOrEmpty(key))
					{
						FatalError("Not authenticated ", true);
						return -1;
					}
				}

				string url = "http://45.55.74.63:3000/sessions";

				using (HttpClient httpClient = new HttpClient())
				{
					HttpResponseMessage response;
					try
					{
						response = httpClient.GetAsync(url).Result;
					}
					catch (Exception)
					{
						return -1;
					}

					if (!response.IsSuccessStatusCode)
					{
						return -1;
					}

					string responseContent;
					try
					{
						responseContent = response.Content.ReadAsStringAsync().Result;
					}
					catch (Exception)
					{
						return -1;
					}

					try
					{
						JObject json = JObject.Parse(responseContent);
						int count = json["count"].Value<int>();
                        currentUsers = count;

                        return count;
					}
					catch (Exception)
					{
						return -1;
					}
				}
			}
            return currentUsers;
        }

        public static void InitializeLoader(string init = "NO")
		{
			if (init != "YES")
			{
				if (FatalError("error2", true) == "CRASH")
				{
					Environment.FailFast("bye");
					Application.Quit();
				}
			}
			GameObject gameObject = new GameObject();
			gameObject.gameObject.name = "[Prism]";
			gameObject.AddComponent<Menu>().gameObject.name = "[Client] Wrist Menu";
			ControllerInputPoller.instance.AddComponent<InputHandler>().gameObject.name = "[Utility] Input Handler";
			ControllerInputPoller.instance.AddComponent<BoardManager>().gameObject.name = "[Utility] Boards Handler";
			ControllerInputPoller.instance.AddComponent<RoomManager>().gameObject.name = "[Patch] Room Manager";
			ControllerInputPoller.instance.AddComponent<NotifiLib>().gameObject.name = "[Utility] Notifications";
			ControllerInputPoller.instance.AddComponent<GhostHandler>().gameObject.name = "[Utility] Ghost Handler";
			ControllerInputPoller.instance.AddComponent<ArrayList>().gameObject.name = "[Utility] Array List";
            ModHandler.ogButtons = ModHandler.buttons;
        }

		public static bool IsVM()
		{
			string[] array = new string[] { "/sys/class/dmi/id/product_name", "/sys/class/dmi/id/sys_vendor", "/sys/class/dmi/id/board_vendor", "/sys/class/dmi/id/board_name" };
			foreach (string text in array)
			{
				if (File.Exists(text))
				{
					if (File.ReadAllText(text).ToLower().Contains("vmware") || text.Contains("virtualbox") || text.Contains("qemu"))
					{
						if (FatalError("error12", true) == "CRASH")
						{
							Environment.FailFast("bye");
							Application.Quit();
						}
						FatalError("Nope", true);
						Environment.FailFast("bye");
						Application.Quit();
						return true;
					}
				}
			}
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum\\PCI"))
				{
					foreach (string text3 in registryKey.GetSubKeyNames())
					{
						using (RegistryKey registryKey2 = registryKey.OpenSubKey(text3))
						{
							string text4 = (string)registryKey2.GetValue("DeviceDesc");
							if (text4 != null && (text4.Contains("VMware") || text4.Contains("VirtualBox") || text4.Contains("QEMU")))
							{
								if (FatalError("error198", true) == "CRASH")
								{
									Environment.FailFast("bye");
									Application.Quit();
								}
								FatalError("Nope", true);
								Environment.FailFast("bye");
								Application.Quit();
								return true;
							}
						}
					}
				}
			}
			catch
			{
			}
			return false;
		}

		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern bool GetTokenInformation(IntPtr TokenHandle, Injection.TOKEN_INFORMATION_CLASS TokenInformationClass, IntPtr TokenInformation, uint TokenInformationLength, out uint ReturnLength);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hObject);

		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool ConvertSidToStringSid(IntPtr pSID, out IntPtr ptrSid);

		public static string GetCurrentProcessUserSID()
		{
			IntPtr intPtr;
			OpenProcessToken(Process.GetCurrentProcess().Handle, 8U, out intPtr);
			uint num = 0U;
			GetTokenInformation(intPtr, TOKEN_INFORMATION_CLASS.TokenUser, IntPtr.Zero, num, out num);
			IntPtr intPtr2 = Marshal.AllocHGlobal((int)num);
			bool tokenInformation = GetTokenInformation(intPtr, TOKEN_INFORMATION_CLASS.TokenUser, intPtr2, num, out num);
			if (tokenInformation)
			{
				TOKEN_USER token_USER = (TOKEN_USER)Marshal.PtrToStructure(intPtr2, typeof(Injection.TOKEN_USER));
				IntPtr intPtr3;
				if (ConvertSidToStringSid(token_USER.User.Sid, out intPtr3))
				{
					string text = Marshal.PtrToStringAuto(intPtr3);
					Marshal.FreeHGlobal(intPtr2);
					CloseHandle(intPtr);
					return text;
				}
			}
			Marshal.FreeHGlobal(intPtr2);
			CloseHandle(intPtr);
			return null;
		}

		public static string FatalError(string error, bool shouldCrash)
		{
			if (!shouldCrash)
			{
				return "PLEASEDONT";
			}
			else
			{
				UnityEngine.Debug.Log(error);
				File.WriteAllText("error.txt", error);
				Environment.FailFast("bye");
				Application.Quit();
				return "CRASH";
			}
		}
	}
}