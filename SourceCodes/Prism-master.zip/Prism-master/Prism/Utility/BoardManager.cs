﻿using System;
using System.Net;
using GorillaNetworking;
using Photon.Pun;
using Prism.WristMenu;
using UnityEngine;
using UnityEngine.UI;

namespace Prism.Utility
{
	internal class BoardManager : MonoBehaviour
	{
		internal static void Check()
		{
			if (Time.time > checkTime + 60f)
			{
				idk = true;
				checkTime = Time.time;
			}
			try
			{

				if (idk)
				{
					WebClient webClient = new WebClient();
					string text = webClient.DownloadString("https://raw.githubusercontent.com/kingofnetflix/tundragame/main/interstellarstatus.txt").Trim();
					Debug.Log("VERSION TO CHECK: " + text + ", VERSION TO MATCH: " + CoolThing.Version);

                    if (text != CoolThing.Version.Trim() && text != "disabled")
					{
						NotifiLib.SendNotification("YOU ARE ON THE WRONG VERSION");
						GorillaComputer.instance.GeneralFailureMessage("PLEASE UPDATE PRISM MOD MENU. THIS VERSION MAY BE OUTDATED!\nVISIT OUR DISCORD FOR MORE HELP!\n\n<color=#3D03FC>discord.gg/BBMh7ZAPPX</color>");
					}
					if (text == "disabled")
					{
						NotifiLib.SendNotification("THE MENU HAS BEEN SHUTDOWN");
						GorillaComputer.instance.GeneralFailureMessage("PRISM MOD MENU IS CURRENTLY DISABLED.\n\nVISIT OUR DISCORD FOR MORE INFORMATION.\n\n<color=#3D03FC>discord.gg/BBMh7ZAPPX</color>");
					}
					idk = false;
				}
			}
			catch (Exception ex)
			{
				Debug.Log("ERROR OCCURED AT: " + ex.ToString());
			}
		}

		public void Start()
		{
			base.InvokeRepeating("Check", 0f, 60f);

        }

		public static void doBoards()
		{
            NotifiLib.boardList[1].GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            NotifiLib.boardList[1].GetComponent<Renderer>().material.color = ThemeManager.gPurp;
            NotifiLib.boardList[2].GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            NotifiLib.boardList[2].GetComponent<Renderer>().material.color = ThemeManager.gPurp;

			GameObject monitor = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/GorillaComputerObject/ComputerUI/monitor/monitorScreen");
			monitor.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            monitor.GetComponent<Renderer>().material.color = ThemeManager.gPurp;
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd").GetComponent<Text>().text = "Prism Solutions LLC";

            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct_Group/CodeOfConduct").GetComponent<Text>().text = "<color=cyan>PRISM FAQ</color>";
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd/motdtext").GetComponent<Text>().text = $"<color=#00FFEE>OWNER NOTICE</color>\n<color=#A1F6FF>ALL OWNERS AND/OR DEVS RELATED TO PRISM MOD MENU ARE NOT DIRECTLY RESPONSIBLE FOR ANY BANS YOU RECIEVE IF YOU BLATANTLY CHEAT</color>\n\n<color=red>PLEASE BE ADVISED THIS MENU IS JUST LIKE ANY OTHER MOD MENU, IT CAN STILL BAN YOU\nCurrent Online User Count: [<color=yellow>{Injection.GetCurrentUserCount()}</color>]</color>";

            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct_Group/CodeOfConduct/COC Text").GetComponent<Text>().text = string.Format("\n<color=cyan>Q1</color>: IS THE MENU FULLY UD?\n<color=blue>ANSWER</color>: WE TRY OUR BEST TO KEEP PRISM AS USER-SAFE AS POSSIBLE\n\n<color=cyan>Q2</color>: HOW MANY MODS ARE IN THE MENU?\n<color=blue>ANSWER</color>: PRISM IS EXPANDABLE WITH AROUND [<color=yellow>{0}</color>] MODS\n\n<color=cyan>Q3</color>: IS PRISM A RAT?\n<color=blue>ANSWER</color>: WE DO <color=red>NOT</color> HAVE A REASON TO RAT, SO <color=red>NO</color>!", ModHandler.buttons.Length);
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/Wall Monitors Screens/wallmonitorforest").GetComponent<Renderer>().material.color = Color.black;
            if (PhotonNetwork.InRoom)
            {
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Tree Room Texts/WallScreenForest").GetComponent<Text>().text = string.Format($"[+] CURRENT MASTERCLIENT: [{PhotonNetwork.MasterClient.NickName.ToUpper()}]\n[+] CURRENT NAME: [{PhotonNetwork.LocalPlayer.NickName.ToUpper()}]\n[+] CURRENT PLAYER COUNT: [{PhotonNetwork.CurrentRoom.PlayerCount}]\n[+] ROOM CODE: [{PhotonNetwork.CurrentRoom.Name}]\n[+] ROOM IP: [<color=cyan>{PhotonNetwork.NetworkingClient.LoadBalancingPeer.ServerIpAddress.ToString()}</color>]");
            }
            else if (!PhotonNetwork.InRoom)
            {
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Tree Room Texts/WallScreenForest").GetComponent<Text>().text = string.Concat(new string[]
                {
                    "WELCOME BACK TO PRISM, [<color=yellow>",
                    PhotonNetwork.LocalPlayer.NickName.ToUpper(),
                    "</color>]. Cya Round..\n\n\n\nUSER ID: [<color=cyan>",
                    PhotonNetwork.LocalPlayer.UserId,
                    "</color>]"
                });
            }
        }

		public void LateUpdate()
		{
			if (!PlayFabAuthenticator.instance.loginFailed)
			{
				doBoards();
            }
		}
		private static float checkTime = 0f;

		private static bool idk = true;
	}
}