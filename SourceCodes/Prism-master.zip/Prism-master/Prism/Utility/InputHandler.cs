﻿using UnityEngine;
using UnityEngine.XR;
using Valve.VR;

namespace Prism.Utility
{
    internal class InputHandler : MonoBehaviour
    {
        internal static bool LeftPrim;
        internal static bool RightPrim;

        internal static bool LeftSec;
        internal static bool RightSec;

        internal static bool LeftGrip;
        internal static bool RightGrip;

        internal static bool LeftTrig;
        internal static bool RightTrig;

        public static Vector2 RightJoystick;
        public static bool RightStickClick;

        public static Vector2 LeftJoystick;
        public static bool LeftStickClick;

        public enum VrType
        {
            OpenVR = 0,
            Oculus = 1,
            WindowsMR = 2,
            MockHMD = 3,
            none = 4,
        }

        public UnityEngine.XR.InputDevice leftController;
        public UnityEngine.XR.InputDevice rightController;
        VrType type;

        public void Awake()
        {
            type = HeadsetType();
            leftController = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
            rightController = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        }

        public static VrType HeadsetType()
        {
            if (XRSettings.isDeviceActive)
            {
                if (XRSettings.loadedDeviceName.Contains("Oculus"))
                {
                    return VrType.Oculus;
                }
                if (XRSettings.loadedDeviceName.Contains("Windows"))
                {
                    return VrType.WindowsMR;
                }
                if (XRSettings.loadedDeviceName.Contains("Open"))
                {
                    return VrType.OpenVR;
                }
                return VrType.MockHMD;
            }
            else
            {
                return VrType.none;
            }
        }

        internal void Update()
        {
            // Left Primary
            if (ControllerInputPoller.instance.leftControllerPrimaryButton)
                LeftPrim = true;
            else
                LeftPrim = false;

            // Right Primary
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
                RightPrim = true;
            else
                RightPrim = false;

            // Left Secondary
            if (ControllerInputPoller.instance.leftControllerSecondaryButton)
                LeftSec = true;
            else
                LeftSec = false;

            // Right Secondary
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
                RightSec = true;
            else
                RightSec = false;

            // Left Grip
            if (ControllerInputPoller.instance.leftControllerGripFloat >= 0.1f)
                LeftGrip = true;
            else
                LeftGrip = false;

            // Right Grip
            if (ControllerInputPoller.instance.rightControllerGripFloat >= 0.1f)
                RightGrip = true;
            else
                RightGrip = false;

            // Left Trigger
            if (ControllerInputPoller.instance.leftControllerIndexFloat >= 0.1f)
                LeftTrig = true;
            else
                LeftTrig = false;

            // Right Trigger
            if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.1f)
                RightTrig = true;
            else
                RightTrig = false;

            if (type == VrType.OpenVR)
            {
                RightJoystick = ControllerInputPoller.instance.rightControllerPrimary2DAxis;
                RightStickClick = SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(SteamVR_Input_Sources.RightHand);
                LeftJoystick = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.GetAxis(SteamVR_Input_Sources.LeftHand);
                LeftStickClick = SteamVR_Actions.gorillaTag_LeftJoystickClick.GetState(SteamVR_Input_Sources.LeftHand);
                return;
            }

            leftController.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out LeftStickClick);
            leftController.TryGetFeatureValue(CommonUsages.primary2DAxis, out LeftJoystick);

            rightController.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out RightStickClick);
            rightController.TryGetFeatureValue(CommonUsages.primary2DAxis, out RightJoystick);
        }
    }
}