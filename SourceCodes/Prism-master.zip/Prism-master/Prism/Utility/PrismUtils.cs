﻿using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using Photon.Pun;
using UnityEngine;
using ExitGames.Client.Photon;
using Photon.Realtime;
using Prism.Patches;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Collections.Generic;

namespace Prism.Utility
{
    public class PrismUtils : MonoBehaviour
    {
        internal static System.Random rand = new System.Random();
        internal static bool isKicking = false;
        internal static bool onGround;
        private static readonly System.Random random = new System.Random();

        public static string GenerateRandomUserAgent()
        {
            string[] browsers = new string[]
            {
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/92.0.902.62 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0"
            };

            int index = random.Next(browsers.Length);
            return browsers[index];
        }

        public static Texture2D DownloadBackground(string imageString)
        {
            Texture2D imageTexture = new Texture2D(2, 2);
            try
            {
                byte[] imageBytes;
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Add("user-agent", GenerateRandomUserAgent());
                    imageBytes = webClient.DownloadData(imageString);
                }

                ImageConversion.LoadImage(imageTexture, imageBytes);
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to download image: {e.Message}");
            }
            return imageTexture;
        }

        internal static void OnGroundRaycast()
        {
            float raycastLength = 1.3f;
            float raycastRadius = 0.3f;
            Vector3 raycastOffset = new Vector3(0f, 0.4f, 0f);
            float scale = 1f;
            Transform body = GorillaLocomotion.Player.Instance.bodyCollider.transform;
            float maxDistance = raycastLength * scale;
            Vector3 origin = body.TransformPoint(raycastOffset);
            float radius = raycastRadius * scale;
            RaycastHit hitInfo;
            bool flag = Physics.Raycast(origin, Vector3.down, out hitInfo, maxDistance, GorillaLocomotion.Player.Instance.locomotionEnabledLayers);
            RaycastHit hitInfo2;
            bool flag2 = Physics.SphereCast(origin, radius, Vector3.down, out hitInfo2, maxDistance, GorillaLocomotion.Player.Instance.locomotionEnabledLayers);
            RaycastHit raycastHit;
            if (flag && flag2)
            {
                raycastHit = ((hitInfo.distance <= hitInfo2.distance) ? hitInfo : hitInfo2);
            }
            else if (flag2)
            {
                raycastHit = hitInfo2;
            }
            else
            {
                if (!flag)
                {
                    onGround = false;
                    return;
                }
                raycastHit = hitInfo;
            }
            onGround = true;
        }

        internal static void IThinkICanAssClearCache()
        {
            isKicking = false;
            RaiseEventOptions raiseEventOptions = new RaiseEventOptions
            {
                CachingOption = (EventCaching)6,
                TargetActors = new int[]
                {
                    PhotonNetwork.LocalPlayer.ActorNumber
                }
            };
            PhotonNetwork.NetworkingClient.OpRaiseEvent(200, null, raiseEventOptions, SendOptions.SendReliable);
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
            }
            PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig);
            PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, null, null);
        }

        internal static string RandString(int length)
        {
            return new string((from s in Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", length)
                               select s[rand.Next(s.Length)]).ToArray<char>());
        }

        internal static bool isModded()
        {
            if (PhotonNetwork.InRoom && PhotonNetwork.CurrentRoom.CustomProperties.ToString().Contains("MODDED"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static VRRig GetUnTaggedClosestToVector(Vector3 pos)
        {
            VRRig myRig = GorillaTagger.Instance.offlineVRRig;
            float closestYet = float.MaxValue;
            VRRig closest = null;

            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                if (rig.isOfflineVRRig || rig == GorillaTagger.Instance.myVRRig)
                {
                    continue;
                }
                if (!RoomManager.tagManager.currentInfected.Contains(rig.Creator))
                {
                    if (Vector3.SqrMagnitude(pos - rig.transform.position) < closestYet)
                    {
                        closest = rig;
                        closestYet = Vector3.SqrMagnitude(pos - rig.transform.position);
                    }
                }
            }

            return closest;
        }

        internal static VRRig GetTaggedClosestToVector(Vector3 pos)
        {
            VRRig myRig = GorillaTagger.Instance.offlineVRRig;
            float closestYet = float.MaxValue;
            VRRig closest = null;

            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                if (rig.isOfflineVRRig || rig == GorillaTagger.Instance.myVRRig)
                {
                    continue;
                }
                if (RoomManager.tagManager.currentInfected.Contains(rig.Creator))
                {
                    if (Vector3.SqrMagnitude(pos - rig.transform.position) < closestYet)
                    {
                        closest = rig;
                        closestYet = Vector3.SqrMagnitude(pos - rig.transform.position);
                    }
                }
            }

            return closest;
        }


        internal static VRRig GetRandomRig()
        {
            List<VRRig> rigs = new List<VRRig>();
            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                if (!rig.isOfflineVRRig && rig != GorillaTagger.Instance.myVRRig)
                {
                    rigs.Add(rig);
                }
            }

            if (rigs.Count == 0)
            {
                return null; 
            }

            int randomIndex = rand.Next(rigs.Count);
            return rigs[randomIndex];
        }

        public static VRRig GetTaggedWithLeastVelocity()
        {
            VRRig myRig = GorillaTagger.Instance.offlineVRRig;
            float leastVelocity = float.MaxValue;
            VRRig leastVelocityRig = null;

            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                if (rig.isOfflineVRRig || rig == GorillaTagger.Instance.myVRRig)
                {
                    continue;
                }

                if (RoomManager.tagManager.currentInfected.Contains(rig.Creator))
                {
                    float rigVelocity = rig.GetComponent<Rigidbody>().velocity.magnitude;

                    if (rigVelocity < leastVelocity)
                    {
                        leastVelocityRig = rig;
                        leastVelocity = rigVelocity;
                    }
                }
            }

            return leastVelocityRig;
        }

        internal static bool GSDCheck()
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            Assembly targetAssembly = assemblies.FirstOrDefault(a => a.GetName().Name == "Assembly-CSharp");

            if (targetAssembly != null)
            {
                Type projectileTrackerType = targetAssembly.GetTypes().FirstOrDefault(t => t.Name == "PlayerCosmeticsSystem");

                if (projectileTrackerType != null)
                {
                    FieldInfo field = projectileTrackerType.GetField("isLookingUp", BindingFlags.Instance | BindingFlags.NonPublic);

                    if (field != null)
                    {
                        object defaultValue = field.GetValue(Activator.CreateInstance(projectileTrackerType));
                        bool isLookingUp = (bool)defaultValue;
                        return isLookingUp;
                    }
                    else
                    {
                        Debug.Log("Field 'isLookingUp' not found in PlayerCosmeticsSystem.");
                        return false;
                    }
                }
                else
                {
                    Debug.Log("PlayerCosmeticsSystem class not found in Assembly-CSharp.");
                    return false;
                }
            }
            else
            {
                Debug.Log("Assembly-CSharp not found.");
                return false;
            }
        }

        internal static PhotonView GrabPhotonView(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }

        internal static string GetGamemode()
        {
            if (GorillaGameManager.instance.GameModeName().ToString().Contains("CASUAL"))
            {
                return "CASUAL";
            }
            if (GorillaGameManager.instance.GameModeName().ToString().Contains("INFECTION"))
            {
                return "INFECTION";
            }
            if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
            {
                return "HUNT";
            }
            if (GorillaGameManager.instance.GameModeName().ToString().Contains("BATTLE"))
            {
                return "BATTLE";
            }
            return "NONE";
        }

        internal static bool AmTagged()
        {
            return (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || RoomManager.tagManager.currentInfected.Contains(PhotonNetwork.LocalPlayer)) && PhotonNetwork.InRoom;
        }

        internal static float CalculateTotalDistance(Vector3 a, Vector3 b, Vector3 c)
        {
            float distanceAB = Vector3.Distance(a, b);
            float distanceBC = Vector3.Distance(b, c);
            float distanceCA = Vector3.Distance(c, a);

            return distanceAB + distanceBC + distanceCA;
        }

        internal static bool IsNumberBetween(float number, float lowerBound, float upperBound)
        {
            return number > lowerBound && number < upperBound;
        }

        public static int[] AddElementToArray(int[] originalArray, int newElement)
        {
            if (originalArray == null)
            {
                return new int[] { newElement };
            }

            int[] newArray = new int[originalArray.Length];
            for (int i = 0; i < originalArray.Length; i++)
            {
                newArray[i] = originalArray[i];
            }
            newArray[originalArray.Length] = newElement;
            return newArray;
        }
    }
}