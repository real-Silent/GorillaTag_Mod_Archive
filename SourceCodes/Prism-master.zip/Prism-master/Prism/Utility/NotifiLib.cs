﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Prism.Utility
{
	public class NotifiLib : MonoBehaviour
    {
        private static GameObject MainCamera;

        private static GameObject HUDObj;

        private static GameObject HUDObj2;

        private static Text Testtext;

		private static float notiTimer = 0;

        private static Material AlertText = new Material(Shader.Find("GUI/Text Shader"));

        private static int NotificationDecayTime = 500;

        private static int NotificationDecayTimeCounter = 0;

        public static int NoticationThreshold = 30;

        public static string PreviousNotifi;

        public static Text NotifiText;

        public static bool IsEnabled = true;

        internal static List<GameObject> boardList = new List<GameObject>();
        public void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll(typeof(GameObject)))
			{
				if (gameObject.transform.parent == GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").transform)
				{
					if (gameObject.name == "forestatlas (combined by EdMeshCombinerSceneProcessor)")
					{
						boardList.Add(gameObject);
					}
				}
			}
			MainCamera = GameObject.Find("Main Camera");
			HUDObj = new GameObject("NOTIFICATIONLIB_HUD_OBJ");
			HUDObj2 = new GameObject("NOTIFICATIONLIB_HUD_OBJ");
			Canvas canvas = HUDObj.AddComponent<Canvas>();
			HUDObj.AddComponent<CanvasScaler>();
			HUDObj.AddComponent<GraphicRaycaster>();
			canvas.enabled = true;
			canvas.renderMode = RenderMode.WorldSpace;
			canvas.worldCamera = MainCamera.GetComponent<Camera>();
			RectTransform component = HUDObj.GetComponent<RectTransform>();
			component.sizeDelta = new Vector2(5f, 5f);
			component.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
			HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z - 4.6f);
			HUDObj.transform.parent = HUDObj2.transform;
			component.localPosition = new Vector3(0f, 0f, 1.6f);
			Vector3 eulerAngles = component.rotation.eulerAngles;
			eulerAngles.y = -270f;
			HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
			component.rotation = Quaternion.Euler(eulerAngles);
			Testtext = new GameObject
			{
				transform = 
				{
					parent = HUDObj.transform
				}
			}.AddComponent<Text>();
			Testtext.text = "";
			Testtext.fontSize = 10;
			Testtext.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
			Testtext.rectTransform.sizeDelta = new Vector2(260f, 70f);
			Testtext.alignment = TextAnchor.LowerLeft;
			Testtext.rectTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
			Testtext.rectTransform.localPosition = new Vector3(-1.5f, -0.9f, -0.6f);
			Testtext.material = AlertText;
			NotifiText = Testtext;
		}

		public void FixedUpdate()
		{
			HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
			HUDObj2.transform.rotation = MainCamera.transform.rotation;
			if (!string.IsNullOrEmpty(Testtext.text))
			{
				NotificationDecayTimeCounter++;
				if (NotificationDecayTimeCounter > NotificationDecayTime)
				{
					NotificationDecayTimeCounter = 0;
					string[] array = Testtext.text.Split(new string[] { Environment.NewLine }, StringSplitOptions.None).Skip(1).ToArray<string>();
					Testtext.text = string.Join("\n", array);
				}
			}
			else
			{
				NotificationDecayTimeCounter = 0;
			}
			if (!IsEnabled)
			{
				Testtext.text = "";
				NotifiText.text = "";
            }
		}

		public static void SendNotification(string NotificationText)
		{
			if (IsEnabled)
			{
				if (!NotificationText.Contains(Environment.NewLine))
				{
					NotificationText += Environment.NewLine;
				}
				NotifiText.text = NotifiText.text + NotificationText;
				PreviousNotifi = NotificationText;
			}
		}

		public static void SendWithCooldown(string NotificationText)
		{
            if (IsEnabled)
            {
				if (Time.time > notiTimer + 0.8f)
				{
                    if (!NotificationText.Contains(Environment.NewLine))
                    {
                        NotificationText += Environment.NewLine;
                    }
                    NotifiText.text = NotifiText.text + NotificationText;
                    PreviousNotifi = NotificationText;
					notiTimer = Time.time;
                }
            }
        }

		public static void ClearAllNotifications()
		{
			NotifiText.text = "";
		}

		public static void ClearPastNotifications(int amount)
		{
			string text = "";
			string[] array = NotifiText.text.Split(Environment.NewLine.ToCharArray()).Skip(amount).ToArray<string>();
			foreach (string text2 in array)
			{
				if (text2 != "")
				{
					text = text + text2 + "\n";
				}
			}
			NotifiText.text = text;
		}
	}
}