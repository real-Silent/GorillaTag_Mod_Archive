﻿using System.Collections.Generic;
using System.Linq;
using Prism.Mods;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;
using Valve.VR;

internal class Settings : MonoBehaviour
{
    internal static int projSpeed = 1;

    internal static Color currentProjectileColor = Color.white;

    public static List<ButtonHandler> GetButtonInfoByPage(ModHandler.Category page)
    {
        return ModHandler.buttons.Where((ButtonHandler button) => button.category == page).ToList();
    }



    internal static void ESP_Color()
    {
        var buttonHandler = MenuHandler.FindButton("ESP: [GameMode]") 
        ?? MenuHandler.FindButton("ESP: [RGB]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 2)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "ESP: [GameMode]";
                break;
            case 2:
                buttonHandler.text = "ESP: [RGB]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void AntiReport_Setting()
    {
        var buttonHandler = MenuHandler.FindButton("AntiReport: [Leave]")
        ?? MenuHandler.FindButton("AntiReport: [Stutter]") 
        ?? MenuHandler.FindButton("AntiReport: [Hop]") 
        ?? MenuHandler.FindButton("AntiReport: [Rejoin]");

        buttonHandler.settingIndex++;
        if (buttonHandler.settingIndex > 4)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "AntiReport: [Leave]";
                break;
            case 2:
                buttonHandler.text = "AntiReport: [Stutter]";
                break;
            case 3:
                buttonHandler.text = "AntiReport: [Hop]";
                break;
            case 4:
                buttonHandler.text = "AntiReport: [Rejoin]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void PlatForm_Setting()
    {
        var buttonHandler = MenuHandler.FindButton("Plats: [Normal]") 
        ?? MenuHandler.FindButton("Plats: [Sticky]") 
        ?? MenuHandler.FindButton("Plats: [Invis]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 3)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Plats: [Normal]";
                break;
            case 2:
                buttonHandler.text = "Plats: [Sticky]";
                break;
            case 3:
                buttonHandler.text = "Plats: [Invis]";
                break;

        }
        MenuHandler.RedrawMenu();
    }

    internal static void OpenButton()
    {
        var buttonHandler2 = MenuHandler.FindButton("Menu Hand: [Left]")
        ?? MenuHandler.FindButton("Menu Hand: [Right]");

        var buttonHandler = MenuHandler.FindButton("Menu Input: [X]")
        ?? MenuHandler.FindButton("Menu Input: [Y]")
        ?? MenuHandler.FindButton("Menu Input: [L3]")
        ?? MenuHandler.FindButton("Menu Input: [A]")
        ?? MenuHandler.FindButton("Menu Input: [B]")
        ?? MenuHandler.FindButton("Menu Input: [R3]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 3)
            buttonHandler.settingIndex = 1;

        if (buttonHandler2.settingIndex == 1)
        {
            switch (buttonHandler.settingIndex)
            {
                case 1:
                    buttonHandler.text = "Menu Input: [X]";
                    break;
                case 2:
                    buttonHandler.text = "Menu Input: [Y]";
                    break;
                case 3:
                    buttonHandler.text = "Menu Input: [L3]";
                    break;
            }
        }
        else if (buttonHandler2.settingIndex == 2)
        {
            switch (buttonHandler.settingIndex)
            {
                case 1:
                    buttonHandler.text = "Menu Input: [A]";
                    break;
                case 2:
                    buttonHandler.text = "Menu Input: [B]";
                    break;
                case 3:
                    buttonHandler.text = "Menu Input: [R3]";
                    break;
            }
        }

        MenuHandler.RedrawMenu();
    }

    internal static void MenuHand()
    {
        var buttonHandler = MenuHandler.FindButton("Menu Hand: [Left]") 
        ?? MenuHandler.FindButton("Menu Hand: [Right]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 2)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Menu Hand: [Left]";
                break;
            case 2:
                buttonHandler.text = "Menu Hand: [Right]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void MenuSounds()
    {
        var buttonHandler = MenuHandler.FindButton("Menu Sound: [CS]") 
        ?? MenuHandler.FindButton("Menu Sound: [SS]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 2)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Menu Sound: [CS]";
                break;
            case 2:
                buttonHandler.text = "Menu Sound: [SS]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void MenuTheme()
    {
        var buttonInfoArray = GetButtonInfoByPage(ModHandler.Category.MenuPrefs)?.ToArray();
        if (buttonInfoArray == null || buttonInfoArray.Length == 0)
        {
            return;
        }

        var buttonHandler = buttonInfoArray[0];
        if (buttonHandler == null)
        {
            return;
        }

        if (ThemeManager.Themes == null || ThemeManager.Themes.Count() == 0)
        {
            return;
        }

        if (buttonHandler.settingIndex < ThemeManager.Themes.Count() - 1)
        {
            buttonHandler.settingIndex++;
        }
        else
        {
            buttonHandler.settingIndex = 0;
        }

        ThemeManager.currentTheme = ThemeManager.Themes[(int)buttonHandler.settingIndex];

        if (ThemeManager.currentTheme == null)
        {
            return;
        }

        buttonHandler.text = "Menu Theme: " + ThemeManager.currentTheme.themeName;
        MenuHandler.RedrawMenu();
    }

    internal static void Fly_Setting()
    {
        var buttonHandler = MenuHandler.FindButton("Fly's: [Normal]") 
        ?? MenuHandler.FindButton("Fly's: [Slow]") 
        ?? MenuHandler.FindButton("Fly's: [High]");

        buttonHandler.settingIndex++;
        if (buttonHandler.settingIndex > 3)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Fly's: [Normal]";
                break;
            case 2:
                buttonHandler.text = "Fly's: [Slow]";
                break;
            case 3:
                buttonHandler.text = "Fly's: [High]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void Speed_Setting()
    {
        ButtonHandler buttonHandler = MenuHandler.FindButton("SpeedBoost: [Semi]")
        ?? MenuHandler.FindButton("SpeedBoost: [Comp]") 
        ?? MenuHandler.FindButton("SpeedBoost: [Blatant]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 3)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "SpeedBoost: [Semi]";
                break;
            case 2:
                buttonHandler.text = "SpeedBoost: [Comp]";
                break;
            case 3:
                buttonHandler.text = "SpeedBoost: [Blatant]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void ProjColor_Setting()
    {
        ButtonHandler buttonHandler = MenuHandler.FindButton("Proj Color: [White]")
        ?? MenuHandler.FindButton("Proj Color: [Black]")
        ?? MenuHandler.FindButton("Proj Color: [Red]")
        ?? MenuHandler.FindButton("Proj Color: [Green]") 
        ?? MenuHandler.FindButton("Proj Color: [Blue]") 
        ?? MenuHandler.FindButton("Proj Color: [Purple]") 
        ?? MenuHandler.FindButton("Proj Color: [Random]") 
        ?? MenuHandler.FindButton("Proj Color: [RGB]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 8)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Proj Color: [White]";
                currentProjectileColor = Color.white;
                break;
            case 2:
                buttonHandler.text = "Proj Color: [Black]";
                currentProjectileColor = Color.black;
                break;
            case 3:
                buttonHandler.text = "Proj Color: [Red]";
                currentProjectileColor = Color.red;
                break;
            case 4:
                buttonHandler.text = "Proj Color: [Green]";
                currentProjectileColor = Color.green;
                break;
            case 5:
                buttonHandler.text = "Proj Color: [Blue]";
                currentProjectileColor = Color.blue;
                break;
            case 6:
                buttonHandler.text = "Proj Color: [Purple]";
                break;
            case 7:
                buttonHandler.text = "Proj Color: [Random]";
                break;
            case 8:
                buttonHandler.text = "Proj Color: [RGB]";
                break;
            default:
                Debug.LogWarning($"Corrupt ProjColor: {buttonHandler.settingIndex}");
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void ProjTrail_Setting()
    {
        var buttonHandle = MenuHandler.FindButton("Proj Trail: [NONE]")
        ?? MenuHandler.FindButton("Proj Trail: [Slingshot]")
        ?? MenuHandler.FindButton("Proj Trail: [Cloud]")
        ?? MenuHandler.FindButton("Proj Trail: [Cupid]")
        ?? MenuHandler.FindButton("Proj Trail: [Horns]");

        buttonHandle.settingIndex++;
        if (buttonHandle.settingIndex > 5)
            buttonHandle.settingIndex = 1;

        switch (buttonHandle.settingIndex)
        {
            case 1:
                buttonHandle.text = "Proj Trail: [None]";
                break;
            case 2:
                buttonHandle.text = "Proj Trail: [Slingshot]";
                break;
            case 3:
                buttonHandle.text = "Proj Trail: [Cloud]";
                break;
            case 4:
                buttonHandle.text = "Proj Trail: [Cupid]";
                break;
            case 5:
                buttonHandle.text = "Proj Trail: [Horns]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void ProjType_Setting()
    {
        var buttonHandler = MenuHandler.FindButton("Proj Type: [Snow]") 
        ?? MenuHandler.FindButton("Proj Type: [Balloon]") 
        ?? MenuHandler.FindButton("Proj Type: [Rock]") 
        ?? MenuHandler.FindButton("Proj Type: [Gift]") 
        ?? MenuHandler.FindButton("Proj Type: [Candy]") 
        ?? MenuHandler.FindButton("Proj Type: [Fish]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 6f)
            buttonHandler.settingIndex = 1f;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Proj Type: [Snow]";
                ProjectileMods.projType = 0;
                break;
            case 2:
                buttonHandler.text = "Proj Type: [Balloon]";
                ProjectileMods.projType = 2;
                break;
            case 3:
                buttonHandler.text = "Proj Type: [Rock]";
                ProjectileMods.projType = 3;
                break;
            case 4:
                buttonHandler.text = "Proj Type: [Gift]";
                ProjectileMods.projType = 4;
                break;
            case 5:
                buttonHandler.text = "Proj Type: [Candy]";
                ProjectileMods.projType = 5;
                break;
            case 6:
                buttonHandler.text = "Proj Type: [Fish]";
                ProjectileMods.projType = 6;
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static void PlatInput_Setting()
    {
        var buttonHandler = MenuHandler.FindButton("Plat Input: [Grip]") 
        ?? MenuHandler.FindButton("Plat Input: [RT/LT]") 
        ?? MenuHandler.FindButton("Plat Input: [L3/R3]");

        buttonHandler.settingIndex++;

        if (buttonHandler.settingIndex > 3)
            buttonHandler.settingIndex = 1;

        switch (buttonHandler.settingIndex)
        {
            case 1:
                buttonHandler.text = "Plat Input: [Grip]";
                break;
            case 2:
                buttonHandler.text = "Plat Input: [RT/LT]";
                break;
            case 3:
                buttonHandler.text = "Plat Input: [L3/R3]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static bool OpenButtonInput()
    {
        var buttonHandler2 = MenuHandler.FindButton("Menu Input: [X]")
        ?? MenuHandler.FindButton("Menu Input: [Y]")
        ?? MenuHandler.FindButton("Menu Input: [L3]")
        ?? MenuHandler.FindButton("Menu Input: [A]")
        ?? MenuHandler.FindButton("Menu Input: [B]")
        ?? MenuHandler.FindButton("Menu Input: [R3]");

        var buttonHandler = MenuHandler.FindButton("Menu Hand: [Left]")
        ?? MenuHandler.FindButton("Menu Hand: [Right]");

        if (buttonHandler.settingIndex == 1)
        {
            if (buttonHandler2.settingIndex == 1)
            {
                return InputHandler.LeftPrim;
            }
            if (buttonHandler2.settingIndex == 2)
            {
                return InputHandler.LeftSec;
            }
            if (buttonHandler2.settingIndex == 3)
            {
                return SteamVR_Actions.gorillaTag_LeftJoystickClick.GetStateDown((SteamVR_Input_Sources.LeftHand));
            }
        }
        else if (buttonHandler.settingIndex == 2)
        {
            if (buttonHandler2.settingIndex == 1)
            {
                return InputHandler.RightPrim;
            }
            if (buttonHandler2.settingIndex == 2)
            {
                return InputHandler.RightSec;
            }
            if (buttonHandler2.settingIndex == 3)
            {
                return SteamVR_Actions.gorillaTag_RightJoystickClick.GetStateDown((SteamVR_Input_Sources.RightHand));
            }
        }
        return InputHandler.LeftPrim;
    }

    internal static void MenuOpen()
    {
        var button = MenuHandler.FindButton("Menu Draw: [Toggle]")
        ?? MenuHandler.FindButton("Menu Draw: [Hold]");

        button.settingIndex++;

        if (button.settingIndex > 2)
            button.settingIndex = 1;

        switch (button.settingIndex)
        {
            case 1:
                button.text = "Menu Draw: [Toggle]";
                break;
            case 2:
                button.text = "Menu Draw: [Hold]";
                break;

        }
    }

    internal static void NotifOn()
    {
        var button = MenuHandler.FindButton("Notifs: [Enabled]") 
        ?? MenuHandler.FindButton("Notifs: [Disabled]");

        button.settingIndex++;

        if (button.settingIndex > 2)
            button.settingIndex = 1;

        switch (button.settingIndex)
        {
            case 1:
                NotifiLib.IsEnabled = true;
                button.text = "Notifs: [Enabled]";
                break;
            case 2:
                NotifiLib.IsEnabled = false;
                button.text = "Notifs: [Disabled]";
                break;
        }

        MenuHandler.RedrawMenu();
    }

    internal static void WallWalk_Setting()
    {
        var button = MenuHandler.FindButton("Wall Walk: [Normal]")
        ?? MenuHandler.FindButton("Wall Walk: [Legit]") 
        ?? MenuHandler.FindButton("Wall Walk: [Blatant]");

        button.settingIndex++;

        if (button.settingIndex > 3)
            button.settingIndex = 1;

        switch (button.settingIndex)
        {
            case 1:
                button.text = "Wall Walk: [Normal]";
                MovementMods.wwStrength = 7.8f;
                break;

            case 2:
                button.text = "Wall Walk: [Legit]";
                MovementMods.wwStrength = 6.8f;
                break;
            case 3:
                button.text = "Wall Walk: [Blatant]";
                MovementMods.wwStrength = 9.8f;
                break;
        }

        MenuHandler.RedrawMenu();
    }

    internal static void ProjVelSpeed_Setting()
    {
        var button = MenuHandler.FindButton("Proj Speed: [Normal]") 
        ?? MenuHandler.FindButton("Proj Speed: [Slow]") 
        ?? MenuHandler.FindButton("Proj Speed: [Fast]");

        projSpeed++;

        if (projSpeed > 3) 
            projSpeed = 1;

        switch (projSpeed)
        {
            case 1:
                button.text = "Proj Speed: [Normal]";
                ProjectileMods.velSpeed = 95;
                break;
            case 2:
                button.text = "Proj Speed: [Slow]";
                ProjectileMods.velSpeed = 15;
                break;
            case 3:
                button.text = "Proj Speed: [Fast]";
                ProjectileMods.velSpeed = 250;
                break;
            default:
                Debug.Log("Something brok");
                break;
        }

        MenuHandler.RedrawMenu();
    }

    internal static void TagStrafe_Setting()
    {
        var button = MenuHandler.FindButton("Tag Type: [Behind]")
        ?? MenuHandler.FindButton("Tag Type: [Orbit]")
        ?? MenuHandler.FindButton("Tag Type: [Spaz]");

        button.settingIndex++;

        if (button.settingIndex > 3)
            button.settingIndex = 1;

        switch (button.settingIndex)
        {
            case 1:
                button.text = "Tag Type: [Spaz]";
                break;
            case 2:
                button.text = "Tag Type: [Behind]";
                break;
            case 3:
                button.text = "Tag Type: [Orbit]";
                break;
        }

        MenuHandler.RedrawMenu();
    }

    internal static void TagAura_Setting()
    {
        var button = MenuHandler.FindButton("Tag Aura: [Grip]")
        ?? MenuHandler.FindButton("Tag Aura: [Trig]")
        ?? MenuHandler.FindButton("Tag Aura: [L3/R3]");

        button.settingIndex++;

        if (button.settingIndex > 2)
            button.settingIndex = 1;

        switch (button.settingIndex)
        {
            case 1:
                button.text = "Tag Aura: [Grips]";
                break;
            case 2:
                button.text = "Tag Aura: [Triggers]";
                break;
            case 3:
                button.text = "Tag Aura: [L3/R3]";
                break;
        }
        MenuHandler.RedrawMenu();
    }

    internal static bool TagAura_Bind()
    {
        var buttonHandler2 = MenuHandler.FindButton("Tag Aura: [Grip]")
        ?? MenuHandler.FindButton("Tag Aura: [Trig]")
        ?? MenuHandler.FindButton("Tag Aura: [L3/R3]");

        if (buttonHandler2.settingIndex == 1)
        {
            return InputHandler.RightGrip ^ InputHandler.LeftGrip;
        }
        if (buttonHandler2.settingIndex == 2)
        {
            return InputHandler.RightTrig ^ InputHandler.LeftTrig;
        }
        if (buttonHandler2.settingIndex == 3)
        {
            return SteamVR_Actions.gorillaTag_LeftJoystickClick.GetStateDown(SteamVR_Input_Sources.LeftHand) ^ SteamVR_Actions.gorillaTag_RightJoystickClick.GetStateDown(SteamVR_Input_Sources.RightHand);
        }
        return InputHandler.RightGrip;
    }
}