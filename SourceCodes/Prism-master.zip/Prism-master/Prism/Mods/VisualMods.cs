﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Photon.Pun;
using Photon.Realtime;
using Prism.Patches;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;

namespace Prism.Mods
{
	internal class VisualMods : MonoBehaviour
    {
        private static Dictionary<VRRig, GameObject> boxDictionary = new Dictionary<VRRig, GameObject>();

        public static List<GameObject> boxes = new List<GameObject>();

        public static Dictionary<string, List<LineRenderer>> playerFrames = new Dictionary<string, List<LineRenderer>>();

		public static bool hasBeenSmoothed = false;

		public static List<int> filterModes = new List<int>();
		//=========================VARIABLE HANDLERS=================================================================
        private static GameObject CreateBoxSide(string name, Transform parent, Vector3 localPosition, Vector3 localScale)
		{
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject.name = name;
			UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.SetParent(parent);
			gameObject.transform.localPosition = localPosition;
			gameObject.transform.localScale = localScale;
			gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			return gameObject;
		}

		public static Color getColorForESP(VRRig vrrig)
		{
			Color color = Color.white;
            var buttonHandler = MenuHandler.FindButton("ESP: [GameMode]")
?? MenuHandler.FindButton("ESP: [RGB]");
            if (buttonHandler.settingIndex == 1)
			{
				switch (PrismUtils.GetGamemode())
				{
					case "CASUAL":
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            Color playerColor = vrrig.playerColor;
                            playerColor.a = 0.55f;
                            color = playerColor;
                        }
                        break;
					case "INFECTION":
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            color = (!vrrig.mainSkin.material.name.Contains("fected") || RoomManager.tagManager.currentIt != vrrig.Creator) ? Variables.green : Variables.red;
                        }
                        break;
					case "BATTLE":
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("bluealive"))
                        {
                            if (vrrig.mainSkin.material.name.Contains("bluealive"))
                            {
                                color = Variables.red;
                            }
                            else
                            {
                                if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                {
                                    color = Variables.green;
                                }
                                else
                                {
                                    color = Variables.red;
                                }
                            }
                        }
                        else
                        {
                            if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("orangealive"))
                            {
                                if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                {
                                    color = Variables.green;
                                }
                                else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                {
									color = Variables.red;
                                }
								else
								{
                                    color = Variables.red;
                                }
                            }
                            else
                            {
                                color = Variables.red;
                            }
                        }
                        break;
					case "HUNT":
                        if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                        {
                            color = Variables.green;
                        }
                        else
                        {
                            color = Variables.red;
                        }
                        break;
				}
			}
			else if (buttonHandler.settingIndex == 2)
			{
				if (Time.time > VRRigMods.gfaw + 0.04f)
				{
                    VRRigMods.gfaw = Time.time;
                    EspColorTemp = Variables.Rainbow(0.006f);
                }
				return EspColorTemp;
            }
			return color;
		}

		public static Color EspColorTemp = Color.white;

		private static GameObject GetOrCreateChild(GameObject parent, string name)
		{
			Transform transform = parent.transform.Find(name);
			GameObject gameObject;
			if (transform != null)
			{
				gameObject = transform.gameObject;
			}
			else
			{
				GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
				gameObject2.name = name;
				gameObject2.transform.SetParent(parent.transform);
				UnityEngine.Object.Destroy(gameObject2.GetComponent<BoxCollider>());
				gameObject = gameObject2;
			}
			return gameObject;
		}

		public static void NameTagESP(bool enable)
		{
			if (enable)
			{
				GhostHandler.OnEnable.nameTags = true;
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					if (!vrrig.GetComponent<NameTags>() && vrrig != null && vrrig != GorillaTagger.Instance.offlineVRRig)
					{
						vrrig.gameObject.AddComponent<NameTags>();
					}
				}
			}
			else
			{
				GhostHandler.OnEnable.nameTags = false;
			}
		}

		internal static void DrawWireframeBox(string playerID, Vector3 center, Quaternion rotation, Vector3 size, VRRig vrrig)
		{
			if (vrrig != null && vrrig != GorillaTagger.Instance.offlineVRRig)
			{
				if (!playerFrames.ContainsKey(playerID))
				{
					playerFrames[playerID] = new List<LineRenderer>();
				}
				List<LineRenderer> list = playerFrames[playerID];
				Vector3 vector = size * 0.5f;
				Vector3[] array = new Vector3[]
				{
					center + rotation * new Vector3(-vector.x, -vector.y, -vector.z),
					center + rotation * new Vector3(vector.x, -vector.y, -vector.z),
					center + rotation * new Vector3(vector.x, -vector.y, vector.z),
					center + rotation * new Vector3(-vector.x, -vector.y, vector.z),
					center + rotation * new Vector3(-vector.x, vector.y, -vector.z),
					center + rotation * new Vector3(vector.x, vector.y, -vector.z),
					center + rotation * new Vector3(vector.x, vector.y, vector.z),
					center + rotation * new Vector3(-vector.x, vector.y, vector.z)
				};
				Vector3[][] array2 = new Vector3[][]
				{
					new Vector3[]
					{
						array[0],
						array[1]
					},
					new Vector3[]
					{
						array[1],
						array[2]
					},
					new Vector3[]
					{
						array[2],
						array[3]
					},
					new Vector3[]
					{
						array[3],
						array[0]
					},
					new Vector3[]
					{
						array[4],
						array[5]
					},
					new Vector3[]
					{
						array[5],
						array[6]
					},
					new Vector3[]
					{
						array[6],
						array[7]
					},
					new Vector3[]
					{
						array[7],
						array[4]
					},
					new Vector3[]
					{
						array[0],
						array[4]
					},
					new Vector3[]
					{
						array[1],
						array[5]
					},
					new Vector3[]
					{
						array[2],
						array[6]
					},
					new Vector3[]
					{
						array[3],
						array[7]
					}
				};
				Color colorForESP = getColorForESP(vrrig);
				for (int i = 0; i < array2.Length; i++)
				{
					LineRenderer lineRenderer;
					if (i < list.Count && list[i] != null)
					{
						lineRenderer = list[i];
					}
					else
					{
						GameObject gameObject = new GameObject("Line");
						lineRenderer = gameObject.AddComponent<LineRenderer>();
						lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
						lineRenderer.material.color = colorForESP;
						lineRenderer.startColor = colorForESP;
						lineRenderer.endColor = colorForESP;
						lineRenderer.startWidth = 0.0225f;
						lineRenderer.endWidth = 0.0225f;
						lineRenderer.useWorldSpace = true;
						lineRenderer.positionCount = 2;
						list.Add(lineRenderer);
					}
					lineRenderer.startColor = colorForESP;
					lineRenderer.endColor = colorForESP;
					lineRenderer.SetPositions(array2[i]);
					lineRenderer.material.color = colorForESP;
				}
			}
		}

		internal static void TracerHandler(VRRig vrrig)
		{
			if (vrrig != GorillaTagger.Instance.offlineVRRig && vrrig != null)
			{
				LineRenderer lineRenderer = vrrig.gameObject.GetComponent<LineRenderer>();
				if (!lineRenderer)
				{
					lineRenderer = vrrig.gameObject.AddComponent<LineRenderer>();
				}
				lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
				lineRenderer.startWidth = 0.028f;
				lineRenderer.useWorldSpace = true;
				lineRenderer.material.color = getColorForESP(vrrig);
				lineRenderer.SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
				lineRenderer.SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
			}
		}

		internal static void SkeletonHandler(VRRig vrrig)
		{
			if (vrrig != GorillaTagger.Instance.offlineVRRig && vrrig != null)
			{
				LineRenderer lineRenderer = vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>();
				if (!lineRenderer)
				{
					lineRenderer = vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
				}
				lineRenderer.endWidth = 0.025f;
				lineRenderer.startWidth = 0.025f;
				lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
				lineRenderer.material.color = getColorForESP(vrrig);
				lineRenderer.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
				lineRenderer.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
				for (int i = 0; i < Variables.bones.Count(); i += 2)
				{
					LineRenderer lineRenderer2 = vrrig.mainSkin.bones[Variables.bones[i]].gameObject.GetComponent<LineRenderer>();
					if (!lineRenderer2)
					{
						lineRenderer2 = vrrig.mainSkin.bones[Variables.bones[i]].gameObject.AddComponent<LineRenderer>();
					}
					lineRenderer2.endWidth = 0.025f;
					lineRenderer2.startWidth = 0.025f;
					lineRenderer2.material.shader = Shader.Find("GUI/Text Shader");
					lineRenderer2.material.color = getColorForESP(vrrig);
					lineRenderer2.SetPosition(0, vrrig.mainSkin.bones[Variables.bones[i]].position);
					lineRenderer2.SetPosition(1, vrrig.mainSkin.bones[Variables.bones[i + 1]].position);
				}
			}
		}

		internal static void ResetESP()
		{
			try
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					if (vrrig != GorillaTagger.Instance.offlineVRRig && vrrig != null)
					{
						for (int i = 0; i < Variables.bones.Count(); i += 2)
						{
							UnityEngine.Object.Destroy(vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>());
							UnityEngine.Object.Destroy(vrrig.mainSkin.bones[Variables.bones[i]].gameObject.GetComponent<LineRenderer>());
						}
						UnityEngine.Object.Destroy(vrrig.gameObject.GetComponent<LineRenderer>());
						vrrig.mainSkin.material = vrrig.materialsToChangeTo[vrrig.setMatIndex];
					}
				}
				List<VRRig> list = new List<VRRig>();
				foreach (KeyValuePair<VRRig, GameObject> keyValuePair in boxDictionary)
				{
					UnityEngine.Object.Destroy(keyValuePair.Value);
					list.Add(keyValuePair.Key);
				}
				foreach (VRRig vrrig2 in list)
				{
					boxDictionary.Remove(vrrig2);
				}
				foreach (KeyValuePair<string, List<LineRenderer>> keyValuePair2 in playerFrames)
				{
					List<LineRenderer> value = keyValuePair2.Value;
					foreach (LineRenderer lineRenderer in value)
					{
						if (lineRenderer != null)
						{
							UnityEngine.Object.Destroy(lineRenderer.gameObject);
						}
					}
				}
				playerFrames.Clear();
			}
			catch
			{
				throw;
			}
		}
		//==============================VISUAL HANDLERS==============================================================

		internal static void Prism_NameTags()
		{
			if (Variables.webPageContent == null || Variables.webPageContent == string.Empty)
			{
				using (WebClient webClient = new WebClient())
				{
					Variables.webPageContent = webClient.DownloadString(Variables.adminURL);
				}
			}

			foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
			{
				try
				{
					if (Variables.webPageContent.Contains(player.UserId) && Variables.webPageContent != null)
					{
						VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
						vrrig.playerText.color = new Color(0.416f, 0f, 1f, 1f);
						vrrig.playerText.text = $"[ADMIN] - {player.NickName}";
						Variables.adminInRoom = true;
					}
					else if (!Variables.webPageContent.Contains(player.UserId) && Variables.webPageContent != null && player.CustomProperties.ContainsKey("Prism"))
					{
						VRRig vrrig2 = GorillaGameManager.instance.FindPlayerVRRig(player);
						vrrig2.playerText.color = new Color(0f, 1f, 0.678f, 1f);
						vrrig2.playerText.text = $"[PRISM] - {player.NickName}";
						Variables.adminInRoom = false;
					}
					else if (!Variables.webPageContent.Contains(player.UserId) && !player.CustomProperties.ContainsKey("Prism"))
					{
						VRRig vrrig3 = GorillaGameManager.instance.FindPlayerVRRig(player);
						vrrig3.playerText.color = Color.white;
						Variables.adminInRoom = false;
					}

				}
				catch (Exception ex)
				{
					Debug.Log("NameTag NullRef???-  " + ex.Message);
					break;
				}
			}
		}

        internal static void Chams()
		{
			if (!PhotonNetwork.InRoom) { return; }

			try
			{
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					if (vrrig != null && vrrig != GorillaTagger.Instance.offlineVRRig)
					{
						vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
						vrrig.mainSkin.material.color = getColorForESP(vrrig);
					}
				}
			}
			catch
			{
				throw;
			}
		}

		internal static void Tracers()
		{
			if (!PhotonNetwork.InRoom) { return; }

            try
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    TracerHandler(vrrig);
                }
            }
            catch
            {
                throw;
            }
		}

		internal static void BoxESP()
		{
			List<VRRig> list = new List<VRRig>();
			foreach (KeyValuePair<VRRig, GameObject> keyValuePair in boxDictionary)
			{
				if (!PhotonNetwork.InRoom || !PhotonNetwork.PlayerList.Contains(PrismUtils.GrabPhotonView(keyValuePair.Key).Owner))
				{
					UnityEngine.Object.Destroy(keyValuePair.Value);
					list.Add(keyValuePair.Key);
				}
			}
			foreach (VRRig vrrig in list)
			{
				boxDictionary.Remove(vrrig);
			}
			foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
			{
				if (vrrig2 != null && !vrrig2.isOfflineVRRig)
				{
					GameObject gameObject;
					if (!boxDictionary.ContainsKey(vrrig2))
					{
						gameObject = new GameObject("box");
						gameObject.transform.position = vrrig2.transform.position;
						GameObject gameObject2 = CreateBoxSide("top", gameObject.transform, new Vector3(0f, 0.49f, 0f), new Vector3(1f, 0.02f, 0.02f));
						GameObject gameObject3 = CreateBoxSide("bottom", gameObject.transform, new Vector3(0f, -0.49f, 0f), new Vector3(1f, 0.02f, 0.02f));
						GameObject gameObject4 = CreateBoxSide("left", gameObject.transform, new Vector3(-0.49f, 0f, 0f), new Vector3(0.02f, 1f, 0.02f));
						GameObject gameObject5 = CreateBoxSide("right", gameObject.transform, new Vector3(0.49f, 0f, 0f), new Vector3(0.02f, 1f, 0.02f));
						boxDictionary[vrrig2] = gameObject;
					}
					else
					{
						gameObject = boxDictionary[vrrig2];
					}
					gameObject.transform.position = vrrig2.transform.position;
					Color colorForESP = getColorForESP(vrrig2);
					foreach (object obj in gameObject.transform)
					{
						Transform transform = (Transform)obj;
						transform.GetComponent<Renderer>().material.color = colorForESP;
					}
					gameObject.transform.LookAt(gameObject.transform.position + Camera.main.transform.rotation * Vector3.forward, Camera.main.transform.rotation * Vector3.up);
				}
			}
		}

		internal static void BoneESP()
		{
			if (!PhotonNetwork.InRoom) { return; }

            try
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    SkeletonHandler(vrrig);
                }
            }
            catch
            {
                throw;
			}
		}

		public static void VRRigHitCube()
		{
			if (!PhotonNetwork.InRoom) { return; }

			try
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					Vector3 vector = new Vector3(vrrig.transform.localScale.x * 0.5f, vrrig.transform.localScale.y * 0.7f, vrrig.transform.localScale.z * 0.5f);
					Quaternion rotation = vrrig.transform.rotation;
					Vector3 position = vrrig.transform.position;
					DrawWireframeBox(PrismUtils.GrabPhotonView(vrrig).Owner.UserId, position - new Vector3(0f, 0.075f, 0f), rotation, vector, vrrig);
				}
			}
			catch
			{
				throw;
			}
		}
		//===================================VISUAL MODS=========================================================
    }
}