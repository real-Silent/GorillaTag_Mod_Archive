﻿using System.Collections.Generic;
using System.Linq;
using GorillaLocomotion;
using GorillaLocomotion.Gameplay;
using Photon.Pun;
using Prism.Utility;
using UnityEngine;
using HarmonyLib;

namespace Prism.Mods
{
	internal class WorldMods : MonoBehaviour
	{
		private static GliderHoldable[] holdables;

		private static float gew;

		private static float splashtimeout;

        public static void Splash(Vector3 vector)
        {
            GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", RpcTarget.All, new object[]
            {
                vector,
                Quaternion.Euler(new Vector3(UnityEngine.Random.Range(0, 360), UnityEngine.Random.Range(0, 360), UnityEngine.Random.Range(0, 360))),
                4f,
                100f,
                true,
                false
            });
        }

		internal static void GliderPos(Vector3 pos)
		{
            if (holdables == null)
            {
                holdables = Resources.FindObjectsOfTypeAll<GliderHoldable>();
            }
            for (int i = 0; i < GorillaParent.instance.vrrigs.Count; i += 1)
            {
                if (holdables[i] != null)
                {
                    PhotonView component = holdables[i].GetComponent<PhotonView>();
                    if (component.ControllerActorNr != PhotonNetwork.LocalPlayer.ActorNumber)
                    {
						component.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                        Traverse.Create(holdables[i]).Field("ownershipGuard").GetValue<RequestableOwnershipGuard>()
                            .RequestOwnershipImmediately(delegate
                            {
                                holdables[i].OnGrab(null, null);
                            });
                    }
                    if (component != null && component.ControllerActorNr == PhotonNetwork.LocalPlayer.ActorNumber)
                    {
                        GliderHoldable gliderHoldable = holdables[i];
                        gliderHoldable.OnGrab(null, null);
						gliderHoldable.gameObject.transform.position = pos;
                    }
                }
            }
        }

        public static void GrabBug()
		{
			GameObject bug = GameObject.Find("Floating Bug Holdable");

			GorillaTagger.Instance.offlineVRRig.enabled = false;

            GorillaTagger.Instance.offlineVRRig.transform.position = bug.transform.position; 

            GorillaTagger.Instance.offlineVRRig.rightHandTransform.position = bug.transform.position;

            ControllerInputPoller.instance.rightControllerGripFloat = 1f;
            ControllerInputPoller.instance.rightGrab = true;
            if (!ControllerInputPoller.instance.GetComponent<ThemeManager>())
            {
                ControllerInputPoller.instance.AddComponent<ThemeManager>().gameObject.name = "[Utility] Theme Manager";
            }

            GameObject.Find("Player Objects/Player VR Controller/[Utility] Theme Manager/EquipmentInteractor").GetComponent<EquipmentInteractor>().isRightGrabbing = true;
            GorillaTagger.Instance.offlineVRRig.enabled = true;

        }

		internal static void BugOrbit()
		{
			GrabBug();
			GameObject bug = GameObject.Find("Floating Bug Holdable");
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			if (Time.time > splashtimeout)
			{
				float num = 1.2f;
				float num2 = Time.time * num;
				float num3 = 15f;
				Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 0.8f, 0f);
				Vector3 vector2 = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * num3;
				Vector3 vector3 = vector + vector2 * Time.deltaTime * 5f;
				bug.transform.position = vector3;
				splashtimeout = Time.time + 0.3f;
			}

		}

		internal static void SplashOrbit()
		{
			if (Time.time > splashtimeout)
			{
				float num = 1.2f;
				float num2 = Time.time * num;
				float num3 = 15f;
				Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 0.8f, 0f);
				Vector3 vector2 = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * num3;
				Vector3 vector3 = vector + vector2 * Time.deltaTime * 5f;
				Splash(vector3);
				splashtimeout = Time.time + 0.3f;
			}
		}

		internal static void SplashAura()
		{
			if (Time.time > splashtimeout)
			{
				float num = 1f;
				float num2 = 2f;
				Vector3 vector = global::UnityEngine.Random.insideUnitSphere.normalized * global::UnityEngine.Random.Range(num, num2);
				Vector3 vector2 = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + vector;
				Vector3 vector3 = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - vector2;
				Splash(vector2);
				splashtimeout = Time.time + 0.2f;
			}
		}

		public static void SplashGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isShooting && data.isTriggered)
			{
				if (Time.time > splashtimeout)
				{
					GorillaTagger.Instance.offlineVRRig.enabled = false;
					GorillaTagger.Instance.offlineVRRig.transform.position = data.hitPosition - new Vector3(0f, 1f, 0f);
					Splash(data.hitPosition + new Vector3(0f, 1f, 0f));
					GorillaTagger.Instance.offlineVRRig.enabled = true;
					splashtimeout = Time.time + 0.1f;
				}
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		internal static void HideBoard()
		{
			foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
			{
				if (gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer)
				{
					GliderPos(gorillaPlayerScoreboardLine.gameObject.transform.position);
				}
			}
		}

		public static void BlindGun()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (data.isTriggered && data.isLocked)
			{
				GliderPos(data.lockedPlayer.headMesh.transform.position + new Vector3(0f, 0.5f, 0f));
			}
		}

		public static void BlindAll()
		{
			holdables = Resources.FindObjectsOfTypeAll<GliderHoldable>();

			for (int i = 0; i < GorillaParent.instance.vrrigs.Count; i += 1)
			{
				if (GorillaParent.instance.vrrigs[i] != GorillaTagger.Instance.offlineVRRig)
				{
                    PhotonView component = holdables[i].GetComponent<PhotonView>();
                    if (component.ControllerActorNr != PhotonNetwork.LocalPlayer.ActorNumber)
                    {
                        component.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                        Traverse.Create(holdables[i]).Field("ownershipGuard").GetValue<RequestableOwnershipGuard>()
                            .RequestOwnershipImmediately(delegate
                            {
                                holdables[i].OnGrab(null, null);
                            });
                    }
                    if (component != null && component.ControllerActorNr == PhotonNetwork.LocalPlayer.ActorNumber)
                    {
                        GliderHoldable gliderHoldable = holdables[i];
                        gliderHoldable.OnGrab(null, null);
                        gliderHoldable.gameObject.transform.position = GorillaParent.instance.vrrigs[i].headMesh.transform.position + new Vector3(0f, -0.1f, 0.45f);
                        gliderHoldable.gameObject.transform.rotation = GorillaParent.instance.vrrigs[i].headMesh.transform.rotation;
                        gliderHoldable.gameObject.transform.Rotate(90, 90, 90);
                    }
                }
			}
		}

        public static void GrabGlider()
		{
			if (InputHandler.RightGrip)
			{
                GliderPos(Player.Instance.rightControllerTransform.position);
            }
		}
		
		public static void GliderGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isTriggered && data.isShooting)
			{
				GliderPos(data.hitPosition + new Vector3(UnityEngine.Random.Range(-3f, 3f), 2f, UnityEngine.Random.Range(-3f, 3f)));
			}
		}

		public static void GliderGod()
		{
            float orbitSpeed = 4f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 11.2f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;

			GliderPos(vector);
        }

		public static void SendRopeRPC(Vector3 velocity)
		{
			if (Time.time > gew + 0.1f)
			{
				Dictionary<int, GorillaRopeSwing> value = Traverse.Create(RopeSwingManager.instance).Field("ropes").GetValue<Dictionary<int, GorillaRopeSwing>>();
				foreach (KeyValuePair<int, GorillaRopeSwing> keyValuePair in value)
				{
					PhotonView photonView = RopeSwingManager.instance.photonView;
					string text = "SetVelocity";
					RpcTarget rpcTarget = RpcTarget.All;
					object[] array = new object[5];
					array[0] = keyValuePair.Key;
					array[1] = 1;
					array[2] = velocity;
					array[3] = true;
					photonView.RPC(text, rpcTarget, array);
				}
				gew = Time.time;
			}
		}

		public static void RopeUp()
		{
			SendRopeRPC(new Vector3(0f, 100f, 1f));
		}

		public static void RopeDown()
		{
			SendRopeRPC(new Vector3(0f, -100f, 1f));
		}

		public static void RopeSpaz()
		{
			SendRopeRPC(new Vector3(UnityEngine.Random.Range(-9999, 9999), UnityEngine.Random.Range(9999, -9999), UnityEngine.Random.Range(-9999, 9999)));
		}

		public static void RopeToSelf()
		{
			Dictionary<int, GorillaRopeSwing> value = Traverse.Create(RopeSwingManager.instance).Field("ropes").GetValue<Dictionary<int, GorillaRopeSwing>>();
			foreach (KeyValuePair<int, GorillaRopeSwing> keyValuePair in value)
			{
				if (Time.time > gew + 0.1f)
				{
					Vector3 position = Player.Instance.transform.position;
					Vector3 vector = position - keyValuePair.Value.transform.position;
					float magnitude = vector.magnitude;
					float num = 9999f;
					float num2 = Mathf.Clamp01(num / magnitude);
					Vector3 vector2 = keyValuePair.Value.transform.position + vector.normalized * magnitude * num2;
					Vector3 vector3 = (vector2 - keyValuePair.Value.transform.position).normalized * num;
					PhotonView photonView = RopeSwingManager.instance.photonView;
					string text = "SetVelocity";
					RpcTarget rpcTarget = RpcTarget.All;
					object[] array = new object[5];
					array[0] = keyValuePair.Key;
					array[1] = 1;
					array[2] = vector3;
					array[3] = true;
					photonView.RPC(text, rpcTarget, array);
					gew = Time.time;
				}
			}
		}

		public static void RopeFreeze()
		{
			SendRopeRPC(Vector3.zero);
		}

		public static void RopeGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isShooting && data.isTriggered)
			{
				Dictionary<int, GorillaRopeSwing> value = Traverse.Create(RopeSwingManager.instance).Field("ropes").GetValue<Dictionary<int, GorillaRopeSwing>>();
				KeyValuePair<int, GorillaRopeSwing> keyValuePair = value.OrderBy(delegate (KeyValuePair<int, GorillaRopeSwing> ropes)
				{
					Vector3 hitPosition2 = data.hitPosition;
					KeyValuePair<int, GorillaRopeSwing> keyValuePair2 = ropes;
					return Vector3.Distance(hitPosition2, keyValuePair2.Value.transform.position);
				}).FirstOrDefault<KeyValuePair<int, GorillaRopeSwing>>();
				Vector3 hitPosition = data.hitPosition;
				Vector3 vector = hitPosition - keyValuePair.Value.transform.position;
				float magnitude = vector.magnitude;
				float num = 9999f;
				float num2 = Mathf.Clamp01(num / magnitude);
				Vector3 vector2 = keyValuePair.Value.transform.position + vector.normalized * magnitude * num2;
				Vector3 vector3 = (vector2 - keyValuePair.Value.transform.position).normalized * num;
				PhotonView photonView = RopeSwingManager.instance.photonView;
				string text = "SetVelocity";
				RpcTarget rpcTarget = RpcTarget.All;
				object[] array = new object[5];
				array[0] = keyValuePair.Value.ropeId;
				array[1] = 4;
				array[2] = vector3;
				array[3] = true;
				photonView.RPC(text, rpcTarget, array);
			}
		}

		public static void RopeFreezeGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isShooting && data.isTriggered)
			{
				Dictionary<int, GorillaRopeSwing> value = Traverse.Create(RopeSwingManager.instance).Field("ropes").GetValue<Dictionary<int, GorillaRopeSwing>>();
				KeyValuePair<int, GorillaRopeSwing> keyValuePair = value.OrderBy(delegate (KeyValuePair<int, GorillaRopeSwing> rope)
				{
					Vector3 hitPosition = data.hitPosition;
					KeyValuePair<int, GorillaRopeSwing> keyValuePair2 = rope;
					return Vector3.Distance(hitPosition, keyValuePair2.Value.transform.position);
				}).FirstOrDefault<KeyValuePair<int, GorillaRopeSwing>>();
				PhotonView photonView = RopeSwingManager.instance.photonView;
				string text = "SetVelocity";
				RpcTarget rpcTarget = RpcTarget.All;
				object[] array = new object[5];
				array[0] = keyValuePair.Key;
				array[1] = 1;
				array[2] = Vector3.zero;
				array[3] = true;
				photonView.RPC(text, rpcTarget, array);
			}
		}

		public static void SpazRopeGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isShooting && data.isTriggered)
			{
				Dictionary<int, GorillaRopeSwing> value = Traverse.Create(RopeSwingManager.instance).Field("ropes").GetValue<Dictionary<int, GorillaRopeSwing>>();
				KeyValuePair<int, GorillaRopeSwing> keyValuePair = value.OrderBy(delegate (KeyValuePair<int, GorillaRopeSwing> rope)
				{
					Vector3 hitPosition = data.hitPosition;
					KeyValuePair<int, GorillaRopeSwing> keyValuePair2 = rope;
					return Vector3.Distance(hitPosition, keyValuePair2.Value.transform.position);
				}).FirstOrDefault<KeyValuePair<int, GorillaRopeSwing>>();
				Vector3 vector = new Vector3((float)global::UnityEngine.Random.Range(-9999, 9999), (float)global::UnityEngine.Random.Range(9999, -9999), (float)global::UnityEngine.Random.Range(-9999, 9999));
				Vector3 vector2 = vector - keyValuePair.Value.transform.position;
				float magnitude = vector2.magnitude;
				float num = 9999f;
				float num2 = Mathf.Clamp01(num / magnitude);
				Vector3 vector3 = keyValuePair.Value.transform.position + vector2.normalized * magnitude * num2;
				Vector3 vector4 = (vector3 - keyValuePair.Value.transform.position).normalized * num;
				PhotonView photonView = RopeSwingManager.instance.photonView;
				string text = "SetVelocity";
				RpcTarget rpcTarget = RpcTarget.All;
				object[] array = new object[5];
				array[0] = keyValuePair.Value.ropeId;
				array[1] = 4;
				array[2] = vector4;
				array[3] = true;
				photonView.RPC(text, rpcTarget, array);
			}
		}

		public static void SpazAllDoors()
		{
			foreach (GhostLabButton awd in Resources.FindObjectsOfTypeAll<GhostLabButton>())
			{
				awd.ButtonActivation();
			}
		}
	}
}