﻿using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Prism.Patches;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;

namespace Prism.Mods
{
	internal class MiscMods : MonoBehaviour
	{
		internal static bool usingSlingshotSelf;

        public static string NormalizeColor(float color)
		{
            color = System.Math.Max(0f, System.Math.Min(1f, color));
            int normalizedValue = (int)System.Math.Round(color * 9f);
            return normalizedValue.ToString();
        }

		internal static void StaticFinger()
		{
			
			ControllerInputPoller.instance.leftControllerGripFloat = 0f;
			ControllerInputPoller.instance.rightControllerGripFloat = 0f;
			ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
			ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
			ControllerInputPoller.instance.leftControllerPrimaryButton = false;
			ControllerInputPoller.instance.leftControllerSecondaryButton = false;
			ControllerInputPoller.instance.rightControllerPrimaryButton = false;
			ControllerInputPoller.instance.rightControllerSecondaryButton = false;
		}

		internal static void SetNameNothing()
		{
            if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaComputer.instance.friendJoinCollider.thisCapsule.transform.position;
                PhotonNetwork.LocalPlayer.NickName = "----------ㅤ-----------";
            }
            else
            {
                PhotonNetwork.LocalPlayer.NickName = "----------ㅤ-----------";
            }
            GorillaTagger.Instance.offlineVRRig.enabled = true;
		}

		internal static void HideOnLeaderboard()
		{
            Color sheges = new Color32(1, 52, 2, 255);
			if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position = GorillaComputer.instance.friendJoinCollider.thisCapsule.transform.position;
				if (GorillaTagger.Instance.offlineVRRig.transform.position == GorillaComputer.instance.friendJoinCollider.thisCapsule.transform.position)
				{
					GorillaTagger.Instance.offlineVRRig.InitializeNoobMaterialLocal(sheges.r, sheges.g, sheges.b);
					GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
					{
					sheges.r,
					sheges.g,
					sheges.b
					});
				}
				PhotonNetwork.LocalPlayer.NickName = "----------ㅤ-----------";
			}
			else if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
			{
				GorillaTagger.Instance.offlineVRRig.InitializeNoobMaterialLocal(sheges.r, sheges.g, sheges.b);
				GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
				{
					sheges.r,
					sheges.g,
					sheges.b
				});
				PhotonNetwork.LocalPlayer.NickName = "----------ㅤ-----------";
			}
            MenuHandler.FindButton("Hide On Leaderboard").isToggled = false;
            GorillaTagger.Instance.offlineVRRig.enabled = true;
		}

		internal static void ColorLogger()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (data.lockedPlayer && data.isTriggered)
			{
				Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
				string text = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(owner).playerColor.r);
				string text2 = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(owner).playerColor.g);
				string text3 = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(owner).playerColor.b);
				NotifiLib.SendWithCooldown($"[<color=cyan>{owner.NickName}</color>'s] Color Code R: [<color=red>{text}</color>] G: [<color=green>{text2}</color>] B: [<color=blue>{text3}</color>]");
			}
		}

		internal static void HoldRocket()
		{
			if (ControllerInputPoller.instance.rightGrab)
			{
				GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").transform.Rotate(0f, 14f, 0f);
				GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").transform.localScale = new Vector3(0.02f, 0.01f, 0.02f);
				GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").transform.localPosition = new Vector3(0f, -0.0075f, 0f) + GorillaTagger.Instance.rightHandTransform.position;
			}
			else
			{
				GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").transform.Rotate(0f, 0f, 0f);//this is prob best hold rocket in comm
				GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").transform.localScale = new Vector3(1f, 1f, 1f);
				GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").transform.position = new Vector3(-10.79f, 9.73f, -134.07f);
			}
		}

		internal static void Panic()
		{
            var buttonHandler = MenuHandler.FindButton("AntiReport: [Leave]")
			?? MenuHandler.FindButton("AntiReport: [Stutter]")
			?? MenuHandler.FindButton("AntiReport: [Hop]")
			?? MenuHandler.FindButton("AntiReport: [Rejoin]");
            foreach (ButtonHandler dwa in ModHandler.buttons)
			{
				if (dwa.isToggled)
				{
					dwa.isToggled = false;
					buttonHandler.isToggled = true;
				}
				MenuHandler.RedrawMenu();
				ArrayList.RefreshModsList();
			}
		}

		internal static void LeaderBoardSpoof()
		{
            string[] Names = new string[16]
			{
                    "LEOVR",
                    "CRAYONVR",
                    "DRAGONVR",
                    "POOKIE",
                    "LILLY",
                    "OMAR",
                    "COWBOYVR",
                    "LEMONVR",
                    "JACK",
                    "POPTART",
                    "TOP10WALLS",
                    "JUICEBOX",
					"K9",
					"JUAN",
					"JMANCURLY",
					"ELLIOT"
			};
            if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position = GorillaComputer.instance.friendJoinCollider.thisCapsule.transform.position;
				PhotonNetwork.LocalPlayer.NickName = Names[Random.Range(0,16)];
			}
			else
			{
				PhotonNetwork.LocalPlayer.NickName = Names[Random.Range(0, 16)];
			}
			GorillaTagger.Instance.offlineVRRig.enabled = true;
		}

		internal static void SlingshotSelf()
		{
			GorillaTagger.Instance.offlineVRRig.reliableState.activeTransferrableObjectIndex[0] = 212;
            if (GorillaTagger.Instance.offlineVRRig.slingshot == null)
			{
                GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Slingshot Chest Snap/DropZoneAnchor/Slingshot").SetActive(true);
            }
			else
			{
				GorillaTagger.Instance.offlineVRRig.slingshot.gameObject.SetActive(true);
            }
        }

        internal static void Unslingshot()
        {
            GorillaTagger.Instance.offlineVRRig.reliableState.SetIsDirty();
            if (GorillaTagger.Instance.offlineVRRig.slingshot == null)
            {
                GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Slingshot Chest Snap/DropZoneAnchor/Slingshot").SetActive(false);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.slingshot.gameObject.SetActive(false);
            }
            GorillaTagger.Instance.offlineVRRig.reliableState.SetIsNotDirty();
        }
    }
}