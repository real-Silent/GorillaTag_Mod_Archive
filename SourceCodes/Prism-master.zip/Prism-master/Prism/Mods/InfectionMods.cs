﻿using GorillaExtensions;
using GorillaGameModes;
using GorillaTag;
using Photon.Pun;
using Prism.Patches;
using Prism.Utility;
using Prism.WristMenu;
using System.Linq;
using UnityEngine;
using Player = Photon.Realtime.Player;

namespace Prism.Mods
{
    internal class InfectionMods : MonoBehaviour
    {
        internal static GameObject circlethigm;

        private static float ijhr;

        private static float smth = 0f;
        private static Vector3 targetPosition;
        private static Quaternion targetRotation;

        internal static void TagPlayer(Photon.Realtime.Player tagHim)
        {
            if (PhotonNetwork.InRoom)
            {
                VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(tagHim);
                if (RoomManager.tagManager)
                {
                    if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        if (!RoomManager.tagManager.currentInfected.Contains(tagHim) || (RoomManager.tagManager.currentIt != tagHim && PhotonNetwork.PlayerList.Count() < 4))
                        {
                            if (!PrismUtils.AmTagged() || (RoomManager.tagManager.currentIt != tagHim && PhotonNetwork.PlayerList.Count() < 4))
                            {
                                TagSelf();
                                return;
                            }

                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            var button = MenuHandler.FindButton("Tag Type: [Behind]")
                            ?? MenuHandler.FindButton("Tag Type: [Orbit]")
                            ?? MenuHandler.FindButton("Tag Type: [Spaz]");

                            if (button.settingIndex == 1)
                            {
                                GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - vrrig.transform.forward;
                                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = vrrig.transform.position;
                                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = vrrig.transform.position;
                                GorillaTagger.Instance.offlineVRRig.transform.LookAt(vrrig.transform.position);
                            }
                            else if (button.settingIndex == 2)
                            {
                                float num = 4f;
                                float num2 = Time.time * num;
                                float num3 = 20f;
                                Vector3 vector = vrrig.transform.position + new Vector3(0f, 0.8f, 0f);
                                Vector3 vector2 = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * num3;
                                Vector3 vector3 = vector + vector2 * Time.deltaTime * 5f;
                                GorillaTagger.Instance.offlineVRRig.transform.position = (vector3);
                                targetPosition = vrrig.transform.position + vrrig.transform.forward.x0z();
                                GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.RotateTowards(GorillaTagger.Instance.offlineVRRig.transform.rotation, targetRotation, 720f * Time.deltaTime);
                                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + -GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
                                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
                            }
                            else if (button.settingIndex == 3)
                            {
                                float num = 1f;
                                float num2 = 2f;
                                Vector3 vector = UnityEngine.Random.insideUnitSphere.normalized * UnityEngine.Random.Range(num, num2);
                                Vector3 vector2 = vrrig.transform.position + vector;
                                Vector3 vector3 = vrrig.transform.position - vector2;
                                GorillaTagger.Instance.offlineVRRig.transform.position = vector2;
                            }

                            if (Time.time > ijhr + 0.06f)
                            {
                                GameMode.ReportTag(tagHim);
                                ijhr = Time.time;
                            }
                        }
                        else
                        {
                            UI.taggingPlayer = null;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            return;
                        }
                    }
                    else
                    {
                        if (!RoomManager.tagManager.currentInfected.Contains(PhotonNetwork.LocalPlayer))
                        {
                            RoomManager.tagManager.AddInfectedPlayer(PhotonNetwork.LocalPlayer);
                        }
                        RoomManager.tagManager.AddInfectedPlayer(tagHim);
                    }
                }
                else if (RoomManager.battleManager)
                {
                    if (RoomManager.battleManager.playerLives[tagHim.ActorNumber] != 0)
                    {
                        if (!PhotonNetwork.IsMasterClient && !RoomManager.battleManager.OnSameTeam(tagHim, PhotonNetwork.LocalPlayer))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - new Vector3(0, 2, 0);
                            GameObject.Find("GameMode(Clone)").GetPhotonView().RPC("ReportSlingshotHit", RpcTarget.All, new object[] { tagHim, GorillaGameManager.instance.FindPlayerVRRig(tagHim).transform.position, 1 });
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                        else
                        {
                            RoomManager.battleManager.playerLives[tagHim.ActorNumber] = 0;
                        }
                    }
                    else
                    {
                        UI.taggingPlayer = null;
                    }
                }
                else if (RoomManager.huntManager)
                {
                    Player huntTaggingPlayer = RoomManager.huntManager.GetTargetOf(PhotonNetwork.LocalPlayer);
                    if (RoomManager.huntManager.LocalCanTag(PhotonNetwork.LocalPlayer, huntTaggingPlayer))
                    {
                        if (!PhotonNetwork.IsMasterClient)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - new Vector3(0.2f, 0, 0);
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.position = vrrig.transform.position;
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.position = vrrig.leftHandTransform.transform.position;
                            if (Time.time > ijhr + 0.06f)
                            {
                                GameMode.ReportTag(huntTaggingPlayer);
                                ijhr = Time.time;
                            }
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                        else if (!RoomManager.huntManager.currentHunted.Contains(tagHim))
                        {
                            RoomManager.huntManager.currentHunted.Add(tagHim);
                        }
                    }
                    else
                    {
                        UI.taggingPlayer = null;
                    }
                }
                
            }
        }

        internal static void TagSelf()
        {
            if (!PhotonNetwork.InRoom) { return; }

            if (PhotonNetwork.InRoom && PrismUtils.AmTagged())
            {
                NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU'RE ALREADY TAGGED</color>");
                MenuHandler.FindButton("Tag Self").isToggled = false;
                MenuHandler.RedrawMenu();
                return;
            }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                if (!PrismUtils.AmTagged() && !PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    VRRig vrrig = PrismUtils.GetTaggedWithLeastVelocity();
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position + new Vector3(0, 0, 0.3f);
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = vrrig.transform.position;
                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = vrrig.transform.position;
                    GorillaTagger.Instance.offlineVRRig.transform.LookAt(vrrig.transform.position);
                    return;
                }
                else if (!PrismUtils.AmTagged() && PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    RoomManager.tagManager.AddInfectedPlayer(PhotonNetwork.LocalPlayer);
                }
                else
                {
                    if (MenuHandler.FindButton("Tag Self").isToggled)
                    {
                        MenuHandler.FindButton("Tag Self").isToggled = false;
                    }
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                    MenuHandler.RedrawMenu();
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>YOU'RE TAGGED!</color>");
                }
            }
        }

        internal static void TagGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (!PhotonNetwork.InRoom) { return; }
            if (data.lockedPlayer && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
            {
                Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
                TagPlayer(owner);
            }
        }

        internal static void TagAura(bool construscter)
        {
            if (!PhotonNetwork.InRoom) { return; }

            if (construscter)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (circlethigm == null)
                    {
                        circlethigm = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        UnityEngine.Object.Destroy(circlethigm.GetComponent<Rigidbody>());
                        UnityEngine.Object.Destroy(circlethigm.GetComponent<BoxCollider>());
                        UnityEngine.Object.Destroy(circlethigm.GetComponent<SphereCollider>());
                        circlethigm.transform.localScale = new Vector3(6f, 0.5f, 6f);
                        circlethigm.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    }
                    circlethigm.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.9f, 0f);
                    if (!vrrig.mainSkin.material.name.Contains("fected") && vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(GorillaTagger.Instance.offlineVRRig.transform.position, vrrig.transform.position) < 6 && PrismUtils.AmTagged())
                        {
                            circlethigm.GetComponent<Renderer>().material.color = Variables.red;
                            if (Settings.TagAura_Bind())
                            {
                                Player player = PrismUtils.GrabPhotonView(vrrig).Owner;
                                GameMode.ReportTag(player);
                            }
                        }
                        else
                        {
                            circlethigm.GetComponent<Renderer>().material.color = new Color(1, 1, 1, 0.1f);
                        }
                    }
                }
            }
            else
            {
                if (circlethigm)
                {
                    circlethigm.transform.position = Vector3.zero;
                    Object.Destroy(circlethigm);
                    circlethigm = null;
                }
            }
        }

        internal static void TagAll()
        {
            if (!PhotonNetwork.InRoom) { return; }

            if ((RoomManager.tagManager && RoomManager.tagManager.currentInfected.Count != PhotonNetwork.PlayerList.Count()))
            {
                foreach (Player player in PhotonNetwork.PlayerListOthers)
                {
                    if (RoomManager.tagManager)
                    {
                        TagPlayer(PrismUtils.GetUnTaggedClosestToVector(GorillaTagger.Instance.offlineVRRig.transform.position).Creator);
                    }
                }
            }
            else if (RoomManager.battleManager)
            {
                foreach (VRRig w in GorillaParent.instance.vrrigs)
                {
                    if (!RoomManager.battleManager.PlayerInHitCooldown(w.Creator))
                    {
                        TagPlayer(w.Creator);
                    }
                }
            }
            else if (RoomManager.huntManager)
            {
                foreach (VRRig w in GorillaParent.instance.vrrigs)
                {
                    TagPlayer(w.Creator);
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                MenuHandler.FindButton("Tag All").isToggled = false;
                MenuHandler.RedrawMenu();
                NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>ALL PLAYERS HAVE BEEN TAGGED?</color>");
            }
        }

        internal static void NoTagOnJoin()
        {
            if (GTAppState.isQuitting)
            {
                if (PlayerPrefs.GetString("didTutorial", "nope") == "nope")
                {
                    PlayerPrefs.SetString("didTutorial", "done");
                    PlayerPrefs.Save();
                }
            }
            if (!PhotonNetwork.InRoom)
            {
                if (PlayerPrefs.GetString("didTutorial", "nope") == "done")
                {
                    PlayerPrefs.SetString("didTutorial", "nope");
                    PlayerPrefs.Save();
                }
            }
            else if (PhotonNetwork.InRoom)
            {
                if (PlayerPrefs.GetString("didTutorial", "nope") == "nope")
                {
                    PlayerPrefs.SetString("didTutorial", "done");
                    PlayerPrefs.Save();
                }
                else if (PlayerPrefs.GetString("didTutorial", "nope") == "done")
                {
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU'RE ALREADY IN A ROOM!</color>");
                    MenuHandler.FindButton("No Tag On Join").isToggled = false;
                    return;
                }
                MenuHandler.FindButton("No Tag On Join").isToggled = false;
                MenuHandler.RedrawMenu();
            }
        }

        internal static void AntiTag()
        {
            if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        if (vrrig.mainSkin.material.name.Contains("fected") && vrrig != GorillaTagger.Instance.offlineVRRig && vrrig != null)
                        {
                            if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) < 4f)
                            {
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, -999f, 0f);
                            }
                            else if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) > 5f)
                            {
                                GorillaTagger.Instance.offlineVRRig.enabled = true;
                            }
                        }
                    }
                    else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        if (RoomManager.tagManager.currentInfected.Contains(PhotonNetwork.LocalPlayer))
                        {
                            RoomManager.tagManager.currentInfected.Remove(PhotonNetwork.LocalPlayer);
                        }
                        return;
                    }
                }
            }
        }
    }
}