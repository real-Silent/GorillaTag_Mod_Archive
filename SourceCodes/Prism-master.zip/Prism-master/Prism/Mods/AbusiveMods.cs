﻿using Photon.Pun;
using Prism.Utility;
using UnityEngine;
using GorillaNetworking;
using Photon.Realtime;
using System.Linq;
using ExitGames.Client.Photon;
using Prism.Patches;

namespace Prism.Mods
{
    internal class AbusiveMods : MonoBehaviour
    {
        private static float i3gs;
        static string odCode;
        internal static bool antiNotifLibRepeat = false;
        internal static bool antiNotifLibRepeat2 = false;
        private static float gjs;
        internal static bool isKicking = false;

        public static void StutterView(PhotonView photonView)
        {
            if (photonView != GorillaTagger.Instance.myVRRig && photonView != null && !photonView.IsMine)
            {
                photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)204, new Hashtable
                            {
                                { 0, photonView.ViewID }
                            }, new RaiseEventOptions
                            {
                                TargetActors = new int[]
                 {
                                    photonView.Owner.ActorNumber
                 }
                            }, SendOptions.SendUnreliable);
            }
        }

        internal static void MuteView(PhotonView photonView, float timer)
        {
            if (photonView != GorillaTagger.Instance.myVRRig && photonView != null && !photonView.IsMine)
            {
                photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                if (Time.time > gjs + timer)
                {
                    PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)204, new Hashtable
                            {
                                { 0, photonView.ViewID }
                            }, new RaiseEventOptions
                            {
                                TargetActors = new int[]
                                {
                                    photonView.Owner.ActorNumber
                                }
                            }, SendOptions.SendUnreliable);
                    photonView.ViewID = 0;
                    gjs = Time.time;
                }
            }
        }

        internal static void StutterGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (!PhotonNetwork.InRoom) { return; }

            if (data.lockedPlayer != null && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
            {
                PhotonView photonView = PrismUtils.GrabPhotonView(data.lockedPlayer);
                StutterView(photonView);
            }
        }

        internal static void StutterAll()
        {
            if (!PhotonNetwork.InRoom) { return; }

            VRRig vrrig = GorillaParent.instance.vrrigs[UnityEngine.Random.Range(1, GorillaParent.instance.vrrigDict.Count)];
            if (vrrig != null && vrrig != GorillaTagger.Instance.offlineVRRig)
            {
                var photonView = PrismUtils.GrabPhotonView(vrrig);
                StutterView(photonView);
            }
        }

        internal static void TouchToStutter()
        {
            if (!PhotonNetwork.InRoom) { return; }

            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != null && vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    if (Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position) <= 0.35f || Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position) <= 0.35f)
                    {
                        PhotonView photonView = PrismUtils.GrabPhotonView(vrrig);
                        StutterView(photonView);
                    }
                }
            }
        }

        internal static void BecomeTheStutter()
        {
            if (!PhotonNetwork.InRoom) { return; }

            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != null && vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    if (Vector3.Distance(vrrig.leftHandPlayer.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position) <= 0.35f || Vector3.Distance(vrrig.rightHandPlayer.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position) <= 0.35f)
                    {
                        PhotonView photonView = PrismUtils.GrabPhotonView(vrrig);
                        StutterView(photonView);
                    }
                }
            }
        }

        internal static void KickGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (data.lockedPlayer != null && data.lockedPlayer.Creator != null && data.isTriggered && PhotonNetwork.InRoom)
            {
                Debug.unityLogger.logEnabled = false;
                if (!isKicking)
                {
                    antiNotifLibRepeat2 = true;
                }
                antiNotifLibRepeat = true;
                PhotonView view = GameObject.Find("WorldShareableCosmetic").GetComponent<WorldShareableItem>().guard.photonView;
                if (PhotonNetwork.CurrentRoom.Name != " " || PhotonNetwork.CurrentRoom.Name != string.Empty || PhotonNetwork.CurrentRoom.Name != null || PhotonNetwork.CurrentRoom.Name != "" || PhotonNetwork.CurrentRoom.Name != "Null")
                {
                    odCode = PhotonNetwork.CurrentRoom.Name;
                }

                if (PhotonNetwork.PlayerList.Contains(data.lockedPlayer.Creator))
                {
                    for (int i = 0; i < 200; i++)
                    {
                        view.RPC("OwnershipRequested", data.lockedPlayer.Creator, new object[] { "prism solutions on top" });
                    }
                    if (antiNotifLibRepeat2)
                    {
                        NotifiLib.SendNotification($"[<color=cyan>PRISM</color>]: <color=green>KICKING {data.lockedPlayer.Creator.NickName}..</color>");
                        isKicking = true;
                        antiNotifLibRepeat2 = false;
                    }
                    PhotonNetwork.SendAllOutgoingCommands();
                    PhotonNetwork.NetworkingClient.LoadBalancingPeer.SendOutgoingCommands();
                }
            }
            else if (!PhotonNetwork.InRoom && (odCode != " " || odCode != string.Empty || odCode != null || odCode != "" || odCode != "Null"))
            {
                if (antiNotifLibRepeat)
                {
                    Debug.unityLogger.logEnabled = true;
                    PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(odCode, JoinType.Solo);
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU HAVE BEEN DISCONNECTED FOR SAFETY REASONS!</color>");
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>DONT WORRY THEY GOT KICKED (HOPEFULLY)</color>");
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>RECONNECTING...</color>");
                    antiNotifLibRepeat = false;
                    isKicking = false;
                }
                if (!PhotonNetwork.IsConnected)
                {
                    PhotonNetwork.ConnectUsingSettings();
                }
                if (PhotonNetwork.IsConnected)
                {

                    PhotonNetwork.JoinRoom(odCode, null);
                }
            }
        }

        internal static void TouchToKick()
        {
            if (PhotonNetwork.InRoom)
            {
                Debug.unityLogger.logEnabled = false;
                if (!isKicking)
                {
                    antiNotifLibRepeat2 = true;
                }
                antiNotifLibRepeat = true;
                PhotonView view = GameObject.Find("WorldShareableCosmetic").GetComponent<WorldShareableItem>().guard.photonView;
                if (PhotonNetwork.CurrentRoom.Name != " " || PhotonNetwork.CurrentRoom.Name != string.Empty || PhotonNetwork.CurrentRoom.Name != null || PhotonNetwork.CurrentRoom.Name != "" || PhotonNetwork.CurrentRoom.Name != "Null")
                {
                    odCode = PhotonNetwork.CurrentRoom.Name;
                }

                foreach (VRRig data in GorillaParent.instance.vrrigs)
                {
                    if (Vector3.Distance(data.transform.position, GorillaTagger.Instance.leftHandTransform.position) < 0.35f || Vector3.Distance(data.transform.position, GorillaTagger.Instance.rightHandTransform.position) < 0.35f)
                    {
                        if (PhotonNetwork.PlayerList.Contains(data.Creator))
                        {
                            for (int i = 0; i < 100; i++)
                            {
                                view.RPC("OwnershipRequested", data.Creator, new object[] { "prism solutions on top" });
                            }
                            if (antiNotifLibRepeat2)
                            {
                                NotifiLib.SendNotification($"[<color=cyan>PRISM</color>]: <color=green>KICKING [{data.Creator.NickName}]..</color>");
                                isKicking = true;
                                antiNotifLibRepeat2 = false;
                            }
                            PhotonNetwork.SendAllOutgoingCommands();
                            PhotonNetwork.NetworkingClient.LoadBalancingPeer.SendOutgoingCommands();
                        }
                    }
                }
            }
            else if (!PhotonNetwork.InRoom && (odCode != " " || odCode != string.Empty || odCode != null || odCode != "" || odCode != "Null"))
            {
                if (antiNotifLibRepeat)
                {
                    Debug.unityLogger.logEnabled = true;
                    PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(odCode, JoinType.Solo);
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU HAVE BEEN DISCONNECTED FOR SAFETY REASONS!</color>");
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>DONT WORRY THEY GOT KICKED (HOPEFULLY)</color>");
                    NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>RECONNECTING...</color>");
                    antiNotifLibRepeat = false;
                    isKicking = false;
                }
                if (!PhotonNetwork.IsConnected)
                {
                    PhotonNetwork.ConnectUsingSettings();
                }
                if (PhotonNetwork.IsConnected)
                {

                    PhotonNetwork.JoinRoom(odCode, null);
                }
            }
        }
    }
}