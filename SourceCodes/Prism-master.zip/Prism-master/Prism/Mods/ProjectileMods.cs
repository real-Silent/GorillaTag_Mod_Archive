﻿using System.Reflection;
using ExitGames.Client.Photon;
using GorillaExtensions;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;

namespace Prism.Mods
{
    internal class ProjectileMods : MonoBehaviour
    {
        internal static float velSpeed = 95;
        private static float a;
        public static int projType = 0;
        internal static Transform dummyProjectile;
        internal static bool usingMinigun;

        public static void LaunchProjectile(Vector3 vel, Vector3 pos, int type, bool isSlingshot, bool overridecolour, byte r = 255, byte g = 255, byte b = 255, bool seperate = false)
        {
        }
        public static Color32 GetProjectileColor()
        {
            Color32 color = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue);
            ButtonHandler buttonHandler;
            if ((buttonHandler = MenuHandler.FindButton("Proj Color: [White]")) == null && (buttonHandler = MenuHandler.FindButton("Proj Color: [Black]")) == null && (buttonHandler = MenuHandler.FindButton("Proj Color: [Red]")) == null && (buttonHandler = MenuHandler.FindButton("Proj Color: [Green]")) == null && (buttonHandler = MenuHandler.FindButton("Proj Color: [Blue]")) == null && (buttonHandler = MenuHandler.FindButton("Proj Color: [Purple]")) == null)
            {
                buttonHandler = MenuHandler.FindButton("Proj Color: [Random]") ?? MenuHandler.FindButton("Proj Color: [RGB]");
            }
            ButtonHandler buttonHandler2 = buttonHandler;
            if (buttonHandler2.settingIndex != 6f && buttonHandler2.settingIndex != 7f && buttonHandler2.settingIndex != 8f)
            {
                color = Settings.currentProjectileColor;
            }
            else if (buttonHandler2.settingIndex == 6f)
            {
                color = ThemeManager.gPurp;
            }
            else if (buttonHandler2.settingIndex == 7f)
            {
                color = new Color32((byte)Random.Range(0, 255), (byte)Random.Range(0, 255), (byte)Random.Range(0, 255), 255);
            }
            else if (buttonHandler2.settingIndex == 8f)
            {
                color = Variables.timeRainbow(0.3f);
            }
            return color;
        }
        private static void AttachTrail(int trailHash, GameObject newProjectile, Vector3 location, bool blueTeam, bool orangeTeam)
        {
        }
        public static int GetTrail()
        {
            return -1;
        }
        public static Vector3 OrbitManager(Vector3 pos, float speed, float radius)
        {
            float orbitSpeed = speed;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = radius;
            Vector3 POS = pos + new Vector3(0f, 3f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            return vector;
        }
        //==============================LIBS===========================================================

        public static void ProjectileSpam()
        {
        }

        public static void ProjectileGun()
        {
            var data = GunLib.ShootBending();

            if (data == null) { return; }

            if (data.isShooting && data.isTriggered)
            {
                Vector3 vector = (data.hitPosition - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                float d = velSpeed;
                vector *= d;
                Color32 projectileColor = GetProjectileColor();
                byte r = projectileColor.r;
                byte g = projectileColor.g;
                byte b = projectileColor.b;

                LaunchProjectile(vector, GorillaLocomotion.Player.Instance.rightHandFollower.transform.position, projType, false, true, r, g, b);
            }
        }

        public static void ProjectileAura()
        {
            float num = 1f;
            float num2 = 2f;
            Vector3 vector = Random.insideUnitSphere.normalized * Random.Range(num, num2);
            Vector3 vector2 = GorillaTagger.Instance.offlineVRRig.transform.position + vector;
            Color32 projectileColor = GetProjectileColor();
            byte r = projectileColor.r;
            byte g = projectileColor.g;
            byte b = projectileColor.b;
            if (InputHandler.RightTrig)
            {
                LaunchProjectile(new Vector3(0f, 0.35f, 0f), vector2, projType, false, true, r, g, b);
            }
        }

        public static void ProjectileOrbit()
        {
            var orbitVel = OrbitManager(GorillaTagger.Instance.offlineVRRig.transform.position, 4.5f, 12f);
            Color32 projectileColor = GetProjectileColor();
            byte r = projectileColor.r;
            byte g = projectileColor.g;
            byte b = projectileColor.b;
            if (InputHandler.RightTrig)
            {
                LaunchProjectile(new Vector3(0f, 3.5f, 0f), orbitVel, projType, false, true, r, g, b);
            }
        }

        public static void GiveProjectileGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (data.lockedPlayer && PrismUtils.GrabPhotonView(data.lockedPlayer).Owner != null && data.isTriggered)
            {
                Color32 projectileColor = GetProjectileColor();
                byte r = projectileColor.r;
                byte g = projectileColor.g;
                byte b = projectileColor.b;

                if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, data.lockedPlayer.transform.position) < 4)
                {
                    LaunchProjectile(data.lockedPlayer.rightHandTransform.up * velSpeed, data.lockedPlayer.rightHandTransform.position, projType, false, true, r, g, b);
                }
                else if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, data.lockedPlayer.transform.position) > 4)
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = data.lockedPlayer.transform.position + new Vector3(0f, -2f, 0f);
                    LaunchProjectile(data.lockedPlayer.rightHandTransform.up * velSpeed, data.lockedPlayer.rightHandTransform.position, projType, false, true, r, g, b);
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void GiveProjectileAuraGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (data.lockedPlayer && PrismUtils.GrabPhotonView(data.lockedPlayer).Owner != null && data.isTriggered)
            {
                float num = 1f;
                float num2 = 2f;
                Vector3 vector = UnityEngine.Random.insideUnitSphere.normalized * UnityEngine.Random.Range(num, num2);
                Vector3 vector2 = data.lockedPlayer.transform.position + vector;
                Color32 projectileColor = GetProjectileColor();
                byte r = projectileColor.r;
                byte g = projectileColor.g;
                byte b = projectileColor.b;

                if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, data.lockedPlayer.transform.position) < 4)
                {
                    LaunchProjectile(new Vector3(0f, 0.28f, 0f), vector2, projType, false, true, r, g, b);
                }
                else if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, data.lockedPlayer.transform.position) > 4)
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = data.lockedPlayer.transform.position + new Vector3(0f, -2f, 0f);
                    LaunchProjectile(new Vector3(0f, 0.28f, 0f), vector2, projType, false, true, r, g, b);
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void GiveProjectileOrbitGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (data.lockedPlayer && PrismUtils.GrabPhotonView(data.lockedPlayer).Owner != null && data.isTriggered)
            {
                var orbitVel = OrbitManager(data.lockedPlayer.transform.position, 4.5f, 12f);
                Color32 projectileColor = GetProjectileColor();
                byte r = projectileColor.r;
                byte g = projectileColor.g;
                byte b = projectileColor.b;

                if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, data.lockedPlayer.transform.position) < 4)
                {
                    LaunchProjectile(new Vector3(0f, 0.28f, 0f), orbitVel, projType, false, true, r, g, b);
                }
                else if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, data.lockedPlayer.transform.position) > 4)
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position = data.lockedPlayer.transform.position - data.lockedPlayer.transform.forward + new Vector3(0f, 2f, 0f);
                    LaunchProjectile(new Vector3(0f, 0.28f, 0f), orbitVel, projType, false, true, r, g, b);
                }
            }
        }

        public static void Spout()
        {
            if (InputHandler.RightTrig)
            {
                Color32 projectileColor = GetProjectileColor();
                byte r = projectileColor.r;
                byte g = projectileColor.g;
                byte b = projectileColor.b;
                LaunchProjectile(new Vector3(Random.Range(-25, 25), Random.Range(-25, 25), Random.Range(-25, 25)), GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f), projType, false, true, r, g, b);
            }
        }

        public static void Tunnel()
        {
            var orbitVel = OrbitManager(GorillaLocomotion.Player.Instance.transform.position, 5f, 15f);
            Color32 projectileColor = GetProjectileColor();
            byte r = projectileColor.r;
            byte g = projectileColor.g;
            byte b = projectileColor.b;
            if (InputHandler.RightTrig)
            {
                LaunchProjectile(new Vector3(0f, 40f, 0f), orbitVel, projType, false, true, r, g, b);
            }
        }

        public static void BodilyWaste(Vector3 Origin, byte red, byte green, byte blue)
        {
            if (InputHandler.RightTrig)
            {
                LaunchProjectile(GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * Time.deltaTime * 150f, Origin, projType, false, true, red, green, blue, true);
            }
        }

        public static void Shit()
        {
            if (InputHandler.RightTrig)
            {
                LaunchProjectile(Vector3.zero, GorillaTagger.Instance.offlineVRRig.transform.position, projType, false, true, 139, 69, 19, true);
            }
        }

        public static void SlingshotTP()
        {
        }

        public static void DisableSlingshotTP()
        {
        }
    }
}