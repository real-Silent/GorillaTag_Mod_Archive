﻿using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using Prism.Patches;
using Prism.Utility;
using UnityEngine;

namespace Prism.Mods
{
	internal class MasterMods : MonoBehaviour
	{
        private static float coolDown = -1f;
        private static float t;
        private static float matSpamCooldown = 0f;
        private static float balloonCooldown = 0f;
		private static float soundCooldown = 0f;

		//=======================MASTER HANDLERS=======================================================
        internal static void JoinedTaggedTime(ReceiverGroup group)
		{
			if (PhotonNetwork.IsMasterClient && Time.time > t)
			{
				object[] array = new object[] { 1 };
				byte b = 2;
				object obj = array;
				RaiseEventOptions raiseEventOptions = new RaiseEventOptions
				{
					CachingOption = EventCaching.DoNotCache,
					Receivers = ReceiverGroup.Others
				};
				SendEvent(b, obj, raiseEventOptions);
			}
		}

		internal static void SetTaggedTime(ReceiverGroup group)
		{
			if (PhotonNetwork.IsMasterClient && Time.time > t)
			{
				object[] array = new object[] { 0 };
				byte b = 2;
				object obj = array;
				RaiseEventOptions raiseEventOptions = new RaiseEventOptions
				{
					CachingOption = EventCaching.DoNotCache,
					Receivers = ReceiverGroup.Others
				};
				SendEvent(b, obj, raiseEventOptions);
			}
		}

		internal static void SetTaggedTime(Player group)
		{
			if (PhotonNetwork.IsMasterClient && Time.time > t)
			{
				RaiseEventOptions raiseEventOptions = new RaiseEventOptions
				{
					TargetActors = new int[] { group.ActorNumber }
				};
				object[] array = new object[] { 0 };
				byte b = 2;
				object obj = array;
				SendEvent(b, obj, raiseEventOptions);
			}
		}

		internal static void JoinedTaggedTime(Player group)
		{
			if (PhotonNetwork.IsMasterClient && Time.time > t)
			{
				RaiseEventOptions raiseEventOptions = new RaiseEventOptions
				{
					TargetActors = new int[] { group.ActorNumber }
				};
				object[] array = new object[] { 1 };
				byte b = 2;
				object obj = array;
				SendEvent(b, obj, raiseEventOptions);
			}
		}

		internal static void SendEvent(in byte code, in object evData, in RaiseEventOptions r)
		{
			object[] array = new object[]
			{
				PhotonNetwork.ServerTimestamp,
				code,
				evData
			};
			PhotonNetwork.NetworkingClient.OpRaiseEvent(3, array, r, SendOptions.SendReliable);
			float num = 0.3f;
			switch (code)
			{
			case 0:
				num = 0.1f;
				break;
			case 1:
				num = 0.1f;
				break;
			case 2:
				num = 1.9f;
				break;
			case 3:
				num = 0.4f;
				break;
			case 4:
				num = -1f;
				break;
			case 5:
				num = -1f;
				break;
			}
			t = Time.time + num;
		}


	

		internal static void SendSound(int id, float volume)
		{
			if (PhotonNetwork.IsMasterClient)
			{
				if (Time.time > soundCooldown + 0.4f)
				{
                    GorillaTagger.Instance.offlineVRRig.PlayTagSoundLocal(id, volume);
                    object[] array = new object[] { id, volume };
                    byte b = 3;
                    object obj = array;
                    RaiseEventOptions raiseEventOptions = new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.Others,
                        CachingOption = EventCaching.DoNotCache
                    };
                    SendEvent(b, obj, raiseEventOptions);
                    soundCooldown = Time.time;
				}
			}
		}

		internal static void MatHandler(Player asge)
		{
			GorillaTagManager component = GorillaGameManager.instance.GetComponent<GorillaTagManager>();
			if (PhotonNetwork.LocalPlayer.IsMasterClient)
			{
				if (Time.time > matSpamCooldown + 0.04)
				{
					if (!component.currentInfected.Contains(asge))
					{
						component.AddInfectedPlayer(asge);
					}
					else
					{
						if (component.currentInfected.Contains(asge))
						{
							component.currentInfected.Remove(asge);
						}
					}
					matSpamCooldown = Time.time;
				}
			}
			else
			{
				if (!PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>");
				}
			}
		}

		internal static void BattleHandler(Player ojfaw)
		{
			if (PhotonNetwork.LocalPlayer.IsMasterClient)
			{
				if (Time.time > balloonCooldown + 0.04)
				{
					RoomManager.battleManager.playerLives[ojfaw.ActorNumber] = UnityEngine.Random.Range(0, 3);
					balloonCooldown = Time.time;
				}
			}
			else
			{
				NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE NOT MASTERCLIETN!</color>");
			}
		}

		internal static void UntagHandler(Player gjei)
		{
			if (PhotonNetwork.LocalPlayer.IsMasterClient)
			{
				if (RoomManager.tagManager.currentInfected.Contains(gjei))
				{
					RoomManager.tagManager.currentInfected.Remove(gjei);
				}
			}
			else
			{
				NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
			}
		}

		
		//=============================INFECTION=========================================
		internal static void MatSpamAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                foreach (Player player in PhotonNetwork.PlayerList)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        if (Time.time > matSpamCooldown + 0.04)
                        {
                            foreach (Player player2 in PhotonNetwork.PlayerListOthers)
                            {
                                if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(player2))
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(player2);
                                }
                                else
                                {
                                    if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(player2))
                                    {
                                        GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(player2);
                                    }
                                }
                            }
                            matSpamCooldown = Time.time;
                        }
                    }
                    else
                    {
                        if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>");
                            break;
                        }
                    }
                }
            }
        }

		internal static void MatGun()
		{
			var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }

            if (data.isShooting && data.isTriggered)
            {
                Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
                MatHandler(owner);
            }

        }

		internal static void MatSpamSelf()
		{
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                MatHandler(PhotonNetwork.LocalPlayer);
            }
        }

		internal static void MatSpamOnTouch()
		{
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                foreach (Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.position, vrrig.transform.position) <= 0.35f || Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.position, vrrig.transform.position) <= 0.35f)
                    {
                        MatHandler(player);
						return;
                    }
                }
            }
        }

		internal static void TagCountThing(int nuaw)
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (PrismUtils.GetGamemode() == "INFECTION")
			{
				if (PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					RoomManager.tagManager.tagCoolDown = nuaw;
				}
				else
				{
					NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
				}
			}
		}

        internal static void UntagAll()
        {
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                foreach (Player player in PhotonNetwork.PlayerList)
                {
					if (PhotonNetwork.LocalPlayer.IsMasterClient)
					{
                        try
                        {
                            GorillaGameManager.instance.GetComponent<GorillaTagManager>().currentInfected.Remove(player);
                        }
                        catch
                        {
                            throw;
                        }
                    }
                }
            }
        }

        internal static void UntagGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }

            if (data.isShooting && data.isTriggered)
            {
                Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
                UntagHandler(owner);
            }
        }

        internal static void UntagSelf()
        {
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "INFECTION")
            {
                UntagHandler(PhotonNetwork.LocalPlayer);
            }
        }

        internal static void UntagThingy()
        {
			if (!PhotonNetwork.InRoom) { return; }


            if (PrismUtils.GetGamemode() == "BATTLE")
            {
                foreach (Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.position, vrrig.transform.position) <= 0.35f || Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.position, vrrig.transform.position) <= 0.35f)
                    {
                        GorillaGameManager.instance.GetComponent<GorillaTagManager>().currentInfected.Remove(player);
                    }
                }
            }
        }


        //==========================BATTLE======================================
        internal static void SpamBalloonsAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (PrismUtils.GetGamemode() == "BATTLE")
			{

				if (PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					if (Time.time > balloonCooldown + 0.04)
					{
						foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
						{
							GorillaGameManager.instance.GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] = UnityEngine.Random.Range(0, 3);
						}
						balloonCooldown = Time.time;
					}
				}
				else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
					return;
				}

			}
        }

		internal static void SpamBalloonsGun()
		{
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }

            if (data.isShooting && data.isTriggered)
            {
                Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
                BattleHandler(owner);
            }
        }

		internal static void SpamBalloonsSelf()
		{
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "BATTLE")
            {
                BattleHandler(PhotonNetwork.LocalPlayer);
            }
        }

		internal static void SpamBalloonsThing()
		{
			if (!PhotonNetwork.InRoom) { return; }

            if (PrismUtils.GetGamemode() == "BATTLE")
            {
                foreach (Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.position, vrrig.transform.position) <= 0.35f || Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.position, vrrig.transform.position) <= 0.35f)
                    {
                        BattleHandler(player);
                    }
                }
            }
        }

		internal static void GodModeAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (PrismUtils.GetGamemode() == "BATTLE")
			{
				foreach (Player player in PhotonNetwork.PlayerList)
				{
					if (!PhotonNetwork.LocalPlayer.IsMasterClient)
					{
						NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
					}
					RoomManager.battleManager.playerLives[player.ActorNumber] = 9999999;
				}
			}
		}

		internal static void GodModeGun()
		{
			if (PrismUtils.GetGamemode() == "BATTLE")
			{
                var data = GunLib.ShootLockedBending();

                if (data == null) { return; }

				if (!PhotonNetwork.InRoom) { return; }
                if (data.isShooting && data.isTriggered)
                {
                    Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
                    if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
                    }
                    RoomManager.battleManager.playerLives[owner.ActorNumber] = 999999;
                }
            }
		}

		internal static void KillAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (PrismUtils.GetGamemode() == "BATTLE")
			{
				foreach (Player player in PhotonNetwork.PlayerList)
				{
					if (!PhotonNetwork.LocalPlayer.IsMasterClient)
					{
						NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
						break;
					}
					RoomManager.battleManager.playerLives[player.ActorNumber] = 0;
				}
			}
		}

		internal static void KillGun()
		{
			if (PrismUtils.GetGamemode() == "BATTLE")
			{
				var data = GunLib.ShootLockedBending();

				if (data == null) { return; }

				if (!PhotonNetwork.InRoom) { return; }
				if (data.isShooting && data.isTriggered)
				{
					Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
					if (!PhotonNetwork.LocalPlayer.IsMasterClient)
					{
                        NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>YOU ARE <color=orange>NOT</color> MASTER</color>");
                    }
                    RoomManager.battleManager.playerLives[owner.ActorNumber] = 0;
                }
			}
		}


		//================OTHER===============================
		internal static void SlowAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (Time.time > coolDown + 0.5)
			{
				if (PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					SetTaggedTime(ReceiverGroup.Others);
				}
				coolDown = Time.time;
			}
		}

		internal static void SlowGun()
		{
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }
            if (data.isShooting && data.isTriggered)
            {
                if (Time.time > coolDown + 0.5 && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SetTaggedTime(PrismUtils.GrabPhotonView(data.lockedPlayer).Owner);
                    }
                    coolDown = Time.time;
                }
            }
        }

		internal static void VibrateAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (Time.time > coolDown + 0.5f)
			{
				if (PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					JoinedTaggedTime(ReceiverGroup.Others);
				}
				coolDown = Time.time;
			}
		}

		internal static void VibrateGun()
		{
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }
            if (data.isShooting && data.isTriggered)
            {
                if (Time.time > coolDown + 0.5 && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        JoinedTaggedTime(PrismUtils.GrabPhotonView(data.lockedPlayer).Owner);
                    }
                    coolDown = Time.time;
                }
            }
        }
	}
}
