﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using BepInEx;
using Photon.Pun;
using Prism.Patches;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;
using UnityEngine.XR;
using Valve.VR;
using UnityEngine.InputSystem;

namespace Prism.Mods
{
	internal class MovementMods : BaseClass
    {
        public static LineRenderer lineRenderer = null;
        public static bool disablegrapple = false;
        private static Vector3? grapplePoint = null;
		internal static float wwStrength = 7.8f;
        private static float tjge = 0f;
		private static System.Random sege = new System.Random();
		private static Material spiderMonkeMaterial;
		private static LineRenderer leftWeb;
		private static LineRenderer rightWeb;
		private static List<GameObject> leftWebSegments = new List<GameObject>();
		private static List<GameObject> rightWebSegments = new List<GameObject>();
		private static List<GameObject> webSegments = new List<GameObject>();
		private static Vector3 leftWebHitPos;
		private static Vector3 rightWebHitPos;
		internal static Vector3[] lastLeft = new Vector3[]
		{
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero
		};
		internal static Vector3[] lastRight = new Vector3[]
		{
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero,
			Vector3.zero
		};
        internal static Vector3[] localPositions = new Vector3[]
		{
                    new Vector3(0, 0.5f, 0),
                    new Vector3(0, -0.5f, 0),
                    new Vector3(0.5f, 0, 0),
                    new Vector3(-0.5f, 0, 0),
                    new Vector3(0, 0, 0.5f),
                    new Vector3(0, 0, -0.5f)
		};
		internal static Quaternion[] localRotations = new Quaternion[]
		{
					Quaternion.Euler(90, 0, 0),
					Quaternion.Euler(-90, 0, 0),
					Quaternion.Euler(0, -90, 0),
					Quaternion.Euler(0, 90, 0),
					Quaternion.identity,
					Quaternion.Euler(0, 180, 0)
		};
		public static GameObject projectileGameobject = null;
		internal static Vector3 previousMousePosition;

		public static void TeleportGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isShooting && data.isTriggered)
			{
				if (Variables.canTP)
				{
					Variables.canTP = false;
					TeleportLib.Teleport(data.hitPosition);
				}
			}
			else
			{
				Variables.canTP = true;
			}
		}

		public static void Platforms()
		{
            var buttonHandler = MenuHandler.FindButton("Plats: [Normal]")
			?? MenuHandler.FindButton("Plats: [Sticky]")
			?? MenuHandler.FindButton("Plats: [Invis]");
            var buttonHandler2 = MenuHandler.FindButton("Plat Input: [Grip]")
			?? MenuHandler.FindButton("Plat Input: [RT/LT]")
			?? MenuHandler.FindButton("Plat Input: [B/Y]");

            if (buttonHandler.settingIndex == 1)
			{
				switch (buttonHandler2.settingIndex)
				{
					case 1:
						HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightGrip, GorillaLocomotion.Player.Instance.rightControllerTransform, false, false, true);
						HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftGrip, GorillaLocomotion.Player.Instance.leftControllerTransform, false, false);
						break;
					case 2:
						HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightTrig, GorillaLocomotion.Player.Instance.rightControllerTransform, false, false, true);
						HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftTrig, GorillaLocomotion.Player.Instance.leftControllerTransform, false, false);
						break;
					case 3:
						HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightSec, GorillaLocomotion.Player.Instance.rightControllerTransform, false, false, true);
						HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftSec, GorillaLocomotion.Player.Instance.leftControllerTransform, false, false);
						break;
				}
			}
			else
			{
				if (buttonHandler.settingIndex == 2)
				{
					switch (buttonHandler2.settingIndex)
					{
						case 1:
							HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightGrip, GorillaLocomotion.Player.Instance.rightControllerTransform, true, false, true);
							HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftGrip, GorillaLocomotion.Player.Instance.leftControllerTransform, true, false);
							break;
						case 2:
							HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightTrig, GorillaLocomotion.Player.Instance.rightControllerTransform, true, false, true);
							HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftTrig, GorillaLocomotion.Player.Instance.leftControllerTransform, true, false);
							break;
						case 3:
							HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightSec, GorillaLocomotion.Player.Instance.rightControllerTransform, true, false, true);
							HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftSec, GorillaLocomotion.Player.Instance.leftControllerTransform, true, false);
							break;
					}
				}
				else
				{
					if (buttonHandler.settingIndex == 3)
					{
						switch (buttonHandler2.settingIndex)
						{
							case 1:
								HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightGrip, GorillaLocomotion.Player.Instance.rightControllerTransform, true, true, true);
								HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftGrip, GorillaLocomotion.Player.Instance.leftControllerTransform, true, true);
								break;
							case 2:
								HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightTrig, GorillaLocomotion.Player.Instance.rightControllerTransform, true, true, true);
								HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftTrig, GorillaLocomotion.Player.Instance.leftControllerTransform, true, true);
								break;
							case 3:
								HandlePlatform(ref Variables.localPlatformRight, InputHandler.RightSec, GorillaLocomotion.Player.Instance.rightControllerTransform, true, true, true);
								HandlePlatform(ref Variables.localPlatformLeft, InputHandler.LeftSec, GorillaLocomotion.Player.Instance.leftControllerTransform, true, true);
								break;
						}
					}
				}
			}
		}

		public static bool isPlatformsUntoggled = false;
		public static float unToggleCooldown = 0;

		public static void HandlePlatform(ref GameObject platform, bool isHoldingGrip, Transform controllerTransform, bool isPlatformsSticky, bool isInvis, bool isRight = false)
		{
			if (Time.time > unToggleCooldown + 2f)
			{
				if (InputHandler.RightStickClick)
				{
					isPlatformsUntoggled = !isPlatformsUntoggled;
					unToggleCooldown = Time.time;
                }
			}

            if (isHoldingGrip && !isPlatformsUntoggled)
			{
				if (platform == null)
				{
					platform = GameObject.CreatePrimitive(PrimitiveType.Cube);
					platform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f) * GorillaLocomotion.Player.Instance.scale;
                    // supposed collision fix
                    for (int i = 0; i < localPositions.Length; i++)
                    {
                        GameObject side = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        side.transform.SetParent(platform.transform);
                        side.transform.localPosition = localPositions[i];
                        side.transform.localRotation = localRotations[i];
                        side.transform.localScale = new Vector3(1f, 1f, 0.01f);
                        side.GetComponent<Renderer>().enabled = false;
                    }
                    platform.SetActive(false);
				}
				if (!platform.activeSelf)
				{
					Vector3 vector = (isPlatformsSticky ? Vector3.zero : new Vector3(0f, -0.04f, 0f));
					platform.transform.position = controllerTransform.position + vector;
					platform.transform.rotation = controllerTransform.rotation;
					Renderer component = platform.GetComponent<Renderer>();
					component.enabled = !isInvis;
					if (component.enabled)
					{
						component.material.shader = Shader.Find("GorillaTag/UberShader");
						component.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Background;
					}
				}
				platform.SetActive(true);
            }
			else
			{
				if (platform != null && platform.activeSelf)
				{
					platform.SetActive(false);
				}
			}
		}

		public static void AdvancedWASD(float speed)
		{
			GorillaTagger.Instance.rigidbody.useGravity = false;
			GorillaTagger.Instance.rigidbody.velocity = new Vector3(0f, 0f, 0f);
			float num = speed * Time.deltaTime;

			if (UnityInput.Current.GetKey(KeyCode.LeftShift) || UnityInput.Current.GetKey(KeyCode.RightShift))
			{
				num *= 10f;
			}

			if (UnityInput.Current.GetKey(KeyCode.LeftArrow) || UnityInput.Current.GetKey(KeyCode.A))
			{
				Camera.main.transform.position += Camera.main.transform.right * -1f * num;
			}

			if (UnityInput.Current.GetKey(KeyCode.RightArrow) || UnityInput.Current.GetKey(KeyCode.D))
			{
				Camera.main.transform.position += Camera.main.transform.right * num;
			}

			if (UnityInput.Current.GetKey(KeyCode.UpArrow) || UnityInput.Current.GetKey(KeyCode.W))
			{
				Camera.main.gameObject.transform.position += Camera.main.transform.forward * num;
			}

			if (UnityInput.Current.GetKey(KeyCode.DownArrow) || UnityInput.Current.GetKey(KeyCode.S))
			{
				Camera.main.transform.position += Camera.main.transform.forward * -1f * num;
			}

			if (UnityInput.Current.GetKey(KeyCode.Space) || UnityInput.Current.GetKey(KeyCode.PageUp))
			{
				Camera.main.transform.position += Camera.main.transform.up * num;
			}

			if (UnityInput.Current.GetKey(KeyCode.LeftControl) || UnityInput.Current.GetKey(KeyCode.PageDown))
			{
				Camera.main.transform.position += Camera.main.transform.up * -1f * num;
			}

			if (UnityInput.Current.GetMouseButton(1))
			{
				Vector3 vector = UnityInput.Current.mousePosition - previousMousePosition;
				float num2 = Camera.main.transform.localEulerAngles.y + vector.x * 0.3f;
				float num3 = Camera.main.transform.localEulerAngles.x - vector.y * 0.3f;
				Camera.main.transform.localEulerAngles = new Vector3(num3, num2, 0f);
			}

			previousMousePosition = UnityInput.Current.mousePosition;
		}

		public static void SpeedBoost(bool resetSpeed = false)
		{
			if (resetSpeed)
			{
				GorillaLocomotion.Player.Instance.maxJumpSpeed = 6.5f;
				GorillaLocomotion.Player.Instance.jumpMultiplier = 0f;
            }
			else
			{
                ButtonHandler buttonHandler = MenuHandler.FindButton("SpeedBoost: [Semi]")
 ?? MenuHandler.FindButton("SpeedBoost: [Comp]")
 ?? MenuHandler.FindButton("SpeedBoost: [Blatant]");
                switch (buttonHandler.settingIndex)
				{
					case 1:
                        GorillaLocomotion.Player.Instance.maxJumpSpeed = 8.4f;
                        GorillaLocomotion.Player.Instance.jumpMultiplier = 1.6f;
                        break;
					case 2:
                        GorillaLocomotion.Player.Instance.maxJumpSpeed = 7.2f;
                        GorillaLocomotion.Player.Instance.jumpMultiplier = 1.6f;
                        break;
					case 3:
                        GorillaLocomotion.Player.Instance.maxJumpSpeed = 9.5f;
                        GorillaLocomotion.Player.Instance.jumpMultiplier = 1.6f;
                        break;
				}
			}
		}

		public static void NoClip()
		{
			if (InputHandler.LeftTrig || !XRSettings.isDeviceActive)
			{
				if (!Variables.isnoclipped)
				{
					MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
					if (array != null)
					{
						foreach (MeshCollider meshCollider in array)
						{
							if (meshCollider.enabled)
							{
								meshCollider.enabled = false;
							}
						}
					}
					Variables.isnoclipped = true;
				}
			}
			else
			{
				if (Variables.isnoclipped)
				{
					MeshCollider[] array3 = Resources.FindObjectsOfTypeAll<MeshCollider>();
					if (array3 != null)
					{
						foreach (MeshCollider meshCollider2 in array3)
						{
							if (!meshCollider2.enabled)
							{
								meshCollider2.enabled = true;
							}
						}
					}
					Variables.isnoclipped = false;
				}
			}
		}

		public static void DisableNoClip()
		{
			MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
			if (array != null)
			{
				foreach (MeshCollider meshCollider in array)
				{
					if (!meshCollider.enabled)
					{
						meshCollider.enabled = true;
					}
				}
			}
		}

		static Vector3 handHandler = Vector3.zero;
        static Vector3 gravHandle = Vector3.zero;

		public static void WallWalk()
		{
            bool notRightGrab = ControllerInputPoller.instance.rightControllerGripFloat < 0.1f;
            bool notLeftGrab = ControllerInputPoller.instance.leftControllerGripFloat < 0.1f;
            bool rightGrab = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f;
            bool leftGrab = ControllerInputPoller.instance.leftControllerGripFloat > 0.1f;
            if (GorillaLocomotion.Player.Instance.wasLeftHandTouching || GorillaLocomotion.Player.Instance.wasRightHandTouching)
            {
                FieldInfo fieldInfo = typeof(GorillaLocomotion.Player).GetField("lastHitInfoHand", BindingFlags.NonPublic | BindingFlags.Instance);
                RaycastHit hit = (RaycastHit)fieldInfo.GetValue(GorillaLocomotion.Player.Instance);
                handHandler = hit.point;
                gravHandle = hit.normal;
            }
            if (notLeftGrab)
            {
                leftGrab = false;
                handHandler = Vector3.zero;
                GravityChanger("reset");
            }
            if (notRightGrab)
            {
                rightGrab = false;
                handHandler = Vector3.zero;
				GravityChanger("reset");
            }
            if (rightGrab)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(gravHandle * -wwStrength, ForceMode.Acceleration);
				GravityChanger("none");
            }
            if (leftGrab)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(gravHandle * -wwStrength, ForceMode.Acceleration);
				GravityChanger("none");
            }
        }

		public static void SpiderMonke()
		{
			HandleWebShooting(ref leftWeb, GorillaLocomotion.Player.Instance.leftControllerTransform, ref leftWebHitPos, "leftWeb", true);
			HandleWebShooting(ref rightWeb, GorillaLocomotion.Player.Instance.rightControllerTransform, ref rightWebHitPos, "rightWeb", false);
		}

		private static void HandleWebShooting(ref LineRenderer web, Transform controllerTransform, ref Vector3 webHitPos, string webName, bool isLeftHand)
		{
			if ((isLeftHand ? InputHandler.LeftTrig : InputHandler.RightTrig))
			{
				if (!web)
				{
					RaycastHit raycastHit;
					if (Physics.Raycast(controllerTransform.position, controllerTransform.forward, out raycastHit, float.PositiveInfinity, -9))
					{
						webHitPos = raycastHit.point;
						GameObject gameObject = new GameObject(webName);
						web = gameObject.AddComponent<LineRenderer>();
						if (spiderMonkeMaterial == null)
						{
							spiderMonkeMaterial = new Material(Shader.Find("Sprites/Default"));
						}
						web.material = spiderMonkeMaterial;
						web.endWidth = 0.01f;
						web.startWidth = 0.01f;
						web.positionCount = 2;
						GorillaTagger.Instance.StartVibration(isLeftHand, 1f, 0.0001f);
					}
				}
				if (web)
				{
					web.SetPositions(new Vector3[] { webHitPos, controllerTransform.position });
					SpringJoint springJoint = GorillaLocomotion.Player.Instance.GetComponent<SpringJoint>();
					if (springJoint == null)
					{
						springJoint = GorillaLocomotion.Player.Instance.gameObject.AddComponent<SpringJoint>();
						springJoint.connectedBody = null;
						springJoint.autoConfigureConnectedAnchor = false;
						springJoint.connectedAnchor = webHitPos;
					}
					springJoint.spring = 10f;
					springJoint.damper = 7f;
					springJoint.massScale = 4.5f;
					float num = Vector3.Distance(GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.position, webHitPos);
					springJoint.maxDistance = num * 0.9f;
					springJoint.minDistance = num * 0.1f;
					Vector3 normalized = (webHitPos - controllerTransform.position).normalized;
					GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(normalized * 10f, ForceMode.Impulse);
					GorillaTagger.Instance.StartVibration(isLeftHand, GorillaTagger.Instance.tapHapticStrength / 90f * GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.velocity.magnitude, GorillaTagger.Instance.tapHapticDuration);
				}
			}
			else
			{
				if (web)
				{
					UnityEngine.Object.Destroy(web.gameObject);
					web = null;
				}
				if (GorillaLocomotion.Player.Instance.GetComponent<SpringJoint>())
				{
					UnityEngine.Object.Destroy(GorillaLocomotion.Player.Instance.GetComponent<SpringJoint>());
				}
			}
		}

		public static void LeanBom(bool awd)
		{
			if (awd)
			{
				if (InputHandler.RightGrip && !InputHandler.RightTrig)
				{
					if (Variables.C4 == null)
					{
                        Variables.C4 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        UnityEngine.Object.Destroy(Variables.C4.GetComponent<Rigidbody>());
                        UnityEngine.Object.Destroy(Variables.C4.GetComponent<BoxCollider>());
                        Variables.C4.transform.localScale = new Vector3(0.2f, 0.1f, 0.2f);
                        Variables.C4.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        Variables.C4.GetComponent<Renderer>().material.color = Color.red;
                    }
                    Variables.C4.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position + new Vector3(0.2f, 0f, 0f);
                }
				if (!InputHandler.RightGrip && InputHandler.RightTrig && Variables.C4 != null)
				{
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(60000f, Variables.C4.transform.position, 10f, 5f);
                    UnityEngine.Object.Destroy(Variables.C4);
                }
			}
			else
			{
                UnityEngine.Object.Destroy(Variables.C4);
                Variables.C4 = null;
            }
		}

		public static void ProcessCheckPoint(bool on)
		{
			if (on)
			{
				if (InputHandler.RightGrip)
				{
					if (Variables.pointer == null)
					{
						Variables.pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
						UnityEngine.Object.Destroy(Variables.pointer.GetComponent<Rigidbody>());
						UnityEngine.Object.Destroy(Variables.pointer.GetComponent<SphereCollider>());
						UnityEngine.Object.Destroy(Variables.pointer.GetComponent<MeshCollider>());
						UnityEngine.Object.Destroy(Variables.pointer.GetComponent<Collider>());
						Variables.pointer.transform.localScale = new Vector3(0.35f, 0.35f, 0.35f);
						Variables.pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
						Variables.pointer.GetComponent<Renderer>().material.color = Color.red;
					}
					else
					{
						if (Variables.pointer != null)
						{
							Variables.pointer.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
						}
					}
				}
				if (!InputHandler.RightGrip && InputHandler.RightTrig && Variables.pointer != null)
				{
					Variables.pointer.GetComponent<Renderer>().material.color = Color.green;
					TeleportLib.Teleport(Variables.pointer.transform.position);
				}
				if (!InputHandler.RightTrig)
				{
					Variables.pointer.GetComponent<Renderer>().material.color = Color.red;
				}
			}
			else
			{
				UnityEngine.Object.Destroy(Variables.pointer);
				Variables.pointer = null;
			}
		}

		public static float previousTime = 0f;

        public static void FakeLag(bool enable)
        {
            if (enable)
            {
                if (Time.time - previousTime >= 0.35f)
                {
                    previousTime = Time.time;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;

                    if (Time.time - previousTime >= (PhotonNetwork.GetPing() / 500))
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        previousTime = Time.time;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void GrappleHook()
        {
            if (InputHandler.RightGrip && !InputHandler.RightTrig)
            {
                disablegrapple = false;

                if (lineRenderer == null)
                {
                    GameObject ob = new GameObject("line");
                    lineRenderer = ob.AddComponent<LineRenderer>();
                    lineRenderer.startColor = new Color(0, 0, 0, 1f);
                    lineRenderer.endColor = new Color(0, 0, 0, 1f);
                    lineRenderer.startWidth = 0.01f;
                    lineRenderer.endWidth = 0.01f;
                    lineRenderer.positionCount = 2;
                    lineRenderer.useWorldSpace = true;
                    lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
                }
            }

            if (InputHandler.RightGrip && InputHandler.RightTrig && !disablegrapple)
            {
                if (grapplePoint == null)
                {
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                        -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    grapplePoint = hit.point;
                }

                if (grapplePoint != null)
                {
                    Vector3 dir2 = (grapplePoint.Value - GorillaLocomotion.Player.Instance.bodyCollider.transform.position)
                        .normalized * 30;
                    GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(dir2, ForceMode.Acceleration);

                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.bodyCollider.transform.position, grapplePoint.Value) < 4)
                    {
                        disablegrapple = true;
                        UnityEngine.Object.Destroy(lineRenderer);
                        lineRenderer = null;
                        grapplePoint = null;
                        return;
                    }
                }
            }

            if (!InputHandler.RightGrip && !InputHandler.RightTrig)
            {
                if (lineRenderer != null)
                {
                    UnityEngine.Object.Destroy(lineRenderer);
                    lineRenderer = null;
                    grapplePoint = null;
                }
            }

            if (lineRenderer != null && grapplePoint != null)
            {
                lineRenderer.SetPosition(0, grapplePoint.Value);
                lineRenderer.SetPosition(1, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
            }
        }

        internal static void IronMonke()
		{
			if (InputHandler.LeftGrip)
			{
				GorillaTagger.Instance.StartVibration(true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
				GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(20f * GorillaLocomotion.Player.Instance.leftControllerTransform.right.x * -1f, 20f * GorillaLocomotion.Player.Instance.leftControllerTransform.right.y * -1f, 20f * GorillaLocomotion.Player.Instance.leftControllerTransform.right.z * -1f), ForceMode.Acceleration);
			}
			if (InputHandler.RightGrip)
			{
				GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
				GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(20f * GorillaLocomotion.Player.Instance.rightControllerTransform.right.x, 20f * GorillaLocomotion.Player.Instance.rightControllerTransform.right.y, 20f * GorillaLocomotion.Player.Instance.rightControllerTransform.right.z), ForceMode.Acceleration);
			}
		}

		internal static void Bees()
		{
			if (Time.time > tjge + 0.02f)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				int num = sege.Next(1, GorillaParent.instance.vrrigDict.Count - 1);
				GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(-94.1266f, 9999f, -132.3289f);
				GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(-94.1266f, 9999f, -132.3289f);
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 8f, 0f);
				GorillaTagger.Instance.offlineVRRig.transform.position = GorillaParent.instance.vrrigs[num].transform.position + new Vector3(0f, 0.8f, 0f);
				tjge = Time.time;
			}
		}

		internal static void UPNDOWN()
		{
			if (InputHandler.LeftTrig)
			{
				GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
				GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(1500f, GorillaLocomotion.Player.Instance.transform.position, 10f, 10f);
			}
			if (InputHandler.RightTrig)
			{
				GorillaTagger.Instance.StartVibration(true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
				GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(-1800f, GorillaLocomotion.Player.Instance.transform.position, 10f, 10f);
			}
		}

		internal static void TpRandom()
		{
			try
			{
				if (InputHandler.RightPrim)
				{
					if (!Variables.TPRandom)
					{
						if (PhotonNetwork.PlayerListOthers.Count<Photon.Realtime.Player>() > 3)
						{
							System.Random random = new System.Random();
							int num = random.Next(1, GorillaParent.instance.vrrigDict.Count);
							foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
							{
								meshCollider.enabled = false;
							}
							TeleportLib.Teleport(GorillaParent.instance.vrrigs[num].transform.position);
							Variables.TPRandom = true;
						}
						else
						{
							if (PhotonNetwork.PlayerListOthers.Count<Photon.Realtime.Player>() < 3)
							{
								NotifiLib.SendNotification("[PRISM]: <color=red>PLAYER COUNT IS TOO LOW</color>");
							}
						}
					}
					else
					{
						foreach (MeshCollider meshCollider2 in Resources.FindObjectsOfTypeAll<MeshCollider>())
						{
							meshCollider2.enabled = true;
						}
						Variables.TPRandom = true;
					}
				}
				else
				{
					Variables.TPRandom = false;
				}
			}
			catch (Exception ex)
			{
				Debug.LogException(ex);
			}
		}

		internal static void PunchMod()
		{
			int num = -1;
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				num++;
				if (vrrig != GorillaTagger.Instance.offlineVRRig)
				{
					Vector3 position = vrrig.rightHandTransform.position;
					Vector3 position2 = GorillaTagger.Instance.offlineVRRig.transform.position;
					float num2 = Vector3.Distance(position, position2);
					if (num2 < 0.4)
					{
						GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.rightHandTransform.position - lastRight[num]) * 10f;
					}
					lastRight[num] = vrrig.rightHandTransform.position;
					if (num2 < 0.4)
					{
						GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.leftHandTransform.position - lastLeft[num]) * 10f;
					}
					lastLeft[num] = vrrig.leftHandTransform.position;
				}
			}
		}

		internal static void AirStrike()
		{
            var data = GunLib.ShootBending();

            if (data == null) { return; }

            if (data.isShooting && data.isTriggered)
            {
                GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                if (!Variables.stopTPRep)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = data.hitPosition;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = new Vector3(0f, 40f, 0f);
                    Variables.stopTPRep = true;
                    foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        meshCollider.enabled = false;
                    }
                }
            }
            else
            {
                DisableNoClip();
                Variables.stopTPRep = false;
            }
        }

		internal static void CarMonke()
		{
			if (InputHandler.LeftTrig)
			{
				Vector3 vector = GorillaLocomotion.Player.Instance.headCollider.transform.forward.normalized * -28.5f;
				GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(vector, GorillaLocomotion.Player.Instance.bodyCollider.transform.position, ForceMode.Acceleration);
			}
			if (InputHandler.RightTrig)
			{
				Vector3 vector2 = GorillaLocomotion.Player.Instance.headCollider.transform.forward.normalized * 28.5f;
				GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(vector2, GorillaLocomotion.Player.Instance.bodyCollider.transform.position, ForceMode.Acceleration);
			}
		}

		internal static void BunnyHop()
		{
			Rigidbody rigidbody = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
			float hopValue = 7f;
			float fastFallValue = 7f;
			if (!XRSettings.isDeviceActive)
			{
                if (Keyboard.current[Key.W].isPressed)
                {
                    Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.forward * 7f * Time.fixedDeltaTime;
                    rigidbody.MovePosition(rigidbody.position + vector);
                    if (PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.up * hopValue, ForceMode.Impulse);
                    }
                    if (!PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.down * fastFallValue, ForceMode.Impulse);
                    }
                }
                if (Keyboard.current[Key.A].isPressed)
                {
                    Vector3 vector2 = -GorillaTagger.Instance.offlineVRRig.transform.right * 7f * Time.fixedDeltaTime;
                    rigidbody.MovePosition(rigidbody.position + vector2);
                    if (PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.up * hopValue, ForceMode.Impulse);
                    }
                    if (!PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.down * fastFallValue, ForceMode.Impulse);

                    }
                }
                if (Keyboard.current[Key.S].isPressed)
                {
                    Vector3 vector3 = -GorillaTagger.Instance.offlineVRRig.transform.forward * 7f * Time.fixedDeltaTime;
                    rigidbody.MovePosition(rigidbody.position + vector3);
                    if (PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.up * hopValue, ForceMode.Impulse);
                    }
                    if (!PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.down * fastFallValue, ForceMode.Impulse);
                    }
                }
                if (Keyboard.current[Key.D].isPressed)
                {
                    Vector3 vector4 = GorillaTagger.Instance.offlineVRRig.transform.right * 7f * Time.fixedDeltaTime;
                    rigidbody.MovePosition(rigidbody.position + vector4);
                    if (PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.up * hopValue, ForceMode.Impulse);
                    }
                    if (!PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.down * fastFallValue, ForceMode.Impulse);
                    }
                }
            }
			else if (XRSettings.isDeviceActive)
			{
				if (InputHandler.RightTrig)
				{
                    Vector3 vector4 = GorillaTagger.Instance.offlineVRRig.transform.forward * 7f * Time.fixedDeltaTime;
                    rigidbody.MovePosition(rigidbody.position + vector4);
                    if (PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.up * 10f, ForceMode.Impulse);
                    }
                    if (!PrismUtils.onGround)
                    {
                        rigidbody.AddForce(Vector3.down * fastFallValue, ForceMode.Impulse);
                    }
                }
			}
           
        }

		internal static void Frozone()
		{
			if (InputHandler.LeftGrip)
			{
				GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
				gameObject.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
				gameObject.transform.position = new Vector3(0f, -0.0625f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
				gameObject.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.transform.rotation;
				Renderer component = gameObject.GetComponent<Renderer>();
				component.material.shader = Shader.Find("GUI/Text Shader");
				component.material.color = new Color(0.769f, 0.984f, 1f, 1f);
				gameObject.AddComponent<GorillaSurfaceOverride>().overrideIndex = 59;
				UnityEngine.Object.Destroy(gameObject, 0.85f);
			}
			if (InputHandler.RightGrip)
			{
				GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
				gameObject2.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
				gameObject2.transform.position = new Vector3(0f, -0.0625f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position;
				gameObject2.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.transform.rotation;
				Renderer component2 = gameObject2.GetComponent<Renderer>();
				component2.material.shader = Shader.Find("GUI/Text Shader");
				component2.material.color = new Color(0.769f, 0.984f, 1f, 1f);
				gameObject2.AddComponent<GorillaSurfaceOverride>().overrideIndex = 59;
				UnityEngine.Object.Destroy(gameObject2, 0.85f);
			}
		}

		internal static void LongArms(float pos)
		{
			GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(pos, pos, pos);
		}

		internal static void Fly()
		{
			if (InputHandler.RightPrim)
			{
                var buttonHandler = MenuHandler.FindButton("Fly's: [Normal]")
?? MenuHandler.FindButton("Fly's: [Slow]")
?? MenuHandler.FindButton("Fly's: [High]");
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
				switch (buttonHandler.settingIndex)
				{
				case 1:
					GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 35f;
					break;
				case 2:
					GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 10f;
					break;
				case 3:
					GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 75f;
					break;
				}
			}
		}

		internal static void VelFly()
		{
			if (InputHandler.RightPrim)
			{
                var buttonHandler = MenuHandler.FindButton("Fly's: [Normal]")
?? MenuHandler.FindButton("Fly's: [Slow]")
?? MenuHandler.FindButton("Fly's: [High]");
                switch (buttonHandler.settingIndex)
				{
				case 1:
					GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 30f;
					break;
				case 2:
					GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 12.5f;
					break;
				case 3:
					GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 70f;
					break;
				}
			}
		}

		internal static void Hertz()
		{
			Thread.Sleep(15);
		}

		internal static void GravityChanger(string type)
		{
			if (!string.IsNullOrEmpty(type))
			{
				if (type == "moon" || type == "low")
				{
					Physics.gravity = new Vector3(0f, -4f, 0f);
				}
				if (type == "none")
				{
					Physics.gravity = new Vector3(0f, -0f, 0f);
				}
				if (type == "high" || type == "sun")
				{
					Physics.gravity = new Vector3(0f, -28f, 0f);
				}
				if (type == "reset")
				{
					Physics.gravity = new Vector3(0f, -9.81f, 0f);
				}
			}
		}

		internal static void FastSwim(float val)
		{
			if (GorillaLocomotion.Player.Instance.InWater)
			{
				GorillaLocomotion.Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= val;
			}
		}

		internal static void SlideControl(float speed)
		{
			GorillaLocomotion.Player.Instance.slideControl = speed;
		}

		internal static void SpeedyFuckyou(int wad)
		{
			GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().drag = (float)wad;
		}

		internal static void SizeChange(float parSeced)
		{
			GorillaLocomotion.Player.Instance.scale = parSeced;
        }
	}
}
