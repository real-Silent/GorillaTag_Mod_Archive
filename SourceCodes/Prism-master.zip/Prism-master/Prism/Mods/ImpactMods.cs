﻿using System;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using Prism.Utility;
using UnityEngine;

namespace Prism.Mods
{
	internal class ImpactMods : MonoBehaviour
	{
		private static float inum;
		internal static void SendImpactEffect(Vector3 position, float r, float g, float b, float a, int projectileCount, bool isPomPom = false)
		{
			try
			{
				
				if ((Time.time > inum + 0.3f) || isPomPom)
				{
                    object[] impactSendData = new object[6];
                    object[] sendEventData = new object[3];
                    impactSendData[0] = position;
                    impactSendData[1] = r;
                    impactSendData[2] = g;
                    impactSendData[3] = b;
                    impactSendData[4] = a;
                    impactSendData[5] = projectileCount;
                    object obj = impactSendData;
                    sendEventData[0] = PhotonNetwork.ServerTimestamp;
                    sendEventData[1] = (byte)1;
                    sendEventData[2] = impactSendData;
                    PhotonNetwork.RaiseEvent(3, sendEventData, new RaiseEventOptions
					{
						Receivers = ReceiverGroup.All
					}, SendOptions.SendUnreliable);
					if (!isPomPom)
						inum = Time.time;
				}
			}
			catch (Exception ex)
			{
				Debug.LogException(ex);
			}
		}

		internal static void ImpactSelf()
		{
			if (!PhotonNetwork.InRoom) { return; }

			SendImpactEffect(GorillaTagger.Instance.offlineVRRig.transform.position, 255f, 0f, 0f, 1f, 1);
		}

		internal static void ImpactPomPoms()
		{
			if (!PhotonNetwork.InRoom) { return; }

			if ((Time.time > inum + 0.3f))
			{
				SendImpactEffect(GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position, 255f, 0f, 0f, 1f, 1, true);
				SendImpactEffect(GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position, 255f, 0f, 0f, 1f, 1, true);
				inum = Time.time;
            }
		}

		internal static void ImpactAura()
		{
			if (!PhotonNetwork.InRoom) { return; }

			float num = 1f;
			float num2 = 2f;
			Vector3 vector = UnityEngine.Random.insideUnitSphere.normalized * UnityEngine.Random.Range(num, num2);
			Vector3 vector2 = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + vector;
			Vector3 vector3 = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - vector2;
			SendImpactEffect(vector2, 1f, 0f, 0f, 1f, 1);
		}

		internal static void ImpactOrbit()
		{
			if (!PhotonNetwork.InRoom) { return; }

			float num = 4.5f;
			float num2 = Time.time * num;
			float num3 = 3f;
			Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 1f, 0f);
			Vector3 vector2 = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * num3;
			Vector3 vector3 = vector + vector2 * Time.deltaTime * 5f;
			SendImpactEffect(vector3, 255f, 0f, 0f, 1f, 1);
		}

		internal static void ImpactAll()
		{
			if (!PhotonNetwork.InRoom) { return; }

			for (int i = 0; i < GorillaParent.instance.vrrigs.Count; i++)
			{
				SendImpactEffect(GorillaParent.instance.vrrigs[i].transform.position, 1f, 0f, 0f, 1f, 1);
			}
		}

		internal static void ImpactGun()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }
			if (data.lockedPlayer != null && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
				SendImpactEffect(data.lockedPlayer.transform.position, 255f, 0f, 0f, 1f, 1);
			}
			//teamwork makes the dreamwork headahh
		}

		internal static void GivePomPoms()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }

			if (data.lockedPlayer != null && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
				if ((Time.time > inum + 0.3f))
				{
					SendImpactEffect(data.lockedPlayer.rightHandPlayer.transform.position, 255f, 0f, 0f, 1f, 1, true);
					SendImpactEffect(data.lockedPlayer.leftHandPlayer.transform.position, 255f, 0f, 0f, 1f, 1, true);
                    inum = Time.time;
                }
            }

		}

		internal static void GiveAura()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }

			if (data.lockedPlayer != null && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
                float num = 1f;
                float num2 = 2f;
                Vector3 val = UnityEngine.Random.insideUnitSphere; //how many classes have yall cleaned? all of utility is what i did and patches lyin ass nigga
                val = val.normalized * UnityEngine.Random.Range(num, num2);
                Vector3 val2 = data.lockedPlayer.transform.position + val;
                Vector3 val3 = data.lockedPlayer.transform.position - val2;
                SendImpactEffect(val2, 255f, 0f, 0f, 1f, 1);
            }
		}

		internal static void GiveOrbit()
		{
			var data = GunLib.ShootLockedBending();
			if (data == null) { return; }

			if (!PhotonNetwork.InRoom) { return; }
			if (data.lockedPlayer != null && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
				float num = 4.5f;
				float num2 = Time.time * num;
				float num3 = 6f;//impact mods we go!
				Vector3 vector = data.lockedPlayer.transform.position + new Vector3(0f, 1f, 0f);
				Vector3 vector2 = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * num3;
				Vector3 vector3 = vector + vector2 * Time.deltaTime * 5f;
				SendImpactEffect(vector3, 1f, 0f, 0f, 1f, 1);
			}
		}
	}
}

