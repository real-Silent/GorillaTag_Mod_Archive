﻿using GorillaExtensions;
using GorillaNetworking;
using Photon.Pun;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;
using UnityEngine.InputSystem;
using Prism.Patches;
using System.Collections.Generic;

namespace Prism.Mods
{
	internal class VRRigMods : BaseClass
    {
        static float currentSpeed = 1f;
        static float maxSpeed = 35;
        static float acceleration = 1f;
        public static float gfaw;
		private static Color color;
		private static bool teleportGunAntiRepeat;
		private static Vector3 targetPosition;
		private static Quaternion targetRotation;
		internal static VRRig closestRig;
		internal static VRRig GetClosestRig()//send
		{
			VRRig vrrig = null;
			float num = float.PositiveInfinity;
			Vector3 position = GorillaTagger.Instance.offlineVRRig.transform.position;
			foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
			{
				if (vrrig2 != GorillaTagger.Instance.offlineVRRig)
				{
					float sqrMagnitude = (vrrig2.transform.position - position).sqrMagnitude;
					if (sqrMagnitude < num)
					{
						num = sqrMagnitude;
						vrrig = vrrig2;
					}
				}
			}
			return vrrig;
		}

		internal static void ResetColor()
		{
            GorillaTagger.Instance.offlineVRRig.InitializeNoobMaterialLocal(PlayerPrefs.GetFloat("redValue", 0f), PlayerPrefs.GetFloat("greenValue", 0f), PlayerPrefs.GetFloat("blueValue", 0f));
			if (PhotonNetwork.InRoom)
			{
                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[] { PlayerPrefs.GetFloat("redValue", 0f), PlayerPrefs.GetFloat("greenValue", 0f), PlayerPrefs.GetFloat("blueValue", 0f) });
            }
		}

		internal static void ToggleVRRig(int mode, float parsec = 0)
		{
			if (InputHandler.RightPrim || Keyboard.current[Key.E].wasPressedThisFrame)
			{
				if (Variables.Origin)
				{
					Variables.Reversed = !Variables.Reversed;
					Variables.Origin = false;
				}
			}
			else
			{
				Variables.Origin = true;
			}
			if (GorillaTagger.Instance.offlineVRRig != null)
			{
				if (Variables.Reversed)
				{
					switch (mode)
					{
						case 1:
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            break;
						case 2:
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(999f, 999f, 999f);
                            break;
						case 3:
                            closestRig = GetClosestRig();
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.head.rigTarget.LookAt(closestRig.headMesh.transform.position);
                            break;
						case 4:
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position;
                            GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation;
                            break;
						case 5:
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation;
                            break;
						case 6:
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 9.5f, 0f);
                            GorillaTagger.Instance.offlineVRRig.transform.position += new Vector3(0f, 0.1f, 0f);
                            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + -GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
                            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
                            break;
						case 7:
							GorillaLocomotion.Player.Instance.scale = parsec;
							break;
					}
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.enabled = true;
				}
			}
		}

		internal static void HoldRig()
		{
			if (InputHandler.RightGrip)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.localScale = new Vector3(0.35f, 0.35f, 0.35f);
				GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, -0.0045f, 0f) + GorillaTagger.Instance.rightHandTransform.position;
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 10f, 0f);
				GorillaTagger.Instance.offlineVRRig.headConstraint.transform.Rotate(1f, 10f, 1f);
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

        internal static void OrbitGun()
        {
            var data = GunLib.ShootLockedBending();

            if (data == null) { return; }

            if (data.lockedPlayer && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                float num = 4f;
                float num2 = Time.time * num;
                float num3 = 20f;
                Vector3 vector = data.lockedPlayer.transform.position + new Vector3(0f, 0.8f, 0f);
                Vector3 vector2 = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * num3;
                Vector3 vector3 = vector + vector2 * Time.deltaTime * 5f;
                GorillaTagger.Instance.offlineVRRig.transform.position = (vector3);
                targetPosition = data.lockedPlayer.transform.position + data.lockedPlayer.transform.forward.x0z();
                GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.RotateTowards(GorillaTagger.Instance.offlineVRRig.transform.rotation, targetRotation, 720f * Time.deltaTime);
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + -GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 1f;

            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        internal static void CopyPlayer()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (data.lockedPlayer && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position = data.lockedPlayer.transform.position;
				GorillaTagger.Instance.offlineVRRig.transform.rotation = data.lockedPlayer.transform.rotation;
				GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = data.lockedPlayer.leftHandPlayer.transform.position;
				GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.rotation = data.lockedPlayer.leftHandPlayer.transform.rotation;
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = data.lockedPlayer.rightHandPlayer.transform.position;
				GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.rotation = data.lockedPlayer.rightHandPlayer.transform.rotation;
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		internal static void HeadSpin(string XYZ)
		{
			if (XYZ == "X" || XYZ == "x")
			{
				VRMap head = GorillaTagger.Instance.offlineVRRig.head;
				head.trackingRotationOffset.x = head.trackingRotationOffset.x + 7f;
			}
			if (XYZ == "Y" || XYZ == "y")
			{
				VRMap head2 = GorillaTagger.Instance.offlineVRRig.head;
				head2.trackingRotationOffset.y = head2.trackingRotationOffset.y + 7f;
			}
			if (XYZ == "Z" || XYZ == "z")
			{
				VRMap head3 = GorillaTagger.Instance.offlineVRRig.head;
				head3.trackingRotationOffset.z = head3.trackingRotationOffset.z + 7f;
			}
			if (XYZ == "REVERSE")
			{
				GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset = new Vector3(0f, 0f, 180f);
			}
			if (XYZ == "back")
			{
				GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset = new Vector3(0f, 180f, 0f);
			}
		}

		internal static void ResetVRRig()
		{
			GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0f;
			GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0f;
			GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0f;
			GorillaTagger.Instance.offlineVRRig.enabled = true;
		}

		internal static void RigGun()
		{
			var data = GunLib.ShootBending();

			if (data == null) { return; }

			if (data.isShooting && data.isTriggered)
			{
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = data.hitPosition;
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.transform.rotation;
            }
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

        internal static void LucyGun()
		{
			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (data.isLocked && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
                currentSpeed = Mathf.Min(currentSpeed + acceleration * Time.deltaTime, maxSpeed);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = data.lockedPlayer.transform.position;
                targetPosition = data.lockedPlayer.transform.position + data.lockedPlayer.transform.forward.x0z();
                targetRotation = Quaternion.LookRotation(data.lockedPlayer.transform.position - GorillaTagger.Instance.offlineVRRig.transform.position);
                GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.MoveTowards(GorillaTagger.Instance.offlineVRRig.transform.position, targetPosition, currentSpeed * Time.deltaTime);
                GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.RotateTowards(GorillaTagger.Instance.offlineVRRig.transform.rotation, targetRotation, 720f * Time.deltaTime);
            }
			else
			{
				currentSpeed = 0;
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		internal static void StealPlayer()
		{

			var data = GunLib.ShootLockedBending();

			if (data == null) { return; }

			if (data.lockedPlayer && data.isTriggered && PrismUtils.GrabPhotonView(data.lockedPlayer) != null)
			{
				Photon.Realtime.Player owner = PrismUtils.GrabPhotonView(data.lockedPlayer).Owner;
				if (!teleportGunAntiRepeat)
				{
					if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
					{
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = GorillaComputer.instance.friendJoinCollider.thisCapsule.transform.position;
                        color = GorillaGameManager.instance.FindPlayerVRRig(owner).playerColor;
                        GorillaTagger.Instance.offlineVRRig.InitializeNoobMaterialLocal(color.r, color.g, color.b);
                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
						{
								color.r,
								color.g,
								color.b
						});
						PhotonNetwork.LocalPlayer.NickName = owner.NickName;
						teleportGunAntiRepeat = true;
						NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: You Stole " + owner.NickName + "'s Identity");
					}
					else
                    {
                        color = GorillaGameManager.instance.FindPlayerVRRig(owner).playerColor;
                        GorillaTagger.Instance.offlineVRRig.InitializeNoobMaterialLocal(color.r, color.g, color.b);
                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                        {
                                color.r,
                                color.g,
                                color.b
                        });
                        PhotonNetwork.LocalPlayer.NickName = owner.NickName;
                        teleportGunAntiRepeat = true;
					}
				}
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
				teleportGunAntiRepeat = false;
			}
		}

        public static void SolidMonkeys()
        {
            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(rig.transform.position, GorillaTagger.Instance.headCollider.transform.position) < 6f)
                {
                    GameObject bodyColl = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    bodyColl.transform.position = Vector3.Lerp(rig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f), rig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f), 0.5f);
                    bodyColl.transform.rotation = Quaternion.LookRotation(rig.head.rigTarget.transform.position - (rig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f)));
                    bodyColl.transform.localScale = new Vector3(0.3f, 0.55f, 0.3f);
                    bodyColl.GetComponent<Renderer>().enabled = false;
                    UnityEngine.Object.Destroy(bodyColl, Time.deltaTime * 2);

                    for (int i = 0; i < Variables.bones.Length - 1; i += 2)
                    {
                        GameObject boneColl = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        boneColl.transform.position = Vector3.Lerp(rig.mainSkin.bones[Variables.bones[i]].position, rig.mainSkin.bones[Variables.bones[i + 1]].position, 0.5f);
                        boneColl.transform.LookAt(rig.mainSkin.bones[Variables.bones[i + 1]].position);
                        boneColl.transform.localScale = new Vector3(0.2f, 0.2f, Vector3.Distance(rig.mainSkin.bones[Variables.bones[i]].position, rig.mainSkin.bones[Variables.bones[i + 1]].position));
                        boneColl.GetComponent<Renderer>().enabled = false;
                        UnityEngine.Object.Destroy(boneColl, Time.deltaTime * 2);
                    }
                }
            }
        }

        public static List<Vector3> Macro = new List<Vector3>();
        public static List<Vector3> positions = new List<Vector3>();

        public static List<Vector3> rightHandPositions = new List<Vector3>();
        public static List<Vector3> leftHandPositions = new List<Vector3>();
        public static float MacroHelp = 0;
        public static float RewindHelp = 0;

		public static void disableReverseReplay()
		{
            positions.Clear();
			Macro.Clear();
        }

		public static void Replay()
		{
			MeshCollider[] array2 = Resources.FindObjectsOfTypeAll<MeshCollider>();
			Macro.Add(GorillaLocomotion.Player.Instance.transform.position);
			rightHandPositions.Add(GorillaLocomotion.Player.Instance.rightHandFollower.transform.position);
			leftHandPositions.Add(GorillaLocomotion.Player.Instance.leftHandFollower.transform.position);
            if (!InputHandler.RightGrip)
			{
				GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.useGravity = true;
			}
			else
			{
				GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.useGravity = false;
				if (!Variables.isnoclipped)
				{
					foreach (MeshCollider meshCollider in array2)
					{
						meshCollider.transform.localScale = meshCollider.transform.localScale / 10000f;
					}
				}

				Variables.isnoclipped = true;
				for (int k = 0; k < Macro.Count; k++)
				{
					if (MacroHelp == 0f)
					{
						GorillaLocomotion.Player.Instance.transform.position = Macro[k];
                        GorillaLocomotion.Player.Instance.leftHandFollower.transform.position = leftHandPositions[k];
                        GorillaLocomotion.Player.Instance.rightHandFollower.transform.position = rightHandPositions[k];


                        Macro.RemoveAt(k);
						leftHandPositions.RemoveAt(k);
						rightHandPositions.RemoveAt(k);
                        MacroHelp = Time.deltaTime + 1f;
					}
				}
			}

			if (Variables.isnoclipped && !InputHandler.RightGrip)
			{
				MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
				if (array != null)
				{
					foreach (MeshCollider meshCollider2 in array2)
					{
						meshCollider2.transform.localScale = meshCollider2.transform.localScale * 10000f;
					}
				}
				Variables.isnoclipped = false;
			}
		}

		public static void Reverse()
		{
            if (InputHandler.RightGrip)
            {
                for (int j = positions.Count - 1; j >= 0; j--)
                {
                    if (RewindHelp == 0f)
                    {
                        GorillaLocomotion.Player.Instance.transform.position = positions[j];
                        GorillaLocomotion.Player.Instance.leftHandFollower.transform.position = leftHandPositions[j];
                        GorillaLocomotion.Player.Instance.rightHandFollower.transform.position = rightHandPositions[j];

                        positions.RemoveAt(j);
                        leftHandPositions.RemoveAt(j);
                        rightHandPositions.RemoveAt(j);
                        RewindHelp = Time.deltaTime + 1f;
                    }
                }
            }
            else
            {
                positions.Add(GorillaLocomotion.Player.Instance.transform.position);
                rightHandPositions.Add(GorillaLocomotion.Player.Instance.rightHandFollower.transform.position);
                leftHandPositions.Add(GorillaLocomotion.Player.Instance.leftHandFollower.transform.position);
            }
        }


        internal static void RainbowMonk(float num)
		{
			if (!PhotonNetwork.InRoom) { return; }

			if (Time.time > gfaw + 0.04f)
			{
                color = Variables.Rainbow(num);
                GorillaTagger.Instance.offlineVRRig.InitializeNoobMaterialLocal(color.r, color.g, color.b);
                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                {
                color.r,
                color.g,
                color.b
                });
                gfaw = Time.time;
            }
        }
    }
}