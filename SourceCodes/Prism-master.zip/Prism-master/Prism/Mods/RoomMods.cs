﻿using System;
using ExitGames.Client.Photon;
using GorillaNetworking;
using Photon.Pun;
using Prism.Patches;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;
using UnityEngine.XR;
using WebSocketSharp;

namespace Prism.Mods
{
	internal class RoomMods : MonoBehaviour
	{

        static bool IsVectorInRange(Vector3 vectorA, Vector3 vectorB, float minThreshold, float maxThreshold)
        {
            float distance = Vector3.Distance(vectorA, vectorB);

            return distance > minThreshold && distance <= maxThreshold;
        }

       /* public static void AntiBanNew()
		{
			string text = PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString().Replace(GorillaComputer.instance.currentQueue, GorillaComputer.instance.currentQueue + "MODDEDMODDED");
			Hashtable hashtable = new Hashtable { { "gameMode", text } };
			PhotonNetwork.CurrentRoom.MaxPlayers = 0;
			PhotonNetwork.CurrentRoom.IsVisible = false;
			PhotonNetwork.CurrentRoom.IsOpen = false;
			PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, null, null);
			ExecuteCloudScriptRequest executeCloudScriptRequest = new ExecuteCloudScriptRequest();
			executeCloudScriptRequest.FunctionName = "RoomClosed";
			executeCloudScriptRequest.FunctionParameter = new
			{
				GameId = PhotonNetwork.CurrentRoom.Name,
				Region = Regex.Replace(PhotonNetwork.CloudRegion, "[^a-zA-Z0-9]", "").ToUpper(),
				UserId = PhotonNetwork.PlayerListOthers[0].UserId,
				ActorNr = PhotonNetwork.PlayerListOthers[0].ActorNumber,
				ActorCount = PhotonNetwork.ViewCount,
				AppId = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime,
				AppVersion = PhotonNetwork.AppVersion,
				Server = PhotonNetwork.PhotonServerSettings,
				Username = "-"
			};
			executeCloudScriptRequest.GeneratePlayStreamEvent = false;
			executeCloudScriptRequest.RevisionSelection = new CloudScriptRevisionOption?(CloudScriptRevisionOption.Live);
			PlayFabClientAPI.ExecuteCloudScript(executeCloudScriptRequest, delegate(ExecuteCloudScriptResult result)
			{
				ABReady = true;
				alreadyUsed = false;
			}, null, null, null);
			PhotonNetwork.CurrentRoom.masterClientId = PhotonNetwork.LocalPlayer.ActorNumber;
		}

		public static void SetMaster()
		{
			if (PhotonNetwork.LocalPlayer.IsMasterClient)
			{
				NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=orange>YOU ARE ALREADY MASTERCLIENT</color>");
			}
			else
			{
				if (!PhotonNetwork.LocalPlayer.IsMasterClient && PrismUtils.isModded())
				{
					PhotonNetwork.NetworkingClient.CurrentRoom.SetMasterClient(PhotonNetwork.LocalPlayer);
				}
				else
				{
					if (!ABReady || !PrismUtils.isModded())
					{
						NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>PLEASE USE ANTIBAN</color>");
					}
				}
			}
		}

		internal static void FuckTrigs(string key)
		{
			if (PhotonNetwork.LocalPlayer.IsMasterClient && ABReady)
			{
				Hashtable hashtable = new Hashtable();
				hashtable.Add("gameMode", key);
				PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, null, null);
			}
			else
			{
				NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>PLEASE USE SET MASTER or ANTIBAN</color>");
			}
		}

		internal static void ChangeGamemode(string gamemode)
		{
			if (PhotonNetwork.LocalPlayer.IsMasterClient)
			{
				Hashtable hashtable = new Hashtable();
				hashtable.Add("gameMode", gamemode);
				PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, null, null);
			}
			else
			{
				NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=red>PLEASE USE SET MASTER or ANTIBAN</color>");
			}
		}*/

		internal static void Create_Public(string CurrentMap = null, string roomName = null)
		{
			if (PhotonNetwork.InRoom)
			{
				PhotonNetwork.Disconnect();
				
			}
            else if (!PhotonNetwork.InRoom)
            {
                string value = PhotonNetworkController.Instance.currentJoinTrigger.gameModeName + GorillaComputer.instance.currentQueue + ((PhotonNetworkController.Instance.currentJoinTrigger.gameModeName == "city" || PhotonNetworkController.Instance.currentJoinTrigger.gameModeName == "basement") ? ((object)"CASUAL") : ((object)GorillaComputer.instance.currentGameMode));
                Hashtable customProps = new Hashtable
				{
					{ "gameMode", value },
					{ "platform", "OTHER" }
				 };
                RoomConfig roomConfig = RoomConfig.AnyPublicConfig();
                roomConfig.MaxPlayers = 10;
				roomConfig.customProps = customProps;
				NetworkSystem.Instance.ConnectToRoom(PrismUtils.RandString(4), roomConfig);
			}
		}

		internal static void Create_Private()
		{
			if (!PhotonNetwork.InRoom)
			{
				PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(PrismUtils.RandString(6), JoinType.Solo);
			}
			else
			{
				if (PhotonNetwork.InRoom)
				{
					PhotonNetwork.Disconnect();
					Create_Private();
				}
			}
		}

		internal static void GameModeManager(int selection)
		{
			string template = GorillaComputer.instance.currentGameMode.ToString();
			switch (selection)
			{
				case 0:
                    template = "CASUAL";
					break;
				case 1:
                    template = "INFECTION";
                    break;
                case 2:
                    template = "HUNT";
                    break;
                case 3:
                    template = "BATTLE";
                    break;
				default:
                    template = GorillaComputer.instance.currentGameMode.ToString();
					break;
            }
            if (PhotonNetwork.InRoom)
			{
				try
				{
                    if (!template.IsNullOrEmpty())
                    {
                        if (PhotonNetwork.IsMasterClient)
                        {
                            Hashtable hashtable = new ExitGames.Client.Photon.Hashtable { { "gameMode", template } };
                            PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, null, null);
                            NotifiLib.SendNotification("[PRISM]: <color=white>GAMEMODE HAS BEEN CHANGED</color>");
                            return;
                        }
                        else
                        {
                            NotifiLib.SendNotification("[PRISM]: <color=red>YOU ARE NOT MASTER</color>");
                        }
                    }
                }
				catch
				{
                    NotifiLib.SendNotification("[PRISM]: <color=red>AN ERROR HAS OCCURED.</color>");
                }
            }
		}

		internal static void AttemptDisc()
		{
			if (PhotonNetwork.InRoom && (InputHandler.LeftPrim || !XRSettings.isDeviceActive))
			{
				PhotonNetwork.Disconnect();
			}
			else if (!PhotonNetwork.InRoom && !XRSettings.isDeviceActive)
			{
				if (MenuHandler.FindButton("Disconnect [X/Y]").isToggled)
				{
					MenuHandler.FindButton("Disconnect [X/Y]").isToggled = false;
				}
            }
			else if (!PhotonNetwork.InRoom)
			{
                NotifiLib.SendNotification("[PRISM]: <color=red>YOU'RE NOT IN A ROOM...</color>");
            }
		}

		internal static void AntiReport()
		{
			try
			{
				foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
				{
					if (gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer)
					{
						foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
						{
							Transform transform = gorillaPlayerScoreboardLine.reportButton.transform;
							if (vrrig != GorillaTagger.Instance.offlineVRRig && vrrig != null)
							{
								if (Vector3.Distance(vrrig.leftHandPlayer.transform.position, transform.position) < 0.4 || Vector3.Distance(vrrig.rightHandPlayer.transform.position, transform.position) < 0.4)
								{
									Photon.Realtime.Player owner = PrismUtils.GrabPhotonView(vrrig).Owner;
									NotifiLib.SendNotification("[PRISM]: <color=cyan>" + owner.NickName + " ATTEMPTED REPORTING YOU</color>");
                                    var buttonHandler = MenuHandler.FindButton("AntiReport: [Leave]")
?? MenuHandler.FindButton("AntiReport: [Stutter]")
?? MenuHandler.FindButton("AntiReport: [Hop]")
?? MenuHandler.FindButton("AntiReport: [Rejoin]");
                                    switch (buttonHandler.settingIndex)
									{
									case 1:
										PhotonNetwork.Disconnect();
										break;
									case 2:
									{
										PhotonView photonView = PrismUtils.GrabPhotonView(vrrig);
										if (photonView != null && photonView != GorillaTagger.Instance.myVRRig)
										{
											AbusiveMods.StutterView(photonView);
										}
										break;
									}
									case 3:
										PhotonNetwork.Disconnect();
										if (Time.time > RoomManager.leaveTime + 0.2f)
											{
												RoomManager.HitTheMapTrigger();
											}
										break;
									case 4:
											PhotonNetwork.Disconnect();
											if (Time.time > RoomManager.leaveTime + 0.3f)
											{
                                                if (!PhotonNetwork.InRoom && RoomManager.roomCode != string.Empty)
                                                    PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(RoomManager.roomCode, JoinType.Solo);
                                                else if (PhotonNetwork.InRoom && PhotonNetwork.CurrentRoom.Name != RoomManager.roomCode)
                                                    RoomManager.roomCode = string.Empty;
                                            }
                                            break;

									default:
										PhotonNetwork.Disconnect();
										break;
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogException(ex);
			}
		}

		internal static void NoLobbyLeave(bool turnOn)
		{
			if (PhotonNetwork.InRoom)
			{
				GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(turnOn);
			}
			else
			{
				if (!PhotonNetwork.InRoom)
				{
					GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
				}
			}
		}

		internal static void AntiModerator()
		{
			if (!PhotonNetwork.InRoom) { return; }

			try
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					if (vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAK.") && vrrig != GorillaTagger.Instance.offlineVRRig)
					{
						PhotonNetwork.Disconnect();
						break;
					}
				}
			}
			catch (Exception ex)
			{
				Debug.Log(ex);
			}
		}

        public static void OculusAntiReport()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != GorillaTagger.Instance.offlineVRRig && PrismUtils.GrabPhotonView(vrrig) != null)
                {
                    float dist = PrismUtils.CalculateTotalDistance(vrrig.rightHandTransform.position, vrrig.leftHandTransform.position, vrrig.headMesh.transform.position);
					if (PrismUtils.IsNumberBetween(dist, 0.893f, 0.897f) && IsVectorInRange(vrrig.rightHandTransform.position, vrrig.leftHandTransform.position, 0.125f, 0.1262f))
					{
                        NotifiLib.SendNotification("[PRISM]: <color=cyan>" + PrismUtils.GrabPhotonView(vrrig).Owner.NickName + " ATTEMPTED REPORTING YOU IN OCULUS MENU</color>");
                        var buttonHandler = MenuHandler.FindButton("AntiReport: [Leave]")
?? MenuHandler.FindButton("AntiReport: [Stutter]")
?? MenuHandler.FindButton("AntiReport: [Hop]")
?? MenuHandler.FindButton("AntiReport: [Rejoin]");
                        switch (buttonHandler.settingIndex)
                        {
                            case 1:
                                PhotonNetwork.Disconnect();
                                break;
                            case 2:
                                {
                                    PhotonView photonView = PrismUtils.GrabPhotonView(vrrig);
                                    if (photonView != null && photonView != GorillaTagger.Instance.myVRRig)
                                    {
                                        AbusiveMods.StutterView(photonView);
                                    }
                                    break;
                                }
                            case 3:
                                PhotonNetwork.Disconnect();
                                if (Time.time > RoomManager.leaveTime + 0.2f)
                                {
                                    RoomManager.HitTheMapTrigger();
                                }
                                break;
                            case 4:
                                PhotonNetwork.Disconnect();
                                if (Time.time > RoomManager.leaveTime + 0.3f)
                                {
                                    if (!PhotonNetwork.InRoom && RoomManager.roomCode != string.Empty)
                                        PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(RoomManager.roomCode, JoinType.Solo);
                                    else if (PhotonNetwork.InRoom && PhotonNetwork.CurrentRoom.Name != RoomManager.roomCode)
                                        RoomManager.roomCode = string.Empty;
                                }
                                break;

                            default:
                                PhotonNetwork.Disconnect();
                                break;
                        }
                    }
                }
            }
        }
    }
}
