﻿using Prism.WristMenu;
using System;
using Newtonsoft.Json;
using UnityEngine;
using System.Text;
using System.Net.Http;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Prism.Utility;

namespace Prism.Networking
{
    public class Configs
    {
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public static void UploadConfig(string uploadstring, string configNames, bool isPrivate)
        {
            string creatorName = GetDiscordUsername();
            string configName = configNames;

            var config = new
            {
                creatorName = creatorName,
                configName = configName,
                configString = Base64Encode(uploadstring),
                lastUpdated = DateTime.UtcNow.ToString("o"),
                @private = isPrivate
            };

            string json = JsonConvert.SerializeObject(config);

            SendConfig(json);
        }

        public static string discordUsername = null;
        public static string GetDiscordUsername()
        {
            if (discordUsername != null)
            {
                return discordUsername;
            }

            string id = GetDiscordId(Injection.key);
            string url = $"https://discordlookup.mesalytic.moe/v1/user/{id}";
            string username = "";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    var response = client.GetStringAsync(url).Result;

                    JObject user = JObject.Parse(response);

                    if (user["username"] != null)
                    {
                        username = user["username"].ToString();
                    }
                    else
                    {
                        throw new Exception("Username not found in the response.");
                    }
                }
                catch (HttpRequestException e)
                {
                    Debug.LogError($"Request error: {e.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    Debug.LogError($"Exception occurred: {ex.Message}");
                    throw;
                }
            }
            discordUsername = username;
            return username;
        }

        public static string GetDiscordImageLink()
        {
            string id = GetDiscordId(Injection.key);
            string url = $"https://discordlookup.mesalytic.moe/v1/user/{id}";
            string avatarUrl = "";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    var response = client.GetStringAsync(url).Result;

                    JObject user = JObject.Parse(response);

                    if (user["avatar"] != null && user["avatar"]["link"] != null)
                    {
                        avatarUrl = user["avatar"]["link"].ToString();
                    }
                    else
                    {
                        throw new Exception("Avatar link not found in the response.");
                    }
                }
                catch (HttpRequestException e)
                {
                    Debug.LogError($"Request error: {e.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    Debug.LogError($"Exception occurred: {ex.Message}");
                    throw;
                }
            }

            return avatarUrl;
        }

        public static void SendConfig(string json)
        {
            string url = "http://45.55.74.63:3000/save-config";

            using (HttpClient client = new HttpClient())
            {
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = client.PostAsync(url, content).Result;

                string result = response.Content.ReadAsStringAsync().Result;
                Debug.Log(result);
            }
        }

        public static List<Config> GetConfigs()
        {
            string url = "http://45.55.74.63:3000/configs";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    string json = response.Content.ReadAsStringAsync().Result;
                    var result = JsonConvert.DeserializeObject<Response>(json);
                    return result.Configs;
                }
                else
                {
                    Console.WriteLine("Error: " + response.StatusCode);
                    return null;
                }
            }
        }

        public static string SaveEnabledMods()
        {
            var enabledMods = new List<ModState>();

            foreach (var button in ModHandler.buttons)
            {
                if (button.isToggled)
                {
                    enabledMods.Add(new ModState
                    {
                        ModName = button.text,
                        IsEnabled = button.isToggled,
                        SettingIndex = (button.category == ModHandler.Category.ModPrefs || button.category == ModHandler.Category.MenuPrefs) ? button.settingIndex : -1
                    });
                }
            }

            string json = JsonConvert.SerializeObject(enabledMods);
            return json;
        }

        static string GetDiscordId(string key)
        {
            string url = "http://45.55.74.63:3000/get-discord-id";

            var json = new JObject();
            json["key"] = key;

            var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.PostAsync(url, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    string resultContent = response.Content.ReadAsStringAsync().Result;
                    var resultJson = JObject.Parse(resultContent);

                    if (resultJson["success"].Value<bool>())
                    {
                        return resultJson["discordId"].ToString();
                    }
                }
            }

            return null;
        }

        public static void LoadEnabledMods(string mod)
        {
            string json = Base64Decode(mod);
            var enabledMods = JsonConvert.DeserializeObject<List<ModState>>(json);

            foreach (var button in ModHandler.buttons)
            {
                button.isToggled = false;
            }
            foreach (var modState in enabledMods)
            {
                Debug.Log("button2 " + modState.ModName);
                foreach (var button in ModHandler.buttons)
                {
                    Debug.Log("button " + button.text);
                    if (button.text == modState.ModName)
                    {
                        Debug.Log("Toggling " + button.text);
                        MenuHandler.ToggleButton(button.text);

                        if (button.category == ModHandler.Category.ModPrefs || button.category == ModHandler.Category.MenuPrefs)
                        {
                            button.settingIndex = modState.SettingIndex;
                            button.method();
                            button.method();
                            button.method();
                        }
                    }
                }
            }
        }

        public static string userID = null;


        public static string GetUID(string key)
        {
            if (userID != null)
            {
                return userID;
            }
            string url = "http://45.55.74.63:3000/get-uid";

            var json = new JObject();
            json["key"] = key;

            var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.PostAsync(url, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    string resultContent = response.Content.ReadAsStringAsync().Result;
                    var resultJson = JObject.Parse(resultContent);

                    if (resultJson["success"].Value<bool>())
                    {
                        userID = resultJson["userId"].ToString();
                        return resultJson["userId"].ToString();
                    }
                }
            }

            return null;
        }

        public class ModState
        {
            public string ModName { get; set; }
            public bool IsEnabled { get; set; }
            public float SettingIndex { get; set; }
        }

        public class Config
        {
            public string Id { get; set; }
            public string CreatorName { get; set; }
            public string ConfigName { get; set; }
            public string ConfigString { get; set; }
            public string LastUpdated { get; set; }
            public bool Private { get; set; }
        }

        public class Response
        {
            public bool Success { get; set; }
            public List<Config> Configs { get; set; }
        }
    }
}
