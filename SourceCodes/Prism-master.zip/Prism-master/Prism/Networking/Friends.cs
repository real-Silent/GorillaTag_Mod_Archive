﻿using Prism.WristMenu;
using System;
using Newtonsoft.Json;
using UnityEngine;
using System.Text;
using System.Net.Http;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Prism.Utility;
using UnityEngine.PlayerLoop;

namespace Prism.Networking
{
    public class Friends
    {
        public static string SendFriendRequest(string key, int friendUid)
        {
            string url = "http://45.55.74.63:3000/friend";

            var requestPayload = new
            {
                key = key,
                friendUid = friendUid
            };

            return SendPostRequest(url, requestPayload);
        }

        public class FriendsResponse
        {
            public bool Success { get; set; }
            public List<Friend> Friends { get; set; } // List of all friends
            public string Message { get; set; } // For error messages
        }

        public class FriendRequestsResponse
        {
            public bool Success { get; set; }
            public List<Friend> FriendRequests { get; set; } // This will store both sent and received friend requests
            public string Message { get; set; } // For error messages
        }

        public class Friend
        {
            public int UserId { get; set; }
            public string DiscordId { get; set; }
            public string CurrentRoom { get; set; }
            public bool Online { get; set; }
        }

        public static FriendsResponse friends = null;

        public static FriendsResponse GetAllFriends(string key)
        {
            if (friends != null)
            {
                return friends;
            }
            string url = "http://45.55.74.63:3000/get-friends";

            var requestPayload = new
            {
                key = key
            };

            string jsonResponse = SendPostRequest(url, requestPayload);

            if (jsonResponse == "Error")
            {
                return new FriendsResponse { Success = false, Message = "Request failed." };
            }
            friends = JsonConvert.DeserializeObject<FriendsResponse>(jsonResponse);
            return JsonConvert.DeserializeObject<FriendsResponse>(jsonResponse);
        }

        public static FriendRequestsResponse friendRequests = null;
        public static FriendRequestsResponse GetFriendRequests(string key)
        {
            if (friendRequests != null)
            {
                return friendRequests;
            }
            string url = "http://45.55.74.63:3000/friend-requests";

            var requestPayload = new
            {
                key = key
            };

            string jsonResponse = SendPostRequest(url, requestPayload);

            if (jsonResponse == "Error")
            {
                return new FriendRequestsResponse { Success = false, Message = "Request failed." };
            }

            friendRequests = JsonConvert.DeserializeObject<FriendRequestsResponse>(jsonResponse);
            return JsonConvert.DeserializeObject<FriendRequestsResponse>(jsonResponse);
        }

        public static string AcceptFriendRequest(string key, int friendUid)
        {
            string url = "http://45.55.74.63:3000/accept-friend";

            var requestPayload = new
            {
                key = key,
                friendUid = friendUid
            };

            return SendPostRequest(url, requestPayload);
        }


        public static string GetCurrentRoom(int uid)
        {
            string url = "http://45.55.74.63:3000/current-room";

            var requestPayload = new
            {
                uid = uid
            };

            return SendPostRequest(url, requestPayload);
        }

        private static string SendPostRequest(string url, object requestPayload)
        {
            StringContent stringContent = new StringContent(JsonConvert.SerializeObject(requestPayload), Encoding.UTF8, "application/json");
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage result;

            try
            {
                result = httpClient.PostAsync(url, stringContent).Result;
            }
            catch (Exception ex)
            {
                Injection.FatalError("Error contacting server: " + ex.Message, true);
                return "Error";
            } 

            string resultContent = result.Content.ReadAsStringAsync().Result;

            if (!result.IsSuccessStatusCode)
            {
                Injection.FatalError("Request Failed: " + resultContent, true);
                return "Error";
            }

            return resultContent;
        }

    }
}
