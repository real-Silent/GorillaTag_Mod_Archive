﻿using Prism.Mods;
using Prism.Patches;
using Prism.Utility;
using UnityEngine;

namespace Prism.WristMenu
{
    internal class ModHandler : MonoBehaviour
    {
        internal static Category currentCategory = Category.Home;
        internal static int currentPage = 0;
        public enum Category
        {
            Home,
            Settings,
            MenuPrefs,
            ModPrefs,
            Room,
            Movement,
            Impact,
            VRRig,
            Visual,
            GameMode,
            Master,
            World,
            Misc,
            Projectile,
            Abusive,
        }
        internal static ButtonHandler[] ogButtons = null;

        internal static ButtonHandler[] buttons = new ButtonHandler[]
        {
            #region CATEGORIES
            ButtonHandler.CreateButton("Settings", Category.Home, false, false, ()=>MenuHandler.ChangeCategory(Category.Settings), null, false, ""),
            ButtonHandler.CreateButton("Room", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Room), null, false),
            ButtonHandler.CreateButton("Movement", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Movement), null, false),
            ButtonHandler.CreateButton("Impact", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Impact), null, false),
            ButtonHandler.CreateButton("VRRig", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.VRRig), null, false),
            ButtonHandler.CreateButton("Visual", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Visual), null, false),
            ButtonHandler.CreateButton("GameMode", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.GameMode), null, false),
            ButtonHandler.CreateButton("Master", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Master), null, false),
            ButtonHandler.CreateButton("World", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.World), null, false),
            ButtonHandler.CreateButton("Misc", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Misc), null, false),
            ButtonHandler.CreateButton("Projectile", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Projectile), null, false),
            ButtonHandler.CreateButton("<color=red>Abusive</color>", Category.Home, false, false, ()=> MenuHandler.ChangeCategory(Category.Abusive), null, false, "<color=red>Be Aware.</color>"),
            #endregion


            #region SETTINGS
            ButtonHandler.CreateButton("Menu Settings", Category.Settings, false, false, ()=> MenuHandler.ChangeCategory(Category.MenuPrefs), null, false),
            ButtonHandler.CreateButton("Mod Settings", Category.Settings, false, false, ()=> MenuHandler.ChangeCategory(Category.ModPrefs), null, false),
            #endregion


            #region MENU SETTINGS
            ButtonHandler.CreateButton("Menu Theme: Dark", Category.MenuPrefs, false, false, ()=> Settings.MenuTheme(), null, false, "", 0),
            ButtonHandler.CreateButton("Menu Hand: [Left]", Category.MenuPrefs, false, false, ()=> Settings.MenuHand(), null, false, "", 1),
            ButtonHandler.CreateButton("Menu Input: [X]", Category.MenuPrefs, false, false, ()=> Settings.OpenButton(), null, false, "", 1),
            ButtonHandler.CreateButton("Menu Sound: [CS]", Category.MenuPrefs, false, false, ()=> Settings.MenuSounds(), null, false, "", 1),
            ButtonHandler.CreateButton("Menu Draw: [Toggle]", Category.MenuPrefs, false, false, ()=>Settings.MenuOpen(), null, false, "", 1),
            ButtonHandler.CreateButton("Notifs: [Enabled]", Category.MenuPrefs, false, false, ()=>Settings.NotifOn(), null, false, "", 1),
            #endregion


            #region MOD SETTINGS
            ButtonHandler.CreateButton("AntiReport: [Leave]", Category.ModPrefs, false, false, ()=> Settings.AntiReport_Setting(), null, false, "", 1, "AntiReport"),
            ButtonHandler.CreateButton("ESP: [GameMode]", Category.ModPrefs, false, false, ()=> Settings.ESP_Color(), null, false, "", 1, "ESP"),
            ButtonHandler.CreateButton("Plats: [Normal]", Category.ModPrefs, false, false, ()=> Settings.PlatForm_Setting(), null, false, "", 1, "Platforms"),
            ButtonHandler.CreateButton("Plat Input: [Grip]", Category.ModPrefs, false, false, ()=> Settings.PlatInput_Setting(), null, false, "", 1, "Platforms"),
            ButtonHandler.CreateButton("Fly's: [Normal]", Category.ModPrefs, false, false, ()=> Settings.Fly_Setting(), null, false, "", 1, "Fly"),
            ButtonHandler.CreateButton("Wall Walk: [Normal]", Category.ModPrefs, false, false, ()=>Settings.WallWalk_Setting(), null, false, "", 1, "Wall Walk"),
            ButtonHandler.CreateButton("SpeedBoost: [Semi]", Category.ModPrefs, false, false, ()=> Settings.Speed_Setting(), null, false, "", 1, "Speed Boost"),
            ButtonHandler.CreateButton("Tag Aura: [Grip]", Category.ModPrefs, false, false, ()=> Settings.TagAura_Setting(), null, false, "", 1, "Tag"),
            ButtonHandler.CreateButton("Proj Color: [White]", Category.ModPrefs, false, false, ()=> Settings.ProjColor_Setting(), null, false, "", 1, "Proj"),
            ButtonHandler.CreateButton("Proj Type: [Snow]", Category.ModPrefs, false, false, ()=> Settings.ProjType_Setting(), null, false, "", 1, "Proj"),
            ButtonHandler.CreateButton("Proj Speed: [Normal]", Category.ModPrefs, false, false, ()=>Settings.ProjVelSpeed_Setting(), null, false, "", 1, "Proj"),
            ButtonHandler.CreateButton("Proj Trail: [NONE]", Category.ModPrefs, false, false, ()=> Settings.ProjTrail_Setting(), null, false, "", 1, "Proj"),
            ButtonHandler.CreateButton("Tag Type: [Spaz]", Category.ModPrefs, false, false, ()=>Settings.TagStrafe_Setting(), null, false, "", 3, "Tag"),
            #endregion


            #region ROOM MODS
            ButtonHandler.CreateButton("AntiReport", Category.Room, true, true, ()=> RoomMods.AntiReport(), null, false, "Prevents people from reporting you on the leaderboard"),
            ButtonHandler.CreateButton("Oculus AntiReport", Category.Room, true, false, ()=> RoomMods.OculusAntiReport(), null, false, "Prevent people from reporting you in the oculus overlay"),
            ButtonHandler.CreateButton("Create Public", Category.Room, false, false, ()=> RoomMods.Create_Public(), null, false, "<color=green>Creates a public lobby</color>"),
            ButtonHandler.CreateButton("Create Private", Category.Room, false, false, ()=> RoomMods.Create_Private(), null, false, "<color=green>Creates a private lobby</color>"),
            ButtonHandler.CreateButton("Disconnect [X/Y]", Category.Room, true, false, ()=> RoomMods.AttemptDisc(), null, false, "<color=green>Right Face Buttons to Disconnect</color>"),
            ButtonHandler.CreateButton("Gamemode to Casual", Category.Room, false, false, ()=> RoomMods.GameModeManager(0), null, false, "<color=green>Change the gamemode</color>"),
            ButtonHandler.CreateButton("Gamemode to Infection", Category.Room, false, false, ()=> RoomMods.GameModeManager(1), null, false, "<color=green>Change the gamemode</color>"),
            ButtonHandler.CreateButton("Gamemode to Hunt", Category.Room, false, false, ()=> RoomMods.GameModeManager(2), null, false, "<color=green>Change the gamemode</color>"),
            ButtonHandler.CreateButton("Gamemode to Battle", Category.Room, false, false, ()=> RoomMods.GameModeManager(3), null, false, "<color=green>Change the gamemode</color>"),
            ButtonHandler.CreateButton("Disable Net Trigs [CS]", Category.Room, true, false, ()=> RoomMods.NoLobbyLeave(false), ()=> RoomMods.NoLobbyLeave(true), false, "<color=green>Disconnect Barriers Obsolete</color>"),
            ButtonHandler.CreateButton("Anti-Mod", Category.Room, true, false, ()=> RoomMods.AntiModerator(), null, false, "<color=green>Consistantly Checking for 'Stick' to avoid moderator bans</color>"),
            ButtonHandler.CreateButton("Lobby Hop [X/Y]", Category.Room, true, false, ()=> RoomManager.LobbyJoiner(), null, false, "Click [X] to Join a new Lobby"),
            #endregion


            #region MOVEMENT MODS
            ButtonHandler.CreateButton("Platforms", Category.Movement, true, false, ()=> MovementMods.Platforms(), null, false, "<color=green>The Basic Mod.</color>"),
            ButtonHandler.CreateButton("Teleport Gun", Category.Movement, true, false, ()=> MovementMods.TeleportGun(), ()=> GunLib.GunCleanUp(), false, "<color=green>Classic TP Gun W/Accuracy</color>"),
            ButtonHandler.CreateButton("Wall Walk", Category.Movement, true, false, ()=> MovementMods.WallWalk(), null, false, "Become a Pro on Walls"),
            ButtonHandler.CreateButton("Fake Lag", Category.Movement, true, false, ()=> MovementMods.FakeLag(true), ()=> MovementMods.FakeLag(false), false, "Make it look like your lagging"),
            ButtonHandler.CreateButton("Spider Monke", Category.Movement, true, false, ()=> MovementMods.SpiderMonke(), null, false, "Shoot Webs like Spiderman"),
            ButtonHandler.CreateButton("Fly", Category.Movement, true, false, ()=> MovementMods.Fly(), null, false, "<color=green>[A] to Fly</color>"),
            ButtonHandler.CreateButton("Velocity Fly", Category.Movement, true, false, ()=> MovementMods.VelFly(), null, false, "<color=green>Fly while maintaining velocity</color>"),
            ButtonHandler.CreateButton("Speed Boost", Category.Movement, true, false, ()=> MovementMods.SpeedBoost(), null, false, "<color=green>Customizeable speed</color>"),
            ButtonHandler.CreateButton("No Clip [LT]", Category.Movement, true, false, ()=> MovementMods.NoClip(), ()=> MovementMods.DisableNoClip(), false, "Phase through Constructed Objects"),
            ButtonHandler.CreateButton("Slide Control", Category.Movement, true, false, ()=> MovementMods.SlideControl(1.5f), ()=> MovementMods.SlideControl(0.00425f), false, "Increments Control multiplier"),
            ButtonHandler.CreateButton("Long Arms", Category.Movement, true, false, ()=> MovementMods.LongArms(1.35f), ()=> MovementMods.LongArms(1f), false, "<color=green>Arm Modifier Set to x1.25</color>"),
            ButtonHandler.CreateButton("CheckPoint", Category.Movement, true, false, ()=> MovementMods.ProcessCheckPoint(true), ()=> MovementMods.ProcessCheckPoint(false), false, "<color=green>Set a TP'able Positon</color>"),
            ButtonHandler.CreateButton("C4", Category.Movement, true, false, ()=> MovementMods.LeanBom(true), ()=> MovementMods.LeanBom(false), false, "<color=green>Creates an Explosive</color>"),
            ButtonHandler.CreateButton("Air Strike", Category.Movement, true, false, ()=> MovementMods.AirStrike(), ()=>GunLib.GunCleanUp(), false, "<color=green>Launch yourself through Explosive Force</color>"),
            ButtonHandler.CreateButton("Grapple Hook", Category.Movement, true, false, ()=> MovementMods.GrappleHook(), ()=> GunLib.GunCleanUp(), false, "<color=green>Grapple torwards Selected Point</color>"),
            ButtonHandler.CreateButton("Iron Monke", Category.Movement, true, false, ()=> MovementMods.IronMonke(), null, false, "<color=green>Become Iron Man [Grips]</color>"),
            ButtonHandler.CreateButton("Up & Down", Category.Movement, true, false, ()=> MovementMods.UPNDOWN(), null, false, "<color=green>Up & Down Force [Trigger]</color>"),
            ButtonHandler.CreateButton("Car Monke", Category.Movement, true, false, ()=> MovementMods.CarMonke(), null, false, "<color=green>Simulate Car Movement</color>"),
            ButtonHandler.CreateButton("TP Random [A/B]", Category.Movement, true, false, ()=> MovementMods.TpRandom(), null, false, "<color=green>Teleporting to Random Player...</color>"),
            ButtonHandler.CreateButton("Punch Mod", Category.Movement, true, false, ()=> MovementMods.PunchMod(), null, false, "<color=green>It's Legal.</color>"),
            ButtonHandler.CreateButton("Bunny Hop [RT/W]", Category.Movement, true, false, ()=> MovementMods.BunnyHop(), null, false, "<color=green>Famous CSGO Trick</color>"),
            ButtonHandler.CreateButton("Frozone", Category.Movement, true, false, ()=> MovementMods.Frozone(), null, false, "<color=green>'Honey, Where's my Super Suit?'</color>"),
            ButtonHandler.CreateButton("45Hz", Category.Movement, true, false, ()=> MovementMods.Hertz(), null, false, "<color=green>Reduce your Hz Count</color>"),
            ButtonHandler.CreateButton("No Gravity", Category.Movement, true, false, ()=> MovementMods.GravityChanger("none"), ()=> MovementMods.GravityChanger("reset"), false, "Local Gravity Set to 0"),
            ButtonHandler.CreateButton("Low Gravity", Category.Movement, true, false, ()=> MovementMods.GravityChanger("moon"), ()=> MovementMods.GravityChanger("reset"), false, "Local Gravity Set to - 4"),
            ButtonHandler.CreateButton("High Gravity", Category.Movement, true, false, ()=> MovementMods.GravityChanger("high"), ()=> MovementMods.GravityChanger("reset"), false, "Local Gravity Set to - 28"),
            ButtonHandler.CreateButton("Fast Swim", Category.Movement, true, false, ()=> MovementMods.FastSwim(1.05f), ()=> MovementMods.FastSwim(1f), false, "Velocity Set to 1.05"),
            ButtonHandler.CreateButton("Speedy Brr", Category.Movement, true, false, ()=> MovementMods.SpeedyFuckyou(-2), ()=> MovementMods.SpeedyFuckyou(0), false, "LocalPlayer Drag set to -2"),
            #endregion


            #region IMPACT MODS
            ButtonHandler.CreateButton("Impact Self", Category.Impact, true, false, ()=> ImpactMods.ImpactSelf(), null, false, "<color=green>Create an Impact on Yourself</color>"),
            ButtonHandler.CreateButton("Pom Poms", Category.Impact, true, false, ()=> ImpactMods.ImpactPomPoms(), null, false, "<color=green>Gives Player Pom Poms</color>"),
            ButtonHandler.CreateButton("Impact Aura", Category.Impact, true, false, ()=> ImpactMods.ImpactAura(), null, false, "<color=green>Particles Spawn around You</color>"),
            ButtonHandler.CreateButton("Impact Orbit", Category.Impact, true, false, ()=> ImpactMods.ImpactOrbit(), null, false, "<color=green>Create an Orbit around your Player</color>"),
            ButtonHandler.CreateButton("Impact All", Category.Impact, true, false, ()=> ImpactMods.ImpactAll(), null, false, "<color=green>Create Impact on All Players</color>"),
            ButtonHandler.CreateButton("Impact Gun", Category.Impact, true, false, ()=> ImpactMods.ImpactGun(), ()=> GunLib.GunCleanUp(), false, "<color=green>Impact a Specific Player</color>"),
            ButtonHandler.CreateButton("Give Pom Poms", Category.Impact, true, false, ()=>ImpactMods.GivePomPoms(), ()=>GunLib.GunCleanUp(), false, "<color=green>Give Other Pom Poms</color>"),
            ButtonHandler.CreateButton("Give Aura", Category.Impact, true, false, ()=> ImpactMods.GiveAura(), ()=> GunLib.GunCleanUp(), false, "<color=green>Give Other Aura</color>"),
            ButtonHandler.CreateButton("Give Orbit", Category.Impact, true, false, ()=> ImpactMods.GiveOrbit(), ()=> GunLib.GunCleanUp(), false, "<color=green>Give Other Orbit</color>"),
            #endregion


            #region VRRIG MODS
            ButtonHandler.CreateButton("Ghost Monke [A/E]", Category.VRRig, true, false, ()=> VRRigMods.ToggleVRRig(1), null, false, "Disable You're VRRig"),
            ButtonHandler.CreateButton("Invis Monke [A/E]", Category.VRRig, true, false, ()=> VRRigMods.ToggleVRRig(2), null, false, "Put VRRig Outside the Map"),
            ButtonHandler.CreateButton("RGB Monke", Category.VRRig, true, false, ()=> VRRigMods.RainbowMonk(0.006f), ()=> VRRigMods.ResetColor(), false, "Slow-Paced Rainbow Effect"),
            ButtonHandler.CreateButton("Strobe Monke", Category.VRRig, true, false, ()=> VRRigMods.RainbowMonk(0.06f), ()=> VRRigMods.ResetColor(), false, "Fast-Paced Rainbow Effect"),
            ButtonHandler.CreateButton("Look At Nearest [A/E]", Category.VRRig, true, false, ()=> VRRigMods.ToggleVRRig(3), ()=> VRRigMods.ResetVRRig(), false, "Look at the Nearest VRRig"),
            ButtonHandler.CreateButton("Steal Player", Category.VRRig, true, false, ()=> VRRigMods.StealPlayer(), ()=> GunLib.GunCleanUp(), false, "Steal Selected Players Color & Name"),
            ButtonHandler.CreateButton("Hold Rig [RG]", Category.VRRig, true, false, ()=> VRRigMods.HoldRig(), null, false, "Hold You're Mini Rig Replica"),
            ButtonHandler.CreateButton("Copy Player Gun", Category.VRRig, true, false, ()=> VRRigMods.CopyPlayer(), ()=> GunLib.GunCleanUp(), false, "Follow a VRRig"),
            ButtonHandler.CreateButton("Lucy Gun", Category.VRRig, true, false, ()=> VRRigMods.LucyGun(), ()=> GunLib.GunCleanUp(), false, "Replicate Lucy on a Target"),
            ButtonHandler.CreateButton("Orbit Gun", Category.VRRig, true, false, ()=>VRRigMods.OrbitGun(), ()=> GunLib.GunCleanUp(), false, "Orbit Selected Player"),
            ButtonHandler.CreateButton("Rig Gun", Category.VRRig, true, false, ()=> VRRigMods.RigGun(), ()=> GunLib.GunCleanUp(), false, "Push your VRRig any Direction"),
            ButtonHandler.CreateButton("Ghost Walk [A/E]", Category.VRRig, true, false, ()=> VRRigMods.ToggleVRRig(4), null, false, "Break all VRRig kinematics"),
            ButtonHandler.CreateButton("Frozen Ghost Walk [A/E]", Category.VRRig, true, false, ()=> VRRigMods.ToggleVRRig(5), null, false, "Schizophrenic VRRig"),
            ButtonHandler.CreateButton("Helicopter Monke [A/E]", Category.VRRig, true, false, ()=> VRRigMods.ToggleVRRig(6), null, false, "A Very simplistic feature."),
            ButtonHandler.CreateButton("Head Spin X", Category.VRRig, true, false, ()=> VRRigMods.HeadSpin("x"), ()=> VRRigMods.ResetVRRig(), false, "Spin on the X Axis"),
            ButtonHandler.CreateButton("Head Spin Y", Category.VRRig, true, false, ()=> VRRigMods.HeadSpin("y"), ()=> VRRigMods.ResetVRRig(), false, "Spin on the Y Axis"),
            ButtonHandler.CreateButton("Head Spin Z", Category.VRRig, true, false, ()=> VRRigMods.HeadSpin("z"), ()=> VRRigMods.ResetVRRig(), false, "Spin on the Z Axis"),
            ButtonHandler.CreateButton("Upside-Down Head", Category.VRRig, true, false, ()=> VRRigMods.HeadSpin("REVERSE"), ()=> VRRigMods.ResetVRRig(), false, "Head Scale Reversed"),
            ButtonHandler.CreateButton("Backwards Head", Category.VRRig, true, false, ()=> VRRigMods.HeadSpin("back"), ()=> VRRigMods.ResetVRRig(), false, "Backwards Head Scale"),
            ButtonHandler.CreateButton("Big Monke", Category.VRRig, true, false, ()=>VRRigMods.ToggleVRRig(7, 4), ()=>VRRigMods.ToggleVRRig(7, 1), false, "LocalScale set to '4'"),
            ButtonHandler.CreateButton("Small Monke", Category.VRRig, true, false, ()=>VRRigMods.ToggleVRRig(7, 0.6f), ()=>VRRigMods.ToggleVRRig(7, 1), false, "LocalScale set to '.6'"),
            ButtonHandler.CreateButton("Solid Monkeys", Category.VRRig, true, false, ()=>VRRigMods.SolidMonkeys(), null, false, "Players have colliders"),
            ButtonHandler.CreateButton("Replay", Category.VRRig, true, false, ()=>VRRigMods.Replay(), ()=>VRRigMods.disableReverseReplay(), false, "Hold grip to make macro"),
            ButtonHandler.CreateButton("Reverse", Category.VRRig, true, false, ()=>VRRigMods.Reverse(), ()=>VRRigMods.disableReverseReplay(), false, "Hold grip to reverse since you opened"),
            #endregion      


            #region VISUAL MODS
            ButtonHandler.CreateButton("Chams", Category.Visual, true, false, ()=> VisualMods.Chams(), ()=> VisualMods.ResetESP(), false, "Full Body ESP"),
            ButtonHandler.CreateButton("Tracers", Category.Visual, true, false, ()=> VisualMods.Tracers(), ()=> VisualMods.ResetESP(), false, "LineRenderer Towards all Players"),
            ButtonHandler.CreateButton("Boxes", Category.Visual, true, false, ()=> VisualMods.BoxESP(), ()=> VisualMods.ResetESP(), false, "Draws a 2D box around all Players"),
            ButtonHandler.CreateButton("Skeletons", Category.Visual, true, false, ()=> VisualMods.BoneESP(), ()=> VisualMods.ResetESP(), false, "Draws a Skeleton Replica"),
            ButtonHandler.CreateButton("WireFrame", Category.Visual, true, false, ()=> VisualMods.VRRigHitCube(), ()=> VisualMods.ResetESP(), false, "Coming Soon.."),
            ButtonHandler.CreateButton("Name Tags", Category.Visual, true, false, ()=> VisualMods.NameTagESP(true), ()=> VisualMods.NameTagESP(false), false, "Gives all Players Overhead NameTags"),
            ButtonHandler.CreateButton("Graphic Reducer", Category.Visual, true, false, ()=> QualitySettings.masterTextureLimit = 7, ()=> QualitySettings.masterTextureLimit = 0, false, "Low Graphics/Smooth Game"),
            #endregion


            #region INFECTION MODS
            ButtonHandler.CreateButton("Tag Self", Category.GameMode, true, false, ()=> InfectionMods.TagSelf(), ()=> VRRigMods.ResetVRRig(), false, "Infect Yourself"),
            ButtonHandler.CreateButton("Tag Gun", Category.GameMode, true, false, ()=> InfectionMods.TagGun(), ()=> GunLib.GunCleanUp(), false, "Tag Selected Player"),
            ButtonHandler.CreateButton("Tag Aura [RG]", Category.GameMode, true, false, ()=> InfectionMods.TagAura(true), ()=> InfectionMods.TagAura(false), false, "Tag all Nearby"),
            ButtonHandler.CreateButton("Tag All", Category.GameMode, true, false, ()=> InfectionMods.TagAll(), ()=> VRRigMods.ResetVRRig(), false, "Tag All Untagged VRRigs"),
            ButtonHandler.CreateButton("Anti Tag", Category.GameMode, true, false, ()=> InfectionMods.AntiTag(), ()=> VRRigMods.ResetVRRig(), false, "Evade receiving Tags"),
            ButtonHandler.CreateButton("No Tag On Join", Category.GameMode, true, false, ()=> InfectionMods.NoTagOnJoin(), null, false, "Join a Server Untagged"),
            #endregion


            #region MASTER MODS
            ButtonHandler.CreateButton("Mat Spam All", Category.Master, true, false, ()=> MasterMods.MatSpamAll(), null, false, "Cycle Through infected States"),
            ButtonHandler.CreateButton("Mat Spam Gun", Category.Master, true, false, ()=> MasterMods.MatGun(), ()=> GunLib.GunCleanUp(), false, "Cycle Players infection states"),
            ButtonHandler.CreateButton("Mat Spam Self", Category.Master, true, false, ()=> MasterMods.MatSpamSelf(), null, false, "Cycle Personal infection States"),
            ButtonHandler.CreateButton("Mat Spam on Touch", Category.Master, true, false, ()=> MasterMods.MatSpamOnTouch(), null, false, "Cycle infection states while Touching"),
            ButtonHandler.CreateButton("Tag Lag", Category.Master, true, false, ()=> MasterMods.TagCountThing(999999999), ()=> MasterMods.TagCountThing(5), false, "Tag Cooldown Set to 999999"),
            ButtonHandler.CreateButton("No Tag Cooldown", Category.Master, true, false, ()=> MasterMods.TagCountThing(0), ()=> MasterMods.TagCountThing(5), false, "Tag Cooldown Set to 0"),
            ButtonHandler.CreateButton("Untag All", Category.Master, false, false, ()=> MasterMods.UntagAll(), null, false, "Untagged all Tagged Players"),
            ButtonHandler.CreateButton("Untag Gun", Category.Master, true, false, ()=> MasterMods.UntagGun(), ()=> GunLib.GunCleanUp(), false, "Untag Selected Player"),
            ButtonHandler.CreateButton("Untag Self", Category.Master, false, false, ()=> MasterMods.UntagSelf(), null, false, "Untagged LocalPlayer"),
            ButtonHandler.CreateButton("Untag on Touch", Category.Master, true, false, ()=> MasterMods.UntagThingy(), null, false, "Touch to Untag Any Player"),
            ButtonHandler.CreateButton("Slow All", Category.Master, true, false, ()=> MasterMods.SlowAll(), null, false, "Slow All Players"),
            ButtonHandler.CreateButton("Slow Gun", Category.Master, true, false, ()=> MasterMods.SlowGun(), ()=> GunLib.GunCleanUp(), false, "Slow Selected Player"),
            ButtonHandler.CreateButton("Vibrate All", Category.Master, true, false, ()=> MasterMods.VibrateAll(), null, false, "Vibrate All Players"),
            ButtonHandler.CreateButton("Vibrate Gun", Category.Master, true, false, ()=> MasterMods.VibrateGun(), ()=> GunLib.GunCleanUp(), false, "Vibrate Selected Player"),
            ButtonHandler.CreateButton("Ballon Spam All", Category.Master, true, false, ()=> MasterMods.SpamBalloonsAll(), null, false, "Cycle all Balloon Counts"),
            ButtonHandler.CreateButton("Ballon Spam Gun", Category.Master, true, false, ()=> MasterMods.SpamBalloonsGun(), ()=> GunLib.GunCleanUp(), false, "Cycle Players Balloon Count"),
            ButtonHandler.CreateButton("Ballon Spam Self", Category.Master, true, false, ()=> MasterMods.SpamBalloonsSelf(), null, false, "Cycle Personal Balloon Count"),
            ButtonHandler.CreateButton("Ballon Spam on Touch", Category.Master, true, false, ()=> MasterMods.SpamBalloonsThing(), null, false, "Cycle Players Balloon Count"),
            ButtonHandler.CreateButton("Spazz Teams", Category.Master, true, false, ()=>GorillaGameManager.instance.GetComponent<GorillaBattleManager>().RandomizeTeams(), null, false, "Spazz Random Teams"),
            ButtonHandler.CreateButton("God Mode All", Category.Master, false, false, ()=> MasterMods.GodModeAll(), null, false, "All Lives set to int.MaxValue"),
            ButtonHandler.CreateButton("God Mode Gun", Category.Master, true, false, ()=> MasterMods.GodModeGun(), ()=> GunLib.GunCleanUp(), false, "Selected Player set to int.MaxValue"),
            ButtonHandler.CreateButton("Kill All", Category.Master, false, false, ()=> MasterMods.KillAll(), null, false, "All Lives set to 0"),
            ButtonHandler.CreateButton("Kill Gun", Category.Master, true, false, ()=> MasterMods.KillGun(), ()=> GunLib.GunCleanUp(), false, "Selected Player set to 0"),
            ButtonHandler.CreateButton("Master Sound 1", Category.Master, true, false, ()=> MasterMods.SendSound(0, 0.9f), null, false, "Master Sound Spam 1"),
            ButtonHandler.CreateButton("Master Sound 2", Category.Master, true, false, ()=> MasterMods.SendSound(1, 0.9f), null, false, "Master Sound Spam 2"),
            ButtonHandler.CreateButton("Master Sound 3", Category.Master, true, false, ()=> MasterMods.SendSound(2, 0.9f), null, false, "Master Sound Spam 3"),
            ButtonHandler.CreateButton("Master Sound 4", Category.Master, true, false, ()=> MasterMods.SendSound(5, 0.9f), null, false, "Master Sound Spam 4"),
            ButtonHandler.CreateButton("Master Sound 5", Category.Master, true, false, ()=> MasterMods.SendSound(6, 0.9f), null, false, "Master Sound Spam 5"),
            #endregion
             

            #region WORLD MODS
            ButtonHandler.CreateButton("Ropes Up", Category.World, true, false, ()=> WorldMods.RopeUp(), null, false, "Drag all Ropes Upwards"),
            ButtonHandler.CreateButton("Ropes Down", Category.World, true, false, ()=> WorldMods.RopeDown(), null, false, "Drag all Ropes Downwards"),
            ButtonHandler.CreateButton("Ropes Spaz", Category.World, true, false, ()=> WorldMods.RopeSpaz(), null, false, "Spaz All Ropes"),
            ButtonHandler.CreateButton("Ropes Freeze", Category.World, true, false, ()=> WorldMods.RopeFreeze(), null, false, "Freeze All current Ropes"),
            ButtonHandler.CreateButton("Ropes To Self", Category.World, true, false, ()=> WorldMods.RopeToSelf(), null, false, "Drag all Ropes towards LocaPlayer"),
            ButtonHandler.CreateButton("Ropes To Gun", Category.World, true, false, ()=> WorldMods.RopeGun(), ()=> GunLib.GunCleanUp(), false, "Drag Selected Towards Pointer"),
            ButtonHandler.CreateButton("Rope Spaz Gun", Category.World, true, false, ()=> WorldMods.SpazRopeGun(), ()=> GunLib.GunCleanUp(), false, "Spaz Selected Rope"),
            ButtonHandler.CreateButton("Ropes Freeze Gun", Category.World, true, false, ()=> WorldMods.RopeFreezeGun(), ()=> GunLib.GunCleanUp(), false, "Freeze Selected Rope"),
            ButtonHandler.CreateButton("Grab Gliders", Category.World, true, false, ()=>WorldMods.GrabGlider(), null, false, "[RG] to Collect all Gliders"),
            ButtonHandler.CreateButton("Glider Gun", Category.World, true, false, ()=> WorldMods.GliderGun(), ()=> GunLib.GunCleanUp(), false, "Force Gliders to Selected Position"),
            ButtonHandler.CreateButton("Glider God", Category.World, true, false, ()=>WorldMods.GliderGod(), null, false, "Circle all Glider aboves You [CLOUDS]"),
            ButtonHandler.CreateButton("Blind All", Category.World, true, false, ()=> WorldMods.BlindAll(), null, false, "Blind Selected player [CLOUDS]"),
            ButtonHandler.CreateButton("Blind Gun", Category.World, true, false, ()=> WorldMods.BlindGun(), ()=> GunLib.GunCleanUp(), false, "Blind all players [CLOUDS]"),
            ButtonHandler.CreateButton("Hide Board", Category.World, true, false, ()=> WorldMods.HideBoard(), null, false, "Hide board [CLOUDS]"),
            ButtonHandler.CreateButton("Water Gun", Category.World, true, false, ()=> WorldMods.SplashGun(), null, false, "Spawn Water at your Gun"),
            ButtonHandler.CreateButton("Water Orbit", Category.World, true, false, ()=> WorldMods.SplashOrbit(), null, false, "Water around you"),
            ButtonHandler.CreateButton("Water Aura", Category.World, true, false, ()=> WorldMods.SplashAura(), null, false, "Water auring you"),
            #endregion


            #region MISC MODS
            ButtonHandler.CreateButton("Static Fingers", Category.Misc, true, false, ()=> MiscMods.StaticFinger(), null, false, "Remove Finger Movement"),
            ButtonHandler.CreateButton("Hide On Leaderboard", Category.Misc, true, false, ()=> MiscMods.HideOnLeaderboard(), null, false, "Hide LocaLPlayer"),
            ButtonHandler.CreateButton("Color Logger Gun", Category.Misc, true, false, ()=> MiscMods.ColorLogger(), ()=> GunLib.GunCleanUp(), false, "Grab Selected Players Color Code"),
            ButtonHandler.CreateButton("Set Name Nothing", Category.Misc, false, false, ()=> MiscMods.SetNameNothing(), null, false, "Set nothing as your Current Name"),
            ButtonHandler.CreateButton("Hold Rocket [RG]", Category.Misc, true, false, ()=> MiscMods.HoldRocket(), null, false, "Hold a Mini-Rocket Replica"),
            ButtonHandler.CreateButton("Panic", Category.Misc, false, false, ()=> MiscMods.Panic(), null, false, "Disable all active Buttons"),
            ButtonHandler.CreateButton("Leaderboard Spoof", Category.Misc, false, false, ()=> MiscMods.LeaderBoardSpoof(), null, false, "Change Name on Leaderboard"),
            ButtonHandler.CreateButton("Slingshot Self", Category.Misc, true, false, ()=> MiscMods.SlingshotSelf(), ()=> MiscMods.Unslingshot(), false, "Apply a Slingshot to LocalPlayer"),
            #endregion


            #region PROJECTILE MODS
            ButtonHandler.CreateButton("Projectile Spam", Category.Projectile, true, false, ()=> ProjectileMods.ProjectileSpam(), ()=> ProjectileMods.usingMinigun = false, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Projectile Gun", Category.Projectile, true, false, ()=> ProjectileMods.ProjectileGun(), ()=> GunLib.GunCleanUp(), false, "Settings for Customization"),
            ButtonHandler.CreateButton("Projectile Aura [RT]", Category.Projectile, true, false, ()=> ProjectileMods.ProjectileAura(), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Projectile Orbit [RT]", Category.Projectile, true, false, ()=> ProjectileMods.ProjectileOrbit(), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Slingshot Teleport", Category.Projectile, true, false, ()=> ProjectileMods.SlingshotTP(), ()=> ProjectileMods.DisableSlingshotTP(), false, "Teleport by shooting your slingshot"),
            ButtonHandler.CreateButton("Give Proj Gun", Category.Projectile, true, false, ()=> ProjectileMods.GiveProjectileGun(), ()=> GunLib.GunCleanUp(), false, "Settings for Customization"),
            ButtonHandler.CreateButton("Give Proj Aura Gun", Category.Projectile, true, false, ()=> ProjectileMods.GiveProjectileAuraGun(), ()=> GunLib.GunCleanUp(), false, "Settings for Customization"),
            ButtonHandler.CreateButton("Give Proj Orbit Gun", Category.Projectile, true, false, ()=> ProjectileMods.GiveProjectileOrbitGun(), ()=> GunLib.GunCleanUp(), false, "Settings for Customization"),
            ButtonHandler.CreateButton("Spout [RT]", Category.Projectile, true, false, ()=> ProjectileMods.Spout(), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Tunnel [RT]", Category.Projectile, true, false, ()=> ProjectileMods.Tunnel(), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Piss [RT]", Category.Projectile, true, false, ()=> ProjectileMods.BodilyWaste(GorillaLocomotion.Player.Instance.bodyCollider.transform.position + new Vector3(0f, -0.1f, 0f), 255, 255, 0), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Shit [RT]", Category.Projectile, true, false, ()=> ProjectileMods.Shit(), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Vomit [RT]", Category.Projectile, true, false, ()=> ProjectileMods.BodilyWaste(GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position, 0, 255, 0), null, false, "Settings for Customization"),
            ButtonHandler.CreateButton("Semen [RT]", Category.Projectile, true, false, ()=> ProjectileMods.BodilyWaste(GorillaLocomotion.Player.Instance.bodyCollider.transform.position + new Vector3(0f, -0.1f, 0f), 255, 255, 255), null, false, "Settings for Customization"),
            #endregion


            #region ABUSIVE MODS21
            ButtonHandler.CreateButton("Lag Gun", Category.Abusive, true, false, ()=> AbusiveMods.StutterGun(), ()=> GunLib.GunCleanUp(), false, "Stutter A Player"),
            ButtonHandler.CreateButton("Lag All", Category.Abusive, true, false, ()=> AbusiveMods.StutterAll(), null, false, "Stutter All Players"),
            ButtonHandler.CreateButton("Touch to Lag", Category.Abusive, true, false, ()=> AbusiveMods.TouchToStutter(), null, false, "Touch a Player"),
            ButtonHandler.CreateButton("Become The Lag", Category.Abusive, true, false, ()=>AbusiveMods.BecomeTheStutter(), null, false, "Players touch You to Stutter"),
            ButtonHandler.CreateButton("Kick Gun", Category.Abusive, true, false, ()=> AbusiveMods.KickGun(), ()=> GunLib.GunCleanUp(), false, "Kick a Player"),
            ButtonHandler.CreateButton("Touch to Kick", Category.Abusive, true, false, ()=> AbusiveMods.TouchToKick(), null, false, "Touch to Kick Selected Player"),
            #endregion
        };
    }
}