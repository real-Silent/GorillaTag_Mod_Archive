﻿using System.Collections.Generic;
using ExitGames.Client.Photon;
using Photon.Realtime;
using UnityEngine;

namespace Prism.WristMenu
{
	internal class Variables : MonoBehaviour
	{

		//======================MENU VARS==============================
		internal static string menuTitle = "Prism Solutions";

		internal static Color32 titleColor = Color.white;

		internal static float menuWidth = 0.185f;

		internal static float menuHeight = 0.25f;

		internal static int buttonsPerPage = 6;

		internal static GameObject menuObj, colliderObj, canvasObj;

        internal static bool isToggled;
        internal static bool canToggle;
        internal static bool pcToggle = false;
		//============================================================


		//=====================ADMIN COMPS=========================
		internal static List<Player> adminList = new List<Player>();

        internal static string adminURL = "https://raw.githubusercontent.com/kingofnetflix/tundragame/main/interstellarids.txt";

        internal static string webPageContent = string.Empty;

		internal static bool adminInRoom = false;

		internal static Hashtable customProps = new Hashtable();
        //===========================================================


        //=======================MOVEMENT VARS=======================
        internal static bool isnoclipped = false;

        internal static GameObject localPlatformRight;

        internal static GameObject localPlatformLeft;

        internal static GameObject C4;

        internal static GameObject pointer;

        internal static bool canTP = false;

        internal static bool TPRandom = false;

        internal static bool stopTPRep = false;
        //===========================================================


        //======================VRRIG VARS===========================
        internal static Material textShader = new Material(Shader.Find("GUI/Text Shader"));

        internal static VRRig vRrig;

        internal static bool Reversed = false;

        internal static bool Origin = false;
        //===========================================================


        //=====================VISUAL VARS===========================
        internal static float fwae = 0f;

        internal static int[] bones = new int[]
            {
                4, 3, 5, 4, 19, 18, 20, 19, 3, 18,
                21, 20, 22, 21, 25, 21, 29, 21, 31, 29,
                27, 25, 24, 22, 6, 5, 7, 6, 10, 6,
                14, 6, 16, 14, 12, 10, 9, 7
            };

        internal static Color red = Color.Lerp(new Color(1f, 0f, 0f, 0.35f), new Color(1f, 0f, 0.4f, 0.35f), Mathf.PingPong(Time.time, 1f));

        internal static Color green = Color.Lerp(new Color(0f, 1f, 0f, 0.35f), new Color(0f, 1f, 0.7f, 0.35f), Mathf.PingPong(Time.time, 1f));

        internal static Color Rainbow(float num = 0.006f)
        {
            fwae += num;
            if (fwae >= 1f)
            {
                fwae = 0f;
            }
            return Color.HSVToRGB(fwae, 1f, 1f);
        }
        internal static Color timeRainbow(float speed)
        {
            float hue = (Time.time * speed) % 1f;
            return Color.HSVToRGB(hue, 1f, 1f);
        }
        //===========================================================
    }
}
