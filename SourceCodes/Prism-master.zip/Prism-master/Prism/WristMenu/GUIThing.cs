﻿using UnityEngine;
using Cinemachine;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Prism.Networking;
using Prism.Mods;
using Prism.Patches;
using Prism.Utility;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine.InputSystem;
using WebSocketSharp;
using static Prism.WristMenu.ModHandler;
using System.Net;
using System.IO;

namespace Prism.WristMenu
{
    public class UI : BaseClass
    {
        private bool GUIShown = true, shouldHideRoom = false;

        public Rect window = new Rect(10, 10, 800, 500);

        public Vector2[] scroll = new Vector2[30];

        public static int Page = 0, Theme = 0;

        public static Texture2D infectedTexture = null, nonInfectedTexture = null, prismLogoTexture, cameraLogo, roomLogo, modOn, modsList, configsImage, friendsImage, themesImage, settingsImage, discordPFP;


        string[] pages = new string[]
        {
            "Modules", "Configs", "Room", "Friends", "Themes", "Settings", "Camera"
        };
        public static Player taggingPlayer = null;
        private static ModHandler.Category currentGUICategory = ModHandler.Category.Room;

        string roomStr = "text here", searchString = "", placeHoldertext = "Room Code Here", configNamer = "Name for config here";
        public static float deltaTime, fov = 60;

        public static Font myFont;
        private float speed = 10;
        private bool campause;
        public static bool freecam;
        public static bool firstPerson;
        private bool fpc;
        private static List<Configs.Config> configs = null;

        public static void SaveTexture(Texture2D texture, string nameOfImage)
        {
            var texture2D = texture.EncodeToPNG();
            File.WriteAllBytes(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Prism", nameOfImage + ".png"), texture2D);
        }
        public static readonly string basePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Prism");

        public static Texture2D LoadTexture(string filePath)
        {
            string filePath2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Prism", filePath);
            if (File.Exists(filePath2))
            {
                byte[] fileData = File.ReadAllBytes(filePath2);
                Texture2D texture = new Texture2D(2, 2);
                texture.LoadImage(fileData);
                Debug.Log("Texture loaded from " + filePath2);
                return texture;
            }
            else
            {
                Debug.LogError("File not found at " + filePath2);
                return null;
            }
        }

        public void Start()
        {
            try
            {
                if (!new WebClient().DownloadString("https://github.com/iaodevelop/hazeutilities/raw/main/hi.txt").Contains("="))
                {
                    if (Injection.FatalError("error3", true) == "CRASH")
                    {
                        Environment.FailFast("bye");
                        Application.Quit();
                    }
                }
                if (Injection.Authenticate() != "AGREE")
                {
                    Debug.Log("no");
                    if (Injection.FatalError("error3", true) == "CRASH")
                    {
                        Environment.FailFast("bye");
                        Application.Quit();
                    }
                }

                Injection.Ping();

                if (!Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Prism", "configsImage.txt")))
                {
                    UI.prismLogoTexture = PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/croped.png?raw=true");
                    UI.SaveTexture(UI.prismLogoTexture, "prismLogo");
                    UI.modOn = PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/8968524-3019950680.png?raw=true");
                    UI.SaveTexture(UI.modOn, "modOnImage");
                    UI.modsList = PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/1b6bcdef5a3d92572f517122650716be7ec6458b_prev_ui.png?raw=true");
                    UI.SaveTexture(UI.modsList, "modsListImage");
                    UI.configsImage = UI.UILib.ChangeTextureColor(PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/filemanager.png?raw=true"), Color.white);
                    UI.SaveTexture(UI.configsImage, "configsImage");
                    UI.friendsImage = UI.UILib.ChangeTextureColor(PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/friends.png?raw=true"), Color.white);
                    UI.SaveTexture(UI.friendsImage, "friendsImage");
                    UI.themesImage = UI.UILib.ChangeTextureColor(PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/brush.png?raw=true"), Color.white);
                    UI.SaveTexture(UI.themesImage, "themesImage");
                    UI.settingsImage = UI.UILib.ChangeTextureColor(PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/gear.png?raw=true"), Color.white);
                    UI.SaveTexture(UI.settingsImage, "settingsImage");
                    UI.cameraLogo = UI.UILib.ChangeTextureColor(PrismUtils.DownloadBackground("https://raw.githubusercontent.com/iaodevelop/hazeutilities/6c0a50bb9bf26d9776d033d486dce48174f1cb0c/camera.png"), Color.white);
                    UI.SaveTexture(UI.cameraLogo, "cameraLogo");
                    UI.roomLogo = UI.UILib.ChangeTextureColor(PrismUtils.DownloadBackground("https://github.com/iaodevelop/hazeutilities/blob/main/meeting.png?raw=true"), Color.white);
                    UI.SaveTexture(UI.roomLogo, "roomLogo");
                }
                else
                {
                    UI.prismLogoTexture = UI.LoadTexture("prismLogo.png");
                    UI.modOn = UI.LoadTexture("modOnImage.png");
                    UI.modsList = UI.LoadTexture("modsListImage.png");
                    UI.configsImage = UI.LoadTexture("configsImage.png");
                    UI.friendsImage = UI.LoadTexture("friendsImage.png");
                    UI.themesImage = UI.LoadTexture("themesImage.png");
                    UI.settingsImage = UI.LoadTexture("settingsImage.png");
                    UI.cameraLogo = UI.LoadTexture("cameraLogo.png");
                    UI.roomLogo = UI.LoadTexture("roomLogo.png");
                }


                string discordimagelink = Configs.GetDiscordImageLink();
                if (!discordimagelink.IsNullOrEmpty())
                {
                    discordPFP = PrismUtils.DownloadBackground(Configs.GetDiscordImageLink());
                }
                UILib.Init();
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }

        private static GameObject TPC = null;

        internal static void ChangeCam(bool firstPerson)
        {
            if (firstPerson)
            {
                firstPerson = false;
                return;
            }
            firstPerson = true;
            TPC.gameObject.transform.Find("CM vcam1").GetComponent<CinemachineVirtualCamera>().enabled = true;
            TPC.GetComponent<Camera>().fieldOfView = 110f;
            TPC.gameObject.transform.position = default(Vector3);
            TPC.gameObject.transform.rotation = default(Quaternion);
        }

        public static bool isfirstPersoned = false;

        public static float FOV = 110;

        public void Update()
        {
            if (prismLogoTexture == null)
            {
                Environment.FailFast("f");
                Application.Quit();
            }
            if (freecam)
            {
                MovementMods.AdvancedWASD(speed);
            }

            if (firstPerson)
            {
                if (TPC == null)
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera");
                }
                isfirstPersoned = true;
                TPC.gameObject.transform.Find("CM vcam1").GetComponent<CinemachineVirtualCamera>().enabled = false;
                TPC.GetComponent<Camera>().fieldOfView = FOV;
                TPC.gameObject.transform.position = GorillaTagger.Instance.headCollider.transform.position;
                TPC.gameObject.transform.rotation = Quaternion.Lerp(TPC.transform.rotation, GorillaTagger.Instance.headCollider.transform.rotation, 0.075f);
            }
            else
            {
                if (isfirstPersoned)
                {
                    isfirstPersoned = false;
                    ChangeCam(false);
                }
            }

            if (Keyboard.current[Key.RightShift].wasPressedThisFrame)
            {
                GUIShown = !GUIShown;
            }
        }

        public static void MakeFPC(bool refrence)
        {
            if (refrence)
            {
                if (GorillaTagger.Instance.thirdPersonCamera && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.SetActive(false);
                }
            }
            else
            {
                if (GorillaTagger.Instance.thirdPersonCamera && !GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.SetActive(true);
                }
            }
        }


        public static void PauseCam(bool refrence)
        {
            if (refrence)
            {
                if (GorillaTagger.Instance.thirdPersonCamera && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.SetActive(false);
                }
            }
            else
            {
                if (GorillaTagger.Instance.thirdPersonCamera && !GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.SetActive(true);
                }
            }
        }

        public void OnGUI()
        {
            if (!GUIShown)
                return;

            window = GUI.Window(1, window, Window, "");
        }

        public void Window(int id)
        {
            try
            {
                if (myFont == null)
                {
                    myFont = Font.CreateDynamicFontFromOSFont("Arial Rounded MT", 18);
                }
                UILib.SetTextures();

                GUI.DrawTexture(new Rect(0f, 0f, window.width, window.height), UILib.windowTexture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, new Vector4(6f, 6f, 6f, 6f));
                //GUI.DrawTexture(new Rect(0f, 0f, 200f, window.height), UILib.sidePannelTexture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, new Vector4(6f, 0f, 0f, 6f));
                UILib.DrawTabBar(new Rect(190f, 0f, 10, window.height), new Vector4(8f, 0f, 0f, 8f));
                GUIStyle lb = new GUIStyle(GUI.skin.label);
                lb.font = myFont;
                lb.fontStyle = FontStyle.Bold;
                lb.fontSize = 20;
                GUI.Label(new Rect(20, 5, 70, 70), prismLogoTexture);
                GUI.Label(new Rect(75, 30, window.width, 30), " Prism", lb);
                lb.fontSize = 12;
                GUI.Label(new Rect(85, 50, window.width, 30), " v" + CoolThing.Version, lb);

                GUILayout.BeginArea(new Rect(15f, 30, 200, window.height));
                GUILayout.BeginVertical();
                GUILayout.Space(30);
                for (int i = 0; i < pages.Length; i++)
                {
                    GUILayout.Space(20);
                    string page = pages[i];
                    if (UILib.RoundedPageButton(page, i, GUILayout.Width(160)))
                    {
                        Page = i;
                    }
                    if (i == 0)
                    {
                        GUI.Label(new Rect(10, 48, 35, 35), modsList);
                    }
                    else if (i == 1)
                    {
                        GUI.Label(new Rect(10, 93, 35, 35), configsImage);
                    }
                    else if (i == 2)
                    {
                        GUI.Label(new Rect(10, 136, 35, 35), roomLogo);
                    }
                    else if (i == 3)
                    {
                        GUI.Label(new Rect(10, 180, 35, 35), friendsImage);
                    }
                    else if (i == 4)
                    {
                        GUI.Label(new Rect(10, 229, 31, 31), themesImage);
                    }
                    else if (i == 5)
                    {
                        GUI.Label(new Rect(10, 275, 31, 31), settingsImage);
                    }
                    else if (i == 6)
                    {
                        GUI.Label(new Rect(10, 318, 35, 35), cameraLogo);
                    }
                }

                GUI.DrawTexture(new Rect(0f, 410f, 160f, 50), UILib.buttonTexture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, new Vector4(6f, 0f, 0f, 6f));
                GUI.Label(new Rect(10, 410, 50, 50), discordPFP);
                GUI.Label(new Rect(70, 410, window.width, 30), "@" + Configs.GetDiscordUsername(), lb);
                GUI.Label(new Rect(70, 430, window.width, 30), "uid: " + Configs.GetUID(Injection.key).ToString(), lb);
                
                GUILayout.EndVertical();
                GUILayout.EndArea();

                GUILayout.BeginArea(new Rect(115, 30, 900, window.height - 50));
                GUILayout.BeginVertical();
                switch (Page)
                {
                    case 0:
                        GUILayout.BeginHorizontal();
                        GUILayout.Space(120);

                        int currentCategoryNumber = 0;

                        foreach (object obj in Enum.GetValues(typeof(ModHandler.Category)))
                        {
                            Category changingtoCate = (Category)obj;

                            if (changingtoCate == Category.Settings ||
                                changingtoCate == Category.Home ||
                                changingtoCate == Category.ModPrefs ||
                                changingtoCate == Category.MenuPrefs)
                            {
                                continue;
                            }

                            if (currentCategoryNumber > 0 && currentCategoryNumber % 6 == 0)
                            {
                                GUILayout.EndHorizontal();
                                GUILayout.Space(10);
                                GUILayout.BeginHorizontal();
                                GUILayout.Space(170);
                            }
                            else
                            {
                                GUILayout.Space(2);
                            }

                            if (UILib.RoundedPageCategoryButton(obj.ToString(), changingtoCate, GUILayout.Width(80)))
                            {
                                currentGUICategory = changingtoCate;
                            }

                            currentCategoryNumber++;
                        }

                        GUILayout.EndHorizontal();

                        GUILayout.Space(20);
                        GUILayout.BeginHorizontal();
                        GUILayout.Space(180);
                        if (UILib.currentSettingButton == null)
                        {
                            GUIStyle textFieldStyle = GUI.skin.textField;
                            textFieldStyle.fontSize = 14;
                            textFieldStyle.alignment = TextAnchor.MiddleCenter;
                            searchString = GUILayout.TextField(searchString, textFieldStyle, GUILayout.Width(400), GUILayout.Height(20));

                            if (string.IsNullOrEmpty(searchString) && !GUI.GetNameOfFocusedControl().Equals("SearchField"))
                            {
                                GUIStyle ghostStyle = new GUIStyle(textFieldStyle);
                                ghostStyle.normal.textColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
                                GUI.SetNextControlName("SearchField");
                                GUI.Label(GUILayoutUtility.GetLastRect(), placeHoldertext, ghostStyle);
                            }
                            GUILayout.EndHorizontal();
                            if (UILib.RoundedButton2("Join Room"))
                            {
                                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(searchString.ToUpper(), JoinType.Solo);
                            }
                            scroll[0] = GUILayout.BeginScrollView(scroll[0]);
                            int currentButton = 0;
                            foreach (var bt in Settings.GetButtonInfoByPage(currentGUICategory))
                            {
                                var rect = GUILayoutUtility.GetRect(new GUIContent(bt.text), GUI.skin.button);
                                rect.x += 100;
                                rect.y = rect.y + (45 * currentButton);
                                rect.width -= 340;
                                rect.height += 45f;

                                if (UILib.RoundedToggleButton(bt.text, bt, rect))
                                {
                                    MenuHandler.ToggleButton(bt.text);
                                }
                                currentButton++;
                            }

                            GUILayout.Space(currentButton * 45);
                            GUILayout.EndScrollView();
                        }
                        else
                        {
                            GUIStyle textFieldStyle = GUI.skin.textField;
                            textFieldStyle.fontSize = 14;
                            textFieldStyle.alignment = TextAnchor.MiddleCenter;
                            searchString = GUILayout.TextField(searchString, textFieldStyle, GUILayout.Width(400), GUILayout.Height(20));

                            if (string.IsNullOrEmpty(searchString) && !GUI.GetNameOfFocusedControl().Equals("SearchField"))
                            {
                                GUIStyle ghostStyle = new GUIStyle(textFieldStyle);
                                ghostStyle.normal.textColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
                                GUI.SetNextControlName("SearchField");
                                GUI.Label(GUILayoutUtility.GetLastRect(), placeHoldertext, ghostStyle);
                            }
                            GUILayout.EndHorizontal();
                            if (UILib.RoundedButton2("Join Room"))
                            {
                                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(searchString, JoinType.Solo);
                            }
                            GUILayout.Space(20);
                            if (UILib.RoundedButton2("<color=red>Back</color>"))
                            {
                                UILib.currentSettingButton = null;
                                return;
                            }
                            List<ButtonHandler> settingsButtonsForMod = new List<ButtonHandler>();

                            foreach (var bt in Settings.GetButtonInfoByPage(Category.ModPrefs))
                            {
                                if (UILib.currentSettingButton.text.Contains(bt.modNameForSetting))
                                {
                                    settingsButtonsForMod.Add(bt);
                                }
                            }
                            
                            if (UILib.currentSettingButton.category == Category.Visual)
                            {
                                foreach (var bt in Settings.GetButtonInfoByPage(Category.ModPrefs))
                                {
                                    if (bt.modNameForSetting == "ESP")
                                    {
                                        settingsButtonsForMod.Add(bt);
                                    }
                                }
                            }
                            scroll[0] = GUILayout.BeginScrollView(scroll[0]);
                            int currentButton = 0;
                            foreach (var bt in settingsButtonsForMod)
                            {
                                var rect = GUILayoutUtility.GetRect(new GUIContent(bt.text), GUI.skin.button);
                                rect.x += 100;
                                rect.y = rect.y + (45 * currentButton);
                                rect.width -= 340;
                                rect.height += 45f;

                                if (UILib.RoundedToggleButton(bt.text, bt, rect))
                                {
                                    MenuHandler.ToggleButton(bt.text);
                                }
                                currentButton++;
                            }

                            GUILayout.Space(currentButton * 45);
                            GUILayout.EndScrollView();
                        }

                        
                        break;

                    case 1:

                        ConfigPage();
                        break;
                    case 2:

                        GUILayout.Space(30);
                        scroll[0] = GUILayout.BeginScrollView(scroll[0]);
                        int currentButton3 = 0;
                        foreach (Player player in PhotonNetwork.PlayerListOthers)
                        {

                            var rect = GUILayoutUtility.GetRect(new GUIContent("rgeegr"), GUI.skin.button);
                            rect.x += 100;
                            rect.y = rect.y + (45 * currentButton3);
                            rect.width -= 340;
                            rect.height += 45f;

                            if (UILib.RoundedPlayerToggleButton(player.NickName, player, rect))
                            {
                               // MenuHandler.ToggleButton(bt.text);
                            }
                            currentButton3++;

                        }

                        GUILayout.Space(currentButton3 * 45);
                        GUILayout.EndScrollView();
                        break;

                    case 3:

                        FriendsPage();
                        break;
                    case 4:
                        var rect3 = GUILayoutUtility.GetRect(new GUIContent("snigger"), GUI.skin.button);
                        rect3.x += 100;
                        rect3.y = rect3.y + (45 * 0);
                        rect3.width -= 340;
                        rect3.height += 45f;

                        if (UILib.RoundedToggleButton("Switch Theme Current Theme: " + ThemeManager.currentTheme.themeName, Settings.GetButtonInfoByPage(Category.MenuPrefs)[0], rect3))
                        {
                            MenuHandler.ToggleButton(Settings.GetButtonInfoByPage(Category.MenuPrefs)[0].text);
                        }
                        
                        break;

                    case 5:
                        GUILayout.Space(30);
                        scroll[0] = GUILayout.BeginScrollView(scroll[0]);
                        int currentButton2 = 0;
                        foreach (var bt in Settings.GetButtonInfoByPage(Category.MenuPrefs))
                        {
                            if (bt != Settings.GetButtonInfoByPage(Category.MenuPrefs)[0])
                            {
                                var rect = GUILayoutUtility.GetRect(new GUIContent(bt.text), GUI.skin.button);
                                rect.x += 100;
                                rect.y = rect.y + (45 * currentButton2);
                                rect.width -= 340;
                                rect.height += 45f;

                                if (UILib.RoundedToggleButton(bt.text, bt, rect))
                                {
                                    MenuHandler.ToggleButton(bt.text);
                                }
                                currentButton2++;
                            }
                        }

                        GUILayout.Space(currentButton2 * 45);
                        GUILayout.EndScrollView();

                        break;

                    case 6:
                        CameraPage();
                        break;
                }
                GUILayout.EndVertical();
                GUILayout.EndArea();

                GUI.DragWindow(new Rect(0, 0, 100000, 100000));
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                throw;
            }
        }

        public static int friendsPage = 0;
        public void FriendsPage()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(120);

            int currentCategoryNumber = 0;

            if (configs == null)
            {
                configs = Configs.GetConfigs();
            }

            string[] ConfigPages = new string[]
            {
                    "Online", "Offline", "Pending"
            };

            GUILayout.Space(140);
            foreach (var obj in ConfigPages)
            {
                if (currentCategoryNumber > 0 && currentCategoryNumber % 6 == 0)
                {
                    GUILayout.EndHorizontal();
                    GUILayout.Space(10);
                    GUILayout.BeginHorizontal();
                    GUILayout.Space(170);
                }
                else
                {
                    GUILayout.Space(2);
                }

                if (UILib.RoundedConfigPageCategoryButton(obj.ToString(), currentCategoryNumber, GUILayout.Width(80)))
                {
                    friendsPage = currentCategoryNumber;
                }

                currentCategoryNumber++;
            }

            GUILayout.EndHorizontal();

            GUILayout.Space(40);
            GUILayout.BeginHorizontal();
            GUILayout.Space(200);
            GUIStyle textFieldStyle = new GUIStyle(GUI.skin.textField);
            textFieldStyle.fontSize = 18;
            textFieldStyle.alignment = TextAnchor.MiddleCenter;
            configNamer = GUILayout.TextField(configNamer, textFieldStyle, GUILayout.Width(400), GUILayout.Height(30));
            GUILayout.EndHorizontal();
            if (UILib.RoundedButton("Upload Current Config"))
            {
                string currentfig = Configs.SaveEnabledMods();
                Configs.UploadConfig(currentfig, configNamer, false);
                configs = Configs.GetConfigs();
            }
            scroll[0] = GUILayout.BeginScrollView(scroll[0]);
            int currentButton = 0;


            if (friendsPage == 0)
            {
                foreach (Friends.Friend friend in Friends.GetAllFriends(Injection.key).Friends)
                {
                    if (friend.Online)
                    {
                        var rect = GUILayoutUtility.GetRect(new GUIContent("nigger"), GUI.skin.button);
                        rect.x += 100;
                        rect.y = rect.y + (45 * currentButton);
                        rect.width -= 340;
                        rect.height += 45f;

                        if (UILib.RoundedFriendsToggleButton(friend, rect))
                        {
                            Friends.GetCurrentRoom(friend.UserId);
                        }
                        currentButton++;
                    }
                }
            }
            else if (friendsPage == 1)
            {
                int currentOffline = 0;
                foreach (Friends.Friend friend in Friends.GetAllFriends(Injection.key).Friends)
                {
                    if (!friend.Online)
                    {
                        currentOffline++;
                        var rect = GUILayoutUtility.GetRect(new GUIContent("nigger"), GUI.skin.button);
                        rect.x += 100;
                        rect.y = rect.y + (45 * currentButton);
                        rect.width -= 340;
                        rect.height += 45f;

                        if (UILib.RoundedFriendsToggleButton(friend, rect))
                        {
                        
                        }
                        currentButton++;
                    }
                }
            }
            else if (friendsPage == 2)
            {
                foreach (Friends.Friend friend in Friends.GetFriendRequests(Injection.key).FriendRequests)
                {
                    var rect = GUILayoutUtility.GetRect(new GUIContent(friend.DiscordId), GUI.skin.button);
                    rect.x += 100;
                    rect.y = rect.y + (45 * currentButton);
                    rect.width -= 340;
                    rect.height += 45f;

                    if (UILib.RoundedFriendReqeuestsToggleButton(friend, rect))
                    {
                        Friends.AcceptFriendRequest(Injection.key, friend.UserId);
                    }
                    currentButton++;
                }

            }

            GUILayout.Space(currentButton * 45);

            GUILayout.EndScrollView();
        }

        public void CameraPage()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(120);

            GUILayout.EndHorizontal();
            scroll[0] = GUILayout.BeginScrollView(scroll[0]);
            GUILayout.Space(40);
            string color = "red";
            if (freecam)
            {
                color = "orange";
            }
            else
            {
                color = "red";
            }
            int buttonnum = 0;
            var rect = GUILayoutUtility.GetRect(new GUIContent("WASD Movement"), GUI.skin.button);
            rect.x += 100;
            rect.y = rect.y + (45 * buttonnum);
            rect.width -= 340;
            rect.height += 45f;


            if (UILib.RoundedFirmToggleButton("WASD Movement", freecam, rect))
            {
                freecam = !freecam;
                speed = 10;
                GorillaTagger.Instance.rigidbody.useGravity = true;
            }
            GUILayout.Space(60);
            GUILayout.BeginHorizontal();
            GUILayout.Space(180);
            GUILayout.Label("WASD Speed: " + speed.ToString());
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Space(140);
            speed = GUILayout.HorizontalSlider(speed, 0.1f, 100f, GUILayout.Width(500));
            GUILayout.EndHorizontal();

            int buttonnum2 = 3;
            var rec2t = GUILayoutUtility.GetRect(new GUIContent("WASD Movement"), GUI.skin.button);
            rec2t.x += 100;
            rec2t.y = rec2t.y + (45 * buttonnum2);
            rec2t.width -= 340;
            rec2t.height += 45f;


            if (UILib.RoundedFirmToggleButton("First Person", firstPerson, rec2t))
            {
                firstPerson = !firstPerson;
            }
            GUILayout.Space(60);
            GUILayout.BeginHorizontal();
            GUILayout.Space(180);
            GUILayout.Label("FOV: " + FOV.ToString());
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Space(140);
            FOV = GUILayout.HorizontalSlider(FOV, 60f, 160f, GUILayout.Width(500));
            GUILayout.EndHorizontal();

            GUILayout.EndScrollView();
        }

        public void ConfigPage()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(120);

            int currentCategoryNumber = 0;

            if (configs == null)
            {
                configs = Configs.GetConfigs();
            }

            string[] ConfigPages = new string[]
            {
                    "Public", "Private", "Yours"
            };

            GUILayout.Space(140);
            foreach (var obj in ConfigPages)
            {
                if (currentCategoryNumber > 0 && currentCategoryNumber % 6 == 0)
                {
                    GUILayout.EndHorizontal();
                    GUILayout.Space(10);
                    GUILayout.BeginHorizontal();
                    GUILayout.Space(170);
                }
                else
                {
                    GUILayout.Space(2);
                }

                if (UILib.RoundedConfigPageCategoryButton(obj.ToString(), currentCategoryNumber, GUILayout.Width(80)))
                {
                    UILib.currentConfigCategory = currentCategoryNumber;
                }

                currentCategoryNumber++;
            }

            GUILayout.EndHorizontal();

            GUILayout.Space(40);
            GUILayout.BeginHorizontal();
            GUILayout.Space(200);
            GUIStyle textFieldStyle = new GUIStyle(GUI.skin.textField);
            textFieldStyle.fontSize = 18;
            textFieldStyle.alignment = TextAnchor.MiddleCenter;
            configNamer = GUILayout.TextField(configNamer, textFieldStyle, GUILayout.Width(400), GUILayout.Height(30));
            GUILayout.EndHorizontal();
            if (UILib.RoundedButton("Upload Current Config"))
            {
                string currentfig = Configs.SaveEnabledMods();
                Configs.UploadConfig(currentfig, configNamer, false);
                configs = null;
            }
            if (UILib.RoundedButton("Upload Current Config Private"))
            {
                string currentfig = Configs.SaveEnabledMods();
                Configs.UploadConfig(currentfig, configNamer, true);
                configs = null;
                
            }
            if (UILib.RoundedButton("<color=orange>Unload Config</color>"))
            {
                foreach (ButtonHandler button in ModHandler.buttons)
                {
                    button.isToggled = false;
                    Prism.Utility.ArrayList.RefreshModsList();
                }
            }
            scroll[0] = GUILayout.BeginScrollView(scroll[0]);
            int currentButton = 0;
            foreach (Configs.Config config in configs)
            {
                if (UILib.currentConfigCategory == 0 && !config.Private)
                {
                    var rect = GUILayoutUtility.GetRect(new GUIContent(config.ConfigName), GUI.skin.button);
                    rect.x += 100;
                    rect.y = rect.y + (45 * currentButton);
                    rect.width -= 340;
                    rect.height += 45f;

                    if (UILib.RoundedConfigToggleButton(config, rect))
                    {
                        Configs.LoadEnabledMods(config.ConfigString);
                        configs = null;
                    }
                    currentButton++;
                }
                else if (UILib.currentConfigCategory == 1)
                {
                    if (config.CreatorName == Configs.GetDiscordUsername() && config.Private)
                    {
                        var rect = GUILayoutUtility.GetRect(new GUIContent(config.ConfigName), GUI.skin.button);
                        rect.x += 100;
                        rect.y = rect.y + (45 * currentButton);
                        rect.width -= 340;
                        rect.height += 45f;

                        if (UILib.RoundedConfigToggleButton(config, rect))
                        {
                            Configs.LoadEnabledMods(config.ConfigString);
                            configs = null;
                        }
                        currentButton++;
                    }
                }
                else if (UILib.currentConfigCategory == 2)
                {
                    if (config.CreatorName == Configs.GetDiscordUsername())
                    {
                        var rect = GUILayoutUtility.GetRect(new GUIContent(config.ConfigName), GUI.skin.button);
                        rect.x += 100;
                        rect.y = rect.y + (45 * currentButton);
                        rect.width -= 340;
                        rect.height += 45f;

                        if (UILib.RoundedConfigToggleButton(config, rect))
                        {
                            Configs.LoadEnabledMods(config.ConfigString);
                            configs = null;
                        }
                        currentButton++;
                    }
                }
            }

            GUILayout.Space(currentButton * 45);

            GUILayout.EndScrollView();
        }


        public class UILib
        {
            public static Texture2D sidePannelTexture, TabBar = new Texture2D(2, 2), TextBox = new Texture2D(2, 2), pageButtonTexture = new Texture2D(2, 2), pageButtonHoverTexture = new Texture2D(2, 2), buttonTexture = new Texture2D(2, 2), buttonHoverTexture = new Texture2D(2, 2), buttonClickTexture = new Texture2D(2, 2), windowTexture = new Texture2D(2, 2), boxTexture = new Texture2D(2, 2);

            public static void DrawTabBar(Rect rect, Vector4 borderRadius)
            {
                DrawTexture(rect, TabBar, 0, borderRadius);
            }
            public static void Init()
            {
                if (Injection.Authenticated)
                {
                    switch (Theme)
                    {
                        case 0:
                            pageButtonHoverTexture = ApplyColorFilter(Color.gray);
                            pageButtonTexture = ApplyColorFilter(ThemeManager.gPurp);
                            buttonTexture = ApplyColorFilter(new Color32(27, 27, 27, 255));
                            buttonHoverTexture = ApplyColorFilter(new Color32(35, 35, 35, 255));
                            buttonClickTexture = ApplyColorFilter(new Color32(44, 44, 44, 255));
                            windowTexture = ApplyColorFilter(new Color32(17, 17, 17, 255));
                            TabBar = ApplyColorFilter(ThemeManager.gPurp);
                            sidePannelTexture = ApplyColorFilter(new Color32(37, 37, 37, 255));
                            boxTexture = ApplyColorFilter(new Color32(27, 27, 27, 255));
                            TextBox = CreateRoundedTexture2(12, new Color32(35, 35, 35, 255));
                            break;
                    }
                }
            }

                public static Texture2D ChangeTextureColor(Texture2D texture, Color newColor)
            {
                if (texture == null)
                {
                    Debug.LogError("Texture is null.");
                    return null;
                }

                Color[] pixels = texture.GetPixels();

                for (int i = 0; i < pixels.Length; i++)
                {
                    // Check if the pixel is not transparent
                    if (pixels[i].a > 0)
                    {
                        pixels[i] = newColor;
                    }
                }

                // Apply the modified pixels back to the texture
                texture.SetPixels(pixels);
                texture.Apply();

                return texture;
            }

            public static Texture2D ApplyColorFilter2(Texture2D originalTexture, Color filterColor)
            {
                // Create a new Texture2D with the same dimensions as the original
                Texture2D filteredTexture = new Texture2D(originalTexture.width, originalTexture.height);

                // Get all pixels from the original texture
                Color[] originalPixels = originalTexture.GetPixels();
                Color[] filteredPixels = new Color[originalPixels.Length];

                // Apply the filter to each pixel
                for (int i = 0; i < originalPixels.Length; i++)
                {
                    filteredPixels[i] = originalPixels[i] * filterColor;
                }

                // Set the filtered pixels to the new texture
                filteredTexture.SetPixels(filteredPixels);
                filteredTexture.Apply();

                return filteredTexture;
            }

            public static void SetTextures()
            {
                GUI.skin.label.richText = true;
                GUI.skin.button.richText = true;
                GUI.skin.window.richText = true;
                GUI.skin.textField.richText = true;
                GUI.skin.box.richText = true;

                GUI.skin.window.border.bottom = 5;
                GUI.skin.window.border.left = 5;
                GUI.skin.window.border.top = 5;
                GUI.skin.window.border.right = 5;

                GUI.skin.window.active.background = null;
                GUI.skin.window.normal.background = null;
                GUI.skin.window.hover.background = null;
                GUI.skin.window.focused.background = null;

                GUI.skin.window.onFocused.background = null;
                GUI.skin.window.onActive.background = null;
                GUI.skin.window.onHover.background = null;
                GUI.skin.window.onNormal.background = null;

                GUI.skin.button.active.background = buttonClickTexture;
                GUI.skin.button.normal.background = buttonHoverTexture;
                GUI.skin.button.hover.background = buttonTexture;

                GUI.skin.button.onActive.background = buttonClickTexture;
                GUI.skin.button.onHover.background = buttonHoverTexture;
                GUI.skin.button.onNormal.background = buttonTexture;

                GUI.skin.box.active.background = boxTexture;
                GUI.skin.box.normal.background = boxTexture;
                GUI.skin.box.hover.background = boxTexture;

                GUI.skin.box.onActive.background = boxTexture;
                GUI.skin.box.onHover.background = boxTexture;
                GUI.skin.box.onNormal.background = boxTexture;

                GUI.skin.textField.active.background = TextBox;
                GUI.skin.textField.normal.background = TextBox;
                GUI.skin.textField.hover.background = TextBox;
                GUI.skin.textField.focused.background = TextBox;

                GUI.skin.textField.onFocused.background = TextBox;
                GUI.skin.textField.onActive.background = TextBox;
                GUI.skin.textField.onHover.background = TextBox;
                GUI.skin.textField.onNormal.background = TextBox;

                GUI.skin.horizontalSlider.active.background = buttonTexture;
                GUI.skin.horizontalSlider.normal.background = buttonTexture;
                GUI.skin.horizontalSlider.hover.background = buttonTexture;
                GUI.skin.horizontalSlider.focused.background = buttonTexture;

                GUI.skin.horizontalSlider.onFocused.background = buttonTexture;
                GUI.skin.horizontalSlider.onActive.background = buttonTexture;
                GUI.skin.horizontalSlider.onHover.background = buttonTexture;
                GUI.skin.horizontalSlider.onNormal.background = buttonTexture;



                GUI.skin.verticalScrollbar.border = new RectOffset(0, 0, 0, 0);

                GUI.skin.verticalScrollbar.fixedWidth = 0f;

                GUI.skin.verticalScrollbar.fixedHeight = 0f;

                GUI.skin.verticalScrollbarThumb.fixedHeight = 0f;

                GUI.skin.verticalScrollbarThumb.fixedWidth = 5f;
            }

            public static Texture2D ApplyColorFilter(Color color)
            {
                Texture2D texture = new Texture2D(30, 30);

                Color[] colors = new Color[30 * 30];
                for (int i = 0; i < colors.Length; i++)
                {
                    colors[i] = color;
                }
                texture.SetPixels(colors);
                texture.Apply();
                return texture;
            }


            private static Texture2D CreateRoundedTexture2(int size, Color color)
            {
                Texture2D texture = new Texture2D(size, size);
                Color[] colors = new Color[size * size];
                for (int i = 0; i < size * size; i++)
                {
                    int x = i % size;
                    int y = i / size;
                    if (Mathf.Sqrt((x - size / 2) * (x - size / 2) + (y - size / 2) * (y - size / 2)) <= size / 2)
                    {
                        colors[i] = color;
                    }
                    else
                    {
                        colors[i] = Color.clear;
                    }
                }
                texture.SetPixels(colors);
                texture.Apply();
                return texture;
            }

            public static Texture2D CreateRoundedTexture(int size, Color color)
            {
                Texture2D texture = new Texture2D(size, size);
                Color[] colors = new Color[size * size];
                float radius = size / 2f;
                float radiusSquared = radius * radius;

                for (int x = 0; x < size; x++)
                {
                    for (int y = 0; y < size; y++)
                    {
                        float distanceSquared = (x - radius) * (x - radius) + (y - radius) * (y - radius);
                        if (distanceSquared <= radiusSquared)
                        {
                            float alpha = 1f - distanceSquared / radiusSquared; // Smoothly fade out the edges
                            colors[y * size + x] = new Color(color.r, color.g, color.b, alpha);
                        }
                        else
                        {
                            colors[y * size + x] = Color.clear;
                        }
                    }
                }

                texture.SetPixels(colors);
                texture.Apply();
                return texture;
            }

            public static ButtonHandler currentSettingButton = null;
            public static bool RoundedToggleButton(string content, ButtonHandler button, Rect rect, params GUILayoutOption[] options)
            {
                Texture2D texture = button.isToggled ? buttonClickTexture : buttonTexture;

                Rect settingsRect = rect;

                settingsRect.width = 20;
                settingsRect.height -= 5;
                settingsRect.x += 523;
                settingsRect.y += 3;
                ButtonHandler drawingSettingButton = null;
                foreach (ButtonHandler buttonHandler in Settings.GetButtonInfoByPage(Category.ModPrefs))
                {
                    if (button.text.Contains(buttonHandler.modNameForSetting))
                    {
                        drawingSettingButton = buttonHandler;
                        break;
                    }

                    if (button.category == Category.Visual)
                    {
                        drawingSettingButton = buttonHandler;
                        break;
                    }
                }

                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonClickTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown && !settingsRect.Contains(Event.current.mousePosition))
                {
                    texture = buttonTexture;
                    return true;
                }
                else if (settingsRect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown && drawingSettingButton != null)
                {
                    currentSettingButton = button;
                    return false;
                }

                texture = button.isToggled ? buttonTexture : buttonTexture;
                string modName = button.text;
                DrawTexture(rect, texture, 16);

                DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), modName, 16, Color.white);
                DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), (RemoveColorTags(button.ToolTip)), 13, Color.white);

                UILib.DrawTabBar(new Rect(rect.x + 62, rect.y, 5, rect.height), new Vector4(8f, 0f, 0f, 8f));
                if (!whiteDot)
                {
                    whiteDot = ApplyColorFilter(Color.white);
                }
                if (button.isToggled)
                {
                    if (!coolCheckMark)
                    {
                        coolCheckMark = ApplyColorFilter2(modOn, ThemeManager.gPurp);
                    }
                    GUI.Label(new Rect(rect.x + 10, rect.y + 7, 50, 50), coolCheckMark);
                }
                else
                { 
                    DrawTexture(new Rect(rect.x + 25, rect.y + 25, 10, 10), whiteDot, 50);
                }


                if (drawingSettingButton != null)
                {
                    DrawTexture(settingsRect, pageButtonHoverTexture, 16);
                    DrawTexture(new Rect(rect.x + 530, rect.y + 20, 5, 5), whiteDot, 50);
                    DrawTexture(new Rect(rect.x + 530, rect.y + 30, 5, 5), whiteDot, 50);
                    DrawTexture(new Rect(rect.x + 530, rect.y + 40, 5, 5), whiteDot, 50);
                }


                return false;
            }

            public static bool RoundedPlayerToggleButton(string content, Player player, Rect rect, params GUILayoutOption[] options)
            {
                VRRig playerVRRig = GorillaGameManager.instance.FindPlayerVRRig(player);
                bool isOnPrism = player.CustomProperties.ContainsKey("Prism");
                if (infectedTexture == null)
                {
                    if (playerVRRig.mainSkin.material.mainTexture == null)
                    {
                        return false;
                    }
                    if (RoomManager.tagManager)
                    {
                        if (RoomManager.tagManager.currentInfected.Contains(player) || RoomManager.tagManager.currentIt == player)
                        {
                            infectedTexture = ConvertToTexture2D(playerVRRig.mainSkin.material.mainTexture);
                        }
                        else
                        {
                            nonInfectedTexture = ConvertToTexture2D(playerVRRig.mainSkin.material.mainTexture);
                        }
                    }
                    else if (RoomManager.battleManager)
                    {
                        if (RoomManager.battleManager.playerLives[player.ActorNumber] == 0)
                        {
                            infectedTexture = ConvertToTexture2D(playerVRRig.mainSkin.material.mainTexture);
                        }
                    }
                }

                Texture2D texture = buttonTexture;
                Rect settingsRect = rect;

                settingsRect.width = 20;
                settingsRect.height -= 5;
                settingsRect.x += 523;
                settingsRect.y += 3;

                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    if (!isOnPrism)
                    {
                        if (!Keyboard.current[Key.C].isPressed)
                        {
                            taggingPlayer = player;
                        }
                        else
                        {
                            TeleportLib.Teleport(playerVRRig.transform.position);
                        }
                    }
                       
                    else
                    {

                        string prismUID = player.CustomProperties["Prism"] as string;
                        Debug.Log($"The UID of the player is: {prismUID}");
                        
                        Networking.Friends.SendFriendRequest(Injection.key, int.Parse(prismUID));
                    }
                    texture = buttonClickTexture;
                    return true;
                }

                DrawTexture(rect, texture, 16);
                if (isOnPrism)
                {
                    DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), player.NickName, 16, Color.cyan);
                }
                else
                {
                    DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), player.NickName, 16, Color.white);
                }
                if (!isOnPrism)
                {
                    if (taggingPlayer != player)
                        DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), ("Tag Player (HOLD C WHEN CLICK TO TP INSTEAD)"), 13, Color.white);
                    else
                        DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), ("Tagging Player"), 13, Color.red);
                }
                else
                {
                    DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), ("Add as friend"), 13, Color.blue);
                }

                UILib.DrawTabBar(new Rect(rect.x + 62, rect.y, 5, rect.height), new Vector4(8f, 0f, 0f, 8f));

               
                if (RoomManager.tagManager.currentInfected.Contains(player))
                {
                    if (infectedTexture != null)
                        GUI.Label(new Rect(rect.x + 10, rect.y + 7, 50, 50), infectedTexture);
                }
                else
                {
                    GUI.Label(new Rect(rect.x + 10, rect.y + 7, 50, 50), ApplyColorFilter(playerVRRig.mainSkin.material.color));  
                }

                rect.width -= 400;
                rect.height -= 100;
                rect.x += 220;
                rect.y -= 10;

                texture = buttonHoverTexture;
                // DrawTexture(rect, texture, 6);

                return false;
            }
        
            public static Texture2D ConvertToTexture2D(Texture texture)
            {
                Texture2D convertedTexture = new Texture2D(texture.width, texture.height);

                convertedTexture.SetPixels((texture as Texture2D).GetPixels());

                convertedTexture.Apply();

                return convertedTexture;
            }


            public static bool RoundedFirmToggleButton(string content, bool isEnabled, Rect rect, params GUILayoutOption[] options)
            {
                Texture2D texture = isEnabled ? buttonClickTexture : buttonTexture;

                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonClickTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonTexture;
                    return true;
                }

                texture = isEnabled ? buttonTexture : buttonTexture;
                string modName = content;
                DrawTexture(rect, texture, 16);

                DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), modName, 16, Color.white);

                UILib.DrawTabBar(new Rect(rect.x + 62, rect.y, 5, rect.height), new Vector4(8f, 0f, 0f, 8f));
                if (isEnabled)
                {
                    if (!coolCheckMark)
                    {
                        coolCheckMark = ApplyColorFilter2(modOn, ThemeManager.gPurp);
                    }
                    GUI.Label(new Rect(rect.x + 10, rect.y + 7, 50, 50), coolCheckMark);
                }
                else
                {
                    if (!whiteDot)
                    {
                        whiteDot = ApplyColorFilter(Color.white);
                    }
                    DrawTexture(new Rect(rect.x + 25, rect.y + 25, 10, 10), whiteDot, 50);
                }
                return false;
            }

            public static Texture2D whiteDot = null;

            public static Texture2D coolCheckMark = null;

            public static bool RoundedConfigToggleButton(Configs.Config content, Rect rect, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;

                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonClickTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonTexture;
                    return true;
                }

                string modName = content.ConfigName;
                DrawTexture(rect, texture, 16);

                DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), modName, 16, Color.white);
                DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), (RemoveColorTags("Config Made by: " + content.CreatorName)), 13, Color.white);

                UILib.DrawTabBar(new Rect(rect.x + 62, rect.y, 5, rect.height), new Vector4(8f, 0f, 0f, 8f));

                    DrawTexture(new Rect(rect.x + 25, rect.y + 25, 10, 10), ApplyColorFilter(Color.white), 50);
                
                return false;
            }

            internal static bool RoundedFriendReqeuestsToggleButton(Friends.Friend friend, Rect rect, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;

                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonClickTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonTexture;
                    return true;
                }

                string modName = "Accept Friend Request From: " + friend.DiscordId;
                DrawTexture(rect, texture, 16);

                DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), modName, 16, Color.white);
                //DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), (RemoveColorTags("Config Made by: " + content.CreatorName)), 13, Color.white);

                UILib.DrawTabBar(new Rect(rect.x + 62, rect.y, 5, rect.height), new Vector4(8f, 0f, 0f, 8f));

                DrawTexture(new Rect(rect.x + 25, rect.y + 25, 10, 10), ApplyColorFilter(Color.white), 50);

                return false;
            }

            public static bool RoundedFriendsToggleButton(Friends.Friend friend, Rect rect, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;

                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonClickTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonTexture;
                    return true;
                }

                string modName = "Friend: " + friend.DiscordId + "in code: " + friend.CurrentRoom;
                DrawTexture(rect, texture, 16);

                DrawNoCenterText(new Rect(rect.x + 80, rect.y + 5, rect.width, 25f), modName, 16, Color.white);
                //DrawNoCenterText(new Rect(rect.x + 95, rect.y + 24, rect.width, 25f), (RemoveColorTags("Config Made by: " + content.CreatorName)), 13, Color.white);

                UILib.DrawTabBar(new Rect(rect.x + 62, rect.y, 5, rect.height), new Vector4(8f, 0f, 0f, 8f));

                DrawTexture(new Rect(rect.x + 25, rect.y + 25, 10, 10), ApplyColorFilter(Color.white), 50);

                return false;
            }

            public static string RemoveColorTags(string input)
            {
                // Define regex patterns for the beginning and end color tags
                string startTagPattern = @"^(<color=#[0-9A-Fa-f]{6}>|<color=[a-zA-Z]+>)";
                string endTagPattern = @"</color>$";

                // Remove the start color tag if it exists
                string result = Regex.Replace(input, startTagPattern, "");

                // Remove the end color tag if it exists
                result = Regex.Replace(result, endTagPattern, "");

                return result;
            }

            public static bool RoundedPlayerButton(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y, rect.width, 25f), content, 12, Color.white);
                return false;
            }

            public static bool RoundedButton(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                rect.width -= 500;
                rect.x += 200;
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white);
                return false;
            }
            public static bool RoundedButton2(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                rect.width -= 500;
                rect.x += 180;
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white);
                return false;
            }

            public static bool RoundedButton(string content, GUIStyle style, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), style, options);
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white);
                return false;
            }

            public static bool RoundedButton(string content, bool refrence, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                if (refrence)
                {
                    texture = buttonClickTexture;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white);
                return false;
            }

            public static bool RoundedButton(Rect rect, string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white);
                return false;
            }

            public static bool PlayerButton(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);

                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white);
                return false;
            }


            public static void DrawText(Rect rect, string text, int fontSize = 12, Color textColor = default)
            {
                GUIStyle _style = new GUIStyle(GUI.skin.label);
                _style.fontSize = fontSize;
                _style.font = myFont;
                _style.normal.textColor = textColor;
                float X = rect.x + rect.width / 2f - _style.CalcSize(new GUIContent(text)).x / 2f;
                float Y = rect.y + rect.height / 2f - _style.CalcSize(new GUIContent(text)).y / 2f;
                GUI.Label(new Rect(X, Y, rect.width, rect.height), new GUIContent(text), _style);
            }

            public static void DrawTextOverlap(Rect rect, string text, int fontSize = 12, Color textColor = default)
            {
                GUIStyle _style = new GUIStyle(GUI.skin.label);
                _style.fontSize = fontSize;
                _style.font = myFont;
                _style.normal.textColor = textColor;
                float X = rect.x + rect.width / 2f - _style.CalcSize(new GUIContent(text)).x / 2f;
                float Y = rect.y + rect.height / 2f - _style.CalcSize(new GUIContent(text)).y / 2f;
                GUI.Label(new Rect(X, Y, rect.width, rect.height), new GUIContent(text), _style);
            }
            public static void DrawNoCenterText(Rect rect, string text, int fontSize = 12, Color textColor = default)
            {
                GUIStyle _style = new GUIStyle(GUI.skin.label);
                _style.fontSize = fontSize;
                _style.font = myFont;
                _style.normal.textColor = textColor;

                float X = rect.x;
                float Y = rect.y;

                GUI.Label(new Rect(X, Y, rect.width, rect.height), new GUIContent(text), _style);
            }



            static Rect pageButtonRect;
            public static bool RoundedPageButton(string content, int i, params GUILayoutOption[] options)
            {
                if (Page == i)
                {
                    Texture2D texture = pageButtonTexture;
                    pageButtonRect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect.height += 10;
                    if (pageButtonRect.Contains(Event.current.mousePosition))
                    {
                        texture = pageButtonHoverTexture;
                    }
                    if (pageButtonRect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        return true;
                    }
                    if (content == "GameMode")
                    {
                        DrawTexture(pageButtonRect, texture, 8); DrawText(new Rect(pageButtonRect.x, pageButtonRect.y, pageButtonRect.width, 25f), content, 12, Color.white);
                    }
                    else
                    {
                        DrawTexture(pageButtonRect, texture, 8); DrawText(new Rect(pageButtonRect.x, pageButtonRect.y, pageButtonRect.width, 25f), content, 20, Color.white);
                    }
                    return false;
                }
                else
                {
                    Texture2D texture = buttonTexture;
                    pageButtonRect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect.height += 10;
                    if (pageButtonRect.Contains(Event.current.mousePosition))
                    {
                        texture = buttonHoverTexture;
                    }
                    if (pageButtonRect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        texture = buttonClickTexture;
                        return true;
                    }

                    if (content == "GameMode")
                    {
                        DrawTexture(pageButtonRect, texture, 8); DrawText(new Rect(pageButtonRect.x, pageButtonRect.y, pageButtonRect.width, 25f), content, 12, Color.white);
                    }
                    else
                    {
                        DrawTexture(pageButtonRect, texture, 8); DrawText(new Rect(pageButtonRect.x, pageButtonRect.y, pageButtonRect.width, 25f), content, 20, Color.white);
                    }
          
                    return false;
                }
            }

            static Rect pageButtonRect2;
            internal static bool RoundedPageCategoryButton(string content, Category i, params GUILayoutOption[] options)
            {
                if (currentGUICategory == i)
                {
                    Texture2D texture = pageButtonTexture;
                    pageButtonRect2 = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect2.height += 10;
                    if (pageButtonRect2.Contains(Event.current.mousePosition))
                    {
                        texture = pageButtonHoverTexture;
                    }
                    if (pageButtonRect2.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        return true;
                    }
                    DrawTexture(pageButtonRect2, texture, 8); DrawText(new Rect(pageButtonRect2.x, pageButtonRect2.y, pageButtonRect2.width, 25f), content, 16, Color.white);
                    return false;
                }
                else
                {
                    Texture2D texture = buttonTexture;
                    pageButtonRect2 = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect2.height += 10;
                    if (pageButtonRect2.Contains(Event.current.mousePosition))
                    {
                        texture = buttonHoverTexture;
                    }
                    if (pageButtonRect2.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        texture = buttonClickTexture;
                        return true;
                    }
                    DrawTexture(pageButtonRect2, texture, 8); DrawText(new Rect(pageButtonRect2.x, pageButtonRect2.y, pageButtonRect2.width, 25f), content, 16, Color.white);
                    return false;
                }
            }

            public static int currentConfigCategory = 0;
            public static bool RoundedConfigPageCategoryButton(string content, int i, params GUILayoutOption[] options)
            {
                if (currentConfigCategory == friendsPage)
                {
                    Texture2D texture = pageButtonTexture;
                    pageButtonRect2 = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect2.height += 10;
                    if (pageButtonRect2.Contains(Event.current.mousePosition))
                    {
                        texture = pageButtonHoverTexture;
                    }
                    if (pageButtonRect2.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        return true;
                    }
                    DrawTexture(pageButtonRect2, texture, 8); DrawText(new Rect(pageButtonRect2.x, pageButtonRect2.y, pageButtonRect2.width, 25f), content, 16, Color.white);
                    return false;
                }
                else
                {
                    Texture2D texture = buttonTexture;
                    pageButtonRect2 = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect2.height += 10;
                    if (pageButtonRect2.Contains(Event.current.mousePosition))
                    {
                        texture = buttonHoverTexture;
                    }
                    if (pageButtonRect2.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        texture = buttonClickTexture;
                        return true;
                    }
                    DrawTexture(pageButtonRect2, texture, 8); DrawText(new Rect(pageButtonRect2.x, pageButtonRect2.y, pageButtonRect2.width, 25f), content, 16, Color.white);
                    return false;
                }
            }

            public static bool RoundedOtherPageCategoryButton(string content, int i, params GUILayoutOption[] options)
            {
                if (currentConfigCategory == i)
                {
                    Texture2D texture = pageButtonTexture;
                    pageButtonRect2 = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect2.height += 10;
                    if (pageButtonRect2.Contains(Event.current.mousePosition))
                    {
                        texture = pageButtonHoverTexture;
                    }
                    if (pageButtonRect2.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        return true;
                    }
                    DrawTexture(pageButtonRect2, texture, 8); DrawText(new Rect(pageButtonRect2.x, pageButtonRect2.y, pageButtonRect2.width, 25f), content, 16, Color.white);
                    return false;
                }
                else
                {
                    Texture2D texture = buttonTexture;
                    pageButtonRect2 = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    pageButtonRect2.height += 10;
                    if (pageButtonRect2.Contains(Event.current.mousePosition))
                    {
                        texture = buttonHoverTexture;
                    }
                    if (pageButtonRect2.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        texture = buttonClickTexture;
                        return true;
                    }
                    DrawTexture(pageButtonRect2, texture, 8); DrawText(new Rect(pageButtonRect2.x, pageButtonRect2.y, pageButtonRect2.width, 25f), content, 16, Color.white);
                    return false;
                }
            }

            private static void DrawTexture(Rect rect, Texture2D texture, int borderRadius, Vector4 borderRadius4 = default)
            {
                if (borderRadius4 == Vector4.zero)
                    borderRadius4 = new Vector4(borderRadius, borderRadius, borderRadius, borderRadius);
                GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, borderRadius4);
            }
        }

    }
}