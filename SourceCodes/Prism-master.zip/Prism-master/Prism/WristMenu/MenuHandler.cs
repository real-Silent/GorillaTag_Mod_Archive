﻿using System;
using System.Collections.Generic;
using GorillaLocomotion;
using Photon.Pun;
using Prism.Utility;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace Prism.WristMenu
{
	internal class MenuHandler
    {
        internal static void DrawButton(ButtonHandler button, float offset)
        {
            if (Variables.menuObj == null) return;

            GameObject menu = Variables.menuObj;

            float menuTop = (Variables.menuHeight - Variables.menuHeight / 2f) - 0.025f;

            // Draw Button
            GameObject newButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
            newButton.name = "Template Button";
            newButton.transform.parent = menu.transform;

            // Button Positions
            newButton.transform.localScale = new Vector3(1f, 0.90f, 0.11f) * GorillaLocomotion.Player.Instance.scale;
            newButton.transform.position = menu.transform.position + new Vector3(0.057f, 0f, menuTop - offset);
            newButton.transform.rotation = Quaternion.identity;

            // Button Collisions
            newButton.GetComponent<BoxCollider>().isTrigger = true;
            newButton.AddComponent<ToggleButton>().text = button.text;
            newButton.AddComponent<EventTrigger>();
            // Set Button Colors and Renderers
            newButton.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");

            if (button.isToggled)            
				newButton.GetComponent<Renderer>().AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.OnButton;
            else
                newButton.GetComponent<Renderer>().AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.OffButton;

            GameObject canvasObj = new GameObject();
            canvasObj.transform.parent = newButton.transform;
            Canvas canvas = canvasObj.AddComponent<Canvas>();

            CanvasScaler canvasScale = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScale.dynamicPixelsPerUnit = 1000;

            // Add Text to the Button
            GameObject buttonTextObj = new GameObject();
            buttonTextObj.transform.parent = canvasObj.transform;
            Text buttonText = buttonTextObj.AddComponent<Text>();
            buttonText.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            buttonText.text = button.text;
            buttonText.fontSize = 1;            
            buttonText.color = ThemeManager.currentTheme.textColor;
            buttonText.alignment = TextAnchor.MiddleCenter;
            buttonText.resizeTextForBestFit = true;
            buttonText.resizeTextMinSize = 0;

            // Set Text Position and Siz
            RectTransform textTransform = buttonText.GetComponent<RectTransform>();
            textTransform.localPosition = Vector3.zero;
            textTransform.sizeDelta = new Vector2(0.164f, 0.022f);
            textTransform.position = new Vector3(0.062f, 0f, menuTop - offset);
            textTransform.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }

        internal static void DestroyAllButtons()
		{
			foreach (ToggleButton toggleButton in Resources.FindObjectsOfTypeAll<ToggleButton>())
			{
				UnityEngine.Object.Destroy(toggleButton.gameObject);
			}
		}

		internal static void ToggleButton(string text)
		{
			ButtonHandler buttonHandler = FindButton(text);
			if (buttonHandler.requiresMaster)
			{
				if (!PhotonNetwork.LocalPlayer.IsMasterClient)
				{
					NotifiLib.SendNotification("[<color=green>PRISM</color>]: <color=red>YOU ARE NOT MASTERCLIENT!</color>");
					return;
				}
			}
			if (buttonHandler.isTogglable)
			{
				buttonHandler.isToggled = !buttonHandler.isToggled;
				ArrayList.RefreshModsList();
				if (!buttonHandler.isToggled)
				{
					if (buttonHandler.onDisableMethod != null)
					{
						buttonHandler.onDisableMethod();
					}
				}
				else
				{
					if (buttonHandler.ToolTip == "" || buttonHandler.ToolTip == string.Empty)
					{
						return;
					}
					NotifiLib.SendNotification("[<color=cyan>PRISM</color>]: <color=green>" + buttonHandler.ToolTip + "</color>");
				}
				RedrawMenu();
			}
			else
			{
				if (buttonHandler.method != null)
				{
					buttonHandler.method();
					if (buttonHandler.ToolTip == "" || buttonHandler.ToolTip == string.Empty)
					{
						return;
					}
					NotifiLib.SendNotification($"[<color=cyan>PRISM</color>]: <color=green> {buttonHandler.ToolTip} </color>");
				}
				RedrawMenu();
			}

		}

		internal static ButtonHandler FindButton(string buttonText)
		{
			foreach (ButtonHandler buttonHandler in ModHandler.buttons)
			{
				if (buttonHandler.text == buttonText)
				{
					return buttonHandler;
				}
			}
			return null;
		}

        internal static List<ButtonHandler> FindContanButton(string buttonText)
        {
			List<ButtonHandler> buttons = new List<ButtonHandler>();
            foreach (ButtonHandler buttonHandler in ModHandler.buttons)
            {
                if (buttonHandler.text.Contains(buttonText))
                {
                    buttons.Add(buttonHandler);
                }
            }
            return buttons;
        }

        internal static void DrawBottomButtons()
		{
			float num = Variables.menuHeight - Variables.menuHeight * 3.27f;
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject.transform.parent = Variables.menuObj.transform;
			gameObject.transform.localScale = new Vector3(1f, 0.48f, 0.07f);
			gameObject.transform.localPosition = new Vector3(13.7f, 0.26f, num);
			gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Background;
			GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject2.transform.parent = gameObject.transform;
			gameObject2.transform.localScale = new Vector3(1f, 1f, 1f) + new Vector3(0f, 0.02f, 0.05f);
			gameObject2.transform.localPosition = new Vector3(-0.1f, 0f, 0f);
			gameObject2.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject2.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Outline;
			GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject3.transform.parent = Variables.menuObj.transform;
			gameObject3.transform.localScale = new Vector3(1f, 0.48f, 0.07f);
			gameObject3.transform.localPosition = new Vector3(13.7f, -0.26f, num);
			gameObject3.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject3.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Background;
			GameObject gameObject4 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject4.transform.parent = gameObject3.transform;
			gameObject4.transform.localScale = new Vector3(1f, 1f, 1f) + new Vector3(0f, 0.02f, 0.05f);
			gameObject4.transform.localPosition = new Vector3(-0.1f, 0f, 0f);
			gameObject4.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject4.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Outline;
			gameObject.AddComponent<BoxCollider>().isTrigger = true;
			gameObject.AddComponent<ToggleButton>().text = "<";
			gameObject3.AddComponent<BoxCollider>().isTrigger = true;
			gameObject3.AddComponent<ToggleButton>().text = ">";
			GameObject gameObject5 = new GameObject();
			gameObject5.transform.parent = Variables.menuObj.transform;
			Canvas canvas = gameObject5.AddComponent<Canvas>();
			CanvasScaler canvasScaler = gameObject5.AddComponent<CanvasScaler>();
			gameObject5.AddComponent<GraphicRaycaster>();
			canvas.renderMode = RenderMode.WorldSpace;
			canvasScaler.dynamicPixelsPerUnit = 1000f;
			Text text = new GameObject
			{
				transform = 
				{
					parent = gameObject5.transform
				}
			}.AddComponent<Text>();
			text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
			text.text = "Prev";
			text.color = ThemeManager.currentTheme.textColor;
			text.fontSize = 1;
			text.alignment = TextAnchor.MiddleCenter;
			text.resizeTextForBestFit = true;
			text.resizeTextMinSize = 0;
			RectTransform component = text.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.164f, 0.012f);
			component.position = new Vector3(0.057f, 0.047f, -0.1415f);
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			Text text2 = new GameObject
			{
				transform = 
				{
					parent = gameObject5.transform
				}
			}.AddComponent<Text>();
			text2.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
			text2.text = "Next";
			text2.color = ThemeManager.currentTheme.textColor;
			text2.fontSize = 1;
			text2.alignment = TextAnchor.MiddleCenter;
			text2.resizeTextForBestFit = true;
			text2.resizeTextMinSize = 0;
			RectTransform component2 = text2.GetComponent<RectTransform>();
			component2.localPosition = Vector3.zero;
			component2.sizeDelta = new Vector2(0.164f, 0.012f);
			component2.position = new Vector3(0.057f, -0.0475f, -0.1415f);
			component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
		}

		internal static void DrawTopButtons()
		{
			float num = Variables.menuHeight - Variables.menuHeight * 2.25f;
			float num2 = Variables.menuHeight - num;
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject.transform.parent = Variables.menuObj.transform;
			gameObject.transform.localScale = new Vector3(1f, 0.48f, 0.07f);
			gameObject.transform.localPosition = new Vector3(13.7f, 0.26f, num2);
			gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Background;
			GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject2.transform.parent = gameObject.transform;
			gameObject2.transform.localScale = new Vector3(1f, 1f, 1f) + new Vector3(0f, 0.02f, 0.05f);
			gameObject2.transform.localPosition = new Vector3(-0.1f, 0f, 0f);
			gameObject2.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject2.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Outline;
			GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject3.transform.parent = Variables.menuObj.transform;
			gameObject3.transform.localScale = new Vector3(1f, 0.48f, 0.07f);
			gameObject3.transform.localPosition = new Vector3(13.7f, -0.26f, num2);
			gameObject3.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject3.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Background;
			GameObject gameObject4 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject4.transform.parent = gameObject3.transform;
			gameObject4.transform.localScale = new Vector3(1f, 1f, 1f) + new Vector3(0f, 0.02f, 0.05f);
			gameObject4.transform.localPosition = new Vector3(-0.1f, 0f, 0f);
			gameObject4.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			gameObject4.AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Outline;
			gameObject.AddComponent<BoxCollider>().isTrigger = true;
			gameObject.AddComponent<ToggleButton>().text = "Leave";
			gameObject3.AddComponent<BoxCollider>().isTrigger = true;
			gameObject3.AddComponent<ToggleButton>().text = "Home";
			GameObject gameObject5 = new GameObject();
			gameObject5.transform.parent = Variables.menuObj.transform;
			Canvas canvas = gameObject5.AddComponent<Canvas>();
			CanvasScaler canvasScaler = gameObject5.AddComponent<CanvasScaler>();
			gameObject5.AddComponent<GraphicRaycaster>();
			canvas.renderMode = RenderMode.WorldSpace;
			canvasScaler.dynamicPixelsPerUnit = 1000f;
			Text text = new GameObject
			{
				transform = 
				{
					parent = gameObject5.transform
				}
			}.AddComponent<Text>();
			text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
			text.text = "Leave";
			text.color = ThemeManager.currentTheme.textColor;
			text.fontSize = 1;
			text.alignment = TextAnchor.MiddleCenter;
			text.resizeTextForBestFit = true;
			text.resizeTextMinSize = 0;
			RectTransform component = text.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.164f, 0.012f);
			component.position = new Vector3(0.057f, 0.047f, 0.1415f);
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			Text text2 = new GameObject
			{
				transform = 
				{
					parent = gameObject5.transform
				}
			}.AddComponent<Text>();
			text2.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
			text2.text = "Home";
			text2.color = ThemeManager.currentTheme.textColor;
			text2.fontSize = 1;
			text2.alignment = TextAnchor.MiddleCenter;
			text2.resizeTextForBestFit = true;
			text2.resizeTextMinSize = 0;
			RectTransform component2 = text2.GetComponent<RectTransform>();
			component2.localPosition = Vector3.zero;
			component2.sizeDelta = new Vector2(0.164f, 0.012f);
			component2.position = new Vector3(0.057f, -0.0475f, 0.1415f);
			component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
		}

        internal static void DrawTemp()
        {
            // Check if Menu is Already Drawn
            if (Variables.menuObj != null) return;

            if (!ControllerInputPoller.instance.GetComponent<ThemeManager>())
            {
                ControllerInputPoller.instance.AddComponent<ThemeManager>().gameObject.name = "[Utility] Theme Manager";
            }

            // Create Menu Base
            Variables.menuObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            GameObject menu = Variables.menuObj;
            menu.transform.localScale = new Vector3(0.004f, Variables.menuWidth, Variables.menuHeight);
            Object.Destroy(menu.GetComponent<Renderer>());
            Object.Destroy(menu.GetComponent<Collider>());
            Object.Destroy(menu.GetComponent<Rigidbody>());

            // Create Menu Surface (Background)
            GameObject menuSurface = GameObject.CreatePrimitive(PrimitiveType.Cube);
            menuSurface.transform.parent = menu.transform;
            menuSurface.transform.localScale = new Vector3(1f, 1f, 1f);
            menuSurface.transform.position = new Vector3(0.055f, 0f, 0f);
            menuSurface.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			menuSurface.GetComponent<Renderer>().AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Background;
            Object.Destroy(menuSurface.GetComponent<Collider>());
            Object.Destroy(menuSurface.GetComponent<Rigidbody>());

            // Create Menu Border
            GameObject menuBorder = GameObject.CreatePrimitive(PrimitiveType.Cube);
            menuBorder.transform.parent = menuSurface.transform;
            menuBorder.transform.position = menuSurface.transform.position - new Vector3(0.001f, 0f, 0f);
            menuBorder.transform.rotation = menuSurface.transform.rotation;
            menuBorder.transform.localScale = new Vector3(1f, 1f, 1f) + new Vector3(0f, 0.01f, 0.01f);
            menuBorder.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			menuBorder.GetComponent<Renderer>().AddComponent<ThemeManager.ColorChanger>().whichColor = ThemeManager.ButtonType.Outline;
            Object.Destroy(menuBorder.GetComponent<Collider>());
            Object.Destroy(menuBorder.GetComponent<Rigidbody>());

            InfoDraw();
            DrawCollider();
            DrawBottomButtons();
            DrawTopButtons();

            // Calculate the start and end indices for the current page
            int startIndex = ModHandler.currentPage * Variables.buttonsPerPage;
            int endIndex = startIndex + Variables.buttonsPerPage;

            // Filter buttons based on the current category
            List<ButtonHandler> filteredButtons = new List<ButtonHandler>();
            foreach (ButtonHandler button in ModHandler.buttons)
            {
                if (button.category == ModHandler.currentCategory)
                {
                    filteredButtons.Add(button);
                }
            }

            // Calculate the total number of pages
            int totalButtons = filteredButtons.Count;
            int totalPages = (int)Math.Ceiling((double)totalButtons / Variables.buttonsPerPage);

            // Ensure the current page is within the valid range
            if (ModHandler.currentPage >= totalPages)
            {
                ModHandler.currentPage = totalPages - 1;
                startIndex = ModHandler.currentPage * Variables.buttonsPerPage;
                endIndex = startIndex + Variables.buttonsPerPage;
            }//should be good? i think yes

            // Ensure the endIndex does not exceed the number of filtered buttons
            endIndex = Math.Min(endIndex, filteredButtons.Count);

            // Draw the buttons for the current page
            for (var i = startIndex; i < endIndex; i++)
            {
                DrawButton(filteredButtons[i], (i - startIndex) * 0.038f);
            }
        }

		internal static void DrawCollider()
		{
			if (Variables.colliderObj != null) return;

			Variables.colliderObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
			if (Variables.colliderObj.GetComponent<Collider>() == null)
				Variables.colliderObj.AddComponent<Collider>();

            var buttonHandler = MenuHandler.FindButton("Menu Hand: [Left]")
?? MenuHandler.FindButton("Menu Hand: [Right]");

            if (buttonHandler.settingIndex == 1)
			{
				Variables.colliderObj.transform.parent = Player.Instance.rightControllerTransform;
			}
			else if (buttonHandler.settingIndex == 2)
			{
				Variables.colliderObj.transform.parent = Player.Instance.leftControllerTransform;
			}

			// Rendering
			Variables.colliderObj.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			Variables.colliderObj.GetComponent<Renderer>().material.color = Color.black;

			Variables.colliderObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
			Variables.colliderObj.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
		}

		internal static void InfoDraw()
		{
			if (Variables.menuObj != null)
			{
				Variables.canvasObj = new GameObject();
				Variables.canvasObj.transform.parent = Variables.menuObj.transform;
				Canvas canvas = Variables.canvasObj.AddComponent<Canvas>();
				CanvasScaler canvasScaler = Variables.canvasObj.AddComponent<CanvasScaler>();
				Variables.canvasObj.AddComponent<GraphicRaycaster>();
				canvas.renderMode = RenderMode.WorldSpace;
				canvasScaler.dynamicPixelsPerUnit = 1000f;
				Text text = new GameObject
				{
					transform = 
					{
						parent = Variables.canvasObj.transform
					}
				}.AddComponent<Text>();
				text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
				text.text = Variables.menuTitle;
				text.fontSize = 1;
				text.alignment = TextAnchor.MiddleCenter;
				text.color = Variables.titleColor;
				text.resizeTextForBestFit = true;
				text.resizeTextMinSize = 0;
				RectTransform component = text.GetComponent<RectTransform>();
				component.localPosition = Vector3.zero;
				component.sizeDelta = new Vector2(1f, 0.011f);
				float num = Variables.menuHeight - Variables.menuHeight * 1.5f;
				component.position = new Vector3(0.058f, 0f, num + 0.01f);
				component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
				text.horizontalOverflow = HorizontalWrapMode.Wrap;
			}
		}

		internal static void Toggle()
        {
            if (Variables.canToggle)
            {
                Variables.isToggled = !Variables.isToggled;
                if (!Variables.isToggled)
                    DestroyMenuStuff();
                var buttonHandler = FindButton("Menu Sound: [CS]")
				?? FindButton("Menu Sound: [SS]");
                if (buttonHandler.settingIndex == 1)
                {
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, true, 0.4f);
                }
                else
                {
                    if (buttonHandler.settingIndex == 2)
                    {
                        if (PhotonNetwork.InRoom && GorillaTagger.Instance.offlineVRRig != null)
                        {
                            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", RpcTarget.All, new object[] { 84, false, 0.9f });
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                        }
                    }
                }
                GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(96, true, 0.4f);
            }
		}

		internal static void TogglePC()
		{
            Variables.pcToggle = !Variables.pcToggle;
            if (!Variables.pcToggle)
                DestroyMenuStuff();
            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(96, true, 0.4f);
            var buttonHandler = FindButton("Menu Sound: [CS]")
			?? FindButton("Menu Sound: [SS]");

            if (buttonHandler.settingIndex == 1)
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, true, 0.4f);
			}
			else
			{
				if (buttonHandler.settingIndex == 2)
				{
					if (PhotonNetwork.InRoom && GorillaTagger.Instance.offlineVRRig != null)
					{
						PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", RpcTarget.All, new object[] { 84, false, 0.9f });
					}
					else
					{
                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                    }
				}
			}
		}

        internal static void DestroyMenuStuff()
        {
            if (Variables.menuObj == null) return;

            // Destroy , check if null already.
            Object.Destroy(Variables.menuObj);
            if (Variables.colliderObj != null)
                Object.Destroy(Variables.colliderObj);
            if (Variables.canvasObj != null)
                Object.Destroy(Variables.canvasObj);

            DestroyAllButtons();
        }

        internal static void RedrawMenu()
        {
            if (Variables.menuObj == null) return;

            Object.Destroy(Variables.menuObj);
            Variables.menuObj = null;
            DrawTemp();
        }

        internal static void ChangeCategory(ModHandler.Category category)
		{
			ModHandler.currentCategory = category;
			ModHandler.currentPage = 0;
			RedrawMenu();
		}
	}
}
