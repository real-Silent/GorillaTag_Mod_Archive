﻿using System;

namespace Prism.WristMenu
{
	public class ButtonHandler
    {
        internal string text = "Default Text.";

        internal ModHandler.Category category = ModHandler.Category.Home;

        internal bool isTogglable = true;

        internal bool isToggled = false;

        internal Action method = null;

        internal Action onDisableMethod = null;

        internal bool requiresMaster = false;

        internal string ToolTip = "A ToolTip for this Button.";

		internal float settingIndex = -1;

        internal string modNameForSetting = "NULL";

        internal static ButtonHandler CreateButton(string text, ModHandler.Category category, bool isTogglable, bool isToggled, Action method, Action onDisableMethod, bool requiresMaster, string ToolTip = "", float settingsIndex = -1, string modNameForSetting = "NULL")
		{
			return new ButtonHandler
			{
				text = text,
				category = category,
				isTogglable = isTogglable,
				isToggled = isToggled,
				method = method,
				onDisableMethod = onDisableMethod,
				requiresMaster = requiresMaster,
				ToolTip = ToolTip,
				settingIndex = settingsIndex,
                modNameForSetting = modNameForSetting
            };
		}
	}
}
