﻿using System;
using System.Collections.Generic;
using Photon.Pun;
using Prism.Utility;
using UnityEngine;

namespace Prism.WristMenu
{
	internal class ToggleButton : MonoBehaviour
    {
        internal string text;

        internal static float cooldown;
        public void OnTriggerEnter(Collider other)
		{
            if (other == Variables.colliderObj.GetComponent<Collider>())
			{
                this.PressButton(this.text);
			}
		}

        private void PressButton(string text)
        {
            if (Time.time <= cooldown || Variables.menuObj == null) return;

            cooldown = Time.time + 0.2f;
            GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.taggedHapticDuration / 2f);
            var buttonHandler = MenuHandler.FindButton("Menu Sound: [CS]")
            ?? MenuHandler.FindButton("Menu Sound: [SS]");
            if (buttonHandler.settingIndex == 1)
            {
                GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(64, true, 0.4f);
            }
            else if (buttonHandler.settingIndex == 2)
            {
                if (PhotonNetwork.InRoom && GorillaTagger.Instance.offlineVRRig != null)
                {
                    PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", RpcTarget.All, 84, false, 0.9f);
                }
                else if (!PhotonNetwork.InRoom)
                {
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                }
            }

            switch (text)
            {
                case "<":
                    ModHandler.currentPage--;
                    if (ModHandler.currentPage < 0)
                    {
                        int totalPages = (int)Math.Ceiling((double)FilterButtonsByCategory(ModHandler.currentCategory).Count / Variables.buttonsPerPage);
                        ModHandler.currentPage = totalPages - 1;
                    }
                    break;

                case ">":
                    ModHandler.currentPage++;
                    int maxPages = (int)Math.Ceiling((double)FilterButtonsByCategory(ModHandler.currentCategory).Count / Variables.buttonsPerPage);
                    if (ModHandler.currentPage >= maxPages) ModHandler.currentPage = 0;
                    break;

                case "Leave":
                    PhotonNetwork.Disconnect();
                    break;

                case "Home":
                    ModHandler.currentCategory = ModHandler.Category.Home;
                    ModHandler.currentPage = 0;
                    break;

                default:
                    MenuHandler.ToggleButton(text);
                    break;
            }

            MenuHandler.RedrawMenu();
            NotifiLib.ClearAllNotifications();
        }

        private List<ButtonHandler> FilterButtonsByCategory(ModHandler.Category category)
        {
            List<ButtonHandler> filteredButtons = new List<ButtonHandler>();
            foreach (ButtonHandler button in ModHandler.buttons)
            {
                if (button.category == category) filteredButtons.Add(button);
            }
            return filteredButtons;
        }
    }
}