﻿using System;
using Photon.Pun;
using Prism.Mods;
using Prism.Patches;
using Prism.Utility;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Prism.WristMenu
{
    internal class Menu : BaseClass
    {
        public static float pingTime = 0;
        public void LateUpdate()
        {
            try
            {
                GhostHandler.GhostHandle();
                VisualMods.Prism_NameTags();
                if (PhotonNetwork.InRoom && UI.taggingPlayer != null)
                {
                    InfectionMods.TagPlayer(UI.taggingPlayer);
                }

                if (Keyboard.current[Key.RightShift].wasPressedThisFrame && !ControllerInputPoller.instance.GetComponent<UI>())
                {
                    ControllerInputPoller.instance.AddComponent<UI>().gameObject.name = "[Utility] GUI";
                    if (!ControllerInputPoller.instance.GetComponent<ThemeManager>())
                    {
                        ControllerInputPoller.instance.AddComponent<ThemeManager>().gameObject.name = "[Utility] Theme Manager";
                    }
                }
                if (PhotonNetwork.InRoom)
                {
                    if (RoomManager.battleManager == null && RoomManager.tagManager == null && RoomManager.huntManager == null)
                    {
                        if (GorillaGameManager.instance.GetComponent<GorillaTagManager>())
                        {
                            RoomManager.tagManager = GorillaGameManager.instance.GetComponent<GorillaTagManager>();
                        }
                        if (GorillaGameManager.instance.GetComponent<GorillaBattleManager>())
                        {
                            RoomManager.battleManager = GorillaGameManager.instance.GetComponent<GorillaBattleManager>();
                        }
                        if (GorillaGameManager.instance.GetComponent<GorillaHuntManager>())
                        {
                            RoomManager.huntManager = GorillaGameManager.instance.GetComponent<GorillaHuntManager>();
                        }
                    }
                }
                PrismUtils.OnGroundRaycast();
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }

            //===========================================================================================

            if (Settings.OpenButtonInput())
            {
                MenuHandler.Toggle();
                Variables.canToggle = false;
            }
            else
                Variables.canToggle = true;
            /*
            // PC Toggle
            if (UnityInput.Current.GetKeyDown(KeyCode.LeftAlt))
                MenuHandler.TogglePC();
            */
            // dont uncomment this sial you fat nigger cunt fuck


            if (Variables.isToggled && Variables.menuObj == null || Variables.pcToggle && Variables.menuObj == null)
                MenuHandler.DrawTemp();
            else if (Variables.isToggled && Variables.menuObj != null || Variables.pcToggle && Variables.menuObj != null)
            {
                if (Variables.isToggled)
                {
                    var buttonHandler = MenuHandler.FindButton("Menu Hand: [Left]")
                    ?? MenuHandler.FindButton("Menu Hand: [Right]");
                    if (buttonHandler.settingIndex == 1)
                    {
                        Variables.menuObj.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                        Variables.menuObj.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    }
                    else if (buttonHandler.settingIndex == 2)
                    {
                        Variables.menuObj.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                        Variables.menuObj.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    }
                }
                else if (Variables.pcToggle)
                {
                    float offsetDistance = 0.25f;
                    Vector3 headPosition = GorillaLocomotion.Player.Instance.headCollider.transform.position;
                    Quaternion headRotation = GorillaLocomotion.Player.Instance.headCollider.transform.rotation;
                    Variables.menuObj.transform.position = (headPosition + headRotation * Vector3.forward * offsetDistance);
                    Variables.menuObj.transform.rotation = Quaternion.LookRotation((headPosition - Variables.menuObj.transform.position), Vector3.up);
                    Variables.menuObj.transform.Rotate(Vector3.up, -90.0f);
                    Variables.menuObj.transform.Rotate(Vector3.right, -90.0f);
                }
            }

            if (Variables.colliderObj != null) //this shit is ass.
            {
                if (Mouse.current.leftButton.isPressed)
                {
                    Camera TPC = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                    Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                    bool worked = Physics.Raycast(ray, out RaycastHit hit, 100);
                    if (worked)
                    {
                        ToggleButton collide = hit.transform.gameObject.GetComponent<ToggleButton>();
                        if (collide != null)
                        {
                            collide.OnTriggerEnter(Variables.colliderObj.GetComponent<Collider>());
                        }
                    }
                }
            }


            if (Time.time > pingTime + 200f)
            {
                Injection.Ping();
                pingTime = Time.time;
            }

            if (VRRigMods.RewindHelp > 0f && (float)Time.frameCount > VRRigMods.RewindHelp)
            {
                VRRigMods.RewindHelp = 0f;
            }

            if (VRRigMods.MacroHelp > 0f && (float)Time.frameCount > VRRigMods.MacroHelp)
            {
                VRRigMods.MacroHelp = 0f;
            }


            foreach (ButtonHandler button in ModHandler.buttons)
            {
                if (button != null)
                {
                    if (button.isTogglable)
                    {
                        if (button.isToggled)
                        {
                            if (button.method != null)
                                button.method.Invoke();
                            else
                                Debug.Log("Button Doesn't have a Method.");
                        }
                    }
                }
            }
        }
    }
}
