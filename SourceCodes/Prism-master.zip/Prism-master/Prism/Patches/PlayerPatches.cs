﻿using GorillaLocomotion;
using HarmonyLib;
using UnityEngine;
using Prism.Mods;
using Photon.Pun;

namespace Prism.Patches
{
	internal class PlayerPatches : MonoBehaviour
	{
		[HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2), "GracePeriod", MethodType.Enumerator)]
		internal class GraceBypass : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin), "GracePeriod", MethodType.Enumerator)]
		internal class Grace2Bypass : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin), "LateUpdate", MethodType.Normal)]
		private class GraceBypassLoop : MonoBehaviour
		{
			public static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2), "LateUpdate", MethodType.Normal)]
		private class Grace2BypassLoop : MonoBehaviour
		{
			public static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(Player), "AntiTeleportTechnology")]
		internal class AntiTeleportPatch : MonoBehaviour
		{
			private static bool Prefix(Player __instance)
			{
				return false;
			}
		}

        [HarmonyPatch(typeof(Slingshot), "LaunchProjectile")]
        internal class SelfSlingshotPatch : MonoBehaviour
        {
            private static bool Prefix()
            {
				if (ProjectileMods.usingMinigun)
				{
					return false;
				}
				return true;
            }
        }

        [HarmonyPatch(typeof(VRRig), "UpdateCosmeticsWithTryon")]
        internal class FuckIIDK : MonoBehaviour
        {
            private static bool Prefix(string[] currentItems, string[] tryOnItems, PhotonMessageInfo info)
            {
                if (currentItems.ToString().Contains("LBADE") || tryOnItems.ToString().Contains("LBADE"))
				{
					return false;
				}
				return true;
            }
        }
    }
}