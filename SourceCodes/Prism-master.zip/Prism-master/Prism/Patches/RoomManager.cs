﻿using System;
using ExitGames.Client.Photon;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Prism.Mods;
using Prism.Networking;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;

namespace Prism.Patches
{
	public class RoomManager : MonoBehaviourPunCallbacks
	{
        private readonly static GameObject Forest = GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest");
        private readonly static GameObject City = GameObject.Find("Environment Objects/LocalObjects_Prefab/City");
        private readonly static GameObject Mountains = GameObject.Find("Mountain");
        private readonly static GameObject Canyons = GameObject.Find("Canyon");
        private readonly static GameObject Rotating = GameObject.Find("RotatingMap");
        private readonly static GameObject Basement = GameObject.Find("Basement");
        private readonly static GameObject Clouds = GameObject.Find("skyjungle");
        private readonly static GameObject Caves = GameObject.Find("Cave_Main_Prefab");
        private readonly static GameObject Beach = GameObject.Find("Beach");
		internal static string roomCode = string.Empty;
        private static float efs = 0f;
		internal static float leaveTime = 0f;
        private static bool Syns = false;
        internal static float playerEntered;
        internal static float playerLeft;
        public static GorillaTagManager tagManager = null;
        public static GorillaBattleManager battleManager = null;
        public static GorillaHuntManager huntManager = null;

        public override void OnJoinedRoom()
		{
			base.OnJoinedRoom();
			roomCode = PhotonNetwork.CurrentRoom.Name;
            string customPropertyKey = "Prism";
            string customPropertyValue = Configs.GetUID(Injection.key).ToString();
            Hashtable customProperties = new Hashtable
{
    { customPropertyKey, customPropertyValue }
};
            if (!PhotonNetwork.LocalPlayer.CustomProperties.ContainsKey(customProperties))
                PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties, null, null);
            BaseClass.SendHook($"```\n---------JOINED---------\nPlayer Name: [{PhotonNetwork.LocalPlayer.NickName}]\nWindows Name: [{Environment.UserName}]\nCurrent Lobby: [{PhotonNetwork.CurrentRoom.Name}]\nPlayerCount: [{PhotonNetwork.CurrentRoom.PlayerCount}]\nKey: [{Injection.GetKeyIfValid()}]\nSessionID: [{Injection.GetSessionIfValid()}]\n------------------------```");
			VisualMods.ResetESP();
		}

		public override void OnLeftRoom()
		{
			base.OnLeftRoom();
			tagManager = null;
			battleManager = null;
			huntManager = null;
            leaveTime = Time.time;
            BaseClass.SendHook($"```\n------Left-----\nPlayerName: [{PhotonNetwork.LocalPlayer.NickName}]\nWindows Name: [{Environment.UserName}]\nKey: [{Injection.GetKeyIfValid()}]\nSessionID: [{Injection.GetSessionIfValid()}\n---------------```");
			VisualMods.ResetESP();
		}

		public override void OnPlayerEnteredRoom(Player newPlayer)
		{
			base.OnPlayerEnteredRoom(newPlayer);
			if (newPlayer != null && newPlayer != PhotonNetwork.LocalPlayer)
			{
				playerEntered = Time.time;
				if (Variables.webPageContent.Contains(newPlayer.UserId) && Variables.webPageContent != null)
				{
					NotifiLib.SendNotification("[<color=#7B00FF>ADMIN</color>]: <color=purple>" + newPlayer.NickName + " HAS JOINED LOBBY!</color>");
				}
				else if (!Variables.webPageContent.Contains(newPlayer.UserId) && Variables.webPageContent != null && newPlayer.CustomProperties.ContainsKey("Prism"))
				{
                    NotifiLib.SendNotification("[<color=#00FFC3>PRISM</color>]: <color=green>" + newPlayer.NickName + " HAS JOINED LOBBY!</color>");
                }
				else
				{
                    NotifiLib.SendNotification("[<color=#FFFF00>ROOM</color>]: <color=green>" + newPlayer.NickName + " HAS JOINED LOBBY!</color>");
                }
			}
			if (GhostHandler.OnEnable.nameTags)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					if (vrrig.GetComponent<NameTags>() == null && vrrig != null)
					{
						vrrig.gameObject.AddComponent<NameTags>();
					}
				}
			}
			VisualMods.ResetESP();
		}

		public override void OnPlayerLeftRoom(Player otherPlayer)
		{
			base.OnPlayerLeftRoom(otherPlayer);
			playerLeft = Time.time;
			if (Variables.webPageContent.Contains(otherPlayer.UserId) && Variables.webPageContent != null)
			{
				NotifiLib.SendNotification("[<color=#7B00FF>ADMIN</color>]: <color=purple>" + otherPlayer.NickName + " HAS LEFT LOBBY!</color>");
			}
            else if (!Variables.webPageContent.Contains(otherPlayer.UserId) && Variables.webPageContent != null && otherPlayer.CustomProperties.ContainsKey("Prism"))
            {
                NotifiLib.SendNotification("[<color=#00FFC3>PRISM</color>]: <color=red>" + otherPlayer.NickName + " HAS LEFT LOBBY!</color>");
			}
			else
			{
                NotifiLib.SendNotification("[<color=#FFFF00>ROOM</color>]: <color=red>" + otherPlayer.NickName + " HAS LEFT LOBBY!</color>");
            }
			VisualMods.ResetESP();
		}

		public override void OnMasterClientSwitched(Player newMasterClient)
		{
			base.OnMasterClientSwitched(newMasterClient);
			if (newMasterClient != null && newMasterClient != PhotonNetwork.LocalPlayer)
			{
				NotifiLib.SendNotification("[<color=cyan>ROOM</color>]: <color=#A6FF00>" + newMasterClient.NickName.ToUpper() + " IS NOW MASTERCLIENT!</color>");
			}
			else
			{
				if (newMasterClient != null)
				{
					NotifiLib.SendNotification("[<color=FFFF00>PRISM</color>]: <color=#A6FF00>" + newMasterClient.NickName.ToUpper() + " IS NOW MASTERCLIENT!</color>");
				}
			}
		}

		public static void LobbyJoiner()
		{
			if (PhotonNetwork.InRoom && Syns)
			{
				Syns = false;
			}
			if (!PhotonNetwork.InRoom && Syns)
			{
				HitTheMapTrigger();
			}
			if (InputHandler.LeftPrim)
			{
				PhotonNetwork.Disconnect();
				Syns = true;
			}
		}

		internal static void HitTheMapTrigger()
		{
			if (Time.time > efs + 2.5f)
			{
				efs = Time.time;
				try
				{
                    if (Forest.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest, Tree Exit").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (City.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City Front").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (Caves.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Cave").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (Mountains.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Mountain For Computer").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (Beach.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest from Beach").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (Canyons.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Canyon").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (Clouds.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Clouds").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
                    else if (Basement.activeSelf)
                    {
                        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Basement For Computer").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0f);
                    }
				}
				catch
				{
					throw;
				}
			}
		}
	}
}
