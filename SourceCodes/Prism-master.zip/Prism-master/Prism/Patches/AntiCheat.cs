﻿using HarmonyLib;
using Photon.Pun;
using PlayFab;
using PlayFab.Internal;
using Prism.Utility;
using UnityEngine;
using PlayFab.ClientModels;
using System;
using System.Collections.Generic;
namespace Prism.Patches
{
	internal class AntiCheat : MonoBehaviour
	{
		[HarmonyPatch(typeof(GorillaNot), "CheckReports", MethodType.Enumerator)]
		public class ReportCheck : MonoBehaviourPunCallbacks
		{
			public static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(SecondLookSkeleton))]
		[HarmonyPatch("SetTappedState", MethodType.Normal)]
		internal class GhostNotLoadedFix
		{
			public static bool Prefix(SecondLookSkeleton __instance)
			{
				return !__instance.spookyText;
			}
		}

		[HarmonyPatch(typeof(GorillaNot), "SendReport")]
		public class ReportSent : MonoBehaviourPunCallbacks
		{
			public static bool Prefix(string susReason, string susId, string susNick)
			{
				if (!susReason.Contains("empty"))
				{
					Debug.Log(string.Concat(new string[] { susNick, " was reported! Reason: ", susReason, " ID: ", susId }));
					if (susId == PhotonNetwork.LocalPlayer.UserId)
					{
						BaseClass.SendHook($"{PhotonNetwork.LocalPlayer.NickName.ToUpper()} GOT REPORT FOR: {susReason}");
						NotifiLib.SendNotification("[<color=cyan>PRISM</color>] REPORT FROM: <color=red>" + susReason + "</color>");
					}
				}
				susId = "";
				susReason = "";
				susNick = "";
				return susId != PhotonNetwork.LocalPlayer.UserId;
			}
		}

		[HarmonyPatch(typeof(GorillaNot), "GetRPCCallTracker")]
		public class RPCTracker : MonoBehaviourPunCallbacks
		{
			public static bool Prefix(string userID, string rpcFunction)
			{
				rpcFunction = string.Empty;
				return false;
			}
		}

		[HarmonyPatch(typeof(GorillaNot), "LogErrorCount")]
		public class LogErrorCount : MonoBehaviourPunCallbacks
		{
			public static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(GorillaNot), "DispatchReport")]
		public class Dispatch : MonoBehaviourPunCallbacks
		{
			public static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(Gorillanalytics), "Start", MethodType.Enumerator)]
		public class GorillanalyticsStart : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(Gorillanalytics), "UploadGorillanalytics", MethodType.Normal)]
		public class AnalyticsPatch : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

        [HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportPlayer", MethodType.Normal)]
        public class PlayFabReportPatch : MonoBehaviour
        {
            private static bool Prefix(ReportPlayerClientRequest request, Action<ReportPlayerClientResult> resultCallback, Action<PlayFabError> errorCallback, object customData = null, Dictionary<string, string> extraHeaders = null)
            {
                return false;
            }
        }

		[HarmonyPatch(typeof(PlayFabClientAPI), "ReportPlayer", MethodType.Normal)]
        public class PlayFabReportPatch2 : MonoBehaviour
		{
			private static bool Prefix(ReportPlayerClientRequest request, Action<ReportPlayerClientResult> resultCallback, Action<PlayFabError> errorCallback, object customData = null, Dictionary<string, string> extraHeaders = null)
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabHttp), "InitializeScreenTimeTracker")]
		internal class NoInitializeScreenTimeTracker : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabDeviceUtil), "GetAdvertIdFromUnity")]
		internal class NoGetAdvertIdFromUnity : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabDeviceUtil), "DoAttributeInstall")]
		internal class NoDoAttributeInstall : MonoBehaviour
		{ 
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportDeviceInfo")]
		internal class NoDeviceInfo2 : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabClientAPI), "ReportDeviceInfo")]
		internal class NoDeviceInfo1 : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabDeviceUtil), "SendDeviceInfoToPlayFab")]
		internal class NoDeviceInfo : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(typeof(PlayFabClientAPI), "AttributeInstall")]
		internal class NoAttributeInstall : MonoBehaviour
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		/*
		[HarmonyPatch(typeof(LoadBalancingClient), "OnDisconnectMessageReceived", MethodType.Normal)]
		internal class EvadeKick
        {
			private static bool Prefix(DisconnectMessage obj)
            {
				Debug.Log("sial is a rapist");
				return false;
			}
		}
		*/
    }
}