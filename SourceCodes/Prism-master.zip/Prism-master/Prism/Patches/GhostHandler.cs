﻿using GorillaLocomotion;
using HarmonyLib;
using Prism.Utility;
using Prism.WristMenu;
using UnityEngine;

namespace Prism.Patches
{
	internal class GhostHandler : MonoBehaviour
	{
		public static void GhostHandle()
		{
			if (Variables.vRrig == null)
			{
				Variables.vRrig = UnityEngine.Object.Instantiate<VRRig>(GorillaTagger.Instance.offlineVRRig, Player.Instance.transform.position, Player.Instance.transform.rotation);
				Variables.vRrig.enabled = false;
				Variables.vRrig.playerName = "GHOSTPLAYER";
				Variables.vRrig.transform.position = Vector3.zero;
			}
			if (!GorillaTagger.Instance.offlineVRRig.enabled)
			{
				Color playerColor = GorillaTagger.Instance.offlineVRRig.playerColor;
				playerColor.a = 0.35f;
				Variables.vRrig.enabled = true;
				Variables.vRrig.mainSkin.material = Variables.textShader;
				Variables.vRrig.mainSkin.material.color = playerColor;
				Variables.vRrig.leftHandTransform.position = Player.Instance.leftControllerTransform.position;
				Variables.vRrig.rightHandTransform.position = Player.Instance.rightControllerTransform.position;
				Variables.vRrig.leftHandTransform.rotation = Player.Instance.leftControllerTransform.rotation;
				Variables.vRrig.rightHandTransform.rotation = Player.Instance.rightControllerTransform.rotation;
				Variables.vRrig.transform.position = Player.Instance.transform.position;
				Variables.vRrig.transform.rotation = Player.Instance.transform.rotation;
				if (Player.Instance.IsHandSliding(false) || !Player.Instance.IsHandSliding(true))
				{
					GameObject.Find("Local Gorilla Player(Clone)/VR Constraints/LeftArm/Left Arm IK/SlideAudio").SetActive(false);
					GameObject.Find("Local Gorilla Player(Clone)/VR Constraints/RightArm/Right Arm IK/SlideAudio").SetActive(false);
				}
				else if (Player.Instance.IsHandSliding(false) || Player.Instance.IsHandSliding(true))
				{
					GameObject.Find("Local Gorilla Player(Clone)/VR Constraints/LeftArm/Left Arm IK/SlideAudio").SetActive(true);
					GameObject.Find("Local Gorilla Player(Clone)/VR Constraints/RightArm/Right Arm IK/SlideAudio").SetActive(true);

				}
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
			else if (GorillaTagger.Instance.offlineVRRig.enabled)
			{
				Variables.vRrig.enabled = false;
				Variables.vRrig.transform.position = Vector3.zero;
			}
		}

		[HarmonyPatch(typeof(VRRig), "OnDisable")]
		internal class GhostPatch : MonoBehaviour
		{
			private static bool Prefix(VRRig __instance)
			{
				return !(__instance == GorillaTagger.Instance.offlineVRRig);
			}
		}

		[HarmonyPatch(typeof(VRRig), "OnEnable", MethodType.Normal)]
		public class OnEnable : MonoBehaviour
		{
			private static void Postfix(VRRig __instance)
			{
				if (nameTags)
				{
					NameTags nameTags = __instance.gameObject.AddComponent<NameTags>();
				}
			}

			public static bool nameTags;
		}
	}
}