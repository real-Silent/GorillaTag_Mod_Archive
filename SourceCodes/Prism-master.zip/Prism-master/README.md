vak = sial

sial skidded most of everything
