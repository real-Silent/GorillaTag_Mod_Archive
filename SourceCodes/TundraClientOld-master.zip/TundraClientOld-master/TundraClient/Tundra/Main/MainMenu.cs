﻿using HarmonyLib;
using System;
using UnityEngine;
using UnityEngine.UI;
using ButtonCollisionHandler;
using System.IO;
using Tundra.ColorManagement;
using System.Linq;
using Photon.Pun;
using TundraAntiBan;
using GorillaNetworking;
using GTAG_NotificationLib;
using Tundra.MenuMods;
using MenuUtils;
using Tundra.Boards;
using TundraClient.Tundra.MenuMods;
using TundraClient.Tundra.MenuUtils;

namespace TundraMenu
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class TundraMain
    {
        public static Camera camcomp;
        public static GameObject shouldercam;
        public static GameObject referenceObj = null;
        public static GameObject MenuObj = null;
        public static GameObject canvasObj = null;
        public static GameObject canvasSettingsObj = null; 
        public static GameObject canvasPrevObj = null;
        public static GameObject canvasNextObj = null;
        public static GameObject canvasDiscObj = null;

        //MAIN DECLARATIONS
        public static int pageNumber = 1;
        public static int FramePressCooldown = 0;
        static bool init = true;


        //MENU INPUT VARS
        static bool OnceLTrig;  //Page Input
        static bool OnceRTrig;  //Page Input
        static bool LeftTrigger = false; //Page Input Bool
        static bool RightTrigger = false;//Page Input Bool
        static ControllerInputPoller input;

        //PAGE VARS
        static bool page1 = pageNumber == 1; //Categories
        static bool page2 = pageNumber == 2; // Settings
        static bool page3 = pageNumber == 3; // Basic Mods
        static bool page4 = pageNumber == 4; //Player Mods
        static bool page5 = pageNumber == 5; //Impact Mods
        static bool page6 = pageNumber == 6; //VRRig Mods
        static bool page7 = pageNumber == 7; //Visual Mods
        static bool page8 = pageNumber == 8; //BUG MODS
        static bool page9 = pageNumber == 9; //BAT MODS
        static bool page10 = pageNumber == 10; //BALLOON MODS
        static bool page11 = pageNumber == 11; //WATER MODS
        static bool page12 = pageNumber == 12; //BEACHBALL MODS
        static bool page13 = pageNumber == 13; //MONSTER MODS
        static bool page14 = pageNumber == 14; //SOUND SPAM MODS
        static bool page15 = pageNumber == 15; //ROPE MODS
        static bool page16 = pageNumber == 16; //INFECTION MODS
        static bool page17 = pageNumber == 17; //PAINTBRAWL MODS
        static bool page18 = pageNumber == 18; //MASTER MODS
        static bool page19 = pageNumber == 19; //ABUSIVEMODS
        static bool page20 = pageNumber == 20; //PROJECTILE MODS
        static bool page21 = pageNumber == 21; //MISC MODS
        static bool page22 = pageNumber == 22; //CHRISTMAS MODS

        //PRIMARY INTS
        public static int lobbyhopmode = 1;
        public static int PROJCOLOR = 1;
        public static int ImpactColors = 1;
        public static int GunHand = 1;
        public static int AntiReport = 1;

        //PROJ  INTS
        public static int ProjType = 1;
        public static int ProjTypeSelect = 1;

        //SPECIAL PROJ INTS
        public static int SpecialType = 1;
        public static int TrailType = 1;
        public static int PlayerType = 1;

        //OTHER INTS
        public static int PageType = 1;
        public static int FPSType = 0;
        public static int SpeedType = 1;
        public static int LongArmType = 1;
        public static int MosaType = 1;
        public static int AutoTagSelf = 1;
        public static int ESPType = 1;
        public static int ColorScheme = 1;
        public static int GunLock = 1;
        public static int VelSpeed = 1;
        public static int openButton = 1;
        public static int NotifResult = 1;
        public static int PlatInput = 1;
        public static float smth = 0f;

        public static int PresentType = 1;
        public static int PresentSpamType = 1;


        //RANDOM BOOLS
        public static bool DisconnectWhenRoomIsNull = false;
        public static bool RandomLOL = true;

        public static bool Reversed = false;
        public static bool Origin = false;

        public static bool CustomButtonCooldown = false;
        public static bool righthand = false;

        public static bool onEnable = false;
        public static bool fpcEnabled = false;
        public static bool btcBool = true;
        
        //MAIN ARRAYS
        static string[] Buttons = new string[] { };
        static bool?[] ButtonsActive = new bool?[] { };
        public static int[] bones = { 4, 3, 5, 4, 19, 18, 20, 19, 3, 18, 21, 20, 22, 21, 25, 21, 29, 21, 31, 29, 27, 25, 24, 22, 6, 5, 7, 6, 10, 6, 14, 6, 16, 14, 12, 10, 9, 7 };


        // Scales
        static float MenuWidth = 0.20f;
        static float MenuHeight = 0.33f;


        //CATEGORY NAMES
        public static string[] Pg1 = new string[] { "<color=#3D3DFF>Settings</color>", "<color=red>Basic Mods</color>", "<color=orange>Player Mods</color>", "<color=yellow>Impact Mods</color>", "<color=green>VRRig Mods</color>", "<color=#00FFCC>Visual Mods</color>" };   
        public static bool?[] Pg1Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg2 = new string[] { "<color=blue>Bug Mods</color>", "<color=#4C00FF>Bat Mods</color>", "<color=purple>Balloon Mods</color>", "<color=#292929>Water Mods</color>", "<color=#290000>Beachball Mods</color>", "<color=red>Monster mods</color>" };
        public static bool?[] Pg2Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg3 = new string[] { "<color=orange>Sound Spam Mods</color>", "<color=yellow>Rope Mods</color>", "<color=green>Infection Mods</color>", "<color=#00FFCC>Paintbrawl Mods</color>", "<color=blue>Master Mods</color>", "<color=red>Abusive Mods</color>" };
        public static bool?[] Pg3Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg4 = new string[] { "<color=#4C00FF>Projectile Mods</color>", "<color=purple>Misc Mods</color>", "<color=#FF007B>Christmas Mods</color>", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg4Active = new bool?[] { false, false, false, false, false, false };

        //CATEGORY EXTENDED PAGES
        public static string[] Pg5 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg5Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg6 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg6Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg7 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg7Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg8 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg8Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg9 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg9Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg10 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg10Active = new bool?[] { false, false, false, false, false, false };




        //SETTINGS
        public static string[] Pg11 = new string[] { "<color=cyan>[Go Home]</color>", "Right Hand Menu", "Save Settings: <color=yellow>[NW]</color>", "Menu Input: <color=yellow>[Secondary]</color>", "Second Input: <color=yellow>[Triggers]</color>", "GunLock: <color=yellow>[False]</color>" };
        public static bool?[] Pg11Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg12 = new string[] { "FPS Boost: <color=yellow>[Off]</color>", "LongArm Type: <color=yellow>[1.15]</color>", "Super Speed: <color=yellow>[9.5]</color>", "Mosa Speed: <color=yellow>[No Grip]</color>", "TagSelf On TagMods: <color=yellow>[False]</color>", "VelocityFly Speed: <color=yellow>[10]</color>" };
        public static bool?[] Pg12Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg13 = new string[] { "Projectile Spam Type: <color=yellow>[Gun]</color>", "Projectile Others Type: <color=yellow>[Slingshot]</color>", "Trail Type: <color=yellow>[None]</color>", "Player Projectile: <color=yellow>[Piss]</color>", "-------", "-------" };
        public static bool?[] Pg13Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg14 = new string[] { "Projectile Color: <color=yellow>[Black]</color>", "Impact Color: <color=yellow>[Black]</color>", "ESP Color: <color=yellow>[Infection]</color>", "Color Scheme: <color=yellow>[Black]</color>", "Lobby Hop: <color=yellow>[X/Y]</color>", "Anti Report: <color=yellow>[NW]</color>" };
        public static bool?[] Pg14Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg15 = new string[] { "Guns Hand: <color=yellow>[Right]</color>", "Disable Notifs: <color=yellow>[False]</color>", "Give Spammer Type: <color=yellow>[Slingshot]</color>", "Platform Input: <color=yellow>[Grips]</color>", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg15Active = new bool?[] { false, false, false, false, false, false };


        //BASIC MODS
        public static string[] Pg16 = new string[] { "<color=cyan>[Go Home]</color>", "Create Public", "Disconnect <color=yellow><X/Y></color>", "Lobby hop <color=yellow><X/Y></color>", "First Person Cam", "Unlock Comp" };
        public static bool?[] Pg16Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg17 = new string[] { "Super Speed", "Mosa Speed", "Low Gravity", "No Gravity", "High Gravity", "FPS Boost" };
        public static bool?[] Pg17Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg18 = new string[] { "Slide Control", "Big Monk <color=yellow><A/B></color>", "Small Monk<color=yellow><A/B></color>", "Long Arms", "Fast Fly <color=yellow><A/B></color>", "Slow NoClip Fly <color=yellow><A/B></color>" };
        public static bool?[] Pg18Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg19 = new string[] { "TP Gun", "Checkpoint", "Spawn C4", "No Clip <color=yellow><RT></color>", "Loud Hand Taps", "Join Random Room" };
        public static bool?[] Pg19Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg20 = new string[] { "Platforms", "Sticky Platforms", "Disable Tag Freeze", "AirStrike", "45 Hertz", "Coming Soon" };
        public static bool?[] Pg20Active = new bool?[] { false, false, false, false, false, false };

        //BASIC MODS EXTENDED PAGES
        public static string[] Pg21 = new string[] { "dawdasd", "dasasdw", "wwsazdwa", "dgrdrg", "fyjfty", "tk,yu" };
        public static bool?[] Pg21Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg22 = new string[] { "awdawdadaw", "awdawdawdaw", "dddaswdw", "dwadwaas", "wasdwasdw", "dwaasdwwa" };
        public static bool?[] Pg22Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg23 = new string[] { "dawdasd", "dasasdw", "wwsazdwa", "dgrdrg", "fyjfty", "tk,yu" };
        public static bool?[] Pg23Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg24 = new string[] { "awdawdadaw", "awdawdawdaw", "dddaswdw", "dwadwaas", "wasdwasdw", "dwaasdwwa" };
        public static bool?[] Pg24Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg25 = new string[] { "dawdasd", "dasasdw", "wwsazdwa", "dgrdrg", "fyjfty", "tk,yu" };
        public static bool?[] Pg25Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg26 = new string[] { "awdawdadaw", "awdawdawdaw", "dddaswdw", "dwadwaas", "wasdwasdw", "dwaasdwwa" };
        public static bool?[] Pg26Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg27 = new string[] { "dawdasd", "dasasdw", "wwsazdwa", "dgrdrg", "fyjfty", "tk,yu" };
        public static bool?[] Pg27Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg28 = new string[] { "awdawdadaw", "awdawdawdaw", "dddaswdw", "dwadwaas", "wasdwasdw", "dwaasdwwa" };
        public static bool?[] Pg28Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg29 = new string[] { "dawdasd", "dasasdw", "wwsazdwa", "dgrdrg", "fyjfty", "tk,yu" };
        public static bool?[] Pg29Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg30 = new string[] { "awdawdadaw", "awdawdawdaw", "dddaswdw", "dwadwaas", "wasdwasdw", "dwaasdwwa" };   
        public static bool?[] Pg30Active = new bool?[] { false, false, false, false, false, false };




        //PLAYER MODS
        public static string[] Pg31 = new string[] { "<color=cyan>[Go Home]</color>", "BEES", "UP AND DOWN", "Size Changer <color=yellow><LT+RT, A></color>", "TP 2 Random <color=yellow><A/B></color>", "Velocity Fly <color=yellow><A/B></color>" }; 
        public static bool?[] Pg31Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg32 = new string[] { "Superman Liftoff", "Paintbrawl Spam TP <color=yellow><LAGGY></color>", "RGB <color=yellow><STUMP></color>", "Strobe <color=yellow><STUMP></color>", "Change Indentity <color=yellow><A/B></color>", "Steal Indentity" };
        public static bool?[] Pg32Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg33 = new string[] { "Iron Monke", "Set Name Nothing", "Stick Surfaces <color=yellow><LG/RG></color>", "Name Changer <color=yellow><A/B></color>", "Car Monke <color=yellow><LT/RT></color>", "Grappler" };
        public static bool?[] Pg33Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg34 = new string[] { "Swinging Monk <color=yellow>[WIP]</color>", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg34Active = new bool?[] { false, false, false, false, false, false };


        //PLAYER MODS EXTENDED PAGES
        public static string[] Pg35 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg35Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg36 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg36Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg37 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg37Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg38 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg38Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg39 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg39Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg40 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg40Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg41 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg41Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg42 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" }; 
        public static bool?[] Pg42Active = new bool?[] { false, false, false, false, false, false };




        //IMPACT MODS
        public static string[] Pg43 = new string[] { "<color=cyan>[Go Home]</color>", "Impact Self", "Pom Poms <color=yellow><LG></color>", "Impact Gun", "Impact All", "Impact Orbit" };
        public static bool?[] Pg43Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg44 = new string[] { "Impact Aura", "Give Pom Poms", "Impact Orbit Player", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg44Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg45 = new string[] { "h34ytg", "dasasyh4dw", "wwsazdgy4ewa", "dgrg5drg", "fadwyjfty", "gertk,yu" };
        public static bool?[] Pg45Active = new bool?[] { false, false, false, false, false, false };

        //IMPACT MODS EXTENDED PAGES
        public static string[] Pg46 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg46Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg47 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg47Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg48 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg48Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg49 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg49Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg50 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg50Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg51 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg51Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg52 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg52Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg53 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg53Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg54 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg54Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg55 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg55Active = new bool?[] { false, false, false, false, false, false };



        //VRRIG MODS CATEGORY
        public static string[] Pg56 = new string[] { "<color=cyan>[Go Home]</color>", "Ghost Monke <color=yellow><A/B></color>", "Invis Monke <color=yellow><A/B></color>", "Rig Gun", "Follow Player Gun", "Ghost Walk <color=yellow><LT></color>" };
        public static bool?[] Pg56Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg57 = new string[] { "Frozen Ghost Walk <color=yellow><LT></color>", "Spinny Ghost <color=yellow><LT></color>", "Spaz Monk", "Head Spin 1", "Head Spin 2", "Head Spin 3" };
        public static bool?[] Pg57Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg58 = new string[] { "Spinny Hands", "Upside Down Head", "Look At Nearest <color=yellow><LT></color>", "Helicopter <color=yellow><LT></color>", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg58Active = new bool?[] { false, false, false, false, false, false };


        //VRRIG MODs EXTENDED PAGES
        public static string[] Pg59 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg59Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg60 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg60Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg61 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg61Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg62 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg62Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg63 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg63Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg64 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg64Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg65 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg65Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg66 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg66Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg67 = new string[] { "dawdthdasd", "dasasAQWDdw", "wwersazdwa", "dggjyjfrdrg", "fyjerdghfty", "tk,yuserh" };
        public static bool?[] Pg67Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg68 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg68Active = new bool?[] { false, false, false, false, false, false };


        //VISUAL MODS
        public static string[] Pg69 = new string[] { "<color=cyan>[Go Home]</color>", "Bone ESP", "Tracers", "Chams", "Beacons", "CS-GO ESP" };
        public static bool?[] Pg69Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg70 = new string[] { "Dot ESP", "Hunt Target ESP", "Shiba User ESP", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg70Active = new bool?[] { false, false, false, false, false, false };


        //VISUAL MODS EXTENDED PAGES
        public static string[] Pg71 = new string[] { "rtfjtsrg", "dasaaergsdw", "wwsahstrfzdwa", "dewfagrdrg", "fyjftyhts", "tk,ysfu" };
        public static bool?[] Pg71Active = new bool?[] { false, false, false, false, false, false };



        //BUG MODS CATEGORY
        public static string[] Pg72 = new string[] { "<color=cyan>[Go Home]</color>", "Snipe Bug <color=yellow><RG></color>", "Follow Bug <color=yellow><LT></color>", "Bug Gun", "Reset Bug", "Orbit Bug" };
        public static bool?[] Pg72Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg73 = new string[] { "Bug Aura", "Give Bug", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg73Active = new bool?[] { false, false, false, false, false, false };


        //BUG MODS EXTENDED PAGES
        public static string[] Pg74 = new string[] { "wegsegsegs", "seji0f", "sjiofgi", "ji0srjg", "asidcjisd", "hi0edjs0r" };
        public static bool?[] Pg74Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg75 = new string[] { "Dsadfsevgsrg", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg75Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg76 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg76Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg77 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg77Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg78 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg78Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg79 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg79Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg80 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg80Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg81 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg81Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg82 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg82Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg83 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg83Active = new bool?[] { false, false, false, false, false, false };


        //BAT MODS CATEGORY
        public static string[] Pg84 = new string[] { "<color=cyan>[Go Home]</color>", "Snipe Bat <color=yellow><RG></color>", "Follow Bat <color=yellow><LT></color>", "Bat Gun", "Reset Bat", "Orbit Bat" };
        public static bool?[] Pg84Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg85 = new string[] { "Bat Aura", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg85Active = new bool?[] { false, false, false, false, false, false };


        //BAT MODS EXTENDED PAGES
        public static string[] Pg86 = new string[] { "wegsegsegs", "seji0f", "sjiofgi", "ji0srjg", "asidcjisd", "hi0edjs0r" };
        public static bool?[] Pg86Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg87 = new string[] { "Dsadfsevgsrg", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg87Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg88 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg88Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg89 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg89Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg90 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg90Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg91 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg91Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg92 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg92Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg93 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg93Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg94 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg94Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg95 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg95Active = new bool?[] { false, false, false, false, false, false };


        //BALLOON MODS CATEGORY
        public static string[] Pg96 = new string[] { "<color=cyan>[Go Home]</color>", "Balloon Theif <color=yellow><RG></color>", "Balloon Gun", "Pop All Balloons", "Spinny Balloons", "Balloon Orbit" };
        public static bool?[] Pg96Active = new bool?[] { false, false, false, false, false, false };


        //BALLOON MOD EXTENDED PAGES
        public static string[] Pg97 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg97Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg98 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg98Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg99 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg99Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg100 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg100Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg101 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg101Active = new bool?[] { false, false, false, false, false, false };


        //WATER MODS CATEGORY
        public static string[] Pg102 = new string[] { "<color=cyan>[Go Home]</color>", "Water Self", "Water Gun", "Water Bender", "Water Orbit Self", "Water Orbit All <color=yellow><NEARBY></color>" };
        public static bool?[] Pg102Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg103 = new string[] { "Water Aura Self", "Disable Water <color=yellow><LT></color>", "Fast Swim <color=yellow><LG></color>", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg103Active = new bool?[] { false, false, false, false, false, false };


        //WATER MODS EXTENDED PAGES
        public static string[] Pg104 = new string[] { "ehrgrg", "seges", "erghedge", "srghsger", "hge4wrh", "srghsrrsg" };
        public static bool?[] Pg104Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg105 = new string[] { "rehewrg", "e4rhe", "erhererg", "erheghres", "4ryhrege", "erthjertt" };
        public static bool?[] Pg105Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg106 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg106Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg107 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg107Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg108 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg108Active = new bool?[] { false, false, false, false, false, false };



        //BEACHBALL MODS
        public static string[] Pg109 = new string[] { "<color=cyan>[Go Home]</color>", "Grab Ball <color=yellow><RG></color>", "Ball Gun", "Reset Ball", "Ball Orbit", "Ball Aura" };
        public static bool?[] Pg109Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg110 = new string[] { "Ball MiniGame Spam", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg110Active = new bool?[] { false, false, false, false, false, false };


        //BEACHBALL MODS EXTENDED PAGES
        public static string[] Pg111 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg111Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg112 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg112Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg113 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg113Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg114 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg114Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg115 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg115Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg116 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg116Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg117 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg117Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg118 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg118Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg119 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg119Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg120 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg120Active = new bool?[] { false, false, false, false, false, false };



        //MONSTER MODS CATEGORY
        public static string[] Pg121 = new string[] { "<color=cyan>[Go Home]</color>", "Grab Monsters <color=yellow><RG, M></color>", "Monsters Gun <color=yellow><M></color>", "Orbit Monsters <color=yellow><M></color>", "Invis Monsters <color=yellow><M></color>", "Coming Soon" };  
        public static bool?[] Pg121Active = new bool?[] { false, false, false, false, false, false }; 

        //MONSTER MOD EXTENDED PAGES
        public static string[] Pg122 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg122Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg123 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg123Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg124 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg124Active = new bool?[] { false, false, false, false, false, false };



        //SOUND SPAM MODS CATEGORY
        public static string[] Pg125 = new string[] { "<color=cyan>[Go Home]</color>", "Break SFX All", "Break SFX Gun", "Annoy All", "Annoy Gun", "AK <color=yellow><RG+RT></color>" };
        public static bool?[] Pg125Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg126 = new string[] { "Earrape All", "Earrape Gun", "Duck Spam All", "Duck Spam Gun", "Random Sound Spam", "Sound Spam 1 <color=yellow><M></color>" };
        public static bool?[] Pg126Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg127 = new string[] { "Sound Spam 2 <color=yellow><M></color>", "Sound Spam 3 <color=yellow><M></color>", "Sound Spam 4 <color=yellow><M></color>", "Sound Spam 5 <color=yellow><M></color>", "Sound Spam 6<color=yellow><M></color>", "Coming Soon" };
        public static bool?[] Pg127Active = new bool?[] { false, false, false, false, false, false };


        //SOUND SPAM EXTENDED PAGES
        public static string[] Pg128 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg128Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg129 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg129Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg130 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg130Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg131 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg131Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg132 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg132Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg133 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg133Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg134 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg134Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg135 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg135Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg136 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg136Active = new bool?[] { false, false, false, false, false, false };



        //ROPE MODS CATEGORY
        public static string[] Pg137 = new string[] { "<color=cyan>[Go Home]</color>", "Flick All Ropes", "Spaz All Ropes", "All Ropes Up", "Freeze All Ropes", "Ropes To Gun" };
        public static bool?[] Pg137Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg138 = new string[] { "Rope To Self <color=yellow><NW></color>", "Freeze Rope Gun", "Flick Rope Gun", "Spaz Rope Gun", "Rope Up Gun", "Coming Soon" };
        public static bool?[] Pg138Active = new bool?[] { false, false, false, false, false, false };


        //EXTENDED ROPE MODS PAGES
        public static string[] Pg139 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg139Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg140 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg140Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg141 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg141Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg142 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg142Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg143 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg143Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg144 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg144Active = new bool?[] { false, false, false, false, false, false };


        //INFECTION MODS CATEGORY
        public static string[] Pg145 = new string[] { "<color=cyan>[Go Home]</color>", "Tag Gun", "Tag Aura <color=yellow><RG></color>", "Tag All", "Tag Self", "Untag All <color=yellow><M></color>" };
        public static bool?[] Pg145Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg146 = new string[] { "Untag Gun <color=yellow><M></color>", "Untag Self <color=yellow><M></color>", "No Tag On Join", "Anti Tag", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg146Active = new bool?[] { false, false, false, false, false, false };


        //INFECTION MODS EXTENDED PAGES
        public static string[] Pg147 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg147Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg148 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg148Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg149 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg149Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg150 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg150Active = new bool?[] { false, false, false, false, false, false };



        //PAINTBRAWL MDOS CATEGORY
        public static string[] Pg151 = new string[] { "<color=cyan>[Go Home]</color>", "Kill Gun", "Kill All", "Revive Gun <color=yellow><M></color>", "Revive All <color=yellow><M></color>", "+1 Life Gun <color=yellow><M></color>" };
        public static bool?[] Pg151Active = new bool?[] { false, false, false, false, false, false };


        //PAINTBRAWL MODS EXTENDED PAGES
        public static string[] Pg152 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg152Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg153 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg153Active = new bool?[] { false, false, false, false, false, false };



        //MASTER MODS CATEGORY
        public static string[] Pg154 = new string[] { "<color=cyan>[Go Home]</color>", "Mat Spam All", "Mat Spam Gun", "Mat Spam Self", "Slow All", "Slow Gun" };
        public static bool?[] Pg154Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg155 = new string[] { "Vibrate All", "Vibrate Gun", "Spam Balloons All", "Spam Balloons Gun", "Change Gamemode Casual", "Change Gamemode Infection" };
        public static bool?[] Pg155Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg156 = new string[] { "Change Gamemode Hunt", "Change Gamemode Paintbrawl", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg156Active = new bool?[] { false, false, false, false, false, false };


        //MASTER MODS EXTNEDED PAGES
        public static string[] Pg157 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg157Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg158 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg158Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg159 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg159Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg160 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg160Active = new bool?[] { false, false, false, false, false, false };


        //ABUSIVE MODS CATEGORY
        public static string[] Pg161 = new string[] { "<color=cyan>[Go Home]</color>", "Kick All <color=yellow><PRIV></color>", "Kick Gun <color=yellow><PRIV></color>", "Lag All <color=yellow><RG></color>", "Lag Gun", "Crash All <color=yellow><RG></color>" };
        public static bool?[] Pg161Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg162 = new string[] { "Crash Gun", "Invis All <color=yellow><Rejoin></color>", "Invis Gun <color=yellow><Rejoin></color>", "Crash Aura", "Crash Player Vel Test", "Coming Soon" };
        public static bool?[] Pg162Active = new bool?[] { false, false, false, false, false, false };



        //ABUSIVE MODS EXTENDED PAGES
        public static string[] Pg163 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg163Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg164 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg164Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg165 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg165Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg166 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg166Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg167 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg167Active = new bool?[] { false, false, false, false, false, false };



        //PROJECTILE MODS CATEGOR
        public static string[] Pg168 = new string[] { "<color=cyan>[Go Home]</color>", "Slingshot Spammer\n <color=yellow>[SETTINGS]</color>", "Snowball Spammer\n <color=yellow>[SETTINGS]</color>", "WaterBalloon Spammer\n <color=yellow>[SETTINGS]</color>", "Lavarock Spammer\n <color=yellow>[SETTINGS]</color>", "Cupid Spammer\n <color=yellow>[SETTINGS]</color>" };
        public static bool?[] Pg168Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg169 = new string[] { "DeadShot Spammer\n <color=yellow>[SETTINGS]</color>", "Ice Spammer\n <color=yellow>[SETTINGS]</color>", "Cloud Spammer\n <color=yellow>[SETTINGS]</color>", "LeafPile Spammer\n <color=yellow>[SETTINGS]</color>", "Spider Spammer\n <color=yellow>[SETTINGS]</color>", "MoltenRock Spammer\n <color=yellow>[SETTINGS]</color>" };
        public static bool?[] Pg169Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg170 = new string[] { "Projectile Orbit\n <color=yellow>[SETTINGS]</color> <color=cyan>[RT]</color>", "Projectile Aura\n <color=yellow>[SETTINGS]</color> <color=cyan>[RT]</color>", "Projectile EarthQuake\n <color=yellow>[SETTINGS]</color> <color=yellow>[RT]</color>", "Projectile Hail\n <color=yellow>[SETTINGS]</color> <color=yellow>[RT]</color>", "Projectile JetBeams\n <color=yellow>[SETTINGS]</color> <color=yellow>[RT]</color>", "Projectile Tunnel\n <color=yellow>[SETTINGS]</color> <color=yellow>[RT]</color>" };
        public static bool?[] Pg170Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg171 = new string[] { "Projectile FireWorks\n <color=yellow>SETTINGS]</color> <color=yellow>[RT]</color>", "Player Projectile Spammer", "Ice Beam", "Lazer Eyes", "Give Hand Spammers <color=yellow>[NEARBY]</color> <color=yellow>[SETTINGS]</color>", "Give Orbit Spammers <color=yellow>[NEARBY]</color> <color=yellow>[SETTINGS]</color>" };
        public static bool?[] Pg171Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg172 = new string[] { "Give Hail Spammers <color=yellow>[NEARBY]</color> <color=yellow>[SETTINGS]</color>", "Give Earthquake Spammers <color=yellow>[NEARBY]</color> <color=yellow>[SETTINGS]</color>", "Projectile Massacre <color=yellow>[SETTINGS]</color>", "Unity Block Test", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg172Active = new bool?[] { false, false, false, false, false, false };

        
        //PROJECTILE MODS EXTENDED PAGES
        public static string[] Pg173 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg173Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg174 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg174Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg175 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg175Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg176 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg176Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg177 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg177Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg178 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg178Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg179 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg179Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg180 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg180Active = new bool?[] { false, false, false, false, false, false };


        //MISC MODS CATEGORY
        public static string[] Pg181 = new string[] { "<color=cyan>[Go Home]</color>", "No Lobby Leave", "Spam Cosmetic Slot 1", "Spam Cosmetic Slot 2", "Spam Cosmetic Slot 3", "Spam All Cosmetic Slots" };
        public static bool?[] Pg181Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg182 = new string[] { "Disable AFK Kick", "TP To Stump <color=yellow>[A/B]</color>", "Anti Projectile Crash", "Turn Off QuitBox", "Change to PBBV", "Change to J3VU" };
        public static bool?[] Pg182Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg183 = new string[] { "Change to Daisy09", "Mod Detector", "Color logger", "Coming Soon", "Coming Soon", "Set Master" };
        public static bool?[] Pg183Active = new bool?[] { false, false, false, false, false, false };


        //MISC MODS EXTENDED PAGES
        public static string[] Pg184 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg184Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg185 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg185Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg186 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg186Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg187 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg187Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg188 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg188Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg189 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg189Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg190 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg190Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg191 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg191Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg192 = new string[] { "noidrnmo", "wipgmiopse", "ji0seef", "w903ujriofw", "nadwadwd", "ijwejsg" };
        public static bool?[] Pg192Active = new bool?[] { false, false, false, false, false, false };


        //Christmas mods
        public static string[] Pg193 = new string[] { "<color=cyan>[Go Home]</color>", "Present Type: Cane", "Present Spam: Gun", "Present Spam", "Coming Soon", "Coming Soon" };
        public static bool?[] Pg193Active = new bool?[] { false, false, false, false, false, false };

        static void Prefix(GorillaLocomotion.Player __instance)
        {
            try
            {
                AntiBan.AntiBanEvade();
                CustomBoards.Update();
                ProjectileMods.Colors();
                ImpactMods.ColorLOL();
                ProjectileMods.TrailType();
                ProjectileMods.ProjectileChanger();
                ColorManager.TundraColoScheme();
                BypassTP.Prefix();
                GraceBypass.Prefix();
                ColorManager.OnTriggeredGuns();
                Christmas2023Mods.PresentType();
                if (init)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Debug.Log("Tundra Client Successfully Initalized");
                    NotifiLib.SendNotification("<color=red>PLEASE USE THE SETTINGS!</color>");

                    //PAGE PRESETS
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;



                    righthand = false;
                    Reversed = false;

                    init = false;    
                }
                if (righthand)
                {
                    if (openButton == 1)
                    {
                        if (input.rightControllerSecondaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null)
                        {
                            DrawMenu();
                            // Add Custom Buttons Here
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                            AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && !righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                            if (referenceObj == null && righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.leftControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.rightControllerSecondaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null && righthand)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                            MenuObj.transform.RotateAround(MenuObj.transform.position, MenuObj.transform.forward, 180f);
                        }
                        if (input.rightControllerSecondaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {
                                NotifiLib.SendWithCooldown("NO SECONDARY INPUT", 4000);
                            }
                        }
                        if (!input.rightControllerSecondaryButton && MenuObj != null)
                        {
                            GameObject.Destroy(MenuObj);
                            MenuObj = null;
                            GameObject.Destroy(referenceObj);
                            referenceObj = null;
                            GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                            GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                            GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                        }
                    }
                    else if (openButton == 2)
                    {
                        if (input.rightControllerPrimaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null)
                        {
                            DrawMenu();
                            // Add Custom Buttons Here
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                            AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && !righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                            if (referenceObj == null && righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.leftControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.rightControllerPrimaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null && righthand)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                            MenuObj.transform.RotateAround(MenuObj.transform.position, MenuObj.transform.forward, 180f);
                        }
                        if (input.rightControllerPrimaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {
                                NotifiLib.SendWithCooldown("NO SECONDARY INPUT", 4000);
                            }
                        }
                        if (!input.rightControllerPrimaryButton && MenuObj != null)
                        {
                            GameObject.Destroy(MenuObj);
                            MenuObj = null;
                            GameObject.Destroy(referenceObj);
                            referenceObj = null;
                            GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                            GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                            GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                        }
                    }
                }
                else if (!righthand)
                {
                    if (openButton == 1)
                    {
                        if (input.leftControllerSecondaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null)
                        {
                            DrawMenu();
                            // Add Custom Buttons Here
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                            AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && !righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                            if (referenceObj == null && righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.leftControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.leftControllerSecondaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                        }
                        if (input.leftControllerSecondaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {
                                NotifiLib.SendWithCooldown("NO SECONDARY INPUT", 4000);
                            }
                        }
                        if (!input.leftControllerSecondaryButton && MenuObj != null)
                        {
                            GameObject.Destroy(MenuObj);
                            MenuObj = null;
                            GameObject.Destroy(referenceObj);
                            referenceObj = null;
                            GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                            GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                            GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                        }
                    }
                    else if (openButton == 2)
                    {
                        if (input.leftControllerPrimaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null)
                        {
                            DrawMenu();
                            // Add Custom Buttons Here
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                            AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && !righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                            if (referenceObj == null && righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.leftControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.leftControllerPrimaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                        }
                        if (input.leftControllerPrimaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    GameObject.Destroy(TundraMain.MenuObj);
                                    TundraMain.MenuObj = null;
                                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                                    TundraMain.DrawMenu();
                                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {
                                NotifiLib.SendWithCooldown("NO SECONDARY INPUT", 4000);
                            }
                        }
                        if (!input.leftControllerPrimaryButton && MenuObj != null)
                        {
                            GameObject.Destroy(MenuObj);
                            MenuObj = null;
                            GameObject.Destroy(referenceObj);
                            referenceObj = null;
                            GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                            GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                            GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                        }
                    }
                }


                //Page 1=

                if (Pg1Active[0] == true)
                {
                    Pg1Active[0] = false;
                    pageNumber = 11;
                    page2 = true;
                    page1 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg1Active[1] == true)  
                {
                    Pg1Active[1] = false;
                    pageNumber= 16;
                    page3 = true;
                    page2 = false;
                    page1 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg1Active[2] == true)
                {
                    Pg1Active[2] = false;
                    pageNumber = 31;
                    page3 = false;
                    page2 = false;
                    page1 = false;
                    page4 = true;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg1Active[3] == true)
                {
                    Pg1Active[3] = false;
                    pageNumber = 43;
                    page3 = false;
                    page2 = false;
                    page1 = false;
                    page4 = false;
                    page5 = true;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg1Active[4] == true)
                {
                    Pg1Active[4] = false;
                    pageNumber = 56;
                    page3 = false;
                    page2 = false;
                    page1 = false;
                    page4 = false;
                    page5 = false;
                    page6 = true;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg1Active[5] == true)
                {
                    Pg1Active[5] = false;
                    pageNumber = 69;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = true;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg2Active[0] == true)
                {
                    Pg2Active[0] = false;
                    pageNumber = 72;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = true;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg2Active[1] == true)
                {
                    Pg2Active[1] = false;
                    pageNumber = 84;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = true;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false; 
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg2Active[2] == true)
                {
                    Pg2Active[2] = false;
                    pageNumber = 96;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = true;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg2Active[3] == true)
                {
                    Pg2Active[3] = false;
                    pageNumber = 102;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = true;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg2Active[4] == true)
                {
                    Pg2Active[4] = false;
                    pageNumber = 109;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = true;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg2Active[5] == true)
                {
                    Pg2Active[5] = false;
                    pageNumber = 121;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = true;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg3Active[0] == true)
                {
                    Pg3Active[0] = false;
                    pageNumber = 125;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = true;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg3Active[1] == true)
                {
                    Pg3Active[1] = false;
                    pageNumber = 137;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = true;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg3Active[2] == true)
                {
                    Pg3Active[2] = false;
                    pageNumber = 145;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = true;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg3Active[3] == true)
                {
                    Pg3Active[3] = false;
                    pageNumber = 151;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = true;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg3Active[4] == true)
                {
                    Pg3Active[4] = false;
                    pageNumber = 154;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = true;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg3Active[5] == true)
                {
                    Pg3Active[5] = false;
                    pageNumber = 161;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = true;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg4Active[0] == true)
                {
                    Pg4Active[0] = false;
                    pageNumber = 168;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = true;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg4Active[1] == true)
                {
                    Pg4Active[1] = false;
                    pageNumber = 181;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = true;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg4Active[2] == true)
                {
                    Pg4Active[2] = false;
                    pageNumber = 193;
                    page1 = false;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = true;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }



                //PAGE 2

                if (Pg11Active[0] == true)
                {
                    Pg11Active[0] = false;
                    pageNumber = 1;
                    page2 = false;
                    page1 = true;
                    page3 = false;
                    page5 = false;
                    page4 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg11Active[1] == true)  //RIGHT HAND MENU
                {
                    Pg11[1] = "Right Hand Menu <color=yellow>[Yes]</color>";
                    righthand = true;
                }
                else
                {
                    Pg11[1] = "Right Hand Menu <color=yellow>[No]</color>";
                    righthand = false;
                }
                if (Pg11Active[2] == true) //SAVE SETTINGS
                {

                }
                if (Pg11Active[3] == true) //Menu INPUT
                {
                    openButton++;
                    if (openButton > 3)
                    {
                        openButton = 1;
                    }
                    if (openButton == 1)
                    {
                        Pg11[3] = "Menu Input: <color=yellow>[Secondary]</color>";
                        Pg11Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (openButton == 2)
                    {
                        Pg11[3] = "Menu Input: <color=yellow>[Primary]</color>";
                        Pg11Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg11Active[4] == true)
                {
                    PageType++;
                    if (PageType > 4)
                    {
                        PageType = 1;
                    }
                    if (PageType == 1)
                    {
                        Pg11[4] = "Secondary Layout: <color=yellow>[Triggers]</color>";
                        Pg11Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PageType == 2)
                    {
                        Pg11[4] = "Secondary Layout: <color=yellow>[Grips]</color>";
                        Pg11Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PageType == 3)
                    {
                        Pg11[4] = "Secondary Layout: <color=yellow>[None]</color>";
                        Pg11Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg11Active[5] == true) 
                {
                    GunLock++;
                    if (GunLock > 3)
                    {
                        GunLock = 1;
                    }
                    if (GunLock == 1)
                    {
                        Pg11[5] = "GunLock: <color=yellow>[False]</color>";
                        Pg11Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (GunLock == 2)
                    {
                        Pg11[5] = "GunLock: <color=yellow>[True]</color>";
                        Pg11Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg12Active[0] == true)
                {
                    FPSType++;
                    if (FPSType > 9)
                    {
                        FPSType = 1;
                    }
                    if (FPSType == 1)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.1]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 2)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.2]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 3)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.3]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 4)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.4]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 5)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.5]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 6)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.6]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 7)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.7]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 8)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.8]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (FPSType == 9)
                    {
                        Pg12[0] = "FPS Boost: <color=yellow>[0.9]</color>";
                        Pg12Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg12Active[1] == true) 
                {
                    LongArmType++;
                    if (LongArmType > 5)
                    {
                        LongArmType = 1;
                    }
                    if (LongArmType == 1)
                    {
                        Pg12[1] = "LongArm Type: <color=yellow>[1.15]</color>";
                        Pg12Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (LongArmType == 2)
                    {
                        Pg12[1] = "LongArm Type: <color=yellow>[1.25]</color>";
                        Pg12Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (LongArmType == 3)
                    {
                        Pg12[1] = "LongArm Type: <color=yellow>[1.50]</color>";
                        Pg12Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (LongArmType == 4)
                    {
                        Pg12[1] = "LongArm Type: <color=yellow>[1.75]</color>";
                        Pg12Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg12Active[2] == true) 
                {
                    SpeedType++;
                    if (SpeedType > 6)
                    {
                        SpeedType = 1;
                    }
                    if (SpeedType == 1)
                    {
                        Pg12[2] = "Super Speed: <color=yellow>[9.5]</color>";
                        Pg12Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpeedType == 2)
                    {
                        Pg12[2] = "Super Speed: <color=yellow>[10.0]</color>";
                        Pg12Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpeedType == 3)
                    {
                        Pg12[2] = "Super Speed: <color=yellow>[10.5]</color>";
                        Pg12Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpeedType == 4)
                    {
                        Pg12[2] = "Super Speed: <color=yellow>[11.0]</color>";
                        Pg12Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpeedType == 5)
                    {
                        Pg12[2] = "Super Speed: <color=yellow>[11.5]</color>";
                        Pg12Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg12Active[3] == true)
                {
                    MosaType++;
                    if (MosaType > 3)
                    {
                        MosaType = 1;
                    }
                    if (MosaType == 1)
                    {
                        Pg12[3] = "Mosa Speed: <color=yellow>[No Grip]</color>";
                        Pg12Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (MosaType == 2)
                    {
                        Pg12[3] = "Mosa Speed: <color=yellow>[Grip]</color>";
                        Pg12Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg12Active[4] == true) 
                {
                    AutoTagSelf++;
                    if (AutoTagSelf > 3)
                    {
                        AutoTagSelf = 1;
                    }
                    if (AutoTagSelf == 1)
                    {
                        Pg12[4] = "TagSelf On TagMods: <color=yellow>[False]</color>";
                        Pg12Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (AutoTagSelf == 2)
                    {
                        Pg12[4] = "TagSelf On TagMods: <color=yellow>[True]</color>";
                        Pg12Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg12Active[5] == true) 
                {
                    VelSpeed++;
                    if (VelSpeed > 6)
                    {
                        VelSpeed = 1;
                    }
                    if (VelSpeed == 1)
                    {
                        Pg12[5] = "Velocity Fly Speed: <color=yellow>[10]</color>";
                        Pg12Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (VelSpeed == 2)
                    {
                        Pg12[5] = "Velocity Fly Speed: <color=yellow>[20]</color>";
                        Pg12Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (VelSpeed == 3)
                    {
                        Pg12[5] = "Velocity Fly Speed: <color=yellow>[30]</color>";
                        Pg12Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (VelSpeed == 4)
                    {
                        Pg12[5] = "Velocity Fly Speed: <color=yellow>[40]</color>";
                        Pg12Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (VelSpeed == 5)
                    {
                        Pg12[5] = "Velocity Fly Speed: <color=yellow>[50]</color>";
                        Pg12Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg13Active[0] == true) 
                {
                    ProjType++;
                    if (ProjType > 5)
                    {
                        ProjType = 1;
                    }
                    if (ProjType == 1)
                    {
                        Pg13[0] = "Projectile Type: <color=yellow>[Gun]</color>";
                        Pg13Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjType == 2)
                    {
                        Pg13[0] = "Projectile Type: <color=yellow>[Impact Gun]</color>";
                        Pg13Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjType == 3)
                    {
                        Pg13[0] = "Projectile Type: <color=yellow>[Hand]</color>";
                        Pg13Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjType == 4)
                    {
                        Pg13[0] = "Projectile Type: <color=yellow>[Launcher]</color>";
                        Pg13Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg13Active[1] == true)
                {
                    SpecialType++;
                    if (SpecialType > 12)
                    {
                        SpecialType = 1;
                    }
                    if (SpecialType == 1)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[SlingShot]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 2)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[Snowball]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 3)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[Waterballoon]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 4)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[LavaRock]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 5)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[CupidArrow]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 6)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[DeadShot]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 7)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[Ice]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 8)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[Cloud]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 9)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[LeafPile]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 10)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[Spider]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (SpecialType == 11)
                    {
                        Pg13[1] = "Projectile Specials Type: <color=yellow>[MoltenRock]</color>";
                        Pg13Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg13Active[2] == true) 
                {
                    TrailType++;
                    if (TrailType > 6)
                    {
                        TrailType = 1;
                    }
                    if (TrailType == 1)
                    {
                        Pg13[2] = "Trail Type: <color=yellow>[None]</color>";
                        Pg13Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (TrailType == 2)
                    {
                        Pg13[2] = "Trail Type: <color=yellow>[Normal]</color>";
                        Pg13Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (TrailType == 3)
                    {
                        Pg13[2] = "Trail Type: <color=yellow>[Cloud]</color>";
                        Pg13Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (TrailType == 4)
                    {
                        Pg13[2] = "Trail Type: <color=yellow>[Cupid]</color>";
                        Pg13Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (TrailType == 5)
                    {
                        Pg13[2] = "Trail Type: <color=yellow>[DeadShot]</color>";
                        Pg13Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg13Active[3] == true) 
                {
                    PlayerType++;
                    if (PlayerType > 5)
                    {
                        PlayerType = 1;
                    }
                    if (PlayerType == 1)
                    {
                        Pg13[3] = "Player Projectile <color=yellow>[Piss]</color>";
                        Pg13Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PlayerType == 2)
                    {
                        Pg13[3] = "Player Projectile <color=yellow>[Shit]</color>";
                        Pg13Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PlayerType == 3)
                    {
                        Pg13[3] = "Player Projectile <color=yellow>[Cum]</color>";
                        Pg13Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PlayerType == 4)
                    {
                        Pg13[3] = "Player Projectile <color=yellow>[Vomit]</color>";
                        Pg13Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg13Active[4] == true) 
                {
                   
                }
                if (Pg13Active[5] == true) 
                {
                    
                }
                if (Pg14Active[0] == true) 
                {
                    PROJCOLOR++;
                    if (PROJCOLOR > 18)
                    {
                        PROJCOLOR = 1;
                    }
                    if (PROJCOLOR == 1)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Black]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 2)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[White]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (PROJCOLOR == 3)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Grey]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 4)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Pink]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 5)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Red]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 6)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Orange]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 7)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Yellow]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 8)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Acid]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 9)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Green]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 10)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Mint]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 11)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Cyan]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 12)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Blue]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 13)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Purple]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 14)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Magenta]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 15)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Brown]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 16)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Random]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PROJCOLOR == 17)
                    {
                        Pg14[0] = "Projectile Color: <color=yellow>[Rainbow]</color>";
                        Pg14Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg14Active[1] == true) 
                {
                    int pageInt = 1;
                    ImpactColors++;
                    if (ImpactColors > 8)
                    {
                        ImpactColors = 1;
                    }
                    if (ImpactColors == 1)
                    {
                        Pg14[pageInt] = "Impact Color: <color=red>[Red]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ImpactColors == 2)
                    {
                        Pg14[pageInt] = "Impact Color: <color=green>[Green]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (ImpactColors == 3)
                    {
                        Pg14[pageInt] = "Impact Color: <color=blue>[Blue]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ImpactColors == 4)
                    {
                        Pg14[pageInt] = "Impact Color: <color=yellow>[Black]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ImpactColors == 5)
                    {
                        Pg14[pageInt] = "Impact Color: <color=cyan>[Acid]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ImpactColors == 6)
                    {
                        Pg14[pageInt] = "Impact Color: <color=cyan>[Purple]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ImpactColors == 7)
                    {
                        Pg14[pageInt] = "Impact Color: <color=cyan>[Random Colors]</color>";
                        Pg14Active[pageInt] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg14Active[2] == true) 
                {
                    ESPType++;
                    if (ESPType > 4)
                    {
                        ESPType = 1;
                    }
                    if (ESPType == 1)
                    {
                        Pg14[2] = "ESP Color: <color=yellow>[TeamBased]</color>";
                        Pg14Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ESPType == 2)
                    {
                        Pg14[2] = "ESP Color: <color=yellow>[RGB]</color>";
                        Pg14Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ESPType == 3)
                    {
                        Pg14[2] = "ESP Color: <color=yellow>[RigColor]</color>";
                        Pg14Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg14Active[3] == true) 
                {
                    ColorScheme++;
                    if (ColorScheme > 21)
                    {
                        ColorScheme = 1;
                    }
                    if (ColorScheme == 1)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Black]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 2)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[White]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 3)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Grey]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 4)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Pink]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 5)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Red]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 6)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Orange]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 7)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Yellow]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 8)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Green]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 9)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Mint]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 10)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Blue]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 11)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Purple]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 12)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Magenta - Black]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 13)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Red - Pink]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 14)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Purple - Orange]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 15)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Yellow - Blue]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 16)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Purple - Salmon]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 17)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Black - Orange]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 18)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Mint - Salmon]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 19)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[RGB]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ColorScheme == 20)
                    {
                        Pg14[3] = "ColorScheme: <color=yellow>[Player]</color>";
                        Pg14Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg14Active[4] == true)
                {
                    lobbyhopmode++;
                    if (lobbyhopmode > 2)
                    {
                        lobbyhopmode = 1;
                    }
                    if (lobbyhopmode == 1)
                    {
                        NotifiLib.SendWithCooldown("Just Click Your Controller Button", 2);
                        Pg14[4] = "Lobby Hop Type: <color=yellow>[X/Y]</color>";
                        Pg14Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (lobbyhopmode == 2)
                    {
                        NotifiLib.SendWithCooldown("Leave With <color=yellow>Top Disconnect Button</color> Or <color=yellow>Computers</color>", 3);
                        Pg14[4] = "Lobby Hop Type: <color=yellow>On Leave</color>";
                        Pg14Active[4] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg14Active[5] == true)
                {
                    AntiReport++;
                    if (AntiReport >= 3)
                    {
                        AntiReport = 1;
                    }
                    if (AntiReport == 1)
                    {
                        Pg14[5] = "Anti Report: <color=yellow>[True]</color>";
                        Pg14Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (AntiReport == 2)
                    {
                        Pg14[5] = "Anti Report: <color=yellow>[True]</color>";
                        Pg14Active[5] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg15Active[0] == true)
                {
                    GunHand++;
                    if (GunHand > 4)
                    {
                        GunHand = 1;
                    }
                    if (GunHand == 1)
                    {
                        Pg15[0] = "Guns Hand: <color=yellow>[Right]</color>";
                        Pg15Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (GunHand == 2)
                    {
                        Pg15[0] = "Guns Hand: <color=yellow>[Left]</color>";
                        Pg15Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (GunHand == 3)
                    {
                        Pg15[0] = "Guns Hand: <color=yellow>[Both]</color>";
                        Pg15Active[0] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg15Active[1] == true)
                {
                    NotifResult++;
                    if (NotifResult > 3)
                    {
                        NotifResult = 1;
                    }
                    if (NotifResult == 1)
                    {
                        Pg15[1] = "Disable Notifs <color=yellow>[True]</color>";
                        Pg15Active[1] = false;
                        GameObject.Find("NOTIFICATIONLIB_HUD_OBJ").SetActive(false);
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (NotifResult == 2)
                    {
                        Pg15[1] = "Disable Notifs <color=yellow>[False]</color>";
                        Pg15Active[1] = false;
                        GameObject.Find("NOTIFICATIONLIB_HUD_OBJ").SetActive(true);
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg15Active[2] == true)
                {
                    ProjTypeSelect++;
                    if (ProjTypeSelect > 12)
                    {
                        ProjTypeSelect = 1;
                    }
                    if (ProjTypeSelect == 1)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[SlingShot]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 2)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Snowball]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 3)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Waterballoon]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 4)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Lavarock]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 5)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Cupid]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 6)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[DeadShot]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 7)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Ice]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 8)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Cloud]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 9)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[LeafPile]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 10)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Spider]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (ProjTypeSelect == 11)
                    {
                        Pg15[2] = "Give Spammer Type: <color=yellow>[Molten Rock]</color>";
                        Pg15Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg15Active[3] == true)
                {
                    PlatInput++;
                    if (PlatInput > 3)
                    {
                        PlatInput = 1;
                    }
                    if (PlatInput == 1)
                    {
                        Pg15[3] = "Platform Input: <color=yellow>[Grips]</color>";
                        Pg15Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PlatInput == 2)
                    {
                        Pg15[3] = "Platform Input: <color=yellow>[Triggers]</color>";
                        Pg15Active[3] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }





                //
                if (Pg16Active[0] == true)
                {
                    Pg16Active[0] = false;
                    pageNumber = 1;
                    page3 = false;
                    page2 = false;
                    page1 = true;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg16Active[1] == true)
                {
                    BasicMods.CreatePub();
                    Pg16Active[1] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg16Active[2] == true)
                {
                    BasicMods.LeaveLobby();
                }
                if (Pg16Active[3] == true)
                {
                    LobbyHop.Update();
                }
                if (Pg16Active[4] == true)
                {
                    if (btcBool)
                    {
                        shouldercam = GameObject.Find("Shoulder Camera");
                        camcomp = shouldercam.GetComponent<Camera>();
                        camcomp.fieldOfView = 128f;
                        shouldercam.transform.SetParent(Camera.main.transform);
                        shouldercam.transform.localPosition = new Vector3(0f, 0f, 0f);
                        shouldercam.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        btcBool = false;
                    }
                }
                if (Pg16Active[5] == true)
                {
                    GorillaComputer.instance.CompQueueUnlockButtonPress();
                    Pg16Active[5] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg17Active[0] == true)
                {
                    BasicMods.SpeedType();
                }
                if (Pg17Active[1] == true)
                {
                    BasicMods.MosaType();
                }
                if (Pg17Active[2] == true)
                {
                    Physics.gravity = new Vector3(0f, -4f, 0f);
                }
                else
                {
                    if (Pg17Active[2] == false)
                    {
                        Physics.gravity = new Vector3(0f, -9.81f, 0f);
                    }
                }
                if (Pg17Active[3] == true)
                {
                    Physics.gravity = new Vector3(0f, -0f, 0f);
                }
                else
                {
                    if (Pg17Active[2] == false)
                    {

                    }
                }
                if (Pg17Active[4] == true)
                {
                    Physics.gravity = new Vector3(0f, -28f, 0f);
                }
                else
                {
                    if (Pg17Active[2] == false)
                    {

                    }
                }
                if (Pg17Active[5] == true)
                {
                    BasicMods.FPSBoost(); 
                }
                else
                {
                    QualitySettings.globalTextureMipmapLimit = 0;
                }
                if (Pg18Active[0] == true)
                {
                    GorillaLocomotion.Player.Instance.slideControl = 1;
                }
                else
                {
                    GorillaLocomotion.Player.Instance.slideControl = 0.00425f;
                }
                if (Pg18Active[1] == true)
                {
                    if (input.rightControllerPrimaryButton)
                    {
                        if (Origin)
                        {
                            Reversed = !Reversed;
                            Origin = false;
                        }
                    }
                    else
                    {
                        Origin = true;
                    }

                    if (Reversed)
                    {
                        GorillaLocomotion.Player.Instance.scale = 4;
                    }
                    else
                    {
                        GorillaLocomotion.Player.Instance.scale = 1;
                    }
                }
                if (Pg18Active[2] == true)
                {
                    if (input.rightControllerPrimaryButton)
                    {
                        if (Origin)
                        {
                            Reversed = !Reversed;
                            Origin = false;
                        }
                    }
                    else
                    {
                        Origin = true;
                    }

                    if (Reversed)
                    {
                        GorillaLocomotion.Player.Instance.scale = 0.6f;
                    }
                    else
                    {
                        GorillaLocomotion.Player.Instance.scale = 1;
                    }
                }
                if (Pg18Active[3] == true)
                {
                    BasicMods.LongArmType();
                }
                if (Pg18Active[3] == false)
                {
                    GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1, 1, 1);
                }
                if (Pg18Active[4] == true)
                {
                    BasicMods.FastFly();
                }
                if (Pg18Active[5] == true)
                {
                    BasicMods.SlowFlyNoClip();
                }
                if (Pg19Active[0] == true)
                {
                    BasicMods.ProcessTeleportGun();
                }
                if (Pg19Active[1] == true)
                {
                    BasicMods.Checkpoint();
                }
                if (Pg19Active[2] == true)
                {
                    BasicMods.SpawnC4();
                }
                if (Pg19Active[3] == true)
                {
                    BasicMods.NoClip();
                }
                if (Pg19Active[4] == true)
                {
                    GorillaTagger.Instance.handTapVolume = 0.9f;
                }
                if (Pg19Active[4] == false)
                {
                    GorillaTagger.Instance.handTapVolume = 0.1f;
                }
                if (Pg19Active[5] == true)
                {
                    BasicMods.JRP();
                    Pg19Active[5] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg20Active[0] == true)
                {
                    BasicMods.Plats();
                }
                if (Pg20Active[1] == true)
                {
                    BasicMods.StickyPlats();
                }
                if (Pg20Active[2] == true)
                {
                    GorillaLocomotion.Player.Instance.disableMovement = false;
                }
                if (Pg20Active[3] == true)
                {
                    PlayerMods.AirStrike();
                }
                if (Pg20Active[4] == true)
                {
                    BasicMods.Hertz45();
                }
                



                //CATEGORY 3
                if (Pg31Active[0] == true)
                {
                    Pg31Active[0] = false;
                    pageNumber = 1;
                    page3 = false;
                    page5 = false;
                    page2 = false;
                    page1 = true;
                    page4 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg31Active[1] == true)
                {
                    PlayerMods.Bees();
                }
                if (Pg31Active[1] == false)
                {
                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
                if (Pg31Active[2] == true)
                {
                    PlayerMods.UPNDOWN();
                }
                if (Pg31Active[3] == true)
                {
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaLocomotion.Player.Instance.scale += 0.04f;
                    }
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaLocomotion.Player.Instance.scale -= 0.05f;
                    }
                    if (input.rightControllerPrimaryButton)
                    {
                        GorillaLocomotion.Player.Instance.scale = 1;
                    }
                }
                if (Pg31Active[4] == true)
                {
                    PlayerMods.TPRandomW();
                }
                if (Pg31Active[5] == true)
                {
                    PlayerMods.VelFly();
                }
                if (Pg32Active[0] == true)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().drag = -2;
                }
                if (Pg32Active[0] == false)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().drag = 0;
                }
                if (Pg32Active[1] == true)
                {
                  
                }
                if (Pg32Active[2] == true)
                {
                    PlayerMods.RGB();
                }
                if (Pg32Active[3] == true)
                {
                    PlayerMods.Strobe();
                }
                if (Pg32Active[4] == true)
                {
                    PlayerMods.SpoofPlayer();
                }
                if (Pg32Active[5] == true)
                {
                    PlayerMods.StealPlayer();
                }
                if (Pg33Active[0] == true)
                {
                    PlayerMods.IronMonkKONCreds();
                }
                if (Pg33Active[1] == true)
                {
                    PlayerMods.SetNameNothing();
                    Pg33Active[1] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg33Active[2] == true)
                {
                    PlayerMods.StickySurfaces();
                }
                if (Pg33Active[3] == true)
                {
                    PlayerMods.NameChanger();
                }
                if (Pg33Active[4] == true)
                {
                    PlayerMods.CarMonke();
                }
                if (Pg33Active[5] == true)
                {
                    PlayerMods.GrappleMonk();
                }
                if (Pg34Active[0] == true)
                {
                    PlayerMods.SwingingMonk();
                }
                if (Pg34Active[1] == true)
                {
                    HashManager.Manager();
                }


                //NEXT PAGE
                if (Pg43Active[0] == true)
                {
                    Pg43Active[0] = false;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    pageNumber = 1;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg43Active[1] == true)
                {
                    ImpactMods.ImpactSelf();
                }
                if (Pg43Active[2] == true)
                {
                    ImpactMods.ImpactPomPoms();
                }
                if (Pg43Active[3] == true)
                {
                    ImpactMods.ImpactGun();
                }
                if (Pg43Active[4] == true)
                {
                    ImpactMods.ImpactAll();
                }
                if (Pg43Active[5] == true)
                {
                    ImpactMods.ImpactOrbit();
                }
                if (Pg44Active[0] == true)
                {
                    ImpactMods.ImpactAura();
                }
                if (Pg44Active[1] == true)
                {
                    ImpactMods.GivePomPoms();
                }
                if (Pg44Active[2] == true)
                {
                    ImpactMods.ImpactOrbitPlayer();
                }





                if (Pg56Active[0] == true)
                {
                    Pg56Active[0] = false;
                    pageNumber = 1;
                    page2 = false;
                    page1 = true;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg56Active[1] == true)
                {
                    VRRigMods.GhostMonke();
                }
                if (Pg56Active[2] == true)
                {
                    VRRigMods.InvisMonke();
                }
                if (Pg56Active[3] == true)
                {
                    VRRigMods.RigGun();
                }
                if (Pg56Active[4] == true)
                {
                    VRRigMods.FollowPlayer();
                }
                if (Pg56Active[5] == true)
                {
                    VRRigMods.GhostWalk();
                }
                if (Pg57Active[0] == true)
                {
                    VRRigMods.FrozenGhostWalk();
                }
                if (Pg57Active[1] == true)
                {
                    VRRigMods.SpinnyMonk();
                }
                if (Pg57Active[2] == true)
                {
                    GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(120, 480), (float)UnityEngine.Random.Range(1, 612), (float)UnityEngine.Random.Range(12, 612));
                    GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(120, 480), (float)UnityEngine.Random.Range(1, 612), (float)UnityEngine.Random.Range(12, 612));
                    GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(120, 480), (float)UnityEngine.Random.Range(1, 612), (float)UnityEngine.Random.Range(12, 612));
                }
                if (Pg57Active[3] == true)   //head spin 1
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x += 6;
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0;
                }
                if (Pg57Active[4] == true)   // head spin 2
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y += 6;
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0;
                }
                if (Pg57Active[5] == true)  //head spin 3
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z += 6;
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0;
                }
                if (Pg58Active[0] == true)
                {
                    GorillaTagger.Instance.offlineVRRig.leftHand.trackingRotationOffset.y += 15;
                    GorillaTagger.Instance.offlineVRRig.rightHand.trackingRotationOffset.y += 15;
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.leftHand.trackingRotationOffset.y = 180f;
                    GorillaTagger.Instance.offlineVRRig.rightHand.trackingRotationOffset.y = 180f;
                }
                if (Pg58Active[1] == true)
                {
                    GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 180;
                }
                else
                {
                    if (Pg57Active[4] == false)
                    {

                    }
                }
                if (Pg58Active[2] == true)
                {
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        VRRigMods.closestRig = VRRigMods.GetClosestRig();
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.head.rigTarget.gameObject.transform.rotation = VRRigMods.closestRig.transform.rotation;
                        GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.LookAt(VRRigMods.closestRig.transform.position);
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg58Active[3] == true)
                {
                    VRRigMods.Helicopter();
                }



                if (Pg69Active[0] == true)
                {
                    Pg69Active[0] = false;
                    pageNumber = 1;
                    page2 = false;
                    page1 = true;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg69Active[1] == true)
                {
                    VisualMods.BoneESP();
                }
                if (Pg69Active[1] == false)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        for (int i = 0; i < TundraMain.bones.Count(); i += 2)
                        {
                            GameObject.Destroy(vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>());
                            GameObject.Destroy(vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>());
                        }
                    }
                }
                if (Pg69Active[2] == true)
                {
                    VisualMods.Tracers();
                }
                else
                {
                    if (Pg69Active[5] == false)
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            GameObject.Destroy(vrrig.gameObject.GetComponent<LineRenderer>());
                        }
                    }
                }
                if (Pg69Active[3] == true)
                {
                    VisualMods.Chams();
                }
                else
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                        {
                            vrrig.mainSkin.material = vrrig.materialsToChangeTo[vrrig.setMatIndex];
                        }
                    }
                }
                if (Pg69Active[4] == true)
                {
                    VisualMods.Beaons();
                }
                if (Pg69Active[5] == true)
                {
                    VisualMods.CSGO_ESP();
                }
                else
                {
                    if (Pg69Active[2] == false)
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            GameObject.Destroy(vrrig.gameObject.GetComponent<LineRenderer>());
                        }
                    }
                }
                if (Pg70Active[0] == true)
                {
                    VisualMods.Head_Dot_ESP();
                }
                if (Pg70Active[1] == true)
                {
                    VisualMods.HuntTargetESP();
                }
                if (Pg70Active[2] == true)
                {
                    VisualMods.TundraUserESP();
                }




                //NEXT PAGE
                if (Pg72Active[0] == true)
                {
                    Pg72Active[0] = false;
                    pageNumber = 2;
                    page2 = false;
                    page1 = true;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg72Active[1] == true)
                {
                    BugMods.Bug_To_Hand();
                }
                if (Pg72Active[2] == true)
                {
                    BugMods.Ride_Bug();
                }
                if (Pg72Active[3] == true)
                {
                    BugMods.BugGun();
                }
                if (Pg72Active[4] == true)
                {
                    BugMods.Reset_Doug();
                    Pg72Active[4] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg72Active[5] == true)
                {
                    BugMods.BugOrbit();
                }
                if (Pg73Active[0] == true)
                {
                    BugMods.BugAura();
                }
                if (Pg73Active[1] == true)
                {
                    BugMods.GiveBug();
                }



                //NEXT PAGE
                if (Pg84Active[0] == true)
                {
                    Pg84Active[0] = false;
                    pageNumber = 2;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg84Active[1] == true)
                {
                    BatMods.Grab_Bat();
                }
                if (Pg84Active[2] == true)
                {
                    BatMods.Ride_Bat();
                }
                if (Pg84Active[3] == true)
                {
                    BatMods.BatGun();
                }
                if (Pg84Active[4] == true)
                {
                    BatMods.Reset_bat();
                    Pg84Active[4] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg84Active[5] == true)
                {
                    BatMods.BatOrbit();
                }
                if (Pg85Active[0] == true)
                {
                    BatMods.BatAura();
                }



                //NEXT PAGE
                if (Pg96Active[0] == true)
                {
                    Pg96Active[0] = false;
                    pageNumber = 2;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg96Active[1] == true)
                {
                    BalloonMods.GrabBalloons();
                }
                if (Pg96Active[2] == true)
                {
                    BalloonMods.BallonGun();
                }
                if (Pg96Active[3] == true)
                {
                    BalloonMods.PopEmAll();
                    Pg96Active[3] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg96Active[4] == true)
                {
                    BalloonMods.SpinnyBalloons();
                }
                if (Pg96Active[5] == true)
                {
                    BalloonMods.BalloonOrbit();
                }


                if (Pg102Active[0] == true)
                {
                    Pg102Active[0] = false;
                    pageNumber = 2;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg102Active[1] == true)
                {
                    WaterMods.WaterSelf();
                }
                if (Pg102Active[2] == true)
                {
                    WaterMods.WaterGun();
                }
                if (Pg102Active[3] == true)
                {
                    WaterMods.WaterBending();
                }
                if (Pg102Active[4] == true)
                {
                    WaterMods.WaterOrbit();
                }
                if (Pg102Active[5] == true)
                {
                    WaterMods.WaterOrbitAll();
                }
                if (Pg103Active[0] == true)
                {
                    WaterMods.WaterAura();
                }
                if (Pg103Active[1] == true)
                {
                    WaterMods.DisableWater();
                }
                if (Pg103Active[2] == true)
                {
                    WaterMods.FastSwim();
                }
                if (Pg103Active[3] == true)
                {
                    //Swim Everywhere
                }


                if (Pg109Active[0] == true)
                {
                    Pg109Active[0] = false;
                    pageNumber = 2;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg109Active[1] == true)
                {
                    BeachballMods.GrabBall();
                }
                if (Pg109Active[2] == true)
                {
                    BeachballMods.BallGun();
                }
                if (Pg109Active[3] == true)
                {
                    BeachballMods.ResetBall();
                    Pg109Active[3] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg109Active[4] == true)
                {
                    BeachballMods.BallOrbit();
                }
                if (Pg109Active[5] == true)
                {
                    BeachballMods.BallAura();
                }
                if (Pg110Active[0] == true)
                {
                    BeachballMods.BallGameSpam();
                }




                //NEXT PAGE
                if (Pg121Active[0] == true)
                {
                    Pg121Active[0] = false;
                    pageNumber = 2;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg121Active[1] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        MonsterMods.MonsterGrab();
                    }
                }
                if (Pg121Active[2] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        MonsterMods.MonsterGun();
                    }
                }
                if (Pg121Active[3] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        MonsterMods.MonstersOrbit();
                    }
                }
                if (Pg121Active[4] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        MonsterMods.Invis_Monsters();
                    }
                    Pg121Active[4] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }


                //NEXT PAGE
                if (Pg125Active[0] == true) 
                {
                    Pg125Active[0] = false;
                    pageNumber = 3;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg125Active[1] == true)
                {
                    SoundSpamMods.BreakSFXAll();
                }
                if (Pg125Active[2] == true)
                {
                    SoundSpamMods.BreakSFXGun();
                }
                if (Pg125Active[3] == true)
                {
                    SoundSpamMods.AnnoyAll();
                }
                if (Pg125Active[4] == true)
                {
                    SoundSpamMods.AnnoyGun();
                }
                if (Pg125Active[5] == true)
                {
                    SoundSpamMods.AvtomatKalashnikova();
                }
                if (Pg126Active[0] == true)
                {
                    SoundSpamMods.EarrapeAll();
                }
                if (Pg126Active[1] == true)
                {
                    SoundSpamMods.EarrapeGun();
                }
                if (Pg126Active[2] == true)
                {
                    SoundSpamMods.DuckSpamAll();
                }
                if (Pg126Active[3] == true)
                {
                    SoundSpamMods.DuckSpamGun();
                }
                if (Pg126Active[4] == true)
                {
                    SoundSpamMods.RandomSounds();
                }
                if (Pg126Active[5] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SoundSpamMods.MSoundSpam1();
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 4);
                    }
                }
                if (Pg127Active[0] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SoundSpamMods.MSoundSpam2();
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 4);
                    }
                }
                if (Pg127Active[1] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SoundSpamMods.MSoundSpam3();
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 4);
                    }
                }
                if (Pg127Active[2] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SoundSpamMods.MSoundSpam4();
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 4);
                    }
                }
                if (Pg127Active[3] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SoundSpamMods.MSoundSpam5();
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 4);
                    }
                }
                if (Pg127Active[4] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        SoundSpamMods.MSoundSpam6();
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 4);
                    }
                }


                //NEXT PAGE
                if (Pg137Active[0] == true)
                {
                    Pg137Active[0] = false;
                    pageNumber = 3;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg137Active[1] == true)
                {
                    RopeMods.Flick_All_Ropes();
                    Pg137Active[1] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg137Active[2] == true)
                {
                    RopeMods.Spaz_All_Ropes();
                }
                if (Pg137Active[3] == true)
                {
                    RopeMods.All_Ropes_Up();
                }
                if (Pg137Active[4] == true)
                {
                    RopeMods.FrozenRopes();
                }
                if (Pg137Active[5] == true)
                {
                    RopeMods.RopeToGun();
                }
                if (Pg138Active[0] == true)
                {
                    RopeMods.RopesToSelf();
                }
                if (Pg138Active[1] == true)
                {
                    RopeMods.FrozenRopeGun();
                }
                if (Pg138Active[2] == true)
                {
                    RopeMods.Flick_Rope_Gun();
                }
                if (Pg138Active[3] == true)
                {
                    RopeMods.Spaz_Rope_Gun();
                }
                if (Pg138Active[4] == true)
                {
                    RopeMods.Rope_Up_Gun();
                }


                //NEXT PAGE
                if (Pg145Active[0] == true)
                {
                    Pg145Active[0] = false;
                    pageNumber = 3;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg145Active[1] == true)
                {
                    InfectionMods.TagGun();
                }
                if (Pg145Active[2] == true)
                {
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        InfectionMods.TagAura();
                    }
                }
                if (Pg145Active[3] == true)
                {
                    InfectionMods.TagAll();
                }
                if (Pg145Active[4] == true)
                {
                    InfectionMods.TagSelf();
                    Pg145Active[4] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg145Active[5] == true)
                {
                    InfectionMods.UnTagAll();
                    Pg145Active[5] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg146Active[0] == true)
                {
                    InfectionMods.UnTagGun();
                }
                if (Pg146Active[1] == true)
                {
                    InfectionMods.UnTagSelf();
                    Pg146Active[1] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg146Active[2] == true)
                {
                    InfectionMods.NoTagOnJoin();
                    NotifiLib.SendWithCooldown("TURN OFF AFTER USED", 30);
                }
                else
                {
                    InfectionMods.ResetNoTagOnJoin();
                }
                if (Pg146Active[3] == true)
                {
                    InfectionMods.AntiTag();
                }


                //NEXT PAGE
                if (Pg151Active[0] == true)
                {
                    Pg151Active[0] = false;
                    pageNumber = 3;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg151Active[1] == true)
                {
                    PaintbrawlMods.KillGunNoMaster();
                }
                if (Pg151Active[2] == true)
                {
                    PaintbrawlMods.KillAllNoMaster();
                }
                if (Pg151Active[3] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        PaintbrawlMods.ReviveGunMaster();
                    }
                }
                if (Pg151Active[4] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        PaintbrawlMods.ReviveAllMaster();
                    }
                    Pg151Active[4] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg151Active[5] == true)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        PaintbrawlMods.Give_A_Life_Gun();
                    }
                }


                //NEXT PAGE
                if (Pg154Active[0] == true)
                {
                    Pg154Active[0] = false;
                    pageNumber = 3;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg154Active[1] == true)
                {
                    MasterMods.MatSpamAll();
                }
                if (Pg154Active[2] == true)
                {
                    MasterMods.MatSpamGun();
                }
                if (Pg154Active[3] == true)
                {
                    MasterMods.MatSpamSelf();  
                }
                if (Pg154Active[4] == true)
                {
                    MasterMods.SlowAll();
                }
                if (Pg154Active[5] == true)
                {
                    MasterMods.SlowGun();
                }
                if (Pg155Active[0] == true)
                {
                    MasterMods.VibrateAll();
                }
                if (Pg155Active[1] == true)
                {
                    MasterMods.VibrateGun();
                }
                if (Pg155Active[2] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        MasterMods.SpamBalloonsAll();
                    }
                }
                if (Pg155Active[3] == true)
                {
                    if (PhotonNetwork.LocalPlayer.IsMasterClient)
                    {
                        MasterMods.SpamBalloonsGun();
                    }
                }
                if (Pg155Active[4] == true)
                {
                    
                }
                if (Pg155Active[5] == true)
                {
                    
                }
                if (Pg156Active[0] == true)
                {
                    
                }
                if (Pg156Active[1] == true)
                {
                    
                }



                if (Pg161Active[0] == true)
                {
                    Pg161Active[0] = false;
                    pageNumber = 3;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg161Active[1] == true)
                {
                    AbusiveMods.KickAll();
                }
                if (Pg161Active[2] == true)
                {
                    AbusiveMods.KickGun();
                }
                if (Pg161Active[3] == true)
                {
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        AbusiveMods.LagAll();
                    }
                    else
                    {
                       GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg161Active[4] == true)
                {
                    AbusiveMods.LagGun();
                }
                if (Pg161Active[5] == true)
                {
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                            AbusiveMods.CrashAll();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg162Active[0] == true)
                {
                    AbusiveMods.CrashGun();
                }
                if (Pg162Active[1] == true)
                {
                    AbusiveMods.DestroyAll();
                    Pg162Active[1] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg162Active[2] == true)
                {
                    AbusiveMods.DestroyPlayer();
                }
                if (Pg162Active[3] == true)
                {
                    AbusiveMods.CrashAura();
                }
                if (Pg162Active[4] == true)
                {
                    ProjectileMods.CrashTest();
                }



                //NEXT PAGE
                if (Pg168Active[0] == true)
                {
                    Pg168Active[0] = false;
                    pageNumber = 4;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg168Active[1] == true)
                {
                    ProjectileMods.SlingshotType();
                }
                if (Pg168Active[2] == true)
                {
                    ProjectileMods.SnowballType();
                }
                if (Pg168Active[3] == true)
                {
                    ProjectileMods.WaterballoonType();
                }
                if (Pg168Active[4] == true)
                {
                    ProjectileMods.LavarockType();
                }
                if (Pg168Active[5] == true)
                {
                    ProjectileMods.CupidArrowType();
                }
                if (Pg169Active[0] == true)
                {
                    ProjectileMods.DeadShotType();
                }
                if (Pg169Active[1] == true)
                {
                    ProjectileMods.IceType();
                }
                if (Pg169Active[2] == true)
                {
                    ProjectileMods.CloudType();
                }
                if (Pg169Active[3] == true)
                {
                    ProjectileMods.LeafPileType();
                }
                if (Pg169Active[4] == true)
                {
                    ProjectileMods.SpiderType();
                }
                if (Pg169Active[5] == true)
                {
                    ProjectileMods.MoltenRockType();
                }
                if (Pg170Active[0] == true)
                {
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        ProjectileMods.OrbiterType();
                    }
                }
                if (Pg170Active[1] == true)
                {
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        ProjectileMods.AuraType();
                    }
                }
                if (Pg170Active[2] == true)
                {
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        ProjectileMods.EarthQuakeType();
                    }
                }
                if (Pg170Active[3] == true)
                {
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        ProjectileMods.HailType();
                    }
                }
                if (Pg170Active[4] == true)
                {
                    NotifiLib.SendWithCooldown("Please get a Trail", 45);
                    ProjectileMods.JetBeamType();
                }
                if (Pg170Active[5] == true)
                {
                    ProjectileMods.TunnelType();
                }
                if (Pg171Active[0] == true)
                {
                    ProjectileMods.FireWorksType();
                }
                if (Pg171Active[1] == true)
                {
                    ProjectileMods.PlayerProjectileType();
                }
                if (Pg171Active[2] == true)
                {
                    ProjectileMods.IceBeam();
                }
                if (Pg171Active[3] == true)
                {
                    ProjectileMods.LazerEyes();
                }
                if (Pg171Active[4] == true)
                {
                        ProjectileMods.GiveHandSpammers();
                }
                if (Pg171Active[5] == true)
                {
                        ProjectileMods.GiveOrbitSpammers();
                }
                if (Pg172Active[0] == true)
                {
                        ProjectileMods.GiveHailSpammers();
                }
                if (Pg172Active[1] == true)
                {
                        ProjectileMods.GiveEarthQuakeSpammer();
                }
                if (Pg172Active[2] == true)
                {
                    ProjectileMods.ProjectileMassacre();
                }
                if (Pg172Active[3] == true)
                {
                    ProjectileMods.Test();
                }



                if (Pg181Active[0] == true)
                {
                    Pg181Active[0] = false;
                    pageNumber = 4;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg181Active[1] == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
                }
                else
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
                }
                if (Pg181Active[2] == true)
                {
                    MiscMods.ComsetSlotSpam();
                }
                if (Pg181Active[3] == true)
                {
                    MiscMods.CosmetSlotSpam2();
                }
                if (Pg181Active[4] == true)
                {
                    MiscMods.CosmetSlotSpam3();
                }
                if (Pg181Active[5] == true)
                {
                    MiscMods.CosmetSlotSpamAll();
                }
                if (Pg182Active[0] == true)
                {
                    PhotonNetworkController.Instance.disableAFKKick = true;
                }
                if (Pg182Active[0] == true)
                {
                    PhotonNetworkController.Instance.disableAFKKick = false;
                }
                if (Pg182Active[1] == true)
                {
                    MiscMods.TPToStump();
                }
                if (Pg182Active[2] == true)
                {
                    GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools").SetActive(false);
                    onEnable = false;
                }
                else
                {
                    if (!onEnable)
                    {
                        for (int i = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools").transform.childCount - 1; i >= 0; i--)
                        {
                            Transform child = GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools").transform.GetChild(i);

                            if (child.gameObject.name.Contains("(Clone)"))
                            {
                                child.gameObject.SetActive(false);
                            }
                        }
                    }
                    GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools").SetActive(true);
                    onEnable = true;
                }
                if (Pg182Active[3] == true)
                {
                    MiscMods.QuitBoxOff();
                }
                if (Pg182Active[4] == true)
                {
                    MiscMods.ChangePBBV();
                    Pg182Active[4] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg182Active[5] == true)
                {
                    MiscMods.ChangeJ3VU();
                    Pg182Active[5] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg183Active[0] == true)
                {
                    Pg183Active[0] = false;
                    MiscMods.ChangeDAISY();
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg183Active[1] == true)
                {
                    MiscMods.isModding();
                }
                if (Pg183Active[2] == true)
                {
                    MiscMods.ColorLogger();
                }
                if (Pg183Active[3] == true)
                {
                    
                }
                if (Pg183Active[4] == true)
                {
                    
                }
                if (Pg183Active[5] == true)
                {
                    AbusiveMods.antiban3();
                    NotifiLib.SendNotification("<color=green>ANTIBAN HAS BEEN SUCCESSFULLY ENABLED</color>");
                    Pg183Active[5] = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }


                if (Pg193Active[0] == true)
                {
                    Pg193Active[0] = false;
                    pageNumber = 4;
                    page1 = true;
                    page2 = false;
                    page3 = false;
                    page4 = false;
                    page5 = false;
                    page6 = false;
                    page7 = false;
                    page8 = false;
                    page9 = false;
                    page10 = false;
                    page11 = false;
                    page12 = false;
                    page13 = false;
                    page14 = false;
                    page15 = false;
                    page16 = false;
                    page17 = false;
                    page18 = false;
                    page19 = false;
                    page20 = false;
                    page21 = false;
                    page22 = false;
                    GameObject.Destroy(TundraMain.MenuObj);
                    TundraMain.MenuObj = null;
                    GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                    GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                    GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                    TundraMain.DrawMenu();
                    TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                    TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                    TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                }
                if (Pg193Active[1] == true)
                {
                    PresentType++;
                    if (PresentType > 6)
                    {
                        PresentType = 1;
                    }
                    if (PresentType == 1)
                    {
                        Pg193[1] = "Present Type: Cane";
                        Pg193Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentType == 2)
                    {
                        Pg193[1] = "Present Type: Coal";
                        Pg193Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentType == 3)
                    {
                        Pg193[1] = "Present Type: Roll";
                        Pg193Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentType == 4)
                    {
                        Pg193[1] = "Present Type: Round";
                        Pg193Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentType == 5)
                    {
                        Pg193[1] = "Present Type: Square";
                        Pg193Active[1] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg193Active[2] == true)
                {
                    PresentSpamType++;
                    if (PresentSpamType > 9)
                    {
                        PresentSpamType = 1;
                    }
                    if (PresentSpamType == 1)
                    {
                        Pg193[2] = "Present Spam: Gun";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 2)
                    {
                        Pg193[2] = "Present Spam: Impact Gun";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 3)
                    {
                        Pg193[2] = "Present Spam: Hand";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 4)
                    {
                        Pg193[2] = "Present Spam: Launcher";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 5)
                    {
                        Pg193[2] = "Present Spam: Orbit";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 6)
                    {
                        Pg193[2] = "Present Spam: Aura";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 7)
                    {
                        Pg193[2] = "Present Spam: Hail";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    else if (PresentSpamType == 8)
                    {
                        Pg193[2] = "Present Spam: EarthQuake";
                        Pg193Active[2] = false;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (Pg193Active[3] == true)
                {
                    Christmas2023Mods.SpamThemBitches();
                }






                //CATEGORY NAMES
                if (page1)
                {
                    if (pageNumber > 4)
                    {
                        pageNumber = 1;

                        // DONT CHANGE UNDER THIS

                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 1)
                    {
                        pageNumber = 4;  //Page to goto if menu page is less than 1

                        // DONT CHANGE UNDER THIS

                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }

                //SETTINGS PAGE
                if (page2)
                {
                    if (pageNumber > 15)
                    {
                        pageNumber = 11;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 11)
                    {
                        pageNumber = 15;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }

                //BASIC MODS CATEGORY
                if (page3)
                {
                    if (pageNumber > 20)
                    {
                        pageNumber = 16;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 16)
                    {
                        pageNumber = 20;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }

                //PLAYER MODS CATEGORY
                if (page4)
                {
                    if (pageNumber > 34)
                    {
                        pageNumber = 31;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 31)
                    {
                        pageNumber = 34;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                //IMPACT MODS CATEGORY
                if (page5)
                {
                    if (pageNumber > 44)
                    {
                        pageNumber = 43;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 43)
                    {
                        pageNumber = 44;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                //VRRIG MODS CATEGORY
                if (page6)
                {
                    if (pageNumber > 58)
                    {
                        pageNumber = 56;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 56)
                    {
                        pageNumber = 58;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                //ESP MODS CATEGORY
                if (page7)
                {
                    if (pageNumber > 70)
                    {
                        pageNumber = 69;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 69)
                    {
                        pageNumber = 70;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page8)
                {
                    if (pageNumber > 73)
                    {
                        pageNumber = 72;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 72)
                    {
                        pageNumber = 73;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page9)
                {
                    if (pageNumber > 85)
                    {
                        pageNumber = 84;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 84)
                    {
                        pageNumber = 85;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page10)
                {
                    if (pageNumber > 96)
                    {
                        pageNumber = 96;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 96)
                    {
                        pageNumber = 96;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page11)
                {
                    if (pageNumber > 103)
                    {
                        pageNumber = 102;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 102)
                    {
                        pageNumber = 103;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page12)
                {
                    if (pageNumber > 110)
                    {
                        pageNumber = 109;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 109)
                    {
                        pageNumber = 110;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page13)
                {
                    if (pageNumber > 121)
                    {
                        pageNumber = 121;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 121)
                    {
                        pageNumber = 121;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page14)
                {
                    if (pageNumber > 127)
                    {
                        pageNumber = 125;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 125)
                    {
                        pageNumber = 127;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page15)
                {
                    if (pageNumber > 138)
                    {
                        pageNumber = 137;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 137)
                    {
                        pageNumber = 138;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page16)
                {
                    if (pageNumber > 146)
                    {
                        pageNumber = 145;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 145)
                    {
                        pageNumber = 146;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page17)
                {
                    if (pageNumber > 151)
                    {
                        pageNumber = 151;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 151)
                    {
                        pageNumber = 151;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page18)
                {
                    if (pageNumber > 156)
                    {
                        pageNumber = 154;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 154)
                    {
                        pageNumber = 156;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page19)
                {
                    if (pageNumber > 162)
                    {
                        pageNumber = 161;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 161)
                    {
                        pageNumber = 162;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page20)
                {
                    if (pageNumber > 172)
                    {
                        pageNumber = 168;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 168)
                    {
                        pageNumber = 172;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page21)
                {
                    if (pageNumber > 183)
                    {
                        pageNumber = 181;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 181)
                    {
                        pageNumber = 183;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
                if (page22)
                {
                    if (pageNumber > 193)
                    {
                        pageNumber = 193;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                    if (pageNumber < 193)
                    {
                        pageNumber = 193;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                    }
                }
            }
            catch (Exception ex)
            {
                File.WriteAllText("TundraClient.log", ex.ToString());
            }
        }


        public static void DrawMenu()
        {
            // Menu Stuff

            MenuObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            MenuObj.transform.localScale = new Vector3(0.01f, MenuWidth, MenuHeight);

            GameObject.Destroy(MenuObj.GetComponent<BoxCollider>());
            GameObject.Destroy(MenuObj.GetComponent<Collider>());
            GameObject.Destroy(MenuObj.GetComponent<Rigidbody>());
            GameObject.Destroy(MenuObj.GetComponent<Renderer>());

            // Background Renderer

            GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
            bg.transform.parent = MenuObj.transform;
            bg.transform.localScale = new Vector3(1.2f, 1f, 1f);
            bg.transform.position = new Vector3(0.05f, 0f, 0f);
            bg.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            bg.GetComponent<MeshRenderer>().material.color = Color.black;
            bg.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;

            GameObject.Destroy(bg.GetComponent<BoxCollider>());
            GameObject.Destroy(bg.GetComponent<Collider>());
            GameObject.Destroy(bg.GetComponent<Rigidbody>());

            // Canvas Rendering
            canvasObj = new GameObject();
            canvasObj.transform.parent = MenuObj.transform;
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            CanvasScaler canvasScale = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScale.dynamicPixelsPerUnit = 1000;

            GameObject titleObj = new GameObject();
            titleObj.transform.parent = canvasObj.transform;
            Text title = titleObj.AddComponent<Text>();
            title.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            title.fontSize = 1;
            title.alignment = TextAnchor.MiddleCenter;
            title.resizeTextForBestFit = true;
            title.resizeTextMinSize = 0;

            // Menu Title
            title.text = "<color=red>T</color><color=orange>U</color><color=yellow>N</color><color=green>D</color><color=cyan>R</color><color=blue>A</color> <color=#7300FF>P</color><color=#350075>R</color><color=#DB00D8>I</color><color=#DB004D>V</color><color=red>A</color><color=orange>T</color><color=yellow>E</color>";
            title.color = new Color(ColorManager.TitleR, ColorManager.TitleG, ColorManager.TitleB);

            RectTransform titleTransform = title.GetComponent<RectTransform>();
            titleTransform.localPosition = Vector3.zero;
            titleTransform.sizeDelta = new Vector2(0.6f, 0.0225f);
            titleTransform.position = new Vector3(0.06f, 0, 0.144f);
            titleTransform.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            // Settings Rendering
            canvasSettingsObj = new GameObject();
            canvasSettingsObj.transform.parent = MenuObj.transform;
            Canvas canvas1 = canvasSettingsObj.AddComponent<Canvas>();
            CanvasScaler canvasScale1 = canvasSettingsObj.AddComponent<CanvasScaler>();
            canvasSettingsObj.AddComponent<GraphicRaycaster>();
            canvas1.renderMode = RenderMode.WorldSpace;
            canvasScale1.dynamicPixelsPerUnit = 1000;

            GameObject titleObj1 = new GameObject();
            titleObj1.transform.parent = canvasSettingsObj.transform;
            Text title1 = titleObj1.AddComponent<Text>();
            title1.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            title1.fontSize = 1;
            title1.alignment = TextAnchor.MiddleCenter;
            title1.resizeTextForBestFit = true;
            title1.resizeTextMinSize = 0;

            // Settings Title
            title1.text = "Menu Creator | BTC\n\nCo-Creator | Rev\n\nTemp Creator | JokerGT";

            title1.color = Color.white;
            title1.fontStyle = FontStyle.Bold;

            RectTransform titleTransform1 = title1.GetComponent<RectTransform>();
            titleTransform1.localPosition = Vector3.zero;
            titleTransform1.sizeDelta = new Vector2(0.28f, 0.06f);
            titleTransform1.position = new Vector3(0.04f, 0, 0.07f);
            titleTransform1.rotation = Quaternion.Euler(new Vector3(0, 90, 90));

            // Previous Page Rendering
            canvasPrevObj = new GameObject();
            canvasPrevObj.transform.parent = MenuObj.transform;
            Canvas canvas2 = canvasPrevObj.AddComponent<Canvas>();
            CanvasScaler canvasScale2 = canvasPrevObj.AddComponent<CanvasScaler>();
            canvasPrevObj.AddComponent<GraphicRaycaster>();
            canvas2.renderMode = RenderMode.WorldSpace;
            canvasScale2.dynamicPixelsPerUnit = 1000;

            GameObject titleObj2 = new GameObject();
            titleObj2.transform.parent = canvasPrevObj.transform;
            Text prev = titleObj2.AddComponent<Text>();
            prev.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            prev.fontSize = 1;
            prev.alignment = TextAnchor.MiddleCenter;
            prev.resizeTextForBestFit = true;
            prev.resizeTextMinSize = 0;

            // Settings Title
            prev.text = "<<";

            prev.color = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);  

            RectTransform titleTransform2 = prev.GetComponent<RectTransform>();
            titleTransform2.localPosition = Vector3.zero;
            titleTransform2.sizeDelta = new Vector2(0.5f, 0.02f);
            titleTransform2.position = new Vector3(0.057f, 0.13f, 0.1f);
            titleTransform2.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            // Next Page Rendering
            canvasNextObj = new GameObject();
            canvasNextObj.transform.parent = MenuObj.transform;
            Canvas canvas3 = canvasNextObj.AddComponent<Canvas>();
            CanvasScaler canvasScale3 = canvasNextObj.AddComponent<CanvasScaler>();
            canvasNextObj.AddComponent<GraphicRaycaster>();
            canvas3.renderMode = RenderMode.WorldSpace;
            canvasScale3.dynamicPixelsPerUnit = 1000;

            GameObject titleObj3 = new GameObject();
            titleObj3.transform.parent = canvasNextObj.transform;
            Text next = titleObj3.AddComponent<Text>();
            next.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            next.fontSize = 1;
            next.alignment = TextAnchor.MiddleCenter;
            next.resizeTextForBestFit = true;
            next.resizeTextMinSize = 0;

            // Settings Title
            next.text = ">>";

            next.color = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);

            RectTransform titleTransform3 = next.GetComponent<RectTransform>();
            titleTransform3.localPosition = Vector3.zero;
            titleTransform3.sizeDelta = new Vector2(0.5f, 0.02f);
            titleTransform3.position = new Vector3(0.057f, -0.13f, 0.1f);
            titleTransform3.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            // Disconnect Rendering
            canvasDiscObj = new GameObject();
            canvasDiscObj.transform.parent = MenuObj.transform;
            Canvas canvas4 = canvasDiscObj.AddComponent<Canvas>();
            CanvasScaler canvasScale4 = canvasDiscObj.AddComponent<CanvasScaler>();
            canvasDiscObj.AddComponent<GraphicRaycaster>();
            canvas4.renderMode = RenderMode.WorldSpace;
            canvasScale4.dynamicPixelsPerUnit = 1000;

            GameObject titleObj4 = new GameObject();
            titleObj4.transform.parent = canvasDiscObj.transform;
            Text disc = titleObj4.AddComponent<Text>();
            disc.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            disc.fontSize = 1;
            disc.alignment = TextAnchor.MiddleCenter;
            disc.resizeTextForBestFit = true;
            disc.resizeTextMinSize = 0;

            // Menu Title
            disc.text = "Disconnect";

            disc.color = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);

            RectTransform titleTransform4 = disc.GetComponent<RectTransform>();
            titleTransform4.localPosition = Vector3.zero;
            titleTransform4.sizeDelta = new Vector2(0.2f, 0.04f);
            titleTransform4.position = new Vector3(0.057f, 0, 0.19f);  //z is title up and down
            titleTransform4.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            // Page Rendering

            if (pageNumber == 1)
            {
                for (int i = 0; i < Pg1.Length; i++)
                {
                    AddButton(i * 0.13f, Pg1[i], Pg1, Pg1Active);
                }
            }
            else if (pageNumber == 2)
            {
                for (int i = 0; i < Pg2.Length; i++)
                {
                    AddButton(i * 0.13f, Pg2[i], Pg2, Pg2Active);
                }
            }
            else if (pageNumber == 3)
            {
                for (int i = 0; i < Pg3.Length; i++)
                {
                    AddButton(i * 0.13f, Pg3[i], Pg3, Pg3Active);
                }
            }
            else if (pageNumber == 4)
            {
                for (int i = 0; i < Pg4.Length; i++)
                {
                    AddButton(i * 0.13f, Pg4[i], Pg4, Pg4Active);
                }
            }
            else if (pageNumber == 5)
            {
                for (int i = 0; i < Pg5.Length; i++)
                {
                    AddButton(i * 0.13f, Pg5[i], Pg5, Pg5Active);
                }
            }
            else if (pageNumber == 6)
            {
                for (int i = 0; i < Pg6.Length; i++)
                {
                    AddButton(i * 0.13f, Pg6[i], Pg6, Pg6Active);
                }
            }
            else if (pageNumber == 7)
            {
                for (int i = 0; i < Pg7.Length; i++)
                {
                    AddButton(i * 0.13f, Pg7[i], Pg7, Pg7Active);
                }
            }
            else if (pageNumber == 8)
            {
                for (int i = 0; i < Pg8.Length; i++)
                {
                    AddButton(i * 0.13f, Pg8[i], Pg8, Pg8Active);
                }
            }
            else if (pageNumber == 9)
            {
                for (int i = 0; i < Pg9.Length; i++)
                {
                    AddButton(i * 0.13f, Pg9[i], Pg9, Pg9Active);
                }
            }
            else if (pageNumber == 10)
            {
                for (int i = 0; i < Pg10.Length; i++)
                {
                    AddButton(i * 0.13f, Pg10[i], Pg10, Pg10Active);
                }
            }
            else if (pageNumber == 11)
            {
                for (int i = 0; i < Pg11.Length; i++)
                {
                    AddButton(i * 0.13f, Pg11[i], Pg11, Pg11Active);
                }
            }
            else if (pageNumber == 12)
            {
                for (int i = 0; i < Pg12.Length; i++)
                {
                    AddButton(i * 0.13f, Pg12[i], Pg12, Pg12Active);
                }
            }
            else if (pageNumber == 13)
            {
               for (int i = 0; i < Pg13.Length; i++)
                {
                   AddButton(i * 0.13f, Pg13[i], Pg13, Pg13Active);
                }
            }
            else if (pageNumber == 14)
            {
                for (int i = 0; i < Pg14.Length; i++)
                {
                    AddButton(i * 0.13f, Pg14[i], Pg14, Pg14Active);
                }
            }
            else if (pageNumber == 15)
            {
                for (int i = 0; i < Pg15.Length; i++)
                {
                    AddButton(i * 0.13f, Pg15[i], Pg15, Pg15Active);
                }
            }
            else if (pageNumber == 16)
            {
                for (int i = 0; i < Pg16.Length; i++)
                {
                    AddButton(i * 0.13f, Pg16[i], Pg16, Pg16Active);
                }
            }
            else if (pageNumber == 17)
            {
                for (int i = 0; i < Pg17.Length; i++)
                {
                    AddButton(i * 0.13f, Pg17[i], Pg17, Pg17Active);
                }
            }
            else if (pageNumber == 18)
            {
                for (int i = 0; i < Pg18.Length; i++)
                {
                    AddButton(i * 0.13f, Pg18[i], Pg18, Pg18Active);
                }
            }
            else if (pageNumber == 19)
            {
                for (int i = 0; i < Pg19.Length; i++)
                {
                    AddButton(i * 0.13f, Pg19[i], Pg19, Pg19Active);
                }
            }
            else if (pageNumber == 20)
            {
                for (int i = 0; i < Pg20.Length; i++)
                {
                    AddButton(i * 0.13f, Pg20[i], Pg20, Pg20Active);
                }
            }
            else if (pageNumber == 21)
            {
                for (int i = 0; i < Pg21.Length; i++)
                {
                    AddButton(i * 0.13f, Pg21[i], Pg21, Pg21Active);
                }
            }
            else if (pageNumber == 22)
            {
                for (int i = 0; i < Pg22.Length; i++)
                {
                    AddButton(i * 0.13f, Pg22[i], Pg22, Pg22Active);
                }
            }
            else if (pageNumber == 23)
            {
                for (int i = 0; i < Pg23.Length; i++)
                {
                    AddButton(i * 0.13f, Pg23[i], Pg23, Pg23Active);
                }
            }
            else if (pageNumber == 24)
            {
                for (int i = 0; i < Pg24.Length; i++)
                {
                    AddButton(i * 0.13f, Pg24[i], Pg24, Pg24Active);
                }
            }
            else if (pageNumber == 25)
            {
                for (int i = 0; i < Pg25.Length; i++)
                {
                    AddButton(i * 0.13f, Pg25[i], Pg25, Pg25Active);
                }
            }
            else if (pageNumber == 26)
            {
                for (int i = 0; i < Pg26.Length; i++)
                {
                    AddButton(i * 0.13f, Pg26[i], Pg26, Pg26Active);
                }
            }
            else if (pageNumber == 27)
            {
                for (int i = 0; i < Pg27.Length; i++)
                {
                    AddButton(i * 0.13f, Pg27[i], Pg27, Pg27Active);
                }
            }
            else if (pageNumber == 28)
            {
                for (int i = 0; i < Pg28.Length; i++)
                {
                    AddButton(i * 0.13f, Pg28[i], Pg28, Pg28Active);
                }
            }
            else if (pageNumber == 29)
            {
                for (int i = 0; i < Pg29.Length; i++)
                {
                    AddButton(i * 0.13f, Pg29[i], Pg29, Pg29Active);
                }
            }
            else if (pageNumber == 30)
            {
                for (int i = 0; i < Pg30.Length; i++)
                {
                    AddButton(i * 0.13f, Pg30[i], Pg30, Pg30Active);
                }
            }
            else if (pageNumber == 31)
            {
                for (int i = 0; i < Pg31.Length; i++)
                {
                    AddButton(i * 0.13f, Pg31[i], Pg31, Pg31Active);
                }
            }
            else if (pageNumber == 32)
            {
                for (int i = 0; i < Pg32.Length; i++)
                {
                    AddButton(i * 0.13f, Pg32[i], Pg32, Pg32Active);
                }
            }
            else if (pageNumber == 33)
            {
                for (int i = 0; i < Pg33.Length; i++)
                {
                    AddButton(i * 0.13f, Pg33[i], Pg33, Pg33Active);
                }
            }
            else if (pageNumber == 34)
            {
                for (int i = 0; i < Pg34.Length; i++)
                {
                    AddButton(i * 0.13f, Pg34[i], Pg34, Pg34Active);
                }
            }
            else if (pageNumber == 35)
            {
                for (int i = 0; i < Pg35.Length; i++)
                {
                    AddButton(i * 0.13f, Pg35[i], Pg35, Pg35Active);
                }
            }
            else if (pageNumber == 36)
            {
                for (int i = 0; i < Pg36.Length; i++)
                {
                    AddButton(i * 0.13f, Pg36[i], Pg36, Pg36Active);
                }
            }
            else if (pageNumber == 37)
            {
                for (int i = 0; i < Pg37.Length; i++)
                {
                    AddButton(i * 0.13f, Pg37[i], Pg37, Pg37Active);
                }
            }
            else if (pageNumber == 38)
            {
                for (int i = 0; i < Pg38.Length; i++)
                {
                    AddButton(i * 0.13f, Pg38[i], Pg38, Pg38Active);
                }
            }
            else if (pageNumber == 39)
            {
                for (int i = 0; i < Pg39.Length; i++)
                {
                    AddButton(i * 0.13f, Pg39[i], Pg39, Pg39Active);
                }
            }
            else if (pageNumber == 40)
            {
                for (int i = 0; i < Pg40.Length; i++)
                {
                    AddButton(i * 0.13f, Pg40[i], Pg40, Pg40Active);
                }
            }
            else if (pageNumber == 41)
            {
                for (int i = 0; i < Pg41.Length; i++)
                {
                    AddButton(i * 0.13f, Pg41[i], Pg41, Pg41Active);
                }
            }
            else if (pageNumber == 42)
            {
                for (int i = 0; i < Pg42.Length; i++)
                {
                    AddButton(i * 0.13f, Pg42[i], Pg42, Pg42Active);
                }
            }
            else if (pageNumber == 43)
            {
                for (int i = 0; i < Pg43.Length; i++)
                {
                    AddButton(i * 0.13f, Pg43[i], Pg43, Pg43Active);
                }
            }
            else if (pageNumber == 44)
            {
                for (int i = 0; i < Pg44.Length; i++)
                {
                    AddButton(i * 0.13f, Pg44[i], Pg44, Pg44Active);
                }
            }
            else if (pageNumber == 45)
            {
                for (int i = 0; i < Pg45.Length; i++)
                {
                    AddButton(i * 0.13f, Pg45[i], Pg45, Pg45Active);
                }
            }
            else if (pageNumber == 46)
            {
                for (int i = 0; i < Pg46.Length; i++)
                {
                    AddButton(i * 0.13f, Pg46[i], Pg46, Pg46Active);
                }
            }
            else if (pageNumber == 47)
            {
                for (int i = 0; i < Pg47.Length; i++)
                {
                    AddButton(i * 0.13f, Pg47[i], Pg47, Pg47Active);
                }
            }
            else if (pageNumber == 48)
            {
                for (int i = 0; i < Pg48.Length; i++)
                {
                    AddButton(i * 0.13f, Pg48[i], Pg48, Pg48Active);
                }
            }
            else if (pageNumber == 49)
            {
                for (int i = 0; i < Pg49.Length; i++)
                {
                    AddButton(i * 0.13f, Pg49[i], Pg49, Pg49Active);
                }
            }
            else if (pageNumber == 50)
            {
                for (int i = 0; i < Pg50.Length; i++)
                {
                    AddButton(i * 0.13f, Pg50[i], Pg50, Pg50Active);
                }
            }
            else if (pageNumber == 51)
            {
                for (int i = 0; i < Pg51.Length; i++)
                {
                    AddButton(i * 0.13f, Pg51[i], Pg51, Pg51Active);
                }
            }
            else if (pageNumber == 52)
            {
                for (int i = 0; i < Pg52.Length; i++)
                {
                    AddButton(i * 0.13f, Pg52[i], Pg52, Pg52Active);
                }
            }
            else if (pageNumber == 53)
            {
                for (int i = 0; i < Pg53.Length; i++)
                {
                    AddButton(i * 0.13f, Pg53[i], Pg53, Pg53Active);
                }
            }
            else if (pageNumber == 54)
            {
                for (int i = 0; i < Pg54.Length; i++)
                {
                    AddButton(i * 0.13f, Pg54[i], Pg54, Pg54Active);
                }
            }
            else if (pageNumber == 55)
            {
                for (int i = 0; i < Pg55.Length; i++)
                {
                    AddButton(i * 0.13f, Pg55[i], Pg55, Pg5Active);
                }
            }
            else if (pageNumber == 56)
            {
                for (int i = 0; i < Pg56.Length; i++)
                {
                    AddButton(i * 0.13f, Pg56[i], Pg56, Pg56Active);
                }
            }
            else if (pageNumber == 57)
            {
                for (int i = 0; i < Pg57.Length; i++)
                {
                    AddButton(i * 0.13f, Pg57[i], Pg57, Pg57Active);
                }
            }
            else if (pageNumber == 58)
            {
                for (int i = 0; i < Pg58.Length; i++)
                {
                    AddButton(i * 0.13f, Pg58[i], Pg58, Pg58Active);
                }
            }
            else if (pageNumber == 59)
            {
                for (int i = 0; i < Pg59.Length; i++)
                {
                    AddButton(i * 0.13f, Pg59[i], Pg59, Pg59Active);
                }
            }
            else if (pageNumber == 60)
            {
                for (int i = 0; i < Pg60.Length; i++)
                {
                    AddButton(i * 0.13f, Pg60[i], Pg60, Pg60Active);
                }
            }
            else if (pageNumber == 61)
            {
                for (int i = 0; i < Pg61.Length; i++)
                {
                    AddButton(i * 0.13f, Pg61[i], Pg61, Pg61Active);
                }
            }
            else if (pageNumber == 62)
            {
                for (int i = 0; i < Pg62.Length; i++)
                {
                    AddButton(i * 0.13f, Pg62[i], Pg62, Pg62Active);
                }
            }
            else if (pageNumber == 63)
            {
                for (int i = 0; i < Pg63.Length; i++)
                {
                    AddButton(i * 0.13f, Pg63[i], Pg63, Pg63Active);
                }
            }
            else if (pageNumber == 64)
            {
                for (int i = 0; i < Pg64.Length; i++)
                {
                    AddButton(i * 0.13f, Pg64[i], Pg64, Pg64Active);
                }
            }
            else if (pageNumber == 65)
            {
                for (int i = 0; i < Pg65.Length; i++)
                {
                    AddButton(i * 0.13f, Pg65[i], Pg65, Pg65Active);
                }
            }
            else if (pageNumber == 66)
            {
                for (int i = 0; i < Pg66.Length; i++)
                {
                    AddButton(i * 0.13f, Pg66[i], Pg66, Pg66Active);
                }
            }
            else if (pageNumber == 67)
            {
                for (int i = 0; i < Pg67.Length; i++)
                {
                    AddButton(i * 0.13f, Pg67[i], Pg67, Pg67Active);
                }
            }
            else if (pageNumber == 68)
            {
                for (int i = 0; i < Pg68.Length; i++)
                {
                    AddButton(i * 0.13f, Pg68[i], Pg68, Pg68Active);
                }
            }
            else if (pageNumber == 69)
            {
                for (int i = 0; i < Pg69.Length; i++)
                {
                    AddButton(i * 0.13f, Pg69[i], Pg69, Pg69Active);
                }
            }
            else if (pageNumber == 70)
            {
                for (int i = 0; i < Pg70.Length; i++)
                {
                    AddButton(i * 0.13f, Pg70[i], Pg70, Pg70Active);
                }
            }
            else if (pageNumber == 71)
            {
                for (int i = 0; i < Pg71.Length; i++)
                {
                    AddButton(i * 0.13f, Pg71[i], Pg71, Pg71Active);
                }
            }
            else if (pageNumber == 72)
            {
                for (int i = 0; i < Pg72.Length; i++)
                {
                    AddButton(i * 0.13f, Pg72[i], Pg72, Pg72Active);
                }
            }
            else if (pageNumber == 73)
            {
                for (int i = 0; i < Pg73.Length; i++)
                {
                    AddButton(i * 0.13f, Pg73[i], Pg73, Pg73Active);
                }
            }
            else if (pageNumber == 74)
            {
                for (int i = 0; i < Pg74.Length; i++)
                {
                    AddButton(i * 0.13f, Pg74[i], Pg74, Pg74Active);
                }
            }
            else if (pageNumber == 75)
            {
                for (int i = 0; i < Pg75.Length; i++)
                {
                    AddButton(i * 0.13f, Pg75[i], Pg75, Pg75Active);
                }
            }
            else if (pageNumber == 76)
            {
                for (int i = 0; i < Pg76.Length; i++)
                {
                    AddButton(i * 0.13f, Pg76[i], Pg76, Pg76Active);
                }
            }
            else if (pageNumber == 77)
            {
                for (int i = 0; i < Pg77.Length; i++)
                {
                    AddButton(i * 0.13f, Pg77[i], Pg77, Pg77Active);
                }
            }
            else if (pageNumber == 78)
            {
                for (int i = 0; i < Pg78.Length; i++)
                {
                    AddButton(i * 0.13f, Pg78[i], Pg78, Pg78Active);
                }
            }
            else if (pageNumber == 79)
            {
                for (int i = 0; i < Pg79.Length; i++)
                {
                    AddButton(i * 0.13f, Pg79[i], Pg79, Pg79Active);
                }
            }
            else if (pageNumber == 80)
            {
                for (int i = 0; i < Pg80.Length; i++)
                {
                    AddButton(i * 0.13f, Pg80[i], Pg80, Pg80Active);
                }
            }
            else if (pageNumber == 81)
            {
                for (int i = 0; i < Pg81.Length; i++)
                {
                    AddButton(i * 0.13f, Pg81[i], Pg81, Pg81Active);
                }
            }
            else if (pageNumber == 82)
            {
                for (int i = 0; i < Pg82.Length; i++)
                {
                    AddButton(i * 0.13f, Pg82[i], Pg82, Pg82Active);
                }
            }
            else if (pageNumber == 83)
            {
                for (int i = 0; i < Pg83.Length; i++)
                {
                    AddButton(i * 0.13f, Pg83[i], Pg83, Pg83Active);
                }
            }
            else if (pageNumber == 84)
            {
                for (int i = 0; i < Pg84.Length; i++)
                {
                    AddButton(i * 0.13f, Pg84[i], Pg84, Pg84Active);
                }
            }
            else if (pageNumber == 85)
            {
                for (int i = 0; i < Pg85.Length; i++)
                {
                    AddButton(i * 0.13f, Pg85[i], Pg85, Pg85Active);
                }
            }
            else if (pageNumber == 86)
            {
                for (int i = 0; i < Pg86.Length; i++)
                {
                    AddButton(i * 0.13f, Pg86[i], Pg86, Pg86Active);
                }
            }
            else if (pageNumber == 87)
            {
                for (int i = 0; i < Pg87.Length; i++)
                {
                    AddButton(i * 0.13f, Pg87[i], Pg87, Pg87Active);
                }
            }
            else if (pageNumber == 88)
            {
                for (int i = 0; i < Pg88.Length; i++)
                {
                    AddButton(i * 0.13f, Pg88[i], Pg88, Pg88Active);
                }
            }
            else if (pageNumber == 89)
            {
                for (int i = 0; i < Pg89.Length; i++)
                {
                    AddButton(i * 0.13f, Pg89[i], Pg89, Pg89Active);
                }
            }
            else if (pageNumber == 90)
            {
                for (int i = 0; i < Pg90.Length; i++)
                {
                    AddButton(i * 0.13f, Pg90[i], Pg90, Pg90Active);
                }
            }
            else if (pageNumber == 91)
            {
                for (int i = 0; i < Pg91.Length; i++)
                {
                    AddButton(i * 0.13f, Pg91[i], Pg91, Pg91Active);
                }
            }
            else if (pageNumber == 92)
            {
                for (int i = 0; i < Pg92.Length; i++)
                {
                    AddButton(i * 0.13f, Pg92[i], Pg92, Pg92Active);
                }
            }
            else if (pageNumber == 93)
            {
                for (int i = 0; i < Pg93.Length; i++)
                {
                    AddButton(i * 0.13f, Pg93[i], Pg93, Pg93Active);
                }
            }
            else if (pageNumber == 94)
            {
                for (int i = 0; i < Pg94.Length; i++)
                {
                    AddButton(i * 0.13f, Pg94[i], Pg94, Pg94Active);
                }
            }
            else if (pageNumber == 95)
            {
                for (int i = 0; i < Pg95.Length; i++)
                {
                    AddButton(i * 0.13f, Pg95[i], Pg95, Pg95Active);
                }
            }
            else if (pageNumber == 96)
            {
                for (int i = 0; i < Pg96.Length; i++)
                {
                    AddButton(i * 0.13f, Pg96[i], Pg96, Pg96Active);
                }
            }
            else if (pageNumber == 97)
            {
                for (int i = 0; i < Pg97.Length; i++)
                {
                    AddButton(i * 0.13f, Pg97[i], Pg97, Pg97Active);
                }
            }
            else if (pageNumber == 98)
            {
                for (int i = 0; i < Pg98.Length; i++)
                {
                    AddButton(i * 0.13f, Pg98[i], Pg98, Pg98Active);
                }
            }
            else if (pageNumber == 99)
            {
                for (int i = 0; i < Pg99.Length; i++)
                {
                    AddButton(i * 0.13f, Pg99[i], Pg99, Pg99Active);
                }
            }
            else if (pageNumber == 100)
            {
                for (int i = 0; i < Pg100.Length; i++)
                {
                    AddButton(i * 0.13f, Pg100[i], Pg100, Pg100Active);
                }
            }
            else if (pageNumber == 101)
            {
                for (int i = 0; i < Pg101.Length; i++)
                {
                    AddButton(i * 0.13f, Pg101[i], Pg101, Pg101Active);
                }
            }
            else if (pageNumber == 102)
            {
                for (int i = 0; i < Pg102.Length; i++)
                {
                    AddButton(i * 0.13f, Pg102[i], Pg102, Pg102Active);
                }
            }
            else if (pageNumber == 103)
            {
                for (int i = 0; i < Pg103.Length; i++)
                {
                    AddButton(i * 0.13f, Pg103[i], Pg103, Pg103Active);
                }
            }
            else if (pageNumber == 104)
            {
                for (int i = 0; i < Pg104.Length; i++)
                {
                    AddButton(i * 0.13f, Pg104[i], Pg104, Pg104Active);
                }
            }
            else if (pageNumber == 105)
            {
                for (int i = 0; i < Pg105.Length; i++)
                {
                    AddButton(i * 0.13f, Pg105[i], Pg105, Pg105Active);
                }
            }
            else if (pageNumber == 106)
            {
                for (int i = 0; i < Pg106.Length; i++)
                {
                    AddButton(i * 0.13f, Pg106[i], Pg106, Pg106Active);
                }
            }
            else if (pageNumber == 107)
            {
                for (int i = 0; i < Pg107.Length; i++)
                {
                    AddButton(i * 0.13f, Pg107[i], Pg107, Pg107Active);
                }
            }
            else if (pageNumber == 108)
            {
                for (int i = 0; i < Pg108.Length; i++)
                {
                    AddButton(i * 0.13f, Pg108[i], Pg108, Pg108Active);
                }
            }
            else if (pageNumber == 109)
            {
                for (int i = 0; i < Pg109.Length; i++)
                {
                    AddButton(i * 0.13f, Pg109[i], Pg109, Pg109Active);
                }
            }
            else if (pageNumber == 110)
            {
                for (int i = 0; i < Pg110.Length; i++)
                {
                    AddButton(i * 0.13f, Pg110[i], Pg110, Pg110Active);
                }
            }
            else if (pageNumber == 111)
            {
                for (int i = 0; i < Pg111.Length; i++)
                {
                    AddButton(i * 0.13f, Pg111[i], Pg111, Pg111Active);
                }
            }
            else if (pageNumber == 112)
            {
                for (int i = 0; i < Pg112.Length; i++)
                {
                    AddButton(i * 0.13f, Pg112[i], Pg112, Pg112Active);
                }
            }
            else if (pageNumber == 113)
            {
                for (int i = 0; i < Pg113.Length; i++)
                {
                    AddButton(i * 0.13f, Pg113[i], Pg113, Pg113Active);
                }
            }
            else if (pageNumber == 114)
            {
                for (int i = 0; i < Pg114.Length; i++)
                {
                    AddButton(i * 0.13f, Pg114[i], Pg114, Pg114Active);
                }
            }
            else if (pageNumber == 115)
            {
                for (int i = 0; i < Pg115.Length; i++)
                {
                    AddButton(i * 0.13f, Pg115[i], Pg115, Pg115Active);
                }
            }
            else if (pageNumber == 116)
            {
                for (int i = 0; i < Pg116.Length; i++)
                {
                    AddButton(i * 0.13f, Pg116[i], Pg116, Pg116Active);
                }
            }
            else if (pageNumber == 117)
            {
                for (int i = 0; i < Pg117.Length; i++)
                {
                    AddButton(i * 0.13f, Pg117[i], Pg117, Pg117Active);
                }
            }
            else if (pageNumber == 118)
            {
                for (int i = 0; i < Pg118.Length; i++)
                {
                    AddButton(i * 0.13f, Pg118[i], Pg118, Pg118Active);
                }
            }
            else if (pageNumber == 119)
            {
                for (int i = 0; i < Pg119.Length; i++)
                {
                    AddButton(i * 0.13f, Pg119[i], Pg119, Pg119Active);
                }
            }
            else if (pageNumber == 120)
            {
                for (int i = 0; i < Pg120.Length; i++)
                {
                    AddButton(i * 0.13f, Pg120[i], Pg120, Pg120Active);
                }
            }

            else if (pageNumber == 121)
            {
                for (int i = 0; i < Pg121.Length; i++)
                {
                    AddButton(i * 0.13f, Pg121[i], Pg121, Pg121Active);
                }
            }
            else if (pageNumber == 122)
            {
                for (int i = 0; i < Pg122.Length; i++)
                {
                    AddButton(i * 0.13f, Pg122[i], Pg122, Pg122Active);
                }
            }
            else if (pageNumber == 123)
            {
                for (int i = 0; i < Pg123.Length; i++)
                {
                    AddButton(i * 0.13f, Pg123[i], Pg123, Pg123Active);
                }
            }
            else if (pageNumber == 124)
            {
                for (int i = 0; i < Pg124.Length; i++)
                {
                    AddButton(i * 0.13f, Pg124[i], Pg124, Pg124Active);
                }
            }
            else if (pageNumber == 125)
            {
                for (int i = 0; i < Pg125.Length; i++)
                {
                    AddButton(i * 0.13f, Pg125[i], Pg125, Pg125Active);
                }
            }
            else if (pageNumber == 126)
            {
                for (int i = 0; i < Pg126.Length; i++)
                {
                    AddButton(i * 0.13f, Pg126[i], Pg126, Pg126Active);
                }
            }
            else if (pageNumber == 127)
            {
                for (int i = 0; i < Pg127.Length; i++)
                {
                    AddButton(i * 0.13f, Pg127[i], Pg127, Pg127Active);
                }
            }
            else if (pageNumber == 128)
            {
                for (int i = 0; i < Pg128.Length; i++)
                {
                    AddButton(i * 0.13f, Pg128[i], Pg128, Pg128Active);
                }
            }
            else if (pageNumber == 129)
            {
                for (int i = 0; i < Pg129.Length; i++)
                {
                    AddButton(i * 0.13f, Pg129[i], Pg129, Pg129Active);
                }
            }
            else if (pageNumber == 130)
            {
                for (int i = 0; i < Pg130.Length; i++)
                {
                    AddButton(i * 0.13f, Pg130[i], Pg130, Pg130Active);
                }
            }

            else if (pageNumber == 131)
            {
                for (int i = 0; i < Pg131.Length; i++)
                {
                    AddButton(i * 0.13f, Pg131[i], Pg131, Pg131Active);
                }
            }
            else if (pageNumber == 132)
            {
                for (int i = 0; i < Pg132.Length; i++)
                {
                    AddButton(i * 0.13f, Pg132[i], Pg132, Pg132Active);
                }
            }
            else if (pageNumber == 133)
            {
                for (int i = 0; i < Pg133.Length; i++)
                {
                    AddButton(i * 0.13f, Pg133[i], Pg133, Pg133Active);
                }
            }
            else if (pageNumber == 134)
            {
                for (int i = 0; i < Pg134.Length; i++)
                {
                    AddButton(i * 0.13f, Pg134[i], Pg134, Pg134Active);
                }
            }
            else if (pageNumber == 135)
            {
                for (int i = 0; i < Pg135.Length; i++)
                {
                    AddButton(i * 0.13f, Pg135[i], Pg135, Pg135Active);
                }
            }
            else if (pageNumber == 136)
            {
                for (int i = 0; i < Pg136.Length; i++)
                {
                    AddButton(i * 0.13f, Pg136[i], Pg136, Pg136Active);
                }
            }
            else if (pageNumber == 137)
            {
                for (int i = 0; i < Pg137.Length; i++)
                {
                    AddButton(i * 0.13f, Pg137[i], Pg137, Pg137Active);
                }
            }

            else if (pageNumber == 138)
            {
                for (int i = 0; i < Pg138.Length; i++)
                {
                    AddButton(i * 0.13f, Pg138[i], Pg138, Pg138Active);
                }
            }
            else if (pageNumber == 139)
            {
                for (int i = 0; i < Pg139.Length; i++)
                {
                    AddButton(i * 0.13f, Pg139[i], Pg139, Pg139Active);
                }
            }
            else if (pageNumber == 140)
            {
                for (int i = 0; i < Pg140.Length; i++)
                {
                    AddButton(i * 0.13f, Pg140[i], Pg140, Pg140Active);
                }
            }
            else if (pageNumber == 141)
            {
                for (int i = 0; i < Pg141.Length; i++)
                {
                    AddButton(i * 0.13f, Pg141[i], Pg141, Pg141Active);
                }
            }
            else if (pageNumber == 142)
            {
                for (int i = 0; i < Pg142.Length; i++)
                {
                    AddButton(i * 0.13f, Pg142[i], Pg142, Pg142Active);
                }
            }
            else if (pageNumber == 143)
            {
                for (int i = 0; i < Pg143.Length; i++)
                {
                    AddButton(i * 0.13f, Pg143[i], Pg143, Pg143Active);
                }
            }
            else if (pageNumber == 144)
            {
                for (int i = 0; i < Pg144.Length; i++)
                {
                    AddButton(i * 0.13f, Pg144[i], Pg144, Pg144Active);
                }
            }
            else if (pageNumber == 145)
            {
                for (int i = 0; i < Pg145.Length; i++)
                {
                    AddButton(i * 0.13f, Pg145[i], Pg145, Pg145Active);
                }
            }
            else if (pageNumber == 146)
            {
                for (int i = 0; i < Pg146.Length; i++)
                {
                    AddButton(i * 0.13f, Pg146[i], Pg146, Pg146Active);
                }
            }
            else if (pageNumber == 147)
            {
                for (int i = 0; i < Pg147.Length; i++)
                {
                    AddButton(i * 0.13f, Pg147[i], Pg147, Pg147Active);
                }
            }
            else if (pageNumber == 148)
            {
                for (int i = 0; i < Pg148.Length; i++)
                {
                    AddButton(i * 0.13f, Pg148[i], Pg148, Pg148Active);
                }
            }
            else if (pageNumber == 149)
            {
                for (int i = 0; i < Pg149.Length; i++)
                {
                    AddButton(i * 0.13f, Pg149[i], Pg149, Pg149Active);
                }
            }
            else if (pageNumber == 150)
            {
                for (int i = 0; i < Pg150.Length; i++)
                {
                    AddButton(i * 0.13f, Pg150[i], Pg150, Pg150Active);
                }
            }
            else if (pageNumber == 151)
            {
                for (int i = 0; i < Pg151.Length; i++)
                {
                    AddButton(i * 0.13f, Pg151[i], Pg151, Pg151Active);
                }
            }
            else if (pageNumber == 152)
            {
                for (int i = 0; i < Pg152.Length; i++)
                {
                    AddButton(i * 0.13f, Pg152[i], Pg152, Pg152Active);
                }
            }
            else if (pageNumber == 153)
            {
                for (int i = 0; i < Pg153.Length; i++)
                {
                    AddButton(i * 0.13f, Pg153[i], Pg153, Pg153Active);
                }
            }
            else if (pageNumber == 154)
            {
                for (int i = 0; i < Pg154.Length; i++)
                {
                    AddButton(i * 0.13f, Pg154[i], Pg154, Pg154Active);
                }
            }
            else if (pageNumber == 155)
            {
                for (int i = 0; i < Pg155.Length; i++)
                {
                    AddButton(i * 0.13f, Pg155[i], Pg155, Pg155Active);
                }
            }
            else if (pageNumber == 156)
            {
                for (int i = 0; i < Pg156.Length; i++)
                {
                    AddButton(i * 0.13f, Pg156[i], Pg156, Pg156Active);
                }
            }
            else if (pageNumber == 157)
            {
                for (int i = 0; i < Pg157.Length; i++)
                {
                    AddButton(i * 0.13f, Pg157[i], Pg157, Pg157Active);
                }
            }
            else if (pageNumber == 158)
            {
                for (int i = 0; i < Pg158.Length; i++)
                {
                    AddButton(i * 0.13f, Pg158[i], Pg158, Pg158Active);
                }
            }
            else if (pageNumber == 159)
            {
                for (int i = 0; i < Pg159.Length; i++)
                {
                    AddButton(i * 0.13f, Pg159[i], Pg159, Pg159Active);
                }
            }
            else if (pageNumber == 160)
            {
                for (int i = 0; i < Pg160.Length; i++)
                {
                    AddButton(i * 0.13f, Pg160[i], Pg160, Pg160Active);
                }
            }
            else if (pageNumber == 161)
            {
                for (int i = 0; i < Pg161.Length; i++)
                {
                    AddButton(i * 0.13f, Pg161[i], Pg161, Pg161Active);
                }
            }
            else if (pageNumber == 162)
            {
                for (int i = 0; i < Pg162.Length; i++)
                {
                    AddButton(i * 0.13f, Pg162[i], Pg162, Pg162Active);
                }
            }
            else if (pageNumber == 163)
            {
                for (int i = 0; i < Pg163.Length; i++)
                {
                    AddButton(i * 0.13f, Pg163[i], Pg163, Pg163Active);
                }
            }
            else if (pageNumber == 164)
            {
                for (int i = 0; i < Pg164.Length; i++)
                {
                    AddButton(i * 0.13f, Pg164[i], Pg164, Pg164Active);
                }
            }
            else if (pageNumber == 165)
            {
                for (int i = 0; i < Pg165.Length; i++)
                {
                    AddButton(i * 0.13f, Pg165[i], Pg165, Pg165Active);
                }
            }
            else if (pageNumber == 166)
            {
                for (int i = 0; i < Pg166.Length; i++)
                {
                    AddButton(i * 0.13f, Pg166[i], Pg166, Pg166Active);
                }
            }
            else if (pageNumber == 167)
            {
                for (int i = 0; i < Pg167.Length; i++)
                {
                    AddButton(i * 0.13f, Pg167[i], Pg167, Pg167Active);
                }
            }
            else if (pageNumber == 168)
            {
                for (int i = 0; i < Pg168.Length; i++)
                {
                    AddButton(i * 0.13f, Pg168[i], Pg168, Pg168Active);
                }
            }
            else if (pageNumber == 169)
            {
                for (int i = 0; i < Pg169.Length; i++)
                {
                    AddButton(i * 0.13f, Pg169[i], Pg169, Pg169Active);
                }
            }
            else if (pageNumber == 170)
            {
                for (int i = 0; i < Pg170.Length; i++)
                {
                    AddButton(i * 0.13f, Pg170[i], Pg170, Pg170Active);
                }
            }
            else if (pageNumber == 171)
            {
                for (int i = 0; i < Pg171.Length; i++)
                {
                    AddButton(i * 0.13f, Pg171[i], Pg171, Pg171Active);
                }
            }
            else if (pageNumber == 172)
            {
                for (int i = 0; i < Pg172.Length; i++)
                {
                    AddButton(i * 0.13f, Pg172[i], Pg172, Pg172Active);
                }
            }
            else if (pageNumber == 173)
            {
                for (int i = 0; i < Pg173.Length; i++)
                {
                    AddButton(i * 0.13f, Pg173[i], Pg173, Pg173Active);
                }
            }
            else if (pageNumber == 174)
            {
                for (int i = 0; i < Pg174.Length; i++)
                {
                    AddButton(i * 0.13f, Pg174[i], Pg174, Pg174Active);
                }
            }
            else if (pageNumber == 175)
            {
                for (int i = 0; i < Pg175.Length; i++)
                {
                    AddButton(i * 0.13f, Pg175[i], Pg175, Pg175Active);
                }
            }
            else if (pageNumber == 176)
            {
                for (int i = 0; i < Pg176.Length; i++)
                {
                    AddButton(i * 0.13f, Pg176[i], Pg176, Pg176Active);
                }
            }
            else if (pageNumber == 177)
            {
                for (int i = 0; i < Pg177.Length; i++)
                {
                    AddButton(i * 0.13f, Pg177[i], Pg177, Pg177Active);
                }
            }
            else if (pageNumber == 178)
            {
                for (int i = 0; i < Pg178.Length; i++)
                {
                    AddButton(i * 0.13f, Pg178[i], Pg178, Pg178Active);
                }
            }
            else if (pageNumber == 179)
            {
                for (int i = 0; i < Pg179.Length; i++)
                {
                    AddButton(i * 0.13f, Pg179[i], Pg179, Pg179Active);
                }
            }
            else if (pageNumber == 180)
            {
                for (int i = 0; i < Pg180.Length; i++)
                {
                    AddButton(i * 0.13f, Pg180[i], Pg180, Pg180Active);
                }
            }
            else if (pageNumber == 181)
            {
                for (int i = 0; i < Pg181.Length; i++)
                {
                    AddButton(i * 0.13f, Pg181[i], Pg181, Pg181Active);
                }
            }
            else if (pageNumber == 182)
            {
                for (int i = 0; i < Pg182.Length; i++)
                {
                    AddButton(i * 0.13f, Pg182[i], Pg182, Pg182Active);
                }
            }
            else if (pageNumber == 183)
            {
                for (int i = 0; i < Pg183.Length; i++)
                {
                    AddButton(i * 0.13f, Pg183[i], Pg183, Pg183Active);
                }
            }
            else if (pageNumber == 184)
            {
                for (int i = 0; i < Pg184.Length; i++)
                {
                    AddButton(i * 0.13f, Pg184[i], Pg184, Pg184Active);
                }
            }
            else if (pageNumber == 185)
            {
                for (int i = 0; i < Pg185.Length; i++)
                {
                    AddButton(i * 0.13f, Pg185[i], Pg185, Pg185Active);
                }
            }
            else if (pageNumber == 186)
            {
                for (int i = 0; i < Pg186.Length; i++)
                {
                    AddButton(i * 0.13f, Pg186[i], Pg186, Pg186Active);
                }
            }
            else if (pageNumber == 187)
            {
                for (int i = 0; i < Pg187.Length; i++)
                {
                    AddButton(i * 0.13f, Pg187[i], Pg187, Pg187Active);
                }
            }
            else if (pageNumber == 188)
            {
                for (int i = 0; i < Pg18.Length; i++)
                {
                    AddButton(i * 0.13f, Pg188[i], Pg188, Pg188Active);
                }
            }
            else if (pageNumber == 189)
            {
                for (int i = 0; i < Pg189.Length; i++)
                {
                    AddButton(i * 0.13f, Pg189[i], Pg189, Pg189Active);
                }
            }
            else if (pageNumber == 190)
            {
                for (int i = 0; i < Pg190.Length; i++)
                {
                    AddButton(i * 0.13f, Pg190[i], Pg190, Pg190Active);
                }
            }
            else if (pageNumber == 191)
            {
                for (int i = 0; i < Pg191.Length; i++)
                {
                    AddButton(i * 0.13f, Pg191[i], Pg191, Pg191Active);
                }
            }
            else if (pageNumber == 192)
            {
                for (int i = 0; i < Pg192.Length; i++)
                {
                    AddButton(i * 0.13f, Pg192[i], Pg192, Pg192Active);
                }
            }
            else if (pageNumber == 193)
            {
                for (int i = 0; i < Pg193.Length; i++)
                {
                    AddButton(i * 0.13f, Pg193[i], Pg193, Pg193Active);
                }
            }
        }

        static void AddButton(float offset, string text, string[] btns, bool?[] btnsActive)
        {
            GameObject newBtn = GameObject.CreatePrimitive(PrimitiveType.Cube);

            newBtn.transform.SetParent(MenuObj.transform, true);
            newBtn.transform.rotation = Quaternion.identity;
            newBtn.transform.localScale = new Vector3(0.78f, 0.9f, 0.08f);      //y axis is how slim the buttons are
            newBtn.transform.localPosition = new Vector3(6f, 0f, 0.285f - offset);   //y axis is left and right // X axis is forward and backward // z axis is

            GameObject.Destroy(newBtn.GetComponent<Rigidbody>());
            newBtn.GetComponent<BoxCollider>().isTrigger = true;
            newBtn.AddComponent<ButtonCollision>().Identity = text;

            int index = -1;

            for (int i = 0; i < btns.Length; i++)
            {
                if (text == btns[i])
                {
                    index = i;
                    break;
                }
            }

            // BTN OFF

            if (btnsActive[index] == false)
            {
                newBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                newBtn.GetComponent<Renderer>().material.color = new Color(ColorManager.ButtonR, ColorManager.ButtonG, ColorManager.ButtonB);
            }


            // BTN ON

            else if (btnsActive[index] == true)
            {
                newBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                newBtn.GetComponent<Renderer>().material.color = new Color(ColorManager.ButtonOnR, ColorManager.ButtonOnG, ColorManager.ButtonOnB);
            }


            // BTN ELSE

            else
            {
                newBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                newBtn.GetComponent<Renderer>().material.color = new Color(ColorManager.MenuR, ColorManager.MenuG, ColorManager.MenuB);
            }


            GameObject titleObj = new GameObject();
            titleObj.transform.parent = canvasObj.transform;
            Text title = titleObj.AddComponent<Text>();
            title.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            title.fontSize = 1;
            title.alignment = TextAnchor.MiddleCenter;
            title.resizeTextForBestFit = true;
            title.resizeTextMinSize = 0;

            title.text = text;
            title.color = new Color(ColorManager.ButtonTextR, ColorManager.ButtonTextG, ColorManager.ButtonTextB);

            if (btnsActive[index] == true)
            {
                title.color = new Color(ColorManager.ButtonOnTextR, ColorManager.ButtonOnTextG, ColorManager.ButtonOnTextB);
            }



            RectTransform titleTransform = title.GetComponent<RectTransform>();
            titleTransform.localPosition = Vector3.zero;
            titleTransform.sizeDelta = new Vector2(0.175f, 0.1f);
            titleTransform.position = new Vector3(0.064f, 0, 0.0965f - (offset / 3f));
            titleTransform.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

        }

        public static void AddCustomButton(string text, float offset, bool btnActive, float width, float height, float LR)
        {
            GameObject addBtn = GameObject.CreatePrimitive(PrimitiveType.Cube);
            addBtn.transform.parent = MenuObj.transform;
            addBtn.transform.localScale = new Vector3(1.2f, width, height);
            addBtn.transform.position = new Vector3(0.05f, LR, offset);
            addBtn.AddComponent<ButtonCollision>().Identity = text;
            addBtn.GetComponent<BoxCollider>().isTrigger = true;
            addBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            addBtn.GetComponent<MeshRenderer>().material.color = Color.grey;
            addBtn.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
            
            Buttons.AddItem(text);
            ButtonsActive.AddItem(btnActive);

            GameObject.Destroy(addBtn.GetComponent<Rigidbody>());
        }
        public static void ToggleButton(string btnIdentity, string[] btns, bool?[] btnsActive)
        {
            // Toggle All Buttons (Don't mess with)
            int index = -1;
            for (int i = 0; i < btns.Length; i++)
            {
                if (btnIdentity == btns[i])
                {
                    index = i;
                    break;
                }
            }
            if (btnsActive[index] != null)
            {
                btnsActive[index] = !btnsActive[index];

                GameObject.Destroy(TundraMain.MenuObj);
                TundraMain.MenuObj = null;
                GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                TundraMain.DrawMenu();
                TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
            }
        }
    }
}