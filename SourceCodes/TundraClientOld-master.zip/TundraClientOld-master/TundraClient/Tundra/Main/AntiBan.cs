﻿using Photon.Pun;

namespace TundraAntiBan
{
    internal class AntiBan : MonoBehaviourPunCallbacks
    {
        public static void AntiBanEvade()
        {
            PhotonNetwork.NetworkingClient.LoadBalancingPeer.TrafficStatsReset();
            PhotonNetwork.NetworkingClient.LoadBalancingPeer.DispatchIncomingCommands();
            PhotonNetwork.NetworkingClient.LoadBalancingPeer.LongestSentCall = 1;
            PhotonNetwork.NetworkingClient.LoadBalancingPeer.SendOutgoingCommands();
            PhotonNetwork.NetworkingClient.LoadBalancingPeer.TrafficStatsEnabled = true;
            PhotonNetwork.SendAllOutgoingCommands();
        }
    }
}