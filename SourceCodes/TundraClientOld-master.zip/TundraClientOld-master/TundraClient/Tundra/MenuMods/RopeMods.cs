﻿using GorillaLocomotion.Gameplay;
using Photon.Pun;
using Tundra.ColorManagement;
using UnityEngine;
using MenuUtils;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class RopeMods
    {
        static GameObject gorillaSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        static float smth = 0;
        static ControllerInputPoller input;
        public static void Rope(Vector3 Pos)
        {
            foreach (GorillaRopeSwing gorillaRopeSwing in Object.FindObjectsOfType(typeof(GorillaRopeSwing)))
            {
                PhotonView photonView = gorillaRopeSwing.photonView;
                string methodName = "SetVelocity";
                RpcTarget target = RpcTarget.All;
                object[] array2 = new object[4];
                array2[0] = 1;
                array2[1] = Pos;
                array2[2] = true;
                photonView.RPC(methodName, target, array2);
            }
        }
        public static void Flick_All_Ropes()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 1;
                Rope(new Vector3(9999, 0, 0));
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void Spaz_All_Ropes()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 0.0075f;
                Rope(new Vector3(Random.Range(-9999, 9999), Random.Range(9999, -9999), Random.Range(-9999, 9999)));
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void All_Ropes_Up()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 0.0075f;
                Rope(new Vector3(-117.9764f, 166.7391f, -128.7897f));
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void FrozenRopes()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 0.0075f;
                Rope(Vector3.zero);
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void Flick_Rope_Gun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 1;
                            Vector3 vector = new Vector3(9999, 0, 0);
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                        }
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 1;
                            Vector3 vector = new Vector3(9999, 0, 0);
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                        }
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void Spaz_Rope_Gun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 vector = new Vector3((float)Random.Range(-9999, 9999), (float)Random.Range(9999, -9999), (float)Random.Range(-9999, 9999));
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 vector = new Vector3((float)Random.Range(-9999, 9999), (float)Random.Range(9999, -9999), (float)Random.Range(-9999, 9999));
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void Rope_Up_Gun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 vector = new Vector3(-117.9764f, 166.7391f, -128.7897f);
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 vector = new Vector3(-117.9764f, 166.7391f, -128.7897f);
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void RopeToGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 50000000f;
                            vector *= d;
                            Rope(vector);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 5000000f;
                            vector *= d;
                            Rope(vector);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void FrozenRopeGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 vector = Vector3.zero;
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    PhotonView photonView = hit.collider.GetComponentInParent<GorillaRopeSwing>().photonView;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (smth < Time.time)
                        {
                            smth = Time.time + 0.0075f;
                            Vector3 vector = Vector3.zero;
                            string methodName = "SetVelocity";
                            RpcTarget target = RpcTarget.All;
                            object[] array = new object[4];
                            array[0] = 1;
                            array[1] = vector;
                            array[2] = true;
                            photonView.RPC(methodName, target, array);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void RopesToSelf()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 0.002f;
                Rope(GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/gorilla").transform.position);
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
    }
}