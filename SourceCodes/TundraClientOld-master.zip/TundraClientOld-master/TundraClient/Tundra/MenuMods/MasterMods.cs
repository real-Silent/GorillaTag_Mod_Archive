﻿using HarmonyLib;
using Photon.Pun;
using Tundra.ColorManagement;
using UnityEngine;
using TundraMenu;
using MenuUtils;

namespace Tundra.MenuMods
{
    internal class MasterMods
    {
        static ControllerInputPoller input;
        static float smth = 0;
        static VRRig asda;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static void SlowAll()
        {
            if ((double)Time.time > (double)smth + 0.02)
            {
                foreach (Photon.Realtime.Player players in PhotonNetwork.PlayerListOthers)
                {
                    PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(players);
                    photonView.RPC("SetTaggedTime", players, null);
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                }
                smth = Time.time;
            }
        }
        public static void SlowGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void VibrateAll()
        {
            if ((double)Time.time > (double)smth + 0.02)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(player);
                    photonView.RPC("SetJoinTaggedTime", player, null);
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                }
                smth = Time.time;
            }
        }
        public static void VibrateGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetJoinTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetJoinTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetJoinTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            PhotonView photonView = GorillaGameManager.instance.FindVRRigForPlayer(awd);
                            photonView.RPC("SetJoinTaggedTime", awd, null);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void SpamBalloonsAll()
        {
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
            {
                GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] = Random.Range(0, 3);
            }
        }
        public static void SpamBalloonsGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[awd.ActorNumber] = Random.Range(0, 3);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[awd.ActorNumber] = Random.Range(0, 3);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[awd.ActorNumber] = Random.Range(0, 3);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[awd.ActorNumber] = Random.Range(0, 3);
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void MatSpamAll()
        {
            if (PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString().Contains("INFECTION"))
            {
                if ((double)Time.time > (double)smth + 0.04)
                {
                    foreach (Photon.Realtime.Player players in PhotonNetwork.PlayerListOthers)
                    {
                        if (!GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(players))
                        {
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().AddInfectedPlayer(players);
                        }
                        else
                        {
                            if (GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(players))
                            {
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(players);
                            }
                        }
                    }
                    smth = Time.time;
                }
                TundraUtils.Update();
            }
        }
        public static void MatSpamSelf()
        {
            if ((double)Time.time > (double)smth + 0.04)
            {
                if (!GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                {
                    GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().AddInfectedPlayer(PhotonNetwork.LocalPlayer);
                }
                else
                {
                    if (GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(PhotonNetwork.LocalPlayer);
                    }
                }
                smth = Time.time;
            }
            TundraUtils.Update();
        }
        public static void MatSpamGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        if ((double)Time.time > (double)smth + 0.04)
                        {
                            if (!GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(player))
                            {
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().AddInfectedPlayer(player);
                            }
                            else
                            {
                                if (GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(player))
                                {
                                    GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(player);
                                }
                            }
                            smth = Time.time;
                        }
                        TundraUtils.Update();
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        if ((double)Time.time > (double)smth + 0.04)
                        {
                            if (!GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(player))
                            {
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().AddInfectedPlayer(player);
                            }
                            else
                            {
                                if (GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Contains(player))
                                {
                                    GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(player);
                                }
                            }
                            smth = Time.time;
                        }
                        TundraUtils.Update();
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
    }
}