﻿using HarmonyLib;
using Photon.Pun;
using TundraMenu;
using Tundra.ColorManagement;
using UnityEngine;
using MenuUtils;

namespace Tundra.MenuMods
{
    internal class InfectionMods
    {
        static ControllerInputPoller input;
        static VRRig rig;
        static VRRig asda;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static void TagGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.AutoTagSelf == 1)
                {
                    if (TundraMain.GunHand == 1)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                        if (input.rightControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.rightControllerIndexFloat > 0.1f)
                            {
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                {
                            awd
                                });
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                    else if (TundraMain.GunHand == 2)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                        if (input.leftControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.leftControllerIndexFloat > 0.1f)
                            {
                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                {
                            awd
                                });
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                }
                else if (TundraMain.AutoTagSelf == 2)
                {
                    if (TundraMain.GunHand == 1)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                        if (input.rightControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.rightControllerIndexFloat > 0.1f)
                            {
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
                                }
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                    {
                                awd
                                    });
                                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                }
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                    else if (TundraMain.GunHand == 2)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                        if (input.leftControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.leftControllerIndexFloat > 0.1f)
                            {
                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
                                }
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                    {
                                awd
                                    });
                                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                }
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.AutoTagSelf == 1)
                {
                    if (TundraMain.GunHand == 1)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                        if (input.rightControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.rightControllerIndexFloat > 0.1f)
                            {
                                if (hit.collider.GetComponentInParent<VRRig>() != null)
                                {
                                    asda = hit.collider.GetComponentInParent<VRRig>();
                                }
                                else if (hit.collider.GetComponent<VRRig>() != null)
                                {
                                    pointer.transform.position = asda.transform.position;
                                }
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                {
                            awd
                                });
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                    else if (TundraMain.GunHand == 2)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                        if (input.leftControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.leftControllerIndexFloat > 0.1f)
                            {
                                if (hit.collider.GetComponentInParent<VRRig>() != null)
                                {
                                    asda = hit.collider.GetComponentInParent<VRRig>();
                                }
                                pointer.transform.position = asda.transform.position;
                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                {
                            awd
                                });
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                }
                else if (TundraMain.AutoTagSelf == 2)
                {
                    if (TundraMain.GunHand == 1)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                        if (input.rightControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.rightControllerIndexFloat > 0.1f)
                            {
                                if (hit.collider.GetComponentInParent<VRRig>() != null)
                                {
                                    asda = hit.collider.GetComponentInParent<VRRig>();
                                }
                                pointer.transform.position = asda.transform.position;
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
                                }
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                    {
                                awd
                                    });
                                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                }
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                    else if (TundraMain.GunHand == 2)
                    {
                        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                        Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                        if (input.leftControllerGripFloat > 0.1f)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                            if (input.leftControllerIndexFloat > 0.1f)
                            {
                                if (hit.collider.GetComponentInParent<VRRig>() != null)
                                {
                                    asda = hit.collider.GetComponentInParent<VRRig>();
                                }
                                pointer.transform.position = asda.transform.position;
                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
                                }
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                                {
                                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).transform.position;
                                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaGameManager.instance.FindPlayerVRRig(awd).head.rigTarget.transform.position;
                                    PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                                    {
                                awd
                                    });
                                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                }
                                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                            }
                        }
                    }
                }
            }
        }
        public static void TagAura()
        {
            if (TundraMain.AutoTagSelf == 1)
            {
                foreach (Photon.Realtime.Player awdww in PhotonNetwork.PlayerListOthers)
                {
                    PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                    {
                        awdww
                    });
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                }
            }
            else if (TundraMain.AutoTagSelf == 2)
            {
                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                {
                    GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
                }
                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                {
                    foreach (Photon.Realtime.Player awd in PhotonNetwork.PlayerListOthers)
                    {
                        PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                        {
                            awd
                        });
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    }
                }
            }
        }
        public static void TagAll()
        {
            if (TundraMain.AutoTagSelf == 1)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && !vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        Photon.Realtime.Player agse = rig2view(vrrig.GetComponentInParent<VRRig>()).Owner;
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(agse).transform.position;
                        PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                        {
                            agse
                        });
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    }
                    else if (vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else if (TundraMain.AutoTagSelf == 2)
            {
                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
                {
                    GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
                }
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && !vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        Photon.Realtime.Player agse = rig2view(vrrig.GetComponentInParent<VRRig>()).Owner;
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = GorillaGameManager.instance.FindPlayerVRRig(agse).transform.position;
                        PhotonView.Get(GorillaGameManager.instance).RPC("ReportTagRPC", RpcTarget.All, new object[]
                        {
                            agse
                        });
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    }
                    else if (vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
        }
        public static void TagSelf()
        {
            if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("infected"))
            {
                GorillaGameManager.instance.photonView.RPC("ReportContactWithLavaRPC", 0);
            }
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
        }
        public static void UnTagAll()
        {
            if (PhotonNetwork.IsMasterClient)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(player);
                }
            }
        }
        public static void UnTagGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (PhotonNetwork.IsMasterClient)
                        {
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(awd);
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (PhotonNetwork.IsMasterClient)
                        {
                            GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(awd);
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void UnTagSelf()
        {
            GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(PhotonNetwork.LocalPlayer);
        }
        public static void NoTagOnJoin()
        {
            PlayerPrefs.SetString("tutorial", "nope");
            PlayerPrefs.Save();
        }
        public static void ResetNoTagOnJoin()
        {
            PlayerPrefs.SetString("tutorial", "done");
            PlayerPrefs.Save();
        }
        public static void AntiTag()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    if (vrrig.mainSkin.material.name.Contains("infected") && !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        rig = vrrig;
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position, rig.transform.position) <= 4)
                        {
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, 10000f, 0f);
                        }
                        else if (Vector3.Distance(GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position, rig.transform.position) >= 5)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
                else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    GameObject.Find("Player Objects/GorillaParent/Gorilla Tag Manager(Clone)").GetComponent<GorillaTagManager>().currentInfected.Remove(PhotonNetwork.LocalPlayer);
                }
            }
        }
    }
}
