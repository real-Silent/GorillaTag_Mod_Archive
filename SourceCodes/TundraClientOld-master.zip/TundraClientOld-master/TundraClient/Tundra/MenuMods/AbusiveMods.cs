﻿using Photon.Pun;
using UnityEngine;
using HarmonyLib;
using Tundra.ColorManagement;
using GorillaNetworking;
using GTAG_NotificationLib;
using TundraMenu;
using MenuUtils;

namespace Tundra.MenuMods
{
    internal class AbusiveMods : MonoBehaviour
    {
        static float smth = 0f;
        static ControllerInputPoller input;
        static VRRig asda;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static void KickGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(playerawd.UserId))
                                    {
                                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                        NotifiLib.SendWithCooldown($"ATTEMPTING TO KICK: <color=red>{playerawd.NickName}</color>", 5f);
                                        PhotonView.Get(GorillaGameManager.instance).RPC("JoinPubWithFriends", playerawd, new object[]
                                        {
                                PhotonNetworkController.Instance.shuffler,
                                PhotonNetworkController.Instance.keyStr
                                        });
                                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                    }
                                }
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(playerawd.UserId))
                                    {
                                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                        NotifiLib.SendWithCooldown($"ATTEMPTING TO KICK: <color=red>{playerawd.NickName}</color>", 5f);
                                        PhotonView.Get(GorillaGameManager.instance).RPC("JoinPubWithFriends", playerawd, new object[]
                                        {
                                PhotonNetworkController.Instance.shuffler,
                                PhotonNetworkController.Instance.keyStr
                                        });
                                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                    }
                                }
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;

                                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(playerawd.UserId))
                                    {
                                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                        NotifiLib.SendWithCooldown($"ATTEMPTING TO KICK: <color=red>{playerawd.NickName}</color>", 5f);
                                        PhotonView.Get(GorillaGameManager.instance).RPC("JoinPubWithFriends", playerawd, new object[]
                                        {
                                PhotonNetworkController.Instance.shuffler,
                                PhotonNetworkController.Instance.keyStr
                                        });
                                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                    }
                                }
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(playerawd.UserId))
                                    {
                                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                        NotifiLib.SendWithCooldown($"ATTEMPTING TO KICK: <color=red>{playerawd.NickName}</color>", 5f);
                                        PhotonView.Get(GorillaGameManager.instance).RPC("JoinPubWithFriends", playerawd, new object[]
                                        {
                                PhotonNetworkController.Instance.shuffler,
                                PhotonNetworkController.Instance.keyStr
                                        });
                                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                    }
                                }
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void KickAll()
        {
            NotifiLib.SendWithCooldown("This Only Takes 2-5s to process, It MAY NOT fully work", 3);
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(player.UserId))
                    {
                        PhotonView.Get(GorillaGameManager.instance).RPC("JoinPubWithFriends", player, new object[]
                        {
                            PhotonNetworkController.Instance.shuffler,
                            PhotonNetworkController.Instance.keyStr
                        });
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    }
                }
                if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    NotifiLib.SendWithCooldown($"Please goto Stump to use this!", 5f);
                }
            }
        }
        public static void LagGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                            NotifiLib.SendWithCooldown($"ATTMEPTING TO LAG <color=red>{playerawd.NickName}</color>", 5f);
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", playerawd, new object[]
                            {
                        GorillaTagger.Instance.offlineVRRig.transform.position,
                        new Vector3(0f, 10f, 0f),
                        hashone,
                        hashtrail1,
                        false,
                        num3,
                        true,
                        0f,
                        1f,
                        0.5f,
                        1f
                            });
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            NotifiLib.SendWithCooldown($"ATTMEPTING TO LAG <color=red>{playerawd.NickName}</color>", 5f);
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", playerawd, new object[]
                            {
                        GorillaTagger.Instance.offlineVRRig.transform.position,
                        new Vector3(0f, 10f, 0f),
                        hashone,
                        hashtrail1,
                        false,
                        num3,
                        true,
                        0f,
                        1f,
                        0.5f,
                        1f
                            });
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            NotifiLib.SendWithCooldown($"ATTMEPTING TO LAG <color=red>{playerawd.NickName}</color>", 5f);
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", playerawd, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.transform.position,
                        new Vector3(0f, 10f, 0f),
                        hashone,
                        hashtrail1,
                        false,
                        num3,
                        true,
                        0f,
                        1f,
                        0.5f,
                        1f
                            });
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player playerawd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            NotifiLib.SendWithCooldown($"ATTMEPTING TO LAG <color=red>{playerawd.NickName}</color>", 5f);
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", playerawd, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.transform.position,
                        new Vector3(0f, 10f, 0f),
                        hashone,
                        hashtrail1,
                        false,
                        num3,
                        true,
                        0f,
                        1f,
                        0.5f,
                        1f
                            });
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void LagAll()
        {
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
            NotifiLib.SendWithCooldown($"ATTEMPTING TO LAG ALL <color=yellow>[QUEST]</color> USERS, THIS MAY TAKE 10-25s", 5f);
            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
            int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
            {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 10f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0f,
                    1f,
                    0.5f,
                    1f
            });
            int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
            int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
            int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
            {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 10f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0f,
                    1f,
                    0.5f,
                    1f
            });
        }
        public static void CrashAll()
        {
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
            if ((double)Time.time > (double)smth + 0.1)
            {
                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH ALL <color=yellow>[QUEST]</color> USERS", 5f);
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone12 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail112 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num312 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12,
                    hashtrail112,
                    false,
                    num312,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                  new Vector3(0f, 25f, 0f),
                    hashone123,
                    hashtrail1123,
                    false,
                    num3123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone1234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail11234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num31234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234,
                    hashtrail11234,
                    false,
                    num31234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone12345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail112345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num312345 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345,
                    hashtrail112345,
                    false,
                    num312345,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3123456 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456,
                    hashtrail1123456,
                    false,
                    num3123456,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone1234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail11234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num31234567 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567,
                    hashtrail11234567,
                    false,
                    num31234567,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone12345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail112345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num312345678 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678,
                    hashtrail112345678,
                    false,
                    num312345678,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3123456789 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789,
                    hashtrail1123456789,
                    false,
                    num3123456789,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone1234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail11234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num31234567891 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891,
                    hashtrail11234567891,
                    false,
                    num31234567891,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone12345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail112345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num312345678912 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678912,
                    hashtrail112345678912,
                    false,
                    num312345678912,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3123456789123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789123,
                    hashtrail1123456789123,
                    false,
                    num3123456789123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                int hashone1234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail11234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num31234567891234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.Others, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891234,
                    hashtrail11234567891234,
                    false,
                    num31234567891234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                });
                smth = Time.time;
            }
        }
        public static void CrashGun()
        {
            if (TundraMain.GunHand == 1)
            {
                if (TundraMain.GunLock == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player players = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            if ((double)Time.time > (double)smth + 0.1)
                            {
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH ALL <color=yellow>[QUEST]</color> USERS", 5f);
                                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12,
                    hashtrail112,
                    false,
                    num312,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                  new Vector3(0f, 25f, 0f),
                    hashone123,
                    hashtrail1123,
                    false,
                    num3123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234,
                    hashtrail11234,
                    false,
                    num31234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345,
                    hashtrail112345,
                    false,
                    num312345,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456,
                    hashtrail1123456,
                    false,
                    num3123456,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567,
                    hashtrail11234567,
                    false,
                    num31234567,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678,
                    hashtrail112345678,
                    false,
                    num312345678,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789,
                    hashtrail1123456789,
                    false,
                    num3123456789,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891,
                    hashtrail11234567891,
                    false,
                    num31234567891,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678912 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678912,
                    hashtrail112345678912,
                    false,
                    num312345678912,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789123,
                    hashtrail1123456789123,
                    false,
                    num3123456789123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891234,
                    hashtrail11234567891234,
                    false,
                    num31234567891234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                smth = Time.time;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunLock == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    RaycastHit raycastHit2;
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit2);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                        UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                        UnityEngine.Object.Destroy(pointer.GetComponent<MeshCollider>());
                        UnityEngine.Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = raycastHit2.point;
                        UnityEngine.Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player players = AbusiveMods.rig2view(raycastHit2.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (raycastHit2.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = raycastHit2.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if ((double)Time.time > (double)smth + 0.1)
                            {
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH ALL <color=yellow>[QUEST]</color> USERS", 5f);
                                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12,
                    hashtrail112,
                    false,
                    num312,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                  new Vector3(0f, 25f, 0f),
                    hashone123,
                    hashtrail1123,
                    false,
                    num3123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234,
                    hashtrail11234,
                    false,
                    num31234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345,
                    hashtrail112345,
                    false,
                    num312345,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456,
                    hashtrail1123456,
                    false,
                    num3123456,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567,
                    hashtrail11234567,
                    false,
                    num31234567,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678,
                    hashtrail112345678,
                    false,
                    num312345678,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789,
                    hashtrail1123456789,
                    false,
                    num3123456789,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891,
                    hashtrail11234567891,
                    false,
                    num31234567891,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678912 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678912,
                    hashtrail112345678912,
                    false,
                    num312345678912,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789123,
                    hashtrail1123456789123,
                    false,
                    num3123456789123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891234,
                    hashtrail11234567891234,
                    false,
                    num31234567891234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                smth = Time.time;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                if (TundraMain.GunLock == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player players = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            if ((double)Time.time > (double)smth + 0.1)
                            {
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH ALL <color=yellow>[QUEST]</color> USERS", 5f);
                                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12,
                    hashtrail112,
                    false,
                    num312,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                  new Vector3(0f, 25f, 0f),
                    hashone123,
                    hashtrail1123,
                    false,
                    num3123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234,
                    hashtrail11234,
                    false,
                    num31234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345,
                    hashtrail112345,
                    false,
                    num312345,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456,
                    hashtrail1123456,
                    false,
                    num3123456,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567,
                    hashtrail11234567,
                    false,
                    num31234567,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678,
                    hashtrail112345678,
                    false,
                    num312345678,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789,
                    hashtrail1123456789,
                    false,
                    num3123456789,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891,
                    hashtrail11234567891,
                    false,
                    num31234567891,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678912 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678912,
                    hashtrail112345678912,
                    false,
                    num312345678912,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789123,
                    hashtrail1123456789123,
                    false,
                    num3123456789123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891234,
                    hashtrail11234567891234,
                    false,
                    num31234567891234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                smth = Time.time;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunLock == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player players = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            asda = hit.collider.GetComponentInParent<VRRig>();
                            pointer.transform.position = asda.transform.position;
                            if ((double)Time.time > (double)smth + 0.1)
                            {
                                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH ALL <color=yellow>[QUEST]</color> USERS", 5f);
                                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12,
                    hashtrail112,
                    false,
                    num312,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                  new Vector3(0f, 25f, 0f),
                    hashone123,
                    hashtrail1123,
                    false,
                    num3123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234,
                    hashtrail11234,
                    false,
                    num31234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345,
                    hashtrail112345,
                    false,
                    num312345,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456,
                    hashtrail1123456,
                    false,
                    num3123456,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567,
                    hashtrail11234567,
                    false,
                    num31234567,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678,
                    hashtrail112345678,
                    false,
                    num312345678,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789,
                    hashtrail1123456789,
                    false,
                    num3123456789,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891,
                    hashtrail11234567891,
                    false,
                    num31234567891,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone12345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail112345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num312345678912 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678912,
                    hashtrail112345678912,
                    false,
                    num312345678912,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail1123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num3123456789123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789123,
                    hashtrail1123456789123,
                    false,
                    num3123456789123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                int hashone1234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                                int hashtrail11234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                                int num31234567891234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891234,
                    hashtrail11234567891234,
                    false,
                    num31234567891234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                                });
                                smth = Time.time;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void DestroyPlayer()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player CachePlayer = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        NotifiLib.SendWithCooldown($"NEW JOINERS CANNOT SEE: <color=red>{CachePlayer.NickName}</color>", 3.5f);
                        PhotonNetwork.CurrentRoom.StorePlayer(CachePlayer);
                        PhotonNetwork.CurrentRoom.Players.Remove(CachePlayer.ActorNumber);
                        PhotonNetwork.OpRemoveCompleteCacheOfPlayer(CachePlayer.ActorNumber);
                        PhotonNetwork.OpCleanActorRpcBuffer(CachePlayer.ActorNumber);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.isOfflineVRRig = true;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player CachePlayer = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        NotifiLib.SendWithCooldown($"NEW JOINERS CANNOT SEE: <color=red>{CachePlayer.NickName}</color>", 3.5f);
                        PhotonNetwork.CurrentRoom.StorePlayer(CachePlayer);
                        PhotonNetwork.CurrentRoom.Players.Remove(CachePlayer.ActorNumber);
                        PhotonNetwork.OpRemoveCompleteCacheOfPlayer(CachePlayer.ActorNumber);
                        PhotonNetwork.OpCleanActorRpcBuffer(CachePlayer.ActorNumber);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.isOfflineVRRig = true;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void DestroyAll()
        {
            foreach (Photon.Realtime.Player CachePlayer in PhotonNetwork.PlayerListOthers)
            {
                PhotonNetwork.CurrentRoom.StorePlayer(CachePlayer);
                PhotonNetwork.CurrentRoom.Players.Remove(CachePlayer.ActorNumber);
                PhotonNetwork.OpRemoveCompleteCacheOfPlayer(CachePlayer.ActorNumber);
                PhotonNetwork.OpCleanActorRpcBuffer(CachePlayer.ActorNumber);
                NotifiLib.SendWithCooldown($"ALL NEW PLAYERS WHO JOIN CAN ONLY SEE YOU", 5f);
            }
        }
        public static void antiban3()
        {//WORKS UND IN MODDED LOBBIES (note in 2024: this was ages ago)
            PhotonNetwork.CurrentRoom.SetMasterClient(PhotonNetwork.LocalPlayer);
        }
        public static void CrashAura()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position , vrrig.transform.position) <= 3 && !vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                {
                    Photon.Realtime.Player players = rig2view(vrrig.GetComponentInParent<VRRig>()).Owner;
                    if ((double)Time.time > (double)smth + 0.1)
                    {
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-111.0734f, 190.5294f, -14.2247f);
                        NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH ALL <color=yellow>[QUEST]</color> USERS", 5f);
                        int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone,
                    hashtrail1,
                    false,
                    num3,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail11 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num31 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1,
                    hashtrail11,
                    false,
                    num31,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone12 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail112 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num312 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12,
                    hashtrail112,
                    false,
                    num312,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail1123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num3123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                  new Vector3(0f, 25f, 0f),
                    hashone123,
                    hashtrail1123,
                    false,
                    num3123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone1234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail11234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num31234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234,
                    hashtrail11234,
                    false,
                    num31234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone12345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail112345 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num312345 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345,
                    hashtrail112345,
                    false,
                    num312345,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail1123456 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num3123456 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456,
                    hashtrail1123456,
                    false,
                    num3123456,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone1234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail11234567 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num31234567 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567,
                    hashtrail11234567,
                    false,
                    num31234567,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone12345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail112345678 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num312345678 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678,
                    hashtrail112345678,
                    false,
                    num312345678,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail1123456789 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num3123456789 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789,
                    hashtrail1123456789,
                    false,
                    num3123456789,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone1234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail11234567891 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num31234567891 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891,
                    hashtrail11234567891,
                    false,
                    num31234567891,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone12345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail112345678912 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num312345678912 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone12345678912,
                    hashtrail112345678912,
                    false,
                    num312345678912,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail1123456789123 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num3123456789123 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone123456789123,
                    hashtrail1123456789123,
                    false,
                    num3123456789123,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        int hashone1234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                        int hashtrail11234567891234 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                        int num31234567891234 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", players, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 25f, 0f),
                    hashone1234567891234,
                    hashtrail11234567891234,
                    false,
                    num31234567891234,
                    true,
                    0.34f,
                    0f,
                    1f,
                    1f
                        });
                        smth = Time.time;
                    }
                }
            }
        }
    }
}