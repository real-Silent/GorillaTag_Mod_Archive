﻿using Photon.Pun;
using UnityEngine;
using Tundra.ColorManagement;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class BeachballMods
    {
        static ControllerInputPoller input;
        public static void GrabBall()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
                GameObject.Find("Ball").GetComponent<TransferrableBall>().transform.position = GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position;
                GameObject.Find("Ball").transform.position = GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position;
            }
        }
        public static void BallGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
                        GameObject.Find("Ball").transform.position = hit.point;
                        GameObject.Find("Ball").GetComponent<TransferrableBall>().transform.position = hit.point;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
                        GameObject.Find("Ball").transform.position = hit.point;
                        GameObject.Find("Ball").GetComponent<TransferrableBall>().transform.position = hit.point;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void ResetBall()
        {
            GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
            GameObject.Find("Ball").transform.position = new Vector3(999f, 999f, 999f);
            GameObject.Find("Ball").GetComponent<TransferrableBall>().transform.position = new Vector3(999f, 999f, 999f);
        }
        public static void BallOrbit()
        {
            GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
            float orbitSpeed = 4.5f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 6f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 0.225f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            GameObject.Find("Ball").transform.position = vector;
        }
        public static void BallAura()
        {
            GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
            float minDistance = 1f;
            float maxDistance = 2f;

            Vector3 randomOffset = Random.insideUnitSphere;
            randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

            Vector3 newPosition = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + randomOffset;

            Vector3 directionToPlayer = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - newPosition;
            Quaternion newrotation = Quaternion.LookRotation(directionToPlayer);

            GameObject.Find("Ball").transform.position = newPosition;
            GameObject.Find("Ball").transform.rotation = newrotation;
        }
        public static void BallGameSpam()
        {
            GameObject.Find("Ball").GetComponent<TransferrableBall>().Invoke("TakeOwnershipAndEnablePhysics", 0);
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerIndexFloat > 0.1f)
            {
                GameObject.Find("Ball").transform.position = new Vector3(-26.1299f, 9.1872f, 9.6172f);
            }
            else
            {
                GameObject.Find("Ball").transform.position = new Vector3(-3.3207f, 9.2348f, -1.174f);
            }
        }
    }
}
