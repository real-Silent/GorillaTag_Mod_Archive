﻿using Photon.Pun;
using UnityEngine;
using GorillaNetworking;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class LobbyHop : MonoBehaviour
    {
        static float smth = 0;
        static ControllerInputPoller input;
        public static bool I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY = false;
        public static GameObject clouds = GameObject.Find("Environment Objects/LocalObjects_Prefab/skyjungle");
        public static GameObject basement = GameObject.Find("Environment Objects/LocalObjects_Prefab/Basement");
        public static GameObject forest = GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest");
        public static GameObject city = GameObject.Find("Environment Objects/LocalObjects_Prefab/City");

        public static GameObject canyons = GameObject.Find("Environment Objects/LocalObjects_Prefab/Canyon");
        public static GameObject mountain = GameObject.Find("Environment Objects/LocalObjects_Prefab/Mountain");
        public static GameObject beach = GameObject.Find("Environment Objects/LocalObjects_Prefab/Beach");
        public static GameObject caves = GameObject.Find("Environment Objects/LocalObjects_Prefab/Cave_Main_Prefab");
        public static bool joindaddy = false;
        public static bool IWantThisModToBeTurnedOn = false;
        public static void Update()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (TundraMain.lobbyhopmode == 1)
            {
                if (PhotonNetwork.InRoom && I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY)
                {
                    I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY = false;
                }
                if (!PhotonNetwork.InRoom && I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY)
                {
                    Join();
                }
                if (input.leftControllerPrimaryButton)
                {
                    PhotonNetwork.Disconnect();
                    I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY = true;
                }
            }
            else if (TundraMain.lobbyhopmode == 2)
            {
                if (!PhotonNetwork.InRoom)
                {
                    Join();
                }
            }
        }
        public static void Join()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 2.5f;
                //FOREST
                if (forest.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest, Tree Exit").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //City
                else if (city.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City Front").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //Caves
                else if (caves.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Cave").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //MOUNTAINS
                else if (mountain.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Mountain For Computer").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //BEACH
                else if (beach.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest from Beach").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //CANYONS
                else if (canyons.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Canyon").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //CLOUDS
                else if (clouds.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Clouds").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //BASEMENT
                else if (basement.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Basement For Computer").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
            }
        }
        public static void LeaveNullShitter()
        {
            if (GorillaGameManager.instance == null || GorillaGameManager.instance.photonView == null && PhotonNetwork.InRoom && IWantThisModToBeTurnedOn)
            {
                joindaddy = false;
                if (!joindaddy)
                {
                    Debug.Log("null room");
                    PhotonNetwork.Disconnect();
                    joindaddy = true;
                }
            }
            if (joindaddy && !PhotonNetwork.InRoom)
            {
                Join();
            }
        }
    }
}