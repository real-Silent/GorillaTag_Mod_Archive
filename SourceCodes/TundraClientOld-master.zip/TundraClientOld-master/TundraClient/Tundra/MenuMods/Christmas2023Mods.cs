﻿using MenuUtils;
using Tundra.ColorManagement;
using TundraMenu;
using UnityEngine;
using Tundra.MenuMods;
using Photon.Pun;
using GorillaLocomotion.Gameplay;

namespace TundraClient.Tundra.MenuMods
{
    internal class Christmas2023Mods
    {
        static int Present;
        static ControllerInputPoller input;
        public static void PresentType()
        {
            if (TundraMain.PresentType == 1)
            {
                Present = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/BucketGift_Cane_Projectile Variant(Clone)"));
            }
            else if (TundraMain.PresentType == 2)
            {
                Present = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/BucketGift_Coal_Projectile Variant(Clone)"));
            }
            else if (TundraMain.PresentType == 3)
            {
                Present = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/BucketGift_Roll_Projectile Variant(Clone)"));
            }
            else if (TundraMain.PresentType == 4)
            {
                Present = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/BucketGift_Round_Projectile Variant(Clone)"));
            }
            else if(TundraMain.PresentType == 5)
            {
                Present = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/BucketGift_Square_Projectile Variant(Clone)"));
            }
        }
        public static void SpamThemBitches()
        {
            if (TundraMain.PresentSpamType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 40f;
                            vector *= d;
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            vector,
                            Present,
                            -1,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 40f;
                            vector *= d;
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                            vector,
                            Present,
                            -1,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.PresentSpamType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 5000000f;
                            vector *= d;
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            vector,
                            Present,
                            ProjectileMods.TrailHash,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 5000000f;
                            vector *= d;
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                            vector,
                            Present,
                            ProjectileMods.TrailHash,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.PresentSpamType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            new Vector3(0f, 0f, 0f),
                            Present,
                            -1,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.PresentSpamType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                     GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                           GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                            Present,
                            ProjectileMods.TrailHash,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.PresentSpamType == 5)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                           new Vector3(0f, 0f, 0f),
                            Present,
                            ProjectileMods.TrailHash,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.PresentSpamType == 6)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-5f, 5f), 5f, Random.Range(-5f, 5f));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                           new Vector3(0f, 0f, 0f),
                            Present,
                            ProjectileMods.TrailHash,
                            false,
                            num3,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.PresentSpamType == 7)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 5f, 0f),
                    new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25, 25)),
                    Present,
                    ProjectileMods.TrailHash,
                    false,
                    num3,
                    true,
                   ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.PresentSpamType == 8)
            {
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                     Present,
                    ProjectileMods.TrailHash,
                    false,
                    num3,
                    true,
                   ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                });
                TundraUtils.Update();
            }
        }
    }
}