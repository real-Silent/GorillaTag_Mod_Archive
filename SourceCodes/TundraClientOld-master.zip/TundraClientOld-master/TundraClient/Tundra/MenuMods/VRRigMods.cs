﻿using HarmonyLib;
using Photon.Pun;
using TundraMenu;
using UnityEngine;
using Tundra.ColorManagement;
using MenuUtils;
using GTAG_NotificationLib;
using System.Linq;
namespace Tundra.MenuMods
{
    internal class VRRigMods
    {

        static ControllerInputPoller input;
        static VRRig asda;
        static Photon.Realtime.Player followTarget;
        public static Photon.Realtime.Player GetRandomPlayer(bool includeSelf)
        {
            if (includeSelf)
            {
                Photon.Realtime.Player p = PhotonNetwork.PlayerList[UnityEngine.Random.Range(0, 11)];
                if (p != null)
                {
                    return p;
                }
                return GetRandomPlayer(includeSelf);
            }
            Photon.Realtime.Player p2 = PhotonNetwork.PlayerListOthers[UnityEngine.Random.Range(0, 10)];
            if (p2 != null)
            {
                return p2;
            }
            return GetRandomPlayer(includeSelf);
        }
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static void GhostMonke()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }

            if (TundraMain.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GameObject LeftHand = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject RightHand = GameObject.CreatePrimitive(PrimitiveType.Cube);
                LeftHand.transform.position = GorillaTagger.Instance.leftHandTransform.transform.position;
                RightHand.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;
                LeftHand.transform.rotation = GorillaTagger.Instance.leftHandTransform.transform.rotation;
                RightHand.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                Object.Destroy(LeftHand.GetComponent<SphereCollider>());
                Object.Destroy(LeftHand.GetComponent<Rigidbody>());
                Object.Destroy(LeftHand.GetComponent<MeshCollider>());
                Object.Destroy(LeftHand.GetComponent<Collider>());
                Object.Destroy(RightHand.GetComponent<SphereCollider>());
                Object.Destroy(RightHand.GetComponent<Rigidbody>());
                Object.Destroy(RightHand.GetComponent<MeshCollider>());
                Object.Destroy(RightHand.GetComponent<Collider>());
                LeftHand.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                RightHand.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                LeftHand.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                RightHand.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                Object.Destroy(LeftHand, Time.deltaTime);
                Object.Destroy(RightHand, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void InvisMonke()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }

            if (TundraMain.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(99999f, 0f, 0f);
                GameObject LeftHand = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject RightHand = GameObject.CreatePrimitive(PrimitiveType.Cube);
                LeftHand.transform.position = GorillaTagger.Instance.leftHandTransform.transform.position;
                RightHand.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;
                LeftHand.transform.rotation = GorillaTagger.Instance.leftHandTransform.transform.rotation;
                RightHand.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                Object.Destroy(LeftHand.GetComponent<SphereCollider>());
                Object.Destroy(LeftHand.GetComponent<Rigidbody>());
                Object.Destroy(LeftHand.GetComponent<MeshCollider>());
                Object.Destroy(LeftHand.GetComponent<Collider>());
                Object.Destroy(RightHand.GetComponent<Collider>());
                Object.Destroy(RightHand.GetComponent<SphereCollider>());
                Object.Destroy(RightHand.GetComponent<Rigidbody>());
                Object.Destroy(RightHand.GetComponent<MeshCollider>());
                LeftHand.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                RightHand.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                LeftHand.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                RightHand.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                Object.Destroy(LeftHand, Time.deltaTime);
                Object.Destroy(RightHand, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void RigGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = pointer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = pointer.transform.rotation;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = pointer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = pointer.transform.rotation;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
        }
        public static void FollowPlayer()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player p = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (hit.collider.GetComponentInParent<VRRig>() != null)
                        {
                            asda = hit.collider.GetComponentInParent<VRRig>();
                        }
                        pointer.transform.position = asda.transform.position;

                        VRRig target = GorillaGameManager.instance.FindPlayerVRRig(followTarget);

                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;

                        GorillaTagger.Instance.offlineVRRig.transform.position = target.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = target.transform.rotation;

                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = target.leftHandPlayer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.rotation = target.leftHandPlayer.transform.rotation;

                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = target.rightHandPlayer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.rotation = target.rightHandPlayer.transform.rotation;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player p = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (hit.collider.GetComponentInParent<VRRig>() != null)
                        {
                            asda = hit.collider.GetComponentInParent<VRRig>();
                        }
                        pointer.transform.position = asda.transform.position;

                        if (followTarget == null)
                        {
                            followTarget = GetRandomPlayer(false);

                            NotifiLib.SendNotification("<color=yellow>Player " + followTarget.NickName + " has been targetted</color>");
                        }

                        VRRig target = GorillaGameManager.instance.FindPlayerVRRig(followTarget);

                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;

                        GorillaTagger.Instance.offlineVRRig.transform.position = target.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = target.transform.rotation;

                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = target.leftHandPlayer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.rotation = target.leftHandPlayer.transform.rotation;

                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = target.rightHandPlayer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.rotation = target.rightHandPlayer.transform.rotation;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
        }
        public static void SpinnyMonk()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }
            if (TundraMain.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 9.5f, 0f);
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(999, 0, 0);
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(-999, 0, 0);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void FrozenGhostWalk()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }
            if (TundraMain.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void GhostWalk()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }
            if (TundraMain.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position;
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static VRRig closestRig = null;
        public static VRRig GetClosestRig()
        {
            VRRig bestTarget = null;
            float closestDistanceSqr = Mathf.Infinity;
            Vector3 currentPosition = GorillaLocomotion.Player.Instance.transform.position;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                {
                    Vector3 directionToTarget = vrrig.transform.position - currentPosition;
                    float dSqrToTarget = directionToTarget.sqrMagnitude;
                    if (dSqrToTarget < closestDistanceSqr)
                    {
                        closestDistanceSqr = dSqrToTarget;
                        bestTarget = vrrig;
                    }
                }
            }

            return bestTarget;
        }
        public static void Helicopter()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }
            if (TundraMain.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 9.5f, 0f);
                GorillaTagger.Instance.offlineVRRig.transform.position += new Vector3(0f, 0.10f, 0f);
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(999f, 0f, 0f);
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(-999f, 0f, 0f);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
    }
}