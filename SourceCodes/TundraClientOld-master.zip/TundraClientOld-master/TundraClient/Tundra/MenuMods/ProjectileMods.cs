﻿using Photon.Pun;
using TundraMenu;
using Tundra.ColorManagement;
using UnityEngine;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;
using MenuUtils;
using HarmonyLib;

namespace Tundra.MenuMods
{
    internal class ProjectileMods
    {
        static ControllerInputPoller input;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static float RED;
        public static float GREEN;
        public static float BLUE;
        public static float A = 0f;
        static float smth = 0f;
        public static int TrailHash;
        public static int TypeSelect;
        public static void ProjectileChanger()
        {
            if (TundraMain.ProjTypeSelect == 1)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 2)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 3)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 4)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 5)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 6)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 7)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 8)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 9)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 10)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
            }
            else if (TundraMain.ProjTypeSelect == 11)
            {
                TypeSelect = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
            }
        }
        public static void Colors()
        {
            Material material = new Material(Shader.Find("GorillaTag/UberShader"));
            material.color = Color.HSVToRGB(smth, 1f, 1f);
            smth += 0.006f;
            if (smth >= 1f)
            {
                smth = 0f;
            }
            if (TundraMain.PROJCOLOR == 1)
            {
                RED = 0f;
                GREEN = 0f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 2)
            {
                RED = 1f;
                GREEN = 1f;
                BLUE = 1f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 3)
            {
                RED = 0.5f;
                GREEN = 0.5f;
                BLUE = 0.5f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 4)
            {
                RED = 1f;
                GREEN = 0f;
                BLUE = 1f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 5)
            {
                RED = 1f;
                GREEN = 0f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 6)
            {
                RED = 1f;
                GREEN = 0.5f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 7) // YELLOW
            {
                RED = 1f;
                GREEN = 1f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 8)
            {
                RED = 0.78f;
                GREEN = 1f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 9) //GREEN
            {
                RED = 0f;
                GREEN = 1f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 10) //MINT
            {
                RED = 0f;
                GREEN = 1f;
                BLUE = 0.5f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 11)
            {
                RED = 0f;
                GREEN = 1f;
                BLUE = 1f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 12)
            {
                RED = 0f;
                GREEN = 0f;
                BLUE = 1f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 13)
            {
                RED = 0.43f;
                GREEN = 0f;
                BLUE = 1f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 14)
            {
                RED = 0.3f;
                GREEN = 0f;
                BLUE = 0.6f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 15)
            {
                RED = 0.4f;
                GREEN = 0.165f;
                BLUE = 0f;
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 16)
            {
                RED = Random.Range(0f, 1f);
                GREEN = Random.Range(0f, 1f);
                BLUE = Random.Range(0f, 1f);
                A = 1f;
            }
            else if (TundraMain.PROJCOLOR == 17)
            {
                RED = material.color.r;
                GREEN = material.color.g;
                BLUE = material.color.b;
                A = 1f;
            }
        }
        public static void TrailType()
        {
            if (TundraMain.TrailType == 1)
            {
                TrailHash = -1;
            }
            else if (TundraMain.TrailType == 2)
            {
                TrailHash = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectileTrail Variant(Clone)"));
            }
            else if (TundraMain.TrailType == 3)
            {
                TrailHash = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_ProjectileTrailFX(Clone)"));
            }
            else if (TundraMain.TrailType == 4)
            {
                TrailHash = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_ProjectileTrailFX(Clone)"));
            }
            else if (TundraMain.TrailType == 5)
            {
                TrailHash = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
            }
        }



        public static void SlingshotType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void SnowballType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
                            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            vector,
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void WaterballoonType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void LavarockType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void CupidArrowType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                            GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                            hashone,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void DeadShotType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void IceType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void CloudType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                        GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                        hashone,
                        TrailHash,
                        false,
                        num3,
                        true,
                        RED,
                        GREEN,
                        BLUE,
                        A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void LeafPileType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                        GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                        hashone,
                        TrailHash,
                        false,
                        num3,
                        true,
                        RED,
                        GREEN,
                        BLUE,
                        A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void SpiderType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                        GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                        hashone,
                        TrailHash,
                        false,
                        num3,
                        true,
                        RED,
                        GREEN,
                        BLUE,
                        A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void MoltenRockType()
        {
            if (TundraMain.ProjType == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 3)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var ray);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = ray.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = ray.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 65f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                             {
            GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
            vector,
            hashone,
            TrailHash,
            false,
            num3,
            true,
            RED,
            GREEN,
            BLUE,
            A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            Vector3 point = hit.point;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position).normalized;
                            float d = 500000000f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                vector,
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.ProjType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                        GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.20f, false),
                        hashone,
                        TrailHash,
                        false,
                        num3,
                        true,
                        RED,
                        GREEN,
                        BLUE,
                        A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.ProjType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.up.normalized * 10f,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }



        public static void OrbiterType()
        {
            if (TundraMain.SpecialType == 1)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 2)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 3)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 4)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 5)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 6)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 7)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 8)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 9)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
        }
        public static void AuraType()
        {
            if (TundraMain.SpecialType == 1)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 2)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 3)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 4)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 5)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 6)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 7)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 8)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 9)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
        }
        public static void EarthQuakeType()
        {
            if (TundraMain.SpecialType == 1)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 2)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 3)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 4)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 5)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                 {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                 });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 6)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                 {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                 });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 7)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 8)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 9)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
        }
        public static void HailType()
        {
            if (TundraMain.SpecialType == 1)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                    new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 2)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
                   new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 3)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/LavaRockProjectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                   GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
             new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 4)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_Projectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                   GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
          new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 5)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
        new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 6)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
           new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 7)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CloudSlingshot_Projectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
              new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 8)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/ElfBow_Projectile(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                   GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
           new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
            else if (TundraMain.SpecialType == 9)
            {
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SpiderBowProjectile Variant(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                {
                   GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f),
         new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25,25)),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                TundraUtils.Update();
            }
        }
        public static void JetBeamType()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerIndexFloat > 0.1f)
            {
                if (smth < Time.time)
                {
                    smth = Time.time + 0.002f;
                    for (int w = 0; w < GorillaParent.instance.vrrigs.Count; w++)
                    {
                        if (!GorillaParent.instance.vrrigs[w].isMyPlayer && !GorillaParent.instance.vrrigs[w].isOfflineVRRig)
                        {
                            Vector3 point = GorillaParent.instance.vrrigs[w].transform.position;
                            Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                            float d = 35f;
                            vector *= d;
                            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/MoltenRockSlingshot_Projectile(Clone)"));
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                            {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    vector,
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                            });
                            TundraUtils.Update();
                        }
                    }
                }
            }
        }
        public static void FireWorksType()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerIndexFloat > 0.1f)
            {
                Vector3 vector = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + new Vector3(Random.Range(-2f, 2f), 2f, Random.Range(-2f, 2f));
                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 20f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void TunnelType()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerIndexFloat > 0.1f)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;


                int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    vector,
                    new Vector3(0f, 20f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void ProjectileMassacre()
        {
            System.Random random = new System.Random();
            int funny = random.Next(1, GorillaParent.instance.vrrigDict.Count);
            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = GorillaParent.instance.vrrigs[funny].transform.position + new Vector3(0f, 0.8f, 0f);
            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 3f, 0f),
                    TypeSelect,
                    TrailHash,
                    false,
                    GorillaGameManager.instance.IncrementLocalPlayerProjectileCount(),
                    true,
                    RED,
                    GREEN,
                    BLUE,
                    A
                });
            TundraUtils.Update();
        }


        public static void LazerEyes()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(pointer.GetComponent<Rigidbody>());
                Object.Destroy(pointer.GetComponent<SphereCollider>());
                Object.Destroy(pointer.GetComponent<MeshCollider>());
                Object.Destroy(pointer.GetComponent<Collider>());
                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                pointer.transform.position = hit.point;
                Object.Destroy(pointer, Time.deltaTime);
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    Vector3 position = GorillaTagger.Instance.headCollider.transform.position;
                    Vector3 point = hit.point;
                    Vector3 vector = (point - position).normalized;
                    float rate = 500000000f;
                    vector *= rate;
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectile_PrefabV(Clone)"));
                    int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/HornsSlingshotProjectileTrail_PrefabV(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                        position,
                        vector,
                        hashone,
                        hashtrail1,
                        false,
                        num3,
                        true,
                        1f,
                        0.682f,
                        0f,
                        A
                    });
                    TundraUtils.Update();
                    pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                }
                else
                {
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
            }
        }
        public static void IceBeam()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(pointer.GetComponent<Rigidbody>());
                Object.Destroy(pointer.GetComponent<SphereCollider>());
                Object.Destroy(pointer.GetComponent<MeshCollider>());
                Object.Destroy(pointer.GetComponent<Collider>());
                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                pointer.transform.position = hit.point;
                Object.Destroy(pointer, Time.deltaTime);
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    Vector3 position = GorillaTagger.Instance.headCollider.transform.position;
                    Vector3 point = hit.point;
                    Vector3 vector = (point - position).normalized;
                    float rate = 500000000f;
                    vector *= rate;
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/IceSlingshotProjectile_PrefabV Variant(Clone)"));
                    int hashtrail1 = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/CupidArrow_ProjectileTrailFX(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                        position,
                        vector,
                        hashone,
                        hashtrail1,
                        false,
                        num3,
                        true,
                        1f,
                        1f,
                        1f,
                        A
                    });
                    TundraUtils.Update();
                    pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                }
                else
                {
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
            }
        }

        public static void GiveHandSpammers()
        {
            if (TundraMain.GunHand == 1)
            {
                ProjectileMods.input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                RaycastHit raycastHit;
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit); if (ProjectileMods.input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<MeshCollider>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = raycastHit.point;
                    UnityEngine.Object.Destroy(pointer, Time.deltaTime);
                    VRRig vrrig = raycastHit.collider.GetComponentInParent<VRRig>();
                    if (ProjectileMods.input.rightControllerIndexFloat > 0.1f)
                    {
                        if ((double)Time.time > (double)smth + 0.05)
                        {
                            int num = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                            {
                            vrrig.rightHandPlayer.transform.position + new Vector3(0f, 0.1f, 0f),
                            vrrig.rightHandTransform.up.normalized * 10f,
                            ProjectileMods.TypeSelect,
                            ProjectileMods.TrailHash,
                            false,
                            num,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                ProjectileMods.input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                RaycastHit raycastHit;
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit);
                if (ProjectileMods.input.rightControllerGripFloat > 0.1f)
                {
                    GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(gameObject.GetComponent<SphereCollider>());
                    UnityEngine.Object.Destroy(gameObject.GetComponent<MeshCollider>());
                    UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
                    gameObject.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    gameObject.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    gameObject.transform.position = raycastHit.point;
                    UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
                    VRRig vrrig = raycastHit.collider.GetComponentInParent<VRRig>();
                    if (ProjectileMods.input.rightControllerIndexFloat > 0.1f)
                    {
                        if ((double)Time.time > (double)smth + 0.05)
                        {
                            int num = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                            {
                            vrrig.leftHandPlayer.transform.position + new Vector3(0f, 0.1f, 0f),
                            vrrig.leftHandTransform.up.normalized * 10f,
                            ProjectileMods.TypeSelect,
                            ProjectileMods.TrailHash,
                            false,
                            num,
                            true,
                            ProjectileMods.RED,
                            ProjectileMods.GREEN,
                            ProjectileMods.BLUE,
                            ProjectileMods.A
                            });
                            TundraUtils.Update();
                            gameObject.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    gameObject.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
            }
            else if (TundraMain.GunHand == 3)
            {
                ProjectileMods.input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var raycastHit);
                if (ProjectileMods.input.rightControllerGripFloat > 0.1f)
                {
                    GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(gameObject2.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(gameObject2.GetComponent<SphereCollider>());
                    UnityEngine.Object.Destroy(gameObject2.GetComponent<MeshCollider>());
                    UnityEngine.Object.Destroy(gameObject2.GetComponent<Collider>());
                    gameObject2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    gameObject2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    gameObject2.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    gameObject2.transform.position = raycastHit.point;
                    UnityEngine.Object.Destroy(gameObject2, Time.deltaTime);
                    VRRig vrrig3 = raycastHit.collider.GetComponentInParent<VRRig>();
                    if (ProjectileMods.input.rightControllerIndexFloat > 0.1f)
                    {
                        if ((double)Time.time > (double)smth + 0.05)
                        {
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                            PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                            {
                                vrrig3.rightHandPlayer.transform.position + new Vector3(0f, 0.1f, 0f),
                                vrrig3.rightHandTransform.up.normalized * 10f,
                                ProjectileMods.TypeSelect,
                                ProjectileMods.TrailHash,
                                false,
                                num3,
                                true,
                                ProjectileMods.RED,
                                ProjectileMods.GREEN,
                                ProjectileMods.BLUE,
                                ProjectileMods.A
                            });
                            PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", RpcTarget.All, new object[]
                            {
                                vrrig3.leftHandPlayer.transform.position + new Vector3(0f, 0.1f, 0f),
                                vrrig3.leftHandTransform.up.normalized * 10f,
                                ProjectileMods.TypeSelect,
                                ProjectileMods.TrailHash,
                                false,
                                num3,
                                true,
                                ProjectileMods.RED,
                                ProjectileMods.GREEN,
                                ProjectileMods.BLUE,
                                ProjectileMods.A
                            });
                            smth = Time.time;
                        }
                        gameObject2.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    gameObject2.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
            }
        }
        public static void GiveOrbitSpammers()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                float orbitSpeed = 7.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 15f;
                Vector3 POS = vrrig.headConstraint.transform.position + new Vector3(0f, 2.5f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                        vector,
                        new Vector3(0f, 0f, 0f),
                            TypeSelect,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void GiveHailSpammers()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", 0, new object[]
                {
                        vrrig.transform.position + new Vector3(0f, 2f, 0f),
new Vector3(Random.Range(-25, 25), Random.Range(-25,25), Random.Range(-25, 25)),
                            TypeSelect,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void GiveEarthQuakeSpammer()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 0.002f;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    PhotonView.Get(GorillaGameManager.instance).RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                       vrrig.transform.position + new Vector3(0f, 2.5f, 0f),
new Vector3(Random.Range(-50000, 50000), Random.Range(-50000, 50000), Random.Range(-50000, 50000)),
                            TypeSelect,
                            TrailHash,
                            false,
                            num3,
                            true,
                            RED,
                            GREEN,
                            BLUE,
                            A
                    });
                    TundraUtils.Update();
                }
            }
        }



        public static void PlayerProjectileType()
        {
            if (TundraMain.PlayerType == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    Vector3 origin = GorillaLocomotion.Player.Instance.bodyCollider.transform.position + new Vector3(0f, -0.1f, 0f);
                    Vector3 SpeedPos = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * Time.deltaTime * 150f;
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    origin,
                    SpeedPos,
                    hashone,
                    -1,
                    false,
                    num3,
                    true,
                    1f,
                    1f,
                    0f,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.PlayerType == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    if (smth < Time.time)
                    {
                        smth = Time.time + 1f;
                        int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                        int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                        GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                        {
                    GorillaTagger.Instance.offlineVRRig.transform.position,
                    new Vector3(0f, 0f, 0f),
                    hashone,
                    -1,
                    false,
                    num3,
                    true,
                    0.38f,
                    0.122f,
                    0f,
                    A
                        });
                        TundraUtils.Update();
                    }
                }
            }
            else if (TundraMain.PlayerType == 3)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    Vector3 origin = GorillaLocomotion.Player.Instance.bodyCollider.transform.position + new Vector3(0f, -0.1f, 0f);
                    Vector3 SpeedPos = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * Time.deltaTime * 150f;
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SlingshotProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    origin,
                    SpeedPos,
                    hashone,
                    -1,
                    false,
                    num3,
                    true,
                    1f,
                    1f,
                    1f,
                    A
                    });
                    TundraUtils.Update();
                }
            }
            else if (TundraMain.PlayerType == 4)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    Vector3 origin = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position;
                    Vector3 SpeedPos = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * Time.deltaTime * 150f;
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
                    {
                    origin,
                    SpeedPos,
                    hashone,
                    -1,
                    false,
                    num3,
                    true,
                    0f,
                    1f,
                    0f,
                    A
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void Test()
        {
            float minDistance = 1f;
            float maxDistance = 2f;

            Vector3 randomOffset = Random.insideUnitSphere;
            randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

            Vector3 newPosition = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + randomOffset;

            Vector3 directionToPlayer = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - newPosition;
            Quaternion newrotation = Quaternion.LookRotation(directionToPlayer);

            int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/WaterBalloonProjectile(Clone)"));
            int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
            GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", 0, new object[]
            {
                    newPosition,
                    new Vector3(0f, 2f, 0f),
                    hashone,
                    TrailHash,
                    false,
                    num3,
                    true,
                    0f,
                    200f,
                    255f,
                    5f
            });
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
        }
        public static void CrashTest()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(pointer.GetComponent<Rigidbody>());
                Object.Destroy(pointer.GetComponent<SphereCollider>());
                Object.Destroy(pointer.GetComponent<MeshCollider>());
                Object.Destroy(pointer.GetComponent<Collider>());
                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                pointer.transform.position = hit.point;
                Object.Destroy(pointer, Time.deltaTime);
                Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                VRRig vrrig = hit.collider.GetComponentInParent<VRRig>();
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                    Vector3 point = vrrig.transform.position;
                    Vector3 vector = (point - GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position).normalized;
                    int hashone = PoolUtils.GameObjHashCode(GameObject.Find("Environment Objects/PersistentObjects_Prefab/GlobalObjectPools/SnowballProjectile(Clone)"));
                    int num3 = GorillaGameManager.instance.IncrementLocalPlayerProjectileCount();
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", player, new object[]
                    {
                vector,
                new Vector3(0f, float.MaxValue, 0f),
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                    });
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", player, new object[]
                   {
                vector,
                new Vector3(0f, float.MaxValue, 0f),
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                   });
                    GorillaGameManager.instance.photonView.RPC("LaunchSlingshotProjectile", player, new object[]
                   {
                vector,
                new Vector3(0f, float.MaxValue, 0f),
                hashone,
                TrailHash,
                false,
                num3,
                true,
                RED,
                GREEN,
                BLUE,
                A
                   });
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                }
                else
                {
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
            }
        }
    }
}