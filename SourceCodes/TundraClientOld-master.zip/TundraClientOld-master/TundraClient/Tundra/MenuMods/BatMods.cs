﻿using Photon.Pun;
using TundraMenu;
using UnityEngine;
using Tundra.ColorManagement;

namespace Tundra.MenuMods
{
    internal class BatMods
    {
        static ControllerInputPoller input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
        public static void Grab_Bat()
        {
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromOriginBeforeRespawn = 9999999;
                GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromTargetPlayerBeforeRespawn = 999999;
                GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStartingDescent = 99999;
                GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStoppingAscent = 99999;
                GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
            }
        }
        public static void Ride_Bat()
        {
            if (input.leftControllerIndexFloat > 0.1f)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }
            if (TundraMain.Reversed)
            {
                foreach (MeshCollider awd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    awd.enabled = false;
                }
                GorillaLocomotion.Player.Instance.transform.position = GameObject.Find("Cave Bat Holdable").transform.position;
            }
            else
            {
                foreach (MeshCollider awd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    awd.enabled = true;
                }
            }
        }
        public static void BatGun()
        {
            if (TundraMain.GunHand == 1)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromOriginBeforeRespawn = 9999999;
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromTargetPlayerBeforeRespawn = 999999;
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStartingDescent = 99999;
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStoppingAscent = 99999;
                        GameObject.Find("Cave Bat Holdable").transform.position = hit.point;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromOriginBeforeRespawn = 9999999;
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromTargetPlayerBeforeRespawn = 999999;
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStartingDescent = 99999;
                        GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStoppingAscent = 99999;
                        GameObject.Find("Cave Bat Holdable").transform.position = hit.point;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void Reset_bat()
        {
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromOriginBeforeRespawn = 9999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromTargetPlayerBeforeRespawn = 9999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStartingDescent = 9999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStoppingAscent = 9999999;
            GameObject.Find("Cave Bat Holdable").transform.position = new Vector3(9999999999, 9999999999, 999999999);
        }
        public static void BatOrbit()
        {
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromOriginBeforeRespawn = 9999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromTargetPlayerBeforeRespawn = 999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStartingDescent = 99999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStoppingAscent = 99999;
            float orbitSpeed = 4.5f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 6f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 0.225f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            GameObject.Find("Cave Bat Holdable").transform.position = vector;
        }
        public static void BatAura()
        {
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromOriginBeforeRespawn = 9999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maxDistanceFromTargetPlayerBeforeRespawn = 999999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStartingDescent = 99999;
            GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>().maximumHeightOffOfTheGroundBeforeStoppingAscent = 99999;
            float minDistance = 1f;
            float maxDistance = 2f;

            Vector3 randomOffset = UnityEngine.Random.insideUnitSphere;
            randomOffset = randomOffset.normalized * UnityEngine.Random.Range(minDistance, maxDistance);

            Vector3 newPosition = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + randomOffset;

            Vector3 directionToPlayer = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - newPosition;
            Quaternion newrotation = Quaternion.LookRotation(directionToPlayer);

            GameObject.Find("Cave Bat Holdable").transform.position = newPosition;
            GameObject.Find("Cave Bat Holdable").transform.rotation = newrotation;
        }
    }
}
