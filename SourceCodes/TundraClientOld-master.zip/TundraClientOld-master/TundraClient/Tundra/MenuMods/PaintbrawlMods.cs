﻿using HarmonyLib;
using Photon.Pun;
using Tundra.ColorManagement;
using UnityEngine;
using GTAG_NotificationLib;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class PaintbrawlMods
    {
        static ControllerInputPoller input;
        static float smth = 0;
        static VRRig asda;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static void KillGunNoMaster()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.5f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportSlingshotHit", RpcTarget.All, new object[]
                                {
                            player,
                            hit.point,
                            1
                                });
                                NotifiLib.SendWithCooldown($"{player.NickName} Just lost a balloon!", 2.5f);
                            }
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.5f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportSlingshotHit", RpcTarget.All, new object[]
                                {
                            player,
                            hit.point,
                            1
                                });
                                NotifiLib.SendWithCooldown($"{player.NickName} Just lost a balloon!", 2.5f);
                            }
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.5f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportSlingshotHit", RpcTarget.All, new object[]
                                {
                            player,
                            hit.point,
                            1
                                });
                                NotifiLib.SendWithCooldown($"{player.NickName} Just lost a balloon!", 2.5f);
                            }
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.5f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("ReportSlingshotHit", RpcTarget.All, new object[]
                                {
                            player,
                            hit.point,
                            1
                                });
                                NotifiLib.SendWithCooldown($"{player.NickName} Just lost a balloon!", 2.5f);
                            }
                            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void KillAllNoMaster()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 1f;
                foreach (VRRig w in GorillaParent.instance.vrrigs)
                {
                    Photon.Realtime.Player pla = rig2view(w.GetComponentInParent<VRRig>()).Owner;
                    PhotonView.Get(GorillaGameManager.instance).RPC("ReportSlingshotHit", RpcTarget.All, new object[]
                    {
                    pla,
                    w.transform.position,
                    1
                    });
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                }
            }
        }
        public static void ReviveGunMaster()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] = 3;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] = 3;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void ReviveAllMaster()
        {
            foreach (Photon.Realtime.Player vrrig in PhotonNetwork.PlayerListOthers)
            {
                GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[vrrig.ActorNumber] = 3;
            }
        }
        public static void Give_A_Life_Gun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (smth < Time.time)
                            {
                                smth = Time.time + 2.5f;
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] += 1;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (smth < Time.time)
                            {
                                smth = Time.time + 2.5f;
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] += 1;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 2.5f;
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] += 1;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 2.5f;
                                GameObject.Find("Player Objects/GorillaParent/Gorilla Battle Manager(Clone)").GetComponent<GorillaBattleManager>().playerLives[player.ActorNumber] += 1;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
    }
}
