﻿using UnityEngine;
using Tundra.ColorManagement;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class BalloonMods
    {
        static ControllerInputPoller input;
        public static void GrabBalloons()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerGripFloat > 0.1f)
            {
                foreach (BalloonHoldable awd in Resources.FindObjectsOfTypeAll(typeof(BalloonHoldable)))
                {
                    awd.transform.position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
                }
            }
        }
        public static void BallonGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        foreach (BalloonHoldable awd in Resources.FindObjectsOfTypeAll(typeof(BalloonHoldable)))
                        {
                            awd.transform.position = hit.point;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        foreach (BalloonHoldable awd in Resources.FindObjectsOfTypeAll(typeof(BalloonHoldable)))
                        {
                            awd.transform.position = hit.point;
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void PopEmAll()
        {
            foreach (BalloonHoldable awd in Resources.FindObjectsOfTypeAll(typeof(BalloonHoldable)))
            {
                awd.Invoke("OwnerPopBalloon", 1);
            }
        }
        public static void SpinnyBalloons()
        {
            foreach (BalloonHoldable awd in Resources.FindObjectsOfTypeAll(typeof(BalloonHoldable)))
            {
                awd.transform.Rotate(0f, 45f, 0);
            }
        }
        public static void BalloonOrbit()
        {
            float orbitSpeed = 5f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 8f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 0.3f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            foreach (BalloonHoldable awd in Resources.FindObjectsOfTypeAll(typeof(BalloonHoldable)))
            {
                awd.transform.position = vector;
            }
        }
    }
}
