﻿using UnityEngine;
using Tundra.ColorManagement;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class MonsterMods
    {
        static ControllerInputPoller input;
        public static void MonsterGrab()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_1").transform.position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position + new Vector3(0f, -0.0075f, 0f);
                GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_2").transform.position = GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position + new Vector3(0f, -0.0075f, 0f);
            }
        }
        public static void MonsterGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_1").transform.position = hit.point;
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_2").transform.position = hit.point;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_1").transform.position = hit.point;
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_2").transform.position = hit.point;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void MonstersOrbit()
        {
            float orbitSpeed = 6f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 6.5f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.transform.position;
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_1").transform.position = vector;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_2").transform.position = vector;
        }
        public static void Invis_Monsters()
        {
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_1").transform.position = new Vector3(500, -9999, 0f);
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/BasementMaze/Monkeye_Prefab_2").transform.position = new Vector3(500, -9999, 0f);
        }
    }
}
