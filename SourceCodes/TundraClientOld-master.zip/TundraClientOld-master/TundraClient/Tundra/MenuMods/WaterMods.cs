﻿using GorillaLocomotion.Swimming;
using Photon.Pun;
using TundraMenu;
using Tundra.ColorManagement;
using UnityEngine;
using UnityEngine.XR;
using MenuUtils;

namespace Tundra.MenuMods
{
    internal class WaterMods
    {
        static float smth = 0;
        static ControllerInputPoller input;
        public static void WaterSelf()
        {
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", 0, new object[]
            {
                GorillaTagger.Instance.offlineVRRig.transform.position,
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation,
                0.45f,
                0.45f,
                true,
                false
            });
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
        }
        public static void WaterGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightGrab)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = hit.point + new Vector3(0f, 1.2f, 0f);
                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", 0, new object[]
                        {
                        hit.point,
                        Random.rotation,
                        0.45f,
                        0.45f,
                        true,
                        false
                        });
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = hit.point + new Vector3(0f, 1.2f, 0f);
                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", 0, new object[]
                        {
                        hit.point,
                        Random.rotation,
                        0.45f,
                        0.45f,
                        true,
                        false
                        });
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void WaterBendL()
        {
            InputDevices.GetDeviceAtXRNode(XRNode.LeftHand).TryGetFeatureValue(CommonUsages.gripButton, out bool grp);
            grp = input.leftControllerGripFloat > 0.1f;
            if (grp)
            {
                if (smth < Time.time)
                {
                    smth = Time.time + 0.08f;
                    PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", RpcTarget.All, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position,
                    GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.rotation,
                    0.3f,
                    0.3f,
                    true,
                    false
                    });
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                }
            }
        }
        public static void WaterBendR()
        {
            InputDevices.GetDeviceAtXRNode(XRNode.RightHand).TryGetFeatureValue(CommonUsages.gripButton, out bool grp);
            grp = input.leftControllerGripFloat > 0.1f;
            if (grp)
            {
                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position,
                    GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.rotation,
                    0.3f,
                    0.3f,
                    true,
                    false
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
        }
        public static void WaterBending()
        {
            WaterBendL();
            WaterBendR();
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
        }
        public static void WaterOrbit()
        {
            float orbitSpeed = 4.5f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 6f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 0.225f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", 0, new object[]
            {
                        vector,
                        GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.rotation,
                        0.45f,
                        0.45f,
                        true,
                        false
            });
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
        }
        public static void WaterOrbitAll()
        {
            if (Time.time > smth)
            {
                smth = Time.time + 0.002f;
                foreach (VRRig fef in GorillaParent.instance.vrrigs)
                {
                    float orbitSpeed = 4.5f;
                    float orbitAngle = Time.time * orbitSpeed;
                    float orbitRadius = 6f;
                    Vector3 POS = fef.head.rigTarget.gameObject.transform.position + new Vector3(0f, 0.225f, 0f);
                    Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                    Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                    PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", 0, new object[]
                    {
                        vector,
                        GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.rotation,
                        0.45f,
                        0.45f,
                        true,
                        false
                    });
                    GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                }
            }
        }
        public static void WaterAura()
        {
            float minDistance = 1f;
            float maxDistance = 2f;

            Vector3 randomOffset = UnityEngine.Random.insideUnitSphere;
            randomOffset = randomOffset.normalized * UnityEngine.Random.Range(minDistance, maxDistance);

            Vector3 newPosition = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + randomOffset;

            Vector3 directionToPlayer = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - newPosition;
            Quaternion newrotation = Quaternion.LookRotation(directionToPlayer);

            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", 0, new object[]
                {
                        newPosition,
                        GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.rotation,
                        0.45f,
                        0.45f,
                        true,
                        false
                });
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
        }
        public static void DisableWater()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                GameObject.Find("OceanWater").GetComponent<WaterVolume>().enabled = false;
            }
            else
            { 
                GameObject.Find("OceanWater").GetComponent<WaterVolume>().enabled = true;
            }
        }
        public static void FastSwim()
        {
            if (input.leftControllerGripFloat > 0.1f)
            {
                if (TundraMain.Origin)
                {
                    TundraMain.Reversed = !TundraMain.Reversed;
                    TundraMain.Origin = false;
                }
            }
            else
            {
                TundraMain.Origin = true;
            }
            bool WATTA = GorillaLocomotion.Player.Instance.InWater;
            if (TundraMain.Reversed)
            {
                if (WATTA)
                {
                    GorillaLocomotion.Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= 1.05f;
                }
            }
            else
            {
                if (!WATTA)
                {
                    GorillaLocomotion.Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= 1;
                }
            }
        }
    }
}