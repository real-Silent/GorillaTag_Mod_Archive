﻿using UnityEngine;
using Tundra.ColorManagement;
using Photon.Pun;
using GorillaNetworking;
using System.Linq;
using GTAG_NotificationLib;
using MenuUtils;
using HarmonyLib;
using System.Collections.Generic;
using UnityEngine.XR;
using TundraMenu;

namespace Tundra.MenuMods
{
    internal class PlayerMods
    {
        static bool LeftPlatie = true;
        static bool RightPlatie = true;
        static bool LeftPlatformInput = false;
        static bool RightPlatformInput = false;
        static GameObject LeftPlatform;
        static GameObject RightPlatform;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        static float rgbthingy;
        static float rgbcooldown;
        static Color rgbColor;
        static bool TPRandom = false;
        static float smth = 0;
        static bool teleportGunAntiRepeat = false;
        static ControllerInputPoller input;
        static Color color;
        public static void IronMonkKONCreds()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerGripFloat > 0.1f)
            {
                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(25f * GorillaLocomotion.Player.Instance.leftControllerTransform.right.x * -1f, 25f * GorillaLocomotion.Player.Instance.leftControllerTransform.right.y * -1f, 25f * GorillaLocomotion.Player.Instance.leftControllerTransform.right.z * -1f), ForceMode.Acceleration);
            }
            if (input.rightControllerGripFloat > 0.1f)
            {
                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(25f * GorillaLocomotion.Player.Instance.rightControllerTransform.right.x, 25f * GorillaLocomotion.Player.Instance.rightControllerTransform.right.y, 25f * GorillaLocomotion.Player.Instance.rightControllerTransform.right.z), ForceMode.Acceleration);            }
        }
        public static void Bees()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 0.100f;
                System.Random random = new System.Random();
                int funny = random.Next(1, GorillaParent.instance.vrrigDict.Count);
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(-94.1266f, 9999f, -132.3289f);
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(-94.1266f, 9999f, -132.3289f);
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaParent.instance.vrrigs[funny].transform.position + new Vector3(0f, 0.8f, 0f);
            }
        }
        public static void UPNDOWN()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(1500, GorillaLocomotion.Player.Instance.transform.position, 10, 10);
            }
            if (input.rightControllerIndexFloat > 0.1f)
            {
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(-1800, GorillaLocomotion.Player.Instance.transform.position, 10, 10);
            }
        }
        public static void TPRandomW()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                if (!TPRandom)
                {
                    if (PhotonNetwork.PlayerListOthers.Count() > 3)
                    {
                        System.Random random = new System.Random();
                        int i = random.Next(1, GorillaParent.instance.vrrigDict.Count);
                        foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                        {
                            meshCollider.enabled = false;
                        }
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = GorillaParent.instance.vrrigs[i].transform.position;
                        TPRandom = true;
                    }
                }
                else
                {
                    foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        meshCollider.enabled = true;
                    }
                    TPRandom = true;
                }
            }
            else
            {
                TPRandom = false;
            }
        }
        public static void VelFly()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                if (TundraMain.VelSpeed == 1)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 10f;
                }
                else if (TundraMain.VelSpeed == 2)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 20;
                }
                else if (TundraMain.VelSpeed == 3)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 30;
                }
                else if (TundraMain.VelSpeed == 4)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 40;
                }
                else if (TundraMain.VelSpeed == 5)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 50;
                }
            }
        }
        public static void AirStrike()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = pointer.transform.position;
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = new Vector3(0, 45, 0);
                            teleportGunAntiRepeat = true;
                            foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                            {
                                mawd.enabled = false;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    else
                    {
                        foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                        {
                            mawd.enabled = true;
                        }
                        teleportGunAntiRepeat = false;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = pointer.transform.position;
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = new Vector3(0, 45, 0);
                            teleportGunAntiRepeat = true;
                            foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                            {
                                mawd.enabled = false;
                            }
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    else
                    {
                        foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                        {
                            mawd.enabled = true;
                        }
                        teleportGunAntiRepeat = false;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void Strobe()
        {
            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                color = Color.HSVToRGB(smth, 1f, 1f);
                smth += 0.06f;
                if (smth >= 1f)
                {
                    smth = 0f;
                } //RGB
                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                {
                    color.r,
                    color.g,
                    color.b,
                    false
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
            else
            {
                NotifiLib.SendWithCooldown("PLEASE GOTO STUMP", 2.5f);
            }
        }
        public static void SpoofPlayer()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    if (Time.time > smth)
                    {
                        smth = Time.time + 0.5f;
                        RGBShit();
                        string[] randomnames = new string[]
                        {
                            "PHOTON",
                            "TICKLETIPJR",
                            "BTC",
                            "ETH",
                            "LTC",
                            "XMR",
                            "REV",
                            "OCT",
                            "JMANCURLY",
                            "ELLIOT",
                            "VMT",
                            "UNITYENGINE",
                            "GORILLA",
                            "RPCABUSER",
                            "CONNORVR",
                            "NETWORKING",
                            "TUNDRACLIENT",
                            "JELLOVR"
                        };
                        int Rando = new System.Random().Next(0, randomnames.Length - 1);
                        PhotonNetwork.LocalPlayer.NickName = (randomnames[Rando]);
                        GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
                        PlayerPrefs.Save();
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    } GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
                        PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
                       
                }
                else
                {
                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                    NotifiLib.SendWithCooldown("Using This mod Outside of stump may not work [EVERY] Time", 2.5f);
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void RGB()
        {
            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                color = Color.HSVToRGB(smth, 1f, 1f);
                smth += 0.006f;
                if (smth >= 1f)
                {
                    smth = 0f;
                } //RGB
                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                {
                    color.r,
                    color.g,
                    color.b,
                    false
                });
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            }
            else
            {
                NotifiLib.SendWithCooldown("PLEASE GOTO STUMP", 2.5f);
            }
        }
        public static void SetNameNothing()
        {
            PhotonNetwork.LocalPlayer.NickName = "";
            GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
            GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
            PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
            PlayerPrefs.Save();
        }
        static void RGBShit()
        {
            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                if (Time.time > rgbcooldown + 0.2f)
                {
                    rgbcooldown = Time.time;
                    rgbthingy += 0.2f;

                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                    {
                        if (rgbthingy >= 0.2f)
                        {
                            rgbColor = Color.red;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.3f)
                        {
                            rgbColor = Color.yellow;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.4f)
                        {
                            rgbColor = Color.green;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.5f)
                        {
                            rgbColor = Color.cyan;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.6f)
                        {
                            rgbColor = Color.blue;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);
                        }
                        if (rgbthingy >= 0.7f)
                        {
                            rgbColor = Color.magenta;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);
                        }



                        if (rgbthingy >= 0.7f)
                        {
                            rgbthingy = 0f;
                        }
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    }
                }
            }
        }
        public static void StickySurfaces()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            List<InputDevice> leftList = new List<InputDevice>();
            List<InputDevice> rightList = new List<InputDevice>();
            InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Left | InputDeviceCharacteristics.Controller, leftList);
            InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Right | InputDeviceCharacteristics.Controller, rightList);
            leftList[0].TryGetFeatureValue(CommonUsages.gripButton, out LeftPlatformInput);
            rightList[0].TryGetFeatureValue(CommonUsages.gripButton, out RightPlatformInput);
            LeftPlatformInput = input.leftControllerGripFloat > 0.1f;
            RightPlatformInput = input.rightControllerGripFloat > 0.1f;
            if (LeftPlatformInput && LeftPlatie)
            {
                LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                LeftPlatform.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                //thick going down  //thick wideness //thick length forward backward
                LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                LeftPlatform.GetComponent<Renderer>().enabled = false;
                LeftPlatie = false;
            }
            if (LeftPlatformInput && !LeftPlatie)
            {
                LeftPlatie = false;
            }
            if (!LeftPlatformInput)
            {
                GameObject.Destroy(LeftPlatform);
                LeftPlatie = true;
            }
            if (RightPlatformInput && RightPlatie)
            {
                RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                RightPlatform.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                RightPlatform.GetComponent<Renderer>().enabled = false;

                RightPlatie = false;
            }
            if (RightPlatformInput && !RightPlatie)
            {
                RightPlatie = false;
            }
            if (!RightPlatformInput)
            {
                GameObject.Destroy(RightPlatform);
                RightPlatie = true;
            }
        }
        public static void StealPlayer()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (!teleportGunAntiRepeat)
                        {
                            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                            {
                                color = GorillaGameManager.instance.FindPlayerVRRig(player).playerColor;
                                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                                {
                            color.r,
                            color.g,
                            color.b,
                            false
                                });
                                PhotonNetwork.LocalPlayer.NickName = player.NickName;
                                GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
                                GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
                                PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
                                PlayerPrefs.Save();
                                teleportGunAntiRepeat = true;
                            }
                            else
                            {
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                            }
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player player = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (!teleportGunAntiRepeat)
                        {
                            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                            {
                                color = GorillaGameManager.instance.FindPlayerVRRig(player).playerColor;
                                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                                {
                            color.r,
                            color.g,
                            color.b,
                            false
                                });
                                PhotonNetwork.LocalPlayer.NickName = player.NickName;
                                GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
                                GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
                                PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
                                PlayerPrefs.Save();
                                teleportGunAntiRepeat = true;
                            }
                            else
                            {
                                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                            }
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void NameChanger()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    if (Time.time > smth)
                    {
                        smth = Time.time + 0.5f;
                        string[] randomnames = new string[]
                        {
                            "PHOTON",
                            "TICKLETIPJR",
                            "BTC",
                            "ETH",
                            "LTC",
                            "XMR",
                            "REV",
                            "OCT",
                            "JMANCURLY",
                            "ELLIOT",
                            "VMT",
                            "UNITYENGINE",
                            "GORILLA",
                            "RPCABUSER",
                            "CONNORVR",
                            "NETWORKING",
                            "TUNDRACLIENT",
                            "JELLOVR"
                        };
                        int Rando = new System.Random().Next(0, randomnames.Length - 1);
                        PhotonNetwork.LocalPlayer.NickName = (randomnames[Rando]);
                        GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
                        PlayerPrefs.Save();
                        GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                    }
                    GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
                    PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);

                }
                else
                {
                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                    NotifiLib.SendWithCooldown("Using This mod Outside of stump may not work [EVERY] Time", 2.5f);
                }
            }
        }
        public static void CarMonke()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerIndexFloat > 0.1f)
            {
                Vector3 wdirPos = GorillaLocomotion.Player.Instance.headCollider.transform.forward.normalized * -20;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(wdirPos, GorillaLocomotion.Player.Instance.headCollider.transform.position, ForceMode.Acceleration);
            }
            if (input.rightControllerIndexFloat > 0.1f)
            {
                Vector3 dirPos = GorillaLocomotion.Player.Instance.headCollider.transform.forward.normalized * 20;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(dirPos, GorillaLocomotion.Player.Instance.headCollider.transform.position, ForceMode.Acceleration);
            }
        }
        public static void GrappleMonk()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        Vector3 awd = (hit.point - GorillaLocomotion.Player.Instance.transform.position).normalized * 4;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(awd, hit.point, ForceMode.VelocityChange);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        Vector3 awd = (hit.point - GorillaLocomotion.Player.Instance.transform.position).normalized * 4;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(awd, hit.point, ForceMode.VelocityChange);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void SwingingMonk()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
            if (input.rightControllerGripFloat > 0.1f)
            {
                if (!GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>())
                {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.AddComponent<LineRenderer>();
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                }
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0.42f, 0.173f, 0f, 1f), new Color(0.42f, 0.173f, 0f, 1f), Mathf.PingPong(Time.time, 1));
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position);
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>().SetPosition(1, hit.point);
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    
                }
                else
                {
                    GameObject.Destroy(GorillaTagger.Instance.offlineVRRig.rightHandPlayer.gameObject.GetComponent<LineRenderer>());
                }
            }
            Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var raycast);
            if (input.leftControllerGripFloat > 0.1f)
            {
                if (!GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>())
                {
                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.AddComponent<LineRenderer>();
                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                }
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 0.561f, 0.161f, 1f), new Color(0f, 0.561f, 0.161f, 1f), Mathf.PingPong(Time.time, 1));
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position);
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>().SetPosition(1, raycast.point);
                if (input.leftControllerIndexFloat > 0.1f)
                {
                    
                }
                else
                {
                    GameObject.Destroy(GorillaTagger.Instance.offlineVRRig.leftHandPlayer.gameObject.GetComponent<LineRenderer>());
                }
            }
        }
    }
}