﻿using HarmonyLib;
using Photon.Pun;
using Tundra.ColorManagement;
using UnityEngine;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;
using System.Collections.Generic;
using TundraMenu;
using MenuUtils;

namespace Tundra.MenuMods
{
    internal class ImpactMods
    {
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        static ControllerInputPoller input;
        static float smth = 0;
        public static Color teamColor = Color.green;
        public static int CurrentSelectedColor = 1;
        static VRRig asda;
        public static List<Color> color = new List<Color>
        {
            Color.red,
            Color.green,
            Color.blue,
            Color.black,
            new Color(0.733f, 1f, 0f, 1f),
            new Color(0.329f, 0f, 1f, 1f),
        };

        public static void ColorLOL()
        {
            Material material = new Material(Shader.Find("GorillaTag/UberShader"));
            material.color = Color.HSVToRGB(smth, 1f, 1f);
            smth += 0.006f;
            if (smth >= 1f)
            {
                smth = 0f;
            }
            if (TundraMain.ImpactColors == 1)
            {
                teamColor = Color.red;
            }
            else if (TundraMain.ImpactColors == 2)
            {
                teamColor = Color.green;
            }
            else if (TundraMain.ImpactColors == 3)
            {
                teamColor = Color.blue;
            }
            else if (TundraMain.ImpactColors == 4)
            {
                teamColor = Color.black;
            }
            else if (TundraMain.ImpactColors == 5)
            {
                teamColor = new Color(0.733f, 1f, 0f, 1f);
            }
            else if (TundraMain.ImpactColors == 6)
            {
                teamColor = new Color(0.329f, 0f, 1f, 1f);
            }
            else if (TundraMain.ImpactColors == 7)
            {
                CurrentSelectedColor++;
                if (CurrentSelectedColor > color.Count)
                {
                    CurrentSelectedColor = 1;
                }
                teamColor = color[CurrentSelectedColor];
            }
        }
        public static void ImpactSelf()
        {
            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
            {
                    GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position,
                    teamColor.r,
                    teamColor.g,
                    teamColor.b,
                    teamColor.a,
                    1
            });
            TundraUtils.Update();
        }
        public static void ImpactPomPoms()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerGripFloat > 0.1f)
            {
                if (smth < Time.time)
                {
                    smth = Time.time + 0.002f;
                    GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                    GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                    PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position,
                    teamColor.r,
                    teamColor.g,
                    teamColor.b,
                    teamColor.a,
                    1
                    });

                    PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                    {
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position,
                    teamColor.r,
                    teamColor.g,
                    teamColor.b,
                    teamColor.a,
                    1
                    });
                }
                TundraUtils.Update();
            }
        }
        public static void ImpactGun()
        {
            if (TundraMain.GunLock == 1)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                        pointer.transform.position,
                        teamColor.r,
                        teamColor.g,
                        teamColor.b,
                        teamColor.a,
                        1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                        pointer.transform.position,
                        teamColor.r,
                        teamColor.g,
                        teamColor.b,
                        teamColor.a,
                        1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunLock == 2)
            {
                if (TundraMain.GunHand == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                        pointer.transform.position,
                        teamColor.r,
                        teamColor.g,
                        teamColor.b,
                        teamColor.a,
                        1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunHand == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                        pointer.transform.position,
                        teamColor.r,
                        teamColor.g,
                        teamColor.b,
                        teamColor.a,
                        1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void ImpactAll()
        {
            if (smth > Time.time)
            {
                smth = Time.time + 0.002f;
                for (int w = 0; w < GorillaParent.instance.vrrigs.Count; w++)
                {
                    PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                    {
                            GorillaParent.instance.vrrigs[w].transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                    });
                    TundraUtils.Update();
                }
            }
        }
        public static void ImpactOrbit()
        {
            float orbitSpeed = 4.5f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 6f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
            {
                    vector,
                    teamColor.r,
                    teamColor.g,
                    teamColor.b,
                    teamColor.a,
                    1
            });
            TundraUtils.Update();
        }
        public static void ImpactAura()
        {
            float minDistance = 1f;
            float maxDistance = 2f;

            Vector3 randomOffset = Random.insideUnitSphere;
            randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

            Vector3 newPosition = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + randomOffset;

            Vector3 directionToPlayer = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - newPosition;
            Quaternion newrotation = Quaternion.LookRotation(directionToPlayer);

            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
            {
                    newPosition,
                    teamColor.r,
                    teamColor.g,
                    teamColor.b,
                    teamColor.a,
                    1
            });
            TundraUtils.Update();
        }
        public static void GivePomPoms()
        {
            if (TundraMain.GunHand == 1)
            {
                if (TundraMain.GunLock == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            GorillaGameManager.instance.FindPlayerVRRig(awd).leftHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });

                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            GorillaGameManager.instance.FindPlayerVRRig(awd).rightHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });
                            }
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunLock == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            asda.leftHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });

                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            asda.rightHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });
                            }
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                if (TundraMain.GunLock == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            GorillaGameManager.instance.FindPlayerVRRig(awd).leftHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });

                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            GorillaGameManager.instance.FindPlayerVRRig(awd).rightHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });
                            }
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunLock == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            pointer.transform.position = asda.transform.position;
                            if (smth < Time.time)
                            {
                                smth = Time.time + 0.002f;
                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            asda.leftHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });

                                PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                                {
                            asda.rightHandPlayer.transform.position,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                                });
                            }
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
        public static void ImpactOrbitPlayer()
        {
            if (TundraMain.GunHand == 1)
            {
                if (TundraMain.GunLock == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player asda = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            float orbitSpeed = 4.5f;
                            float orbitAngle = Time.time * orbitSpeed;
                            float orbitRadius = 6f;
                            Vector3 POS = GorillaGameManager.instance.FindPlayerVRRig(asda).transform.position + new Vector3(0f, 0.6f, 0f);
                            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                            vector,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunLock == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                    if (input.rightControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.rightControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            asda = hit.collider.GetComponentInParent<VRRig>();
                            pointer.transform.position = asda.transform.position;
                            float orbitSpeed = 4.5f;
                            float orbitAngle = Time.time * orbitSpeed;
                            float orbitRadius = 6f;
                            Vector3 POS = asda.headConstraint.transform.position;
                            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                            vector,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                            });
                            TundraUtils.Update();
                            pointer.transform.position = asda.transform.position;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                if (TundraMain.GunLock == 1)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player asdaw = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            float orbitSpeed = 4.5f;
                            float orbitAngle = Time.time * orbitSpeed;
                            float orbitRadius = 6f;
                            Vector3 POS = GorillaGameManager.instance.FindPlayerVRRig(asdaw).transform.position + new Vector3(0f, 0.6f, 0f);
                            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                            vector,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
                else if (TundraMain.GunLock == 2)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                    Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                    if (input.leftControllerGripFloat > 0.1f)
                    {
                        GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Object.Destroy(pointer.GetComponent<Rigidbody>());
                        Object.Destroy(pointer.GetComponent<SphereCollider>());
                        Object.Destroy(pointer.GetComponent<MeshCollider>());
                        Object.Destroy(pointer.GetComponent<Collider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        pointer.transform.position = hit.point;
                        Object.Destroy(pointer, Time.deltaTime);
                        Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                        if (input.leftControllerIndexFloat > 0.1f)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            if (hit.collider.GetComponentInParent<VRRig>() != null)
                            {
                                asda = hit.collider.GetComponentInParent<VRRig>();
                            }
                            asda = hit.collider.GetComponentInParent<VRRig>();
                            pointer.transform.position = asda.transform.position;
                            float orbitSpeed = 4.5f;
                            float orbitAngle = Time.time * orbitSpeed;
                            float orbitRadius = 6f;
                            Vector3 POS = asda.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
                            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                            Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                            PhotonView.Get(GorillaGameManager.instance).RPC("SpawnSlingshotPlayerImpactEffect", 0, new object[]
                            {
                            vector,
                            teamColor.r,
                            teamColor.g,
                            teamColor.b,
                            teamColor.a,
                            1
                            });
                            TundraUtils.Update();
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                        else
                        {
                            pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                        }
                    }
                }
            }
        }
    }
}
