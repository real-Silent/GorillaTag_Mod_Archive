﻿using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Tundra.ColorManagement;
using UnityEngine;
using GTAG_NotificationLib;
using TundraMenu;
using MenuUtils;

namespace Tundra.MenuMods
{
    internal class MiscMods
    {
        static bool teleportGunAntiRepeat = false;
        static Color color;
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        static ControllerInputPoller input;
        public static void ComsetSlotSpam()
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton").GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
            TundraUtils.Update();
        }
        public static void CosmetSlotSpam2()
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton (1)").GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
            TundraUtils.Update();
        }
        public static void CosmetSlotSpam3()
        {
            TundraUtils.Update();
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton (2)").GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
        }
        public static void CosmetSlotSpamAll()
        {
            TundraUtils.Update();
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton").GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton (1)").GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton (2)").GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
        }
        public static void TPToStump()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>(); 
            if (GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").activeSelf == true)
            {
                if (input.rightControllerPrimaryButton)
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = false;
                    }
                    GorillaLocomotion.Player.Instance.transform.position = new Vector3(-66.4728f, 11.7809f, -82.641f);
                }
                else
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = true;
                    }
                }
            }
        }
        public static void QuitBoxOff()
        {
            if (GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").activeSelf == true)
            {
                GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(false);
            }
            else
            {
                if (GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").activeSelf == false)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(true);
                }
            }
        }
        public static void ChangePBBV()
        {
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            PhotonNetwork.LocalPlayer.NickName = "PBBV";
            GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
            GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
            PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
            PlayerPrefs.Save();
            color = new Color32(255, 87, 120, 1);
            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", 0, new object[]
            {
                color.r,
                color.g,
                color.b,
                false
            });
        }
        public static void ChangeJ3VU()
        {
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            PhotonNetwork.LocalPlayer.NickName = "J3VU";
            GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
            GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
            PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
            PlayerPrefs.Save();
            color = new Color32(70, 255, 33, 1);
            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", 0, new object[]
            {
                color.r,
                color.g,
                color.b,
                false
            });
        }
        public static void ChangeDAISY()
        {
            GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
            PhotonNetwork.LocalPlayer.NickName = "DAISY09";
            GorillaComputer.instance.savedName = PhotonNetwork.LocalPlayer.NickName;
            GorillaComputer.instance.offlineVRRigNametagText.text = PhotonNetwork.LocalPlayer.NickName;
            PlayerPrefs.SetString("playerName", PhotonNetwork.LocalPlayer.NickName);
            PlayerPrefs.Save();
            color = new Color32(0, 255, 242, 1);
            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", 0, new object[]
            {
                color.r,
                color.g,
                color.b,
                false
            });
        }
        public static void isModding()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        if (awd.CustomProperties["mods"].ToString() != "")
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            NotifiLib.SendWithCooldown($"<color=red>[{awd.NickName}] IS MODDING</color>", 2.5f);
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        if (awd.CustomProperties["mods"].ToString() != "")
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            NotifiLib.SendWithCooldown($"<color=red>[{awd.NickName}] IS MODDING</color>", 2.5f);
                        }
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void ColorLogger()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        NotifiLib.SendWithCooldown($"[{awd.NickName}] Color Code R:[<color=red>{GorillaGameManager.instance.FindPlayerVRRig(awd).playerColor.r}</color>] G: [<color=green>{GorillaGameManager.instance.FindPlayerVRRig(awd).playerColor.g}</color> B: [<color=blue>{GorillaGameManager.instance.FindPlayerVRRig(awd).playerColor.b}</color>]", 4.5f);
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        NotifiLib.SendWithCooldown($"[{awd.NickName}] Color Code R:[<color=red>{GorillaGameManager.instance.FindPlayerVRRig(awd).playerColor.r}</color>] G: [<color=green>{GorillaGameManager.instance.FindPlayerVRRig(awd).playerColor.g}</color> B: [<color=blue>{GorillaGameManager.instance.FindPlayerVRRig(awd).playerColor.b}</color>]", 4.5f);
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void IDLogger()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.forward, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            teleportGunAntiRepeat = true;
                            string text = "ID's Logged";
                            text = string.Concat(new string[]
                            {
                                $"\nPlayer Name: {awd.NickName}",
                                $"\nPlayer ID: {awd.UserId}"
                            });
                            System.IO.File.AppendAllText("TundraIDLogs.txt", text);
                        }
                        NotifiLib.SendWithCooldown($"{awd.NickName}'s ID HAS BEEN LOGGED IN YOUR GTAG FOLDER", 4);
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.forward, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    Photon.Realtime.Player awd = rig2view(hit.collider.GetComponentInParent<VRRig>()).Owner;
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            teleportGunAntiRepeat = true;
                            string text = "ID's Logged";
                            text = string.Concat(new string[]
                            {
                                $"\nPlayer Name: {awd.NickName}",
                                $"\nPlayer ID: {awd.UserId}"
                            });
                            System.IO.File.AppendAllText("TundraIDLogs.txt", text);
                        }
                        NotifiLib.SendWithCooldown($"{awd.NickName}'s ID HAS BEEN LOGGED IN YOUR GTAG FOLDER", 4);
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
    }
}