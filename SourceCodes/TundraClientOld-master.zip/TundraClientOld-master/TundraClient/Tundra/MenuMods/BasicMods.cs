﻿using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using System.Linq;
using TundraMenu;
using UnityEngine;
using UnityEngine.XR;
using Tundra.ColorManagement;
using System.Threading;

namespace Tundra.MenuMods
{
    internal class BasicMods
    {
        static bool LeftPlatie = true;
        static bool RightPlatie = true;
        static bool LeftPlatformInput = false;
        static bool RightPlatformInput = false;
        static GameObject LeftPlatform;
        static GameObject RightPlatform;
        static bool teleportGunAntiRepeat = false;
        static GameObject pointer = null;
        public static bool CreatePublicRoom = false;
        static ControllerInputPoller input;
        public static GameObject clouds = GameObject.Find("Environment Objects/LocalObjects_Prefab/skyjungle");
        public static GameObject basement = GameObject.Find("Environment Objects/LocalObjects_Prefab/Basement");
        public static GameObject forest = GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest");
        public static GameObject city = GameObject.Find("Environment Objects/LocalObjects_Prefab/City");

        public static GameObject canyons = GameObject.Find("Environment Objects/LocalObjects_Prefab/Canyon");
        public static GameObject mountain = GameObject.Find("Environment Objects/LocalObjects_Prefab/Mountain");
        public static GameObject beach = GameObject.Find("Environment Objects/LocalObjects_Prefab/Beach");
        public static GameObject caves = GameObject.Find("Environment Objects/LocalObjects_Prefab/Cave_Main_Prefab");
        static System.Random random = new System.Random();

        public static void SpeedType()
        {
            if (TundraMain.SpeedType == 1)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 9.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 3.6f;
            }
            else if (TundraMain.SpeedType == 2)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 10f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 3.6f;
            }
            else if (TundraMain.SpeedType == 3)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 10.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 3.6f;
            }
            else if (TundraMain.SpeedType == 4)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 11f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 3.6f;
            }
            else if (TundraMain.SpeedType == 5)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 11.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 3.6f;
            }
        }
        public static void LongArmType()
        {
            if (TundraMain.LongArmType == 1)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.15f, 1.15f, 1.15f);
            }
            else if (TundraMain.LongArmType == 2)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.25f, 1.25f, 1.25f);
            }
            else if (TundraMain.LongArmType == 3)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.50f, 1.50f, 1.50f);
            }
            else if (TundraMain.LongArmType == 4)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.75f, 1.75f, 1.75f);
            }
        }
        public static void MosaType()
        {
            if (TundraMain.MosaType == 1)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 7.2f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.5f;
            }
            else if (TundraMain.MosaType == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GorillaLocomotion.Player.Instance.maxJumpSpeed = 7.2f;
                    GorillaLocomotion.Player.Instance.jumpMultiplier = 1.5f;
                }
            }
        }
        static string RandomStringPublic(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public static void CreatePub()
        {
            if (!PhotonNetwork.InRoom)
            {
                CreatePublicRoom = true;
            }
            if (PhotonNetwork.InRoom && !CreatePublicRoom)
            {
                CreatePublicRoom = true;
                PhotonNetwork.Disconnect();
            }
            else if (!PhotonNetwork.InRoom && CreatePublicRoom)
            {
                if (forest.activeSelf == true)
                {
                    CreateRoom("forest");
                }
                //City
                else if (city.activeSelf == true)
                {
                    CreateRoom("city");
                }
                //Caves
                else if (caves.activeSelf == true)
                {
                    CreateRoom("caves");
                }
                //MOUNTAINS
                else if (mountain.activeSelf == true)
                {
                    CreateRoom("mountain");
                }
                //BEACH
                else if (beach.activeSelf == true)
                {
                    CreateRoom("beach");
                }
                //CANYONS
                else if (canyons.activeSelf == true)
                {
                    CreateRoom("canyons");
                }
                //CLOUDS
                else if (clouds.activeSelf == true)
                {
                    CreateRoom("clouds");
                }
                //BASEMENT
                else if (basement.activeSelf == true)
                {
                    CreateRoom("dungeon");
                }
                CreatePublicRoom = false;
            }
        }
        public static void LeaveLobby()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.leftControllerPrimaryButton)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void CreateRoom(string CurrentMap)
        {
            ExitGames.Client.Photon.Hashtable customRoomProperties = new ExitGames.Client.Photon.Hashtable
                    {
                        {
                            "gameMode",
                            CurrentMap + GorillaComputer.instance.currentQueue + GorillaComputer.instance.currentGameMode
                        }
                    };
            PhotonNetwork.CreateRoom(RandomStringPublic(4), new RoomOptions
            {
                IsVisible = true,
                IsOpen = true,
                MaxPlayers = 10,
                CustomRoomProperties = customRoomProperties,
                PublishUserId = true,
                CustomRoomPropertiesForLobby = new string[]
                {
                            "gameMode"
                }
            }, null, null);
        }
        public static void FastFly()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 25;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
        public static void SlowFlyNoClip()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerPrimaryButton)
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 6.5f;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    mesh.enabled = false;
                }
            }
            else
            {
                foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    mesh.enabled = true;
                }
            }
        }
        public static void ProcessTeleportGun()
        {
            if (TundraMain.GunHand == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (input.rightControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.rightControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            teleportGunAntiRepeat = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
            else if (TundraMain.GunHand == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (input.leftControllerGripFloat > 0.1f)
                {
                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (input.leftControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            teleportGunAntiRepeat = true;
                            pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    }
                }
            }
        }
        public static void Checkpoint()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            bool iawd = input.rightControllerIndexFloat > 0.1f;
            if (input.rightGrab)
            {
                if (pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                }
                pointer.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;
            }
            if (input.rightControllerIndexFloat > 0.1f)
            {
                foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    meshCollider.enabled = false;
                }
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = pointer.transform.position;
                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
            }
            if (!iawd)
            {
                foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    meshCollider.enabled = true;
                }
                pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
            }
        }
        public static void SpawnC4()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerGripFloat > 0.1f)
            {
                if (pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    pointer.transform.localScale = new Vector3(0.2f, 0.1f, 0.2f);
                }
                pointer.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;
            }
            if (input.rightControllerIndexFloat > 0.1f)
            {
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(20000, pointer.transform.position, 10, 10);
                Object.Destroy(pointer);
            }
        }
        public static void NoClip()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            if (input.rightControllerIndexFloat > 0.1f)
            {
                foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    mesh.enabled = false;
                }
            }
            else
            {
                foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    mesh.enabled = true;
                }
            }
        }
        public static void SlingShot()
        {
            CosmeticsController instance = CosmeticsController.instance;
            CosmeticsController.CosmeticItem itemFromDict = instance.GetItemFromDict("Slingshot");
            instance.ApplyCosmeticItemToSet(GorillaTagger.Instance.offlineVRRig.cosmeticSet, itemFromDict, true, false);
        }
        public static void Plats()
        {
            if (TundraMain.PlatInput == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                List<InputDevice> leftList = new List<InputDevice>();
                List<InputDevice> rightList = new List<InputDevice>();
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Left | InputDeviceCharacteristics.Controller, leftList);
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Right | InputDeviceCharacteristics.Controller, rightList);
                leftList[0].TryGetFeatureValue(CommonUsages.gripButton, out LeftPlatformInput);
                rightList[0].TryGetFeatureValue(CommonUsages.gripButton, out RightPlatformInput);
                LeftPlatformInput = input.leftControllerGripFloat > 0.1f;
                RightPlatformInput = input.rightControllerGripFloat > 0.1f;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    //thick going down  //thick wideness //thick length forward backward
                    LeftPlatform.transform.position = new Vector3(0f, -0.00825f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                    LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    RightPlatform.transform.position = new Vector3(0f, -0.00825f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                    RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    RightPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
            else if (TundraMain.PlatInput == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                List<InputDevice> leftList = new List<InputDevice>();
                List<InputDevice> rightList = new List<InputDevice>();
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Left | InputDeviceCharacteristics.Controller, leftList);
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Right | InputDeviceCharacteristics.Controller, rightList);
                leftList[0].TryGetFeatureValue(CommonUsages.gripButton, out LeftPlatformInput);
                rightList[0].TryGetFeatureValue(CommonUsages.gripButton, out RightPlatformInput);
                LeftPlatformInput = input.leftControllerIndexFloat > 0.1f;
                RightPlatformInput = input.rightControllerIndexFloat > 0.1f;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    //thick going down  //thick wideness //thick length forward backward
                    LeftPlatform.transform.position = new Vector3(0f, -0.00825f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                    LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    RightPlatform.transform.position = new Vector3(0f, -0.00825f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                    RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    RightPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
        }
        public static void StickyPlats()
        {
            if (TundraMain.PlatInput == 1)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                List<InputDevice> leftList = new List<InputDevice>();
                List<InputDevice> rightList = new List<InputDevice>();
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Left | InputDeviceCharacteristics.Controller, leftList);
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Right | InputDeviceCharacteristics.Controller, rightList);
                leftList[0].TryGetFeatureValue(CommonUsages.gripButton, out LeftPlatformInput);
                rightList[0].TryGetFeatureValue(CommonUsages.gripButton, out RightPlatformInput);
                LeftPlatformInput = input.leftControllerGripFloat > 0.1f;
                RightPlatformInput = input.rightControllerGripFloat > 0.1f;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    //thick going down  //thick wideness //thick length forward backward
                    LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                    LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                    RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    RightPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
            else if (TundraMain.PlatInput == 2)
            {
                input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
                List<InputDevice> leftList = new List<InputDevice>();
                List<InputDevice> rightList = new List<InputDevice>();
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Left | InputDeviceCharacteristics.Controller, leftList);
                InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Right | InputDeviceCharacteristics.Controller, rightList);
                leftList[0].TryGetFeatureValue(CommonUsages.gripButton, out LeftPlatformInput);
                rightList[0].TryGetFeatureValue(CommonUsages.gripButton, out RightPlatformInput);
                LeftPlatformInput = input.leftControllerIndexFloat > 0.1f;
                RightPlatformInput = input.rightControllerIndexFloat > 0.1f;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    //thick going down  //thick wideness //thick length forward backward
                    LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                    LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                    RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    RightPlatform.GetComponent<Renderer>().material = ColorManager.CustomColorScheme;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
        }
        public static void FPSBoost()
        {
            if (TundraMain.FPSType == 1)
            {
                QualitySettings.globalTextureMipmapLimit = 1;
            }
            else if (TundraMain.FPSType == 2)
            {
                QualitySettings.globalTextureMipmapLimit = 2;
            }
            else if (TundraMain.FPSType == 3)
            {
                QualitySettings.globalTextureMipmapLimit = 3;
            }
            else if (TundraMain.FPSType == 4)
            {
                QualitySettings.globalTextureMipmapLimit = 4;
            }
            else if (TundraMain.FPSType == 5)
            {
                QualitySettings.globalTextureMipmapLimit = 5;
            }
            else if (TundraMain.FPSType == 6)
            {
                QualitySettings.globalTextureMipmapLimit = 6;
            }
            else if (TundraMain.FPSType == 7)
            {
                QualitySettings.globalTextureMipmapLimit = 7;
            }
            else if (TundraMain.FPSType == 8)
            {
                QualitySettings.globalTextureMipmapLimit = 8;
            }
            else if (TundraMain.FPSType == 9)
            {
                QualitySettings.globalTextureMipmapLimit = 9;
            }
        }
        public static void Hertz45()
        {
            Thread.Sleep(10);
        }
        public static void JRP()
        {
            PhotonNetwork.JoinRandomRoom();
        }
    }
}