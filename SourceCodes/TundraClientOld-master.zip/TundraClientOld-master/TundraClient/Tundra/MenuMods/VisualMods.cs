﻿using Photon.Pun;
using System.Linq;
using TundraMenu;
using UnityEngine;
using HarmonyLib;
using GTAG_NotificationLib;


namespace Tundra.MenuMods
{
    internal class VisualMods
    {
        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        static float smth = 0;
        public static void BoneESP()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (TundraMain.ESPType == 1)
                {
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && vrrig.mainSkin.material.name.Contains("infected"))    //IF THEY ARE TAGGED
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.45f), new Color(1f, 0f, 0.7f, 0.45f), Mathf.PingPong(Time.time, 1));

                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                        }

                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material = material;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                        for (int i = 0; i < TundraMain.bones.Count(); i += 2)
                        {
                            if (!vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>())
                            {
                                vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.AddComponent<LineRenderer>();
                            }
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().material = material;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[TundraMain.bones[i]].position);
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[TundraMain.bones[i + 1]].position);
                        }
                    }
                    else if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && !vrrig.mainSkin.material.name.Contains("infected"))      //IF THEY ARE NOT TAGGED
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        material.color = material.color = Color.Lerp(new Color(0f, 0.7f, 0f, 0.45f), new Color(0f, 1, 0.77f, 0.45f), Mathf.PingPong(Time.time, 1));

                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                        }

                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material = material;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                        for (int i = 0; i < TundraMain.bones.Count(); i += 2)
                        {
                            if (!vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>())
                            {
                                vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.AddComponent<LineRenderer>();
                            }
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().material = material;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[TundraMain.bones[i]].position);
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[TundraMain.bones[i + 1]].position);
                        }
                    }
                }
                else if (TundraMain.ESPType == 2)
                {
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)    //THIS IS RAINBOW
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        material.color = Color.HSVToRGB(smth, 0.4f, 1);
                        smth += 0.0009f;
                        if (smth >= 1f)
                        {
                            smth = 0f;
                        }

                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                        }

                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material = material;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                        for (int i = 0; i < TundraMain.bones.Count(); i += 2)
                        {
                            if (!vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>())
                            {
                                vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.AddComponent<LineRenderer>();
                            }
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().material = material;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[TundraMain.bones[i]].position);
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[TundraMain.bones[i + 1]].position);
                        }
                    }
                }
                else if (TundraMain.ESPType == 3)
                {
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)    //THIS IS PLAYER COLOR
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), Mathf.PingPong(Time.time, 1));

                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                        }

                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material = material;
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                        for (int i = 0; i < TundraMain.bones.Count(); i += 2)
                        {
                            if (!vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>())
                            {
                                vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.AddComponent<LineRenderer>();
                            }
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().material = material;
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[TundraMain.bones[i]].position);
                            vrrig.mainSkin.bones[TundraMain.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[TundraMain.bones[i + 1]].position);
                        }
                    }
                }
            }
        }
        public static void Tracers()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (TundraMain.ESPType == 1)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.35f), new Color(1f, 0f, 0.7f, 0.35f), Mathf.PingPong(Time.time, 1));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                    }
                    else if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && !vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 0.7f, 0f, 0.35f), new Color(0f, 1, 0.77f, 0.35f), Mathf.PingPong(Time.time, 1));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                    }
                }
                else if (TundraMain.ESPType == 2)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.HSVToRGB(smth, 0.4f, 1);
                        smth += 0.0009f;
                        if (smth >= 1f)
                        {
                            smth = 0f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                    }
                }
                else if (TundraMain.ESPType == 3)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.35f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.35f), Mathf.PingPong(Time.time, 1));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                    }
                }
            }
        }
        public static void Chams()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (TundraMain.ESPType == 1)
                {
                    for (int i = 0; i < GorillaParent.instance.vrrigs.Count; i++)
                    {
                        if (GorillaParent.instance.vrrigs[i].mainSkin.material.name.Contains("fected") && !GorillaParent.instance.vrrigs[i].isMyPlayer && !GorillaParent.instance.vrrigs[i].isOfflineVRRig)
                        {
                            Material wdaw = new Material(Shader.Find("GUI/Text Shader"));
                            GorillaParent.instance.vrrigs[i].mainSkin.material = wdaw;
                            wdaw.color = Color.Lerp(new Color(1f, 0f, 0f, 0.35f), new Color(1f, 0f, 0.357f, 0.35f), Mathf.PingPong(Time.time, 1));
                        }
                        else if (!GorillaParent.instance.vrrigs[i].mainSkin.material.name.Contains("fected") && !GorillaParent.instance.vrrigs[i].isMyPlayer && !GorillaParent.instance.vrrigs[i].isOfflineVRRig)
                        {
                            Material wdaww = new Material(Shader.Find("GUI/Text Shader"));
                            GorillaParent.instance.vrrigs[i].mainSkin.material = wdaww;
                            wdaww.color = Color.Lerp(new Color(0f, 1f, 0f, 0.35f), new Color(0f, 1f, 0.796f, 0.35f), Mathf.PingPong(Time.time, 1));
                        }
                    }
                }
                else if (TundraMain.ESPType == 2)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)  //RGB
                    {
                        Material mats = new Material(Shader.Find("GUI/Text Shader"));
                        vrrig.mainSkin.material = mats;
                        mats.color = Color.HSVToRGB(smth, 0.4f, 1, false);
                        smth += 0.0009f;
                        if (smth >= 1f)
                        {
                            smth = 0f;
                        }
                    }
                }
                else if (TundraMain.ESPType == 3)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)  //PLAYER COLOR
                    {
                        Material mats = new Material(Shader.Find("GUI/Text Shader"));
                        vrrig.mainSkin.material = mats;
                        mats.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), Mathf.PingPong(Time.time, 1));
                    }
                }
            }
        }
        public static void Beaons()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (TundraMain.ESPType == 1)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        Material swastika = new Material(Shader.Find("GUI/Text Shader"));
                        swastika.color = Color.Lerp(new Color(1f, 0f, 0f, 0.35f), new Color(1f, 0f, 0.7f, 0.35f), Mathf.PingPong(Time.time, 1));
                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                        Beacon.GetComponent<Renderer>().material = swastika;
                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                        Object.Destroy(Beacon, Time.deltaTime);
                    }
                    else if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && !vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        Material swastika = new Material(Shader.Find("GUI/Text Shader"));
                        swastika.color = Color.Lerp(new Color(0f, 0.7f, 0f, 0.35f), new Color(0f, 1, 0.77f, 0.35f), Mathf.PingPong(Time.time, 1));
                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                        Beacon.GetComponent<Renderer>().material = swastika;
                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                        Object.Destroy(Beacon, Time.deltaTime);
                    }
                }
                else if (TundraMain.ESPType == 2)
                {
                    Material swastika = new Material(Shader.Find("GUI/Text Shader"));
                    swastika.color = Color.HSVToRGB(smth, 0.4f, 1);
                    smth += 0.0009f;
                    if (smth >= 1f)
                    {
                        smth = 0f;
                    }
                    GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    Beacon.GetComponent<Renderer>().material = swastika;
                    Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                    Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                    GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                    GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                    GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                    GameObject.Destroy(Beacon.GetComponent<Collider>());
                    Object.Destroy(Beacon, Time.deltaTime);
                }
                else if (TundraMain.ESPType == 3)
                {
                    Material swastika = new Material(Shader.Find("GUI/Text Shader"));
                    swastika.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), Mathf.PingPong(Time.time, 1));
                    GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    Beacon.GetComponent<Renderer>().material = swastika;
                    Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                    Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                    GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                    GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                    GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                    GameObject.Destroy(Beacon.GetComponent<Collider>());
                    Object.Destroy(Beacon, Time.deltaTime);
                }
            }            
        }
        public static void CSGO_ESP()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (TundraMain.ESPType == 1)
                {
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.45f), new Color(1f, 0f, 0.7f, 0.45f), Mathf.PingPong(Time.time, 1));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject Box = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        Box.transform.position = vrrig.transform.position;
                        Box.GetComponent<Renderer>().material = material;
                        Box.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.45f), new Color(1f, 0f, 0.7f, 0.45f), Mathf.PingPong(Time.time, 1));
                        GameObject.Destroy(Box.GetComponent<BoxCollider>());
                        GameObject.Destroy(Box.GetComponent<Rigidbody>());
                        GameObject.Destroy(Box.GetComponent<MeshCollider>());
                        GameObject.Destroy(Box.GetComponent<Collider>());
                        Box.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                        Object.Destroy(Box, Time.deltaTime);
                    }
                    else if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && !vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 0.7f, 0f, 0.45f), new Color(0f, 1, 0.77f, 0.45f), Mathf.PingPong(Time.time, 1));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject Box = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        Box.transform.position = vrrig.transform.position;
                        Box.GetComponent<Renderer>().material = material;
                        Box.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 0.7f, 0f, 0.45f), new Color(0f, 1, 0.77f, 0.45f), Mathf.PingPong(Time.time, 1));
                        GameObject.Destroy(Box.GetComponent<BoxCollider>());
                        GameObject.Destroy(Box.GetComponent<Rigidbody>());
                        GameObject.Destroy(Box.GetComponent<MeshCollider>());
                        GameObject.Destroy(Box.GetComponent<Collider>());
                        Box.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                        Object.Destroy(Box, Time.deltaTime);
                    }
                }
                else if (TundraMain.ESPType == 2)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)   //they are tagged
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.HSVToRGB(smth, 0.4f, 1);
                        smth += 0.0009f;
                        if (smth >= 1f)
                        {
                            smth = 0f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject Box = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        Box.transform.position = vrrig.transform.position;
                        Box.GetComponent<Renderer>().material = material;
                        Box.GetComponent<Renderer>().material.color = Color.HSVToRGB(smth, 0.4f, 1);
                        smth += 0.0009f;
                        if (smth >= 1f)
                        {
                            smth = 0f;
                        }
                        GameObject.Destroy(Box.GetComponent<BoxCollider>());
                        GameObject.Destroy(Box.GetComponent<Rigidbody>());
                        GameObject.Destroy(Box.GetComponent<MeshCollider>());
                        GameObject.Destroy(Box.GetComponent<Collider>());
                        Box.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                        Object.Destroy(Box, Time.deltaTime);
                    }
                }
                else if (TundraMain.ESPType == 3)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)   //they are tagged
                    {
                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                        {
                            vrrig.gameObject.AddComponent<LineRenderer>();
                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                        }
                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), Mathf.PingPong(Time.time, 1));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject Box = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        Box.transform.position = vrrig.transform.position;
                        Box.GetComponent<Renderer>().material = material;
                        Box.GetComponent<Renderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), Mathf.PingPong(Time.time, 1));
                        GameObject.Destroy(Box.GetComponent<BoxCollider>());
                        GameObject.Destroy(Box.GetComponent<Rigidbody>());
                        GameObject.Destroy(Box.GetComponent<MeshCollider>());
                        GameObject.Destroy(Box.GetComponent<Collider>());
                        Box.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                        Object.Destroy(Box, Time.deltaTime);
                    }
                }
            }
        }
        public static void Head_Dot_ESP()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (TundraMain.ESPType == 1)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject ball = GameObject.CreatePrimitive(0);
                        ball.transform.position = vrrig.transform.position + new Vector3(0, 1.25f, 0);
                        ball.GetComponent<Renderer>().material = material;
                        ball.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.45f), new Color(1f, 0f, 0.7f, 0.45f), Mathf.PingPong(Time.time, 1));
                        GameObject.Destroy(ball.GetComponent<BoxCollider>());
                        GameObject.Destroy(ball.GetComponent<Rigidbody>());
                        GameObject.Destroy(ball.GetComponent<MeshCollider>());
                        GameObject.Destroy(ball.GetComponent<Collider>());
                        ball.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                        Object.Destroy(ball, Time.deltaTime);
                    }
                    else if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig && !vrrig.mainSkin.material.name.Contains("infected"))
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject ball = GameObject.CreatePrimitive(0);
                        ball.transform.position = vrrig.transform.position + new Vector3(0, 1.25f, 0);
                        ball.GetComponent<Renderer>().material = material;
                        ball.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 0.7f, 0f, 0.45f), new Color(0f, 1, 0.77f, 0.45f), Mathf.PingPong(Time.time, 1));
                        GameObject.Destroy(ball.GetComponent<BoxCollider>());
                        GameObject.Destroy(ball.GetComponent<Rigidbody>());
                        GameObject.Destroy(ball.GetComponent<MeshCollider>());
                        GameObject.Destroy(ball.GetComponent<Collider>());
                        ball.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                        Object.Destroy(ball, Time.deltaTime);
                    }
                }
                else if (TundraMain.ESPType == 2)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject ball = GameObject.CreatePrimitive(0);
                        ball.transform.position = vrrig.transform.position + new Vector3(0, 1.25f, 0);
                        ball.GetComponent<Renderer>().material = material;
                        ball.GetComponent<Renderer>().material.color = Color.HSVToRGB(smth, 0.4f, 1, false);
                        smth += 0.0009f;
                        if (smth >= 1f)
                        {
                            smth = 0f;
                        }
                        GameObject.Destroy(ball.GetComponent<BoxCollider>());
                        GameObject.Destroy(ball.GetComponent<Rigidbody>());
                        GameObject.Destroy(ball.GetComponent<MeshCollider>());
                        GameObject.Destroy(ball.GetComponent<Collider>());
                        ball.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                        Object.Destroy(ball, Time.deltaTime);
                    }
                }
                else if (TundraMain.ESPType == 3)
                {
                    if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        Material material = new Material(Shader.Find("GUI/Text Shader"));
                        GameObject ball = GameObject.CreatePrimitive(0);
                        ball.transform.position = vrrig.transform.position + new Vector3(0, 1.25f, 0);
                        ball.GetComponent<Renderer>().material = material;
                        ball.GetComponent<Renderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.45f), Mathf.PingPong(Time.time, 1));
                        GameObject.Destroy(ball.GetComponent<BoxCollider>());
                        GameObject.Destroy(ball.GetComponent<Rigidbody>());
                        GameObject.Destroy(ball.GetComponent<MeshCollider>());
                        GameObject.Destroy(ball.GetComponent<Collider>());
                        ball.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                        Object.Destroy(ball, Time.deltaTime);
                    }
                }
            }
        }
        public static void HuntTargetESP()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (GorillaGameManager.instance.FindPlayerVRRig(GameObject.Find("Gorilla Hunt Manager(Clone)").GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                {
                    vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                    vrrig.mainSkin.material.color = Color.red;
                }
            }
        }
        public static void TundraUserESP()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                Photon.Realtime.Player players = rig2view(vrrig.GetComponentInParent<VRRig>()).Owner;
                if (players.CustomProperties["mods"].ToString().Contains("shiba") && !vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                {
                    Material material = new Material(Shader.Find("GUI/Text Shader"));
                    vrrig.mainSkin.material = material;
                    material.color = Color.Lerp(new Color(1f, 0.357f, 1f, 0.45f), new Color(1f, 1f, 1f, 0.45f), Mathf.PingPong(Time.time, 1f));
                }
                else
                {
                    NotifiLib.SendWithCooldown("<color=blue>NO SHIBA USERS IN LOBBY</color>", 8f);
                }
            }
        }
    }
}