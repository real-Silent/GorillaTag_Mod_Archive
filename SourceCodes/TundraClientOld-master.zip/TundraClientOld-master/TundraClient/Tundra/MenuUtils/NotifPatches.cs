﻿using GTAG_NotificationLib;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
namespace MenuUtils
{
    [HarmonyPatch(typeof(GorillaNot), "SendReport")]
    internal class GorillaNotAntiCheatReports : MonoBehaviourPunCallbacks
    {
        public static bool Prefix(string susReason, string susId, string susNick)
        {
            if (susId == PhotonNetwork.LocalPlayer.UserId)
            {
                NotifiLib.SendWithCooldown($"<color=blue>[ANTI-CHEAT]</color> REPORT FOR: <color=yellow>{susReason}</color>", 3);
            }
            return false;
        }
    }




    [HarmonyPatch(typeof(GorillaPlayerScoreboardLine), "ReportPlayer")]
    internal class BoardReports : MonoBehaviourPunCallbacks
    {
        public static bool Prefix(string PlayerID, GorillaPlayerLineButton.ButtonType buttonType, string OtherPlayerNickName)
        {
            if (OtherPlayerNickName == PhotonNetwork.LocalPlayer.NickName)
            {
                NotifiLib.SendWithCooldown($"YOU GOT BOARD REPORTED FOR <color=red>[{buttonType}]</color>", 3);
            }
            return false;
        }
    }





    [HarmonyPatch(typeof(GorillaNot), "OnPlayerEnteredRoom")]
    internal class newPeeps : MonoBehaviourPunCallbacks 
    {
        public static bool Prefix(Player newPlayer)
        {
            if (newPlayer != null && newPlayer != PhotonNetwork.LocalPlayer)
            {
                NotifiLib.SendNotification($"<color=green>[{newPlayer.NickName}]</color> HAS CONNECTED TO THE SERVER");
            }
            return false;
        }
    }



    [HarmonyPatch(typeof(RequestableOwnershipGuard), "OnMasterClientSwitched")]
    internal class LOLS : MonoBehaviourPunCallbacks
    {
        public static bool Prefix(Player newMasterClient)
        {
            if (newMasterClient != null && newMasterClient != PhotonNetwork.LocalPlayer)
            {
                NotifiLib.SendWithCooldown($"<color=yellow>[{newMasterClient.NickName}]</color> IS NOW MASTERCLIENT", 4);
            }
            else if (newMasterClient != null && newMasterClient == PhotonNetwork.LocalPlayer)
            {
                NotifiLib.SendWithCooldown("<color=orange>YOU ARE NOW MASTERCLIENT</color>", 4);
            }
            return false;
        }
    }




    [HarmonyPatch(typeof(GorillaNot), "OnPlayerLeftRoom")]
    internal class awdwdw : MonoBehaviourPunCallbacks
    {
        public static bool Prefix(Player otherPlayer)
        {
            if (otherPlayer != null && otherPlayer != PhotonNetwork.LocalPlayer)
            {
                NotifiLib.SendNotification($"<color=red>[{otherPlayer.NickName}]</color> HAS LEFT THE SERVER");
            }
            return false;
        }
    }
}