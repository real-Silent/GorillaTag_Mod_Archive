﻿using TundraMenu;
using UnityEngine;

namespace Tundra.ColorManagement
{
    internal class ColorManager
    {
        public static float smth = 0f;
        public static float MenuR = 31f / 255f;       //Else Statemtn for buttons
        public static float MenuG = 31f / 255f;
        public static float MenuB = 31f / 255f;
        public static float MenuA = 0.85f;

        public static float ButtonR = 0f / 255f;          //Button off Color
        public static float ButtonG = 0f / 255f;
        public static float ButtonB = 0f / 255f;

        public static float ButtonOnR = 255f / 255f;    //buttons on colors
        public static float ButtonOnG = 250f / 255f;
        public static float ButtonOnB = 255f / 255f;

        public static float ButtonTextR = 250f / 255f;   //button off text color
        public static float ButtonTextG = 250f / 255f;
        public static float ButtonTextB = 250f / 255f;
         
        public static float ButtonOnTextR = 0f / 255f;
        public static float ButtonOnTextG = 0f / 255f;     //button on text color
        public static float ButtonOnTextB = 0f / 255f;

        public static float TitleR = 255f / 255f;
        public static float TitleG = 255f / 255f;          //titles of main buttons colors
        public static float TitleB = 255f / 255f;

        public static float CustomButtonTextColorR = 255f / 255f;
        public static float CustomButtonTextColorG = 255f / 255f;
        public static float CustomButtonTextColorB = 255f / 255f;
        public static Material CustomColorScheme = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material OnTriggerGuns = new Material(Shader.Find("GUI/Text Shader"));

        public static void OnTriggeredGuns()
        {
            OnTriggerGuns.color = Color.Lerp(new Color(0f, 0f, 0f, 1f), new Color(1f, 1f, 1f, 1f), Mathf.PingPong(Time.time, 1f));
        }

        public static void TundraColoScheme()
        {
            if (TundraMain.ColorScheme == 1)
            {
                CustomColorScheme.color = Color.black;
            }
            else if (TundraMain.ColorScheme == 2)
            {
                CustomColorScheme.color = Color.white;
            }
            else if (TundraMain.ColorScheme == 3)
            {
                CustomColorScheme.color = Color.gray;
            }
            else if (TundraMain.ColorScheme == 4)
            {
                CustomColorScheme.color = new Color(1f, 0f, 1f, 1f); //PINK
            }
            else if (TundraMain.ColorScheme == 5)
            {
                CustomColorScheme.color = Color.red;
            }
            else if (TundraMain.ColorScheme == 6)
            {
                CustomColorScheme.color = new Color(1f, 0.459f, 0f, 1f); //ORANGE
            }
            else if (TundraMain.ColorScheme == 7)
            {
                CustomColorScheme.color = Color.yellow;
            }
            else if (TundraMain.ColorScheme == 8)
            {
                CustomColorScheme.color = Color.green;
            }
            else if (TundraMain.ColorScheme == 9)
            {
                CustomColorScheme.color = new Color(0f, 1f, 0.784f, 1f); //MINT
            }
            else if (TundraMain.ColorScheme == 10)
            {
                CustomColorScheme.color = Color.blue;
            }
            else if (TundraMain.ColorScheme == 11)
            {
                CustomColorScheme.color = new Color(0.341f, 0f, 1f, 1f); //PURPLE
            }
            else if (TundraMain.ColorScheme == 12)
            {
                CustomColorScheme.color = Color.Lerp(new Color(0.1f, 0f, 0.5f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f)); //MAGENTA AND BLACK
            }
            else if (TundraMain.ColorScheme == 13) 
            {
                CustomColorScheme.color = Color.Lerp(new Color(1f, 0f, 0f, 1f), new Color(1f, 0f, 1f, 1f), Mathf.PingPong(Time.time, 1f)); //RED AND PINIK
            }
            else if (TundraMain.ColorScheme == 14)
            {
                CustomColorScheme.color = Color.Lerp(new Color(0.298f, 0f, 1f, 1f), new Color(1f, 0.5f, 0f, 1f), Mathf.PingPong(Time.time, 1f)); //PURPLE AND ORANGE
            }
            else if (TundraMain.ColorScheme == 15)
            {
                CustomColorScheme.color = Color.Lerp(new Color(1f, 1f, 0f, 1f), new Color(0f, 0f, 1f, 1f), Mathf.PingPong(Time.time, 1f)); //YELLOW AND BLUE
            }
            else if (TundraMain.ColorScheme == 16)
            {
                CustomColorScheme.color = Color.Lerp(new Color(0.298f, 0f, 1f, 1f), new Color(1f, 0.8f, 0.922f, 1f), Mathf.PingPong(Time.time, 1f)); //PURPLE AND SALMON
            }
            else if (TundraMain.ColorScheme == 17)
            {
                CustomColorScheme.color = Color.Lerp(new Color(0f, 0f, 0f, 1f), new Color(1f, 0.5f, 0f, 1f), Mathf.PingPong(Time.time, 1f)); //BLACK AND ORANGE
            }
            else if (TundraMain.ColorScheme == 18)
            {
                CustomColorScheme.color = Color.Lerp(new Color(0f, 1f, 0.769f, 1f), new Color(1f, 0.5f, 0.922f, 1f), Mathf.PingPong(Time.time, 1f)); //MINT AND SALMON
            }
            else if (TundraMain.ColorScheme == 19)
            {
                CustomColorScheme.color = Color.HSVToRGB(smth, 1f, 1f);
                smth += 0.006f;
                if (smth >= 1f)
                {
                    smth = 0f;
                } //RGB
            }
            else if (TundraMain.ColorScheme == 20)
            {
                CustomColorScheme = GorillaTagger.Instance.offlineVRRig.mainSkin.material;
            }
        }
    }
}
