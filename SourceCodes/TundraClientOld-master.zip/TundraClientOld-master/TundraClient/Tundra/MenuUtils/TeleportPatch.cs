﻿using HarmonyLib;
using UnityEngine;

namespace MenuUtils
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("AntiTeleportTechnology", 0)]
    internal class BypassTP : MonoBehaviour
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
