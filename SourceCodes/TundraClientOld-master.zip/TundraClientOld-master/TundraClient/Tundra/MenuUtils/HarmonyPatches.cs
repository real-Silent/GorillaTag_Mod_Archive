﻿using System.Reflection;
using BepInEx;
using HarmonyLib;
namespace MenuUtils
{
    [BepInPlugin(guid, title, version)]
    public class Plugin : BaseUnityPlugin
    {
        private const string guid = "TundraV5";
        private const string title = "TundraV5";
        private const string version = "0.0.0";

        public void Start()
        {
            Harmony harmony = new Harmony(guid);
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
    }
}