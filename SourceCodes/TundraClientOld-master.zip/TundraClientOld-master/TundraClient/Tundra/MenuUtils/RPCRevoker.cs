﻿using Photon.Pun;
using UnityEngine;

namespace MenuUtils
{
    class TundraUtils : MonoBehaviour
    {
        static float Revoke;
        static float Delay = 0.1f;
        public static void Update()
        {
            if (Time.time > Revoke + Delay)
            {
                PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
                PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig);
                PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, null, null);
                GorillaNot.instance.rpcCallLimit = 999999;
                PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
                PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
                PhotonNetwork.RemoveBufferedRPCs(999999);
                PhotonNetwork.SendAllOutgoingCommands();
                GorillaGameManager.instance.maxProjectilesToKeepTrackOfPerPlayer = int.MaxValue;
                GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
                Revoke = Time.time;
            }
        }
    }
}