﻿using BepInEx;
using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using HarmonyLib;

namespace GTAG_NotificationLib
{
    [BepInPlugin("HabibiLars.NotificationLib", "NotificationLib", "1.0")]
    public class NotifiLib : BaseUnityPlugin
    {
        static GameObject MainCamera;
        static GameObject HUDObj;
        static GameObject HUDObj2;
        static Text Testtext;
        static Material AlertText = new Material(Shader.Find("GUI/Text Shader"));
        static int NotificationDecayTime = 150;
        static int NotificationDecayTimeCounter = 0;
        public static int NoticationThreshold = 10; //Amount of notifications before they stop queuing up
        static string[] Notifilines;
        static string newtext;
        public static string PreviousNotifi;
        static bool HasInit = false;
        static Text NotifiText;
        public static bool IsEnabled = true;
        static float smth = 0f;
        private void Awake()
        {
            // Plugin startup logic
            Logger.LogInfo($"NotifLib Successfully Loaded");
            Harmony.CreateAndPatchAll(typeof(NotifiLib));
        }
        private static void Init()
        {
            //this is mostly copy pasted from LHAX, which was also made by me.
            //LHAX got leaked the day before this. so i might as well make this public cus people asked me to.
            MainCamera = GameObject.Find("Main Camera");
            HUDObj = new GameObject();//GameObject.CreatePrimitive(PrimitiveType.Cube);
            HUDObj2 = new GameObject();
            HUDObj2.name = "NOTIFICATIONLIB_HUD_OBJ";
            HUDObj.name = "NOTIFICATIONLIB_HUD_OBJ";
            HUDObj.AddComponent<Canvas>();
            HUDObj.AddComponent<CanvasScaler>();
            HUDObj.AddComponent<GraphicRaycaster>();
            HUDObj.GetComponent<Canvas>().enabled = true;
            HUDObj.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            HUDObj.GetComponent<Canvas>().worldCamera = MainCamera.GetComponent<Camera>();
            HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5, 5);
            //HUDObj.CreatePrimitive()
            HUDObj.GetComponent<RectTransform>().position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);//new Vector3(-67.151f, 11.914f, -82.749f);
            HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z - 4.6f);
            HUDObj.transform.parent = HUDObj2.transform;
            HUDObj.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
            var Temp = HUDObj.GetComponent<RectTransform>().rotation.eulerAngles;
            Temp.y = -270f;
            HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
            HUDObj.GetComponent<RectTransform>().rotation = Quaternion.Euler(Temp);
            GameObject TestText = new GameObject();
            TestText.transform.parent = HUDObj.transform;
            Testtext = TestText.AddComponent<Text>();
            Testtext.text = "";
            Testtext.fontSize = 10;
            Testtext.font = GameObject.Find("COC Text").GetComponent<Text>().font;
            Testtext.rectTransform.sizeDelta = new Vector2(260, 70);
            Testtext.alignment = TextAnchor.LowerCenter;
            Testtext.rectTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
            Testtext.rectTransform.localPosition = new Vector3(-1.5f, -.9f, -.6f);
            Testtext.material = AlertText;
            NotifiText = Testtext;
        }

        private static void FixedUpdate()
        {
            //This is a bad way to do this, but i do not want to rely on utila.
            if (HasInit == false)
            {
                if (GameObject.Find("Main Camera") != null)
                {
                    Init();
                    HasInit = true;
                }
            }
            HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
            HUDObj2.transform.rotation = MainCamera.transform.rotation;
            //HUDObj.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
            if (Testtext.text != "") //THIS CAUSES A MEMORY LEAK!!!!! -no longer causes a memory leak
            {
                NotificationDecayTimeCounter++;
                if (NotificationDecayTimeCounter > NotificationDecayTime)
                {
                    Notifilines = null;
                    newtext = "";
                    NotificationDecayTimeCounter = 0;
                    Notifilines = Testtext.text.Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();
                    foreach (string Line in Notifilines)
                    {
                        if (Line != "")
                        {
                            newtext = newtext + Line + "\n";
                        }
                    }

                    Testtext.text = newtext;
                }
            }
            else
            {
                NotificationDecayTimeCounter = 0;
            }
        }

        public static void SendNotification(string NotificationText)
        {
            if (IsEnabled)
            {
                if (!NotificationText.Contains(Environment.NewLine))
                {
                    NotificationText = NotificationText + Environment.NewLine;
                }
                NotifiText.text = NotifiText.text + NotificationText;
                PreviousNotifi = NotificationText;
            }
        }

        public static void SendWithCooldown(string YOURTEXT, float TIMER)
        {
            if (IsEnabled)
            {
                if (smth < Time.time)
                {
                    smth = Time.time + TIMER;
                    if (!YOURTEXT.Contains(Environment.NewLine))
                    {
                        YOURTEXT = YOURTEXT + Environment.NewLine;
                    }
                    NotifiText.text = NotifiText.text + YOURTEXT;
                    PreviousNotifi = YOURTEXT;
                }
            }
        }

        public static void ClearAllNotifications()
        {
            NotifiText.text = "";
        }
        public static void ClearPastNotifications(int amount)
        {
            string[] Notifilines = null;
            string newtext = "";
            Notifilines = NotifiText.text.Split(Environment.NewLine.ToCharArray()).Skip(amount).ToArray();
            foreach (string Line in Notifilines)
            {
                if (Line != "")
                {
                    newtext = newtext + Line + "\n";
                }
            }

            NotifiText.text = newtext;
        }

        //This is probably not the way i should have fixed it, but it "works" (I CANNOT STRESS THIS ENOUGH, DONT DO IT LIKE THIS!)
        #region HackyFixedUpdateFix
        [HarmonyPatch(typeof(GorillaLocomotion.Player), "FixedUpdate")]
        [HarmonyPrefix]
        static bool FixedUpdateHook()
        {
            FixedUpdate();
            return true;
        }
        #endregion
    }
}
