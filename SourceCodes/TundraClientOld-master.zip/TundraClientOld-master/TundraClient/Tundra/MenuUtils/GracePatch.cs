﻿using UnityEngine;
using HarmonyLib;

namespace MenuUtils
{
    [HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
    [HarmonyPatch("GracePeriod", 0)]
    internal class GraceBypass : MonoBehaviour
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}

