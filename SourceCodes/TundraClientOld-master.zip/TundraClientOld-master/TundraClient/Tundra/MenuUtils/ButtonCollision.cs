﻿using HarmonyLib;
using TundraMenu;
using Photon.Pun;
using UnityEngine;

namespace ButtonCollisionHandler
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class ButtonCollision : MonoBehaviour
    {
        public string Identity;
        public void OnTriggerEnter(Collider other)
        {
            if (Time.frameCount > TundraMain.FramePressCooldown + 15)
            {
                if (other == TundraMain.referenceObj.GetComponent<Collider>())
                {
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, false, 0.25f);
                    GorillaTagger.Instance.StartVibration(false, 0.2f, 0.2f);
                    if (Identity == "Disconnect")
                    {
                        PhotonNetwork.Disconnect();
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (Identity == "PrevPage")
                    {
                        TundraMain.pageNumber--;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }

                    if (Identity == "NextPage")
                    {
                        TundraMain.pageNumber++;
                        GameObject.Destroy(TundraMain.MenuObj);
                        TundraMain.MenuObj = null;
                        GameObject.Destroy(TundraMain.canvasPrevObj); TundraMain.canvasPrevObj = null;
                        GameObject.Destroy(TundraMain.canvasDiscObj); TundraMain.canvasDiscObj = null;
                        GameObject.Destroy(TundraMain.canvasNextObj); TundraMain.canvasNextObj = null;
                        TundraMain.DrawMenu();
                        TundraMain.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                        TundraMain.AddCustomButton("PrevPage", 0.1f, false, 0.160f, 0.985f, 0.13f);
                        TundraMain.AddCustomButton("NextPage", 0.1f, false, 0.160f, 0.985f, -0.13f);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 1)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg1, TundraMain.Pg1Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 2)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg2, TundraMain.Pg2Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 3)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg3, TundraMain.Pg3Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 4)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg4, TundraMain.Pg4Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 5)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg5, TundraMain.Pg5Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 6)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg6, TundraMain.Pg6Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 7)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg7, TundraMain.Pg7Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 8)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg8, TundraMain.Pg8Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 9)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg9, TundraMain.Pg9Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 10)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg10, TundraMain.Pg10Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 11)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg11, TundraMain.Pg11Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 12)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg12, TundraMain.Pg12Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 13)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg13, TundraMain.Pg13Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 14)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg14, TundraMain.Pg14Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 15)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg15, TundraMain.Pg15Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 16)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg16, TundraMain.Pg16Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 17)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg17, TundraMain.Pg17Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 18)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg18, TundraMain.Pg18Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 19)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg19, TundraMain.Pg19Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 20)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg20, TundraMain.Pg20Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 21)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg21, TundraMain.Pg21Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 22)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg22, TundraMain.Pg22Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 23)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg23, TundraMain.Pg23Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 24)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg24, TundraMain.Pg24Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 25)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg25, TundraMain.Pg25Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 26)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg26, TundraMain.Pg26Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 27)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg27, TundraMain.Pg27Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 28)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg28, TundraMain.Pg28Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 29)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg29, TundraMain.Pg29Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 30)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg30, TundraMain.Pg30Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 31)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg31, TundraMain.Pg31Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 32)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg32, TundraMain.Pg32Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 33)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg33, TundraMain.Pg33Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 34)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg34, TundraMain.Pg34Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 35)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg35, TundraMain.Pg35Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 36)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg36, TundraMain.Pg36Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 37)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg37, TundraMain.Pg37Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 38)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg38, TundraMain.Pg38Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 39)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg39, TundraMain.Pg39Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 40)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg40, TundraMain.Pg40Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 41)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg41, TundraMain.Pg41Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 42)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg42, TundraMain.Pg42Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 43)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg43, TundraMain.Pg43Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 44)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg44, TundraMain.Pg44Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 45)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg45, TundraMain.Pg45Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 46)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg46, TundraMain.Pg46Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 47)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg47, TundraMain.Pg47Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 48)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg48, TundraMain.Pg48Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 49)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg49, TundraMain.Pg49Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 50)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg50, TundraMain.Pg50Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 51)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg51, TundraMain.Pg51Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 52)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg52, TundraMain.Pg52Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 53)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg53, TundraMain.Pg53Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 54)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg54, TundraMain.Pg54Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 55)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg55, TundraMain.Pg55Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 56)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg56, TundraMain.Pg56Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 57)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg57, TundraMain.Pg57Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 58)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg58, TundraMain.Pg58Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 59)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg59, TundraMain.Pg59Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 60)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg60, TundraMain.Pg60Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 6)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg61, TundraMain.Pg61Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 62)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg62, TundraMain.Pg62Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 63)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg63, TundraMain.Pg63Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 64)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg64, TundraMain.Pg64Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 65)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg65, TundraMain.Pg65Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 66)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg66, TundraMain.Pg66Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 67)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg67, TundraMain.Pg67Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 68)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg68, TundraMain.Pg68Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 69)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg69, TundraMain.Pg69Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 70)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg70, TundraMain.Pg70Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 71)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg71, TundraMain.Pg71Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 72)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg72, TundraMain.Pg72Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 73)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg73, TundraMain.Pg73Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 74)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg74, TundraMain.Pg74Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 75)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg75, TundraMain.Pg75Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 76)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg76, TundraMain.Pg76Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 77)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg77, TundraMain.Pg77Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 78)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg78, TundraMain.Pg78Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 79)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg79, TundraMain.Pg79Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 80)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg80, TundraMain.Pg80Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 81)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg81, TundraMain.Pg81Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 82)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg82, TundraMain.Pg82Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 83)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg83, TundraMain.Pg83Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 84)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg84, TundraMain.Pg84Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 85)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg85, TundraMain.Pg85Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 86)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg86, TundraMain.Pg86Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 87)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg87, TundraMain.Pg87Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 88)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg88, TundraMain.Pg88Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 89)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg89, TundraMain.Pg89Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 90)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg90, TundraMain.Pg90Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 91)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg91, TundraMain.Pg91Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 92)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg92, TundraMain.Pg92Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 93)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg93, TundraMain.Pg93Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 94)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg94, TundraMain.Pg94Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 95)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg95, TundraMain.Pg95Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 96)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg96, TundraMain.Pg96Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 97)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg97, TundraMain.Pg97Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 98)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg98, TundraMain.Pg98Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 99)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg99, TundraMain.Pg99Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 100)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg100, TundraMain.Pg100Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 101)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg101, TundraMain.Pg101Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 102)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg102, TundraMain.Pg102Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 103)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg103, TundraMain.Pg103Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 104)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg104, TundraMain.Pg104Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 105)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg105, TundraMain.Pg105Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 106)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg106, TundraMain.Pg106Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 107)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg107, TundraMain.Pg107Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 108)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg108, TundraMain.Pg108Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 109)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg109, TundraMain.Pg109Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 110)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg110, TundraMain.Pg110Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 111)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg111, TundraMain.Pg111Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 112)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg112, TundraMain.Pg112Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 113)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg113, TundraMain.Pg113Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 114)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg114, TundraMain.Pg114Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 115)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg115, TundraMain.Pg115Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 116)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg116, TundraMain.Pg116Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 117)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg117, TundraMain.Pg117Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 118)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg118, TundraMain.Pg118Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 119)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg119, TundraMain.Pg119Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 120)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg120, TundraMain.Pg120Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 121)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg121, TundraMain.Pg121Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 122)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg122, TundraMain.Pg122Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 123)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg123, TundraMain.Pg123Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 124)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg124, TundraMain.Pg124Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 125)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg125, TundraMain.Pg125Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 126)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg126, TundraMain.Pg126Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 127)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg127, TundraMain.Pg127Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 128)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg128, TundraMain.Pg128Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 129)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg129, TundraMain.Pg129Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 130)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg130, TundraMain.Pg130Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 131)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg131, TundraMain.Pg131Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 132)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg132, TundraMain.Pg132Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 133)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg133, TundraMain.Pg133Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 134)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg134, TundraMain.Pg134Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 135)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg135, TundraMain.Pg135Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 136)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg136, TundraMain.Pg136Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 137)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg137, TundraMain.Pg137Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 138)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg138, TundraMain.Pg138Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 139)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg139, TundraMain.Pg139Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 140)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg140, TundraMain.Pg140Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 141)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg141, TundraMain.Pg141Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 142)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg142, TundraMain.Pg142Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 143)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg143, TundraMain.Pg143Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 144)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg144, TundraMain.Pg144Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 145)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg145, TundraMain.Pg145Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 146)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg146, TundraMain.Pg146Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 147)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg147, TundraMain.Pg147Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 148)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg148, TundraMain.Pg148Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 149)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg149, TundraMain.Pg149Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 150)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg150, TundraMain.Pg150Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 151)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg151, TundraMain.Pg151Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 152)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg152, TundraMain.Pg152Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 153)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg153, TundraMain.Pg153Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 154)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg154, TundraMain.Pg154Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 155)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg155, TundraMain.Pg155Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 156)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg156, TundraMain.Pg156Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 157)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg157, TundraMain.Pg157Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 158)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg158, TundraMain.Pg158Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 159)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg159, TundraMain.Pg159Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 160)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg160, TundraMain.Pg160Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 161)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg161, TundraMain.Pg161Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 162)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg162, TundraMain.Pg162Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 163)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg163, TundraMain.Pg163Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 164)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg164, TundraMain.Pg165Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 165)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg165, TundraMain.Pg165Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 166)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg166, TundraMain.Pg166Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 167)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg167, TundraMain.Pg167Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 168)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg168, TundraMain.Pg168Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 169)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg169, TundraMain.Pg169Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 170)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg170, TundraMain.Pg170Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 171)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg171, TundraMain.Pg171Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 172)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg172, TundraMain.Pg172Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 173)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg173, TundraMain.Pg173Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 174)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg174, TundraMain.Pg174Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 175)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg175, TundraMain.Pg175Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 176)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg176, TundraMain.Pg176Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 177)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg177, TundraMain.Pg177Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 178)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg178, TundraMain.Pg178Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 179)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg179, TundraMain.Pg179Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 180)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg180, TundraMain.Pg180Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 181)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg181, TundraMain.Pg181Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 182)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg182, TundraMain.Pg182Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 183)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg183, TundraMain.Pg183Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 184)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg184, TundraMain.Pg184Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 185)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg185, TundraMain.Pg185Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 186)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg186, TundraMain.Pg186Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 187)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg187, TundraMain.Pg187Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 188)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg188, TundraMain.Pg188Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 189)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg189, TundraMain.Pg189Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 190)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg190, TundraMain.Pg190Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 191)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg191, TundraMain.Pg191Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 192)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg192, TundraMain.Pg192Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                    if (TundraMain.pageNumber == 193)
                    {
                        TundraMain.ToggleButton(Identity, TundraMain.Pg193, TundraMain.Pg193Active);
                        TundraMain.FramePressCooldown = Time.frameCount;
                    }
                }
            }
        }
    }
}