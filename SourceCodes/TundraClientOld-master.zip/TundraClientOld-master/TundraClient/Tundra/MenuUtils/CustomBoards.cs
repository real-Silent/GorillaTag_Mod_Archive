﻿using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;
using Tundra.ColorManagement;

namespace Tundra.Boards
{
    internal class CustomBoards
    {
        public static void Update()
        {
            for (int w = 0; w < GorillaComputer.instance.levelScreens.Length; w++)
            {
                GorillaComputer.instance.levelScreens[w].goodMaterial = ColorManager.CustomColorScheme;
                GorillaComputer.instance.levelScreens[w].badMaterial = ColorManager.CustomColorScheme;
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/StaticUnlit/motdscreen").GetComponent<Renderer>().material = ColorManager.CustomColorScheme;
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/StaticUnlit/screen").GetComponent<Renderer>().material = ColorManager.CustomColorScheme;    //COC Board
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/-- PhysicalComputer UI --/monitor").GetComponent<Renderer>().material = ColorManager.CustomColorScheme;  //MONITOR
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct").GetComponent<Text>().text = "<color=#3700FF>-HELP TUNDRA-</color>";  //COC TOP TEXT
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd").GetComponent<Text>().text = "<color=#09E3B0> - TUNDRA CLIENT V5 - </color>";    //MOTD TOP TEXT
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd/motdtext").GetComponent<Text>().text = "<color=#763BFF>CURRENT ISSUES</color>-\n[-] I BARELY UPDATE ANYTHING\n\n[-] GUN LOCK IS WORK IN PROGRESS\n\n\n\nMADE BY BTC AND REV";

                if (PhotonNetwork.InRoom)
                {
                    GorillaComputer.instance.levelScreens[w].UpdateText($"[-] CURRENT MENU: TUNDRA ADMIN PANEL\n[-] CURRENT NAME: {PhotonNetwork.LocalPlayer.NickName}\n[-] CURRENT PLAYER COUNT: {PhotonNetwork.CurrentRoom.PlayerCount}\n[-] ROOM CODE: {PhotonNetwork.CurrentRoom.Name}", true);
                }
                else if (!PhotonNetwork.InRoom)
                {
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct/COC Text").GetComponent<Text>().text = "YOUR LUCKY TO BE CHOSEN AS A <color=yellow>[TUNDRA PRIVATE]</color> USER";   //COC BOTTOM TEXT

                    GorillaComputer.instance.levelScreens[w].UpdateText($"WELCOME BACK TO THE TUNDRA <color=#03FCA1>[{PhotonNetwork.LocalPlayer.NickName}]</color>\n\n\n\n\nBE GRATEFUL BTC GAVE YOU THIS.", true);
                }
            }
        }
    }
}