﻿using System.Collections.Generic;
using Photon.Pun;
using System.Net;
using UnityEngine;


namespace TundraClient.Tundra.MenuUtils
{
    internal class HashManager
    {
        public static List<Photon.Realtime.Player> adminList = new List<Photon.Realtime.Player>();
        public string url = "https://raw.githubusercontent.com/kingofnetflix/tundragame/main/adminids.txt";

        public void Update()
        {
            using (WebClient client = new WebClient())
            {
                string webPageContent = client.DownloadString(url);
                foreach (Photon.Realtime.Player p in PhotonNetwork.PlayerListOthers)
                {
                    if (webPageContent.Contains(p.UserId))
                    {
                        if (!adminList.Contains(p))
                        {
                            adminList.Add(p);
                        }
                    }
                }
            }
        }

        public static void Manager()
        {
            if (PhotonNetwork.LocalPlayer.CustomProperties.ContainsKey("Tundra") && (bool)PhotonNetwork.LocalPlayer.CustomProperties["Tundra"])
            {
                if (PhotonNetwork.InRoom)
                {
                    foreach (Photon.Realtime.Player p in PhotonNetwork.PlayerListOthers)
                    {
                        VRRig playerZ = GorillaGameManager.instance.FindPlayerVRRig(p);
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, playerZ.transform.position) <= 3)
                        {
                            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f)
                            {
                                GorillaTagger.Instance.offlineVRRig.transform.position = playerZ.rightHandTransform.transform.position;
                            }
                        }
                    }
                }
                else if (!PhotonNetwork.InRoom)
                {
                    PhotonNetwork.LocalPlayer.CustomProperties.Remove("Tundra");
                }
            }
        }
    }
}
 