﻿using BepInEx;
using GorillaExtensions;
using Interstellar.Main;
using Interstellar.Patches;
using Interstellar.Utility;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class VRRigMods : MonoBehaviour
    {
        static Vector3 targetPosition;
        static Quaternion targetRotation;
        public static VRRig closestRig = null;
        public static VRRig vRrig;
        public static VRRig GetClosestRig()
        {
            VRRig bestTarget = null;
            float closestDistanceSqr = Mathf.Infinity;
            Vector3 currentPosition = GorillaTagger.Instance.offlineVRRig.transform.position;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                {
                    Vector3 directionToTarget = vrrig.transform.position - currentPosition;
                    float dSqrToTarget = directionToTarget.sqrMagnitude;
                    if (dSqrToTarget < closestDistanceSqr)
                    {
                        closestDistanceSqr = dSqrToTarget;
                        bestTarget = vrrig;
                    }
                }
            }

            return bestTarget;
        }
        public static void CheckNewRig()
        {
            if (vRrig == null)
            {
                vRrig = Object.Instantiate<VRRig>(GorillaTagger.Instance.offlineVRRig, GorillaLocomotion.Player.Instance.transform.position, GorillaLocomotion.Player.Instance.transform.rotation);
                vRrig.enabled = false;
                vRrig.transform.position = Vector3.zero;
            }
            if (GorillaTagger.Instance.offlineVRRig.enabled == false)
            {
                vRrig.enabled = true;
                Material awd = new Material(Shader.Find("GUI/Text Shader"));
                awd.color = Color.Lerp(new Color(0.333f, 0f, 0.859f, 0.30f), new Color(0.333f, 0f, 0.859f, 0.30f), Mathf.PingPong(Time.time, 1f));
                vRrig.mainSkin.material = awd;
                vRrig.leftHandTransform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                vRrig.rightHandTransform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                vRrig.leftHandTransform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                vRrig.rightHandTransform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                vRrig.transform.position = GorillaLocomotion.Player.Instance.transform.position;
                vRrig.transform.rotation = GorillaLocomotion.Player.Instance.transform.rotation;
                if (!GorillaLocomotion.Player.Instance.IsHandSliding(false) || !GorillaLocomotion.Player.Instance.IsHandSliding(true))
                {
                    GameObject.Find("Player Objects/GorillaParent/Local Gorilla Player(Clone)/VR Constraints/LeftArm/Left Arm IK/SlideAudio").SetActive(false);
                    GameObject.Find("Player Objects/GorillaParent/Local Gorilla Player(Clone)/VR Constraints/RightArm/Right Arm IK/SlideAudio").SetActive(false);
                }
                else if (GorillaLocomotion.Player.Instance.IsHandSliding(false) || GorillaLocomotion.Player.Instance.IsHandSliding(true))
                {
                    GameObject.Find("Player Objects/GorillaParent/Local Gorilla Player(Clone)/VR Constraints/LeftArm/Left Arm IK/SlideAudio").SetActive(true);
                    GameObject.Find("Player Objects/GorillaParent/Local Gorilla Player(Clone)/VR Constraints/RightArm/Right Arm IK/SlideAudio").SetActive(true);
                }
            }
        }

        public static void GhostMonke()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton || UnityInput.Current.GetKey(KeyCode.F))
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }

            if (MenuSrc.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                CheckNewRig();
            }
            else
            {
                vRrig.transform.position = Vector3.zero;
                vRrig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void InvisMonke()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }

            if (MenuSrc.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.zero;
                CheckNewRig();
            }
            else
            {
                vRrig.enabled = false;
                vRrig.transform.position = Vector3.zero;
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void LookAtNearest()
        {
            closestRig = GetClosestRig();
            GorillaTagger.Instance.offlineVRRig.head.rigTarget.LookAt(closestRig.transform.position);
            GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = closestRig.transform.position;
            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = closestRig.transform.position;
            GorillaTagger.Instance.offlineVRRig.transform.LookAt(closestRig.transform.position);
        }
        public static void RigGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    GameObject iuhe = new GameObject("ArchCore");
                    LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                    kmma.material.shader = Shader.Find("GUI/Text Shader");
                    kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    kmma.startWidth = 0.020f;
                    kmma.useWorldSpace = true;
                    kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                    kmma.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(iuhe, Time.deltaTime);


                    GameObject pointer2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer2.GetComponent<Rigidbody>());
                    Object.Destroy(pointer2.GetComponent<SphereCollider>());
                    Object.Destroy(pointer2.GetComponent<MeshCollider>());
                    Object.Destroy(pointer2.GetComponent<Collider>());
                    pointer2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer2.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer2.transform.position = hit.point;
                    Object.Destroy(pointer2, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        CheckNewRig();
                        GorillaTagger.Instance.offlineVRRig.transform.position = hit.point;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.transform.rotation;
                    }
                    else
                    {
                        vRrig.enabled = false;
                        vRrig.transform.position = Vector3.zero;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                else
                {
                    vRrig.enabled = false;
                    vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.leftGrab)
                {
                    GameObject iuhe = new GameObject("ArchCore");
                    LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                    kmma.material.shader = Shader.Find("GUI/Text Shader");
                    kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    kmma.startWidth = 0.020f;
                    kmma.useWorldSpace = true;
                    kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                    kmma.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(iuhe, Time.deltaTime);


                    GameObject pointer2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer2.GetComponent<Rigidbody>());
                    Object.Destroy(pointer2.GetComponent<SphereCollider>());
                    Object.Destroy(pointer2.GetComponent<MeshCollider>());
                    Object.Destroy(pointer2.GetComponent<Collider>());
                    pointer2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer2.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer2.transform.position = hit.point;
                    Object.Destroy(pointer2, Time.deltaTime);
                    if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = hit.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.transform.rotation;
                    }
                    else
                    {
                        vRrig.enabled = false;
                        vRrig.transform.position = Vector3.zero;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                else
                {
                    vRrig.enabled = false;
                    vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            else if (MenuSrc.GunHand == 3)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hitt);
                if ((ControllerInputPoller.instance.leftGrab && ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed) || (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed || ControllerInputPoller.instance.leftGrab))
                {
                    GameObject iuhe = new GameObject("ArchCore");
                    LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                    kmma.material.shader = Shader.Find("GUI/Text Shader");
                    kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    kmma.startWidth = 0.020f;
                    kmma.useWorldSpace = true;
                    kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                    kmma.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(iuhe, Time.deltaTime);


                    GameObject pointer2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer2.GetComponent<Rigidbody>());
                    Object.Destroy(pointer2.GetComponent<SphereCollider>());
                    Object.Destroy(pointer2.GetComponent<MeshCollider>());
                    Object.Destroy(pointer2.GetComponent<Collider>());
                    pointer2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer2.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer2.transform.position = hit.point;
                    Object.Destroy(pointer2, Time.deltaTime);
                    if ((ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f) || (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f))
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = hit.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.transform.rotation;
                    }
                    else
                    {
                        vRrig.enabled = false;
                        vRrig.transform.position = Vector3.zero;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                else
                {
                    vRrig.enabled = false;
                    vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }
        public static void HoldRig()
        {
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                CheckNewRig();
                GorillaTagger.Instance.offlineVRRig.transform.localScale = new Vector3(0.35f, 0.35f, 0.35f);
                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, -0.0045f, 0f) + GorillaTagger.Instance.rightHandTransform.position;
                GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 10f, 0f);
                GorillaTagger.Instance.offlineVRRig.headConstraint.transform.Rotate(1f, 10f, 1f);
            }
            else
            {
                vRrig.enabled = false;
                vRrig.transform.position = Vector3.zero;
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void GhostWalk()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }
            if (MenuSrc.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                CheckNewRig();
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position;
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation;
            }
            else
            {
                vRrig.enabled = false;
                vRrig.transform.position = Vector3.zero;
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void FrozenGhostWalk()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }
            if (MenuSrc.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                CheckNewRig();
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation;
            }
            else
            {
                vRrig.enabled = false;
                vRrig.transform.position = Vector3.zero;
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void Helicopter()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }
            if (MenuSrc.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                CheckNewRig();
                GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 9.5f, 0f);
                GorillaTagger.Instance.offlineVRRig.transform.position += new Vector3(0f, 0.10f, 0f);
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(999f, 0f, 0f);
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(-999f, 0f, 0f);
            }
            else
            {
                vRrig.enabled = false;
                vRrig.transform.position = Vector3.zero;
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void CopyPlayer()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            CheckNewRig();

                            GorillaTagger.Instance.offlineVRRig.transform.position = MenuSrc.playerLock.transform.position;
                            GorillaTagger.Instance.offlineVRRig.transform.rotation = MenuSrc.playerLock.transform.rotation;

                            GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = MenuSrc.playerLock.leftHandPlayer.transform.position;
                            GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.rotation = MenuSrc.playerLock.leftHandPlayer.transform.rotation;

                            GorillaTagger.Instance.offlineVRRig.headMesh.transform.position = MenuSrc.playerLock.transform.position;
                            GorillaTagger.Instance.offlineVRRig.headMesh.transform.rotation = MenuSrc.playerLock.transform.rotation;

                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = MenuSrc.playerLock.rightHandPlayer.transform.position;
                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.rotation = MenuSrc.playerLock.rightHandPlayer.transform.rotation;
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            vRrig.enabled = false;
                            vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
                else
                {
                    VRRigMods.vRrig.enabled = false;
                    VRRigMods.vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            CheckNewRig();

                            GorillaTagger.Instance.offlineVRRig.transform.position = MenuSrc.playerLock.transform.position;
                            GorillaTagger.Instance.offlineVRRig.transform.rotation = MenuSrc.playerLock.transform.rotation;

                            GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = MenuSrc.playerLock.leftHandPlayer.transform.position;
                            GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.rotation = MenuSrc.playerLock.leftHandPlayer.transform.rotation;

                            GorillaTagger.Instance.offlineVRRig.headMesh.transform.position = MenuSrc.playerLock.transform.position;
                            GorillaTagger.Instance.offlineVRRig.headMesh.transform.rotation = MenuSrc.playerLock.transform.rotation;

                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = MenuSrc.playerLock.rightHandPlayer.transform.position;
                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.rotation = MenuSrc.playerLock.rightHandPlayer.transform.rotation;
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            vRrig.enabled = false;
                            vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
                else
                {
                    VRRigMods.vRrig.enabled = false;
                    VRRigMods.vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }
        public static void LookAtClosest()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }

            if (MenuSrc.Reversed)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                VRRigMods.LookAtNearest();
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void FollowPlayer()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            var targetTransform = MenuSrc.playerLock.transform;
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            CheckNewRig();
                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = targetTransform.position;

                            targetPosition = targetTransform.position + targetTransform.forward.x0z();
                            targetRotation = Quaternion.LookRotation(targetTransform.position - GorillaTagger.Instance.offlineVRRig.transform.position);
                            GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.MoveTowards(GorillaTagger.Instance.offlineVRRig.transform.position, targetPosition, 7.6f * Time.deltaTime);
                            GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.RotateTowards(GorillaTagger.Instance.offlineVRRig.transform.rotation, targetRotation, 720f * Time.deltaTime);

                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            vRrig.enabled = false;
                            vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
                else
                {
                    VRRigMods.vRrig.enabled = false;
                    VRRigMods.vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            var targetTransform = MenuSrc.playerLock.transform;
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            CheckNewRig();
                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = targetTransform.position;

                            targetPosition = targetTransform.position + targetTransform.forward.x0z();
                            targetRotation = Quaternion.LookRotation(targetTransform.position - GorillaTagger.Instance.offlineVRRig.transform.position);
                            GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.MoveTowards(GorillaTagger.Instance.offlineVRRig.transform.position, targetPosition, 7.6f * Time.deltaTime);
                            GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.RotateTowards(GorillaTagger.Instance.offlineVRRig.transform.rotation, targetRotation, 720f * Time.deltaTime);

                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            vRrig.enabled = false;
                            vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
                else
                {
                    VRRigMods.vRrig.enabled = false;
                    VRRigMods.vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }
    }
}