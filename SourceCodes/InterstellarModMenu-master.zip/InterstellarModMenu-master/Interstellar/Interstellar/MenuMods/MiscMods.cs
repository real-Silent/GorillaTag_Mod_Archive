﻿using GorillaNetworking;
using Interstellar.Main;
using Interstellar.Utility;
using Photon.Pun;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class MiscMods : MonoBehaviour
    {
        static bool antiRep = false;
        static Color color;
        static Color awd;
        public static bool leavesToggle = false;
        public static string NormalizeColor(float color)
        {
            return ((int)(color * 9f)).ToString() ?? "";
        }


        public static void TPToStump()
        {
            if (GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").activeSelf == true)
            {
                if (ControllerInputPoller.instance.rightControllerPrimaryButton)
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = false;
                    }
                    GorillaLocomotion.Player.Instance.transform.position = new Vector3(-66.4728f, 11.7809f, -82.641f);
                }
                else
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = true;
                    }
                }
            }
        }
        public static void CosmetSlotSpam(int slotNumber)
        {
            string buttonPath2 = "Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton (" + slotNumber + ")";
            GameObject.Find(buttonPath2).GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
            
        }
        public static void CosmetSpam()
        {
            string buttonPath = "Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/Wardrobe/WardrobeItemButton";
            GameObject.Find(buttonPath).GetComponent<GorillaPressableButton>().ButtonActivationWithHand(false);
            
        }
        public static void Become(string name, byte r, byte g, byte b)
        {
            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                NetworkSystemPUN.Instance.SetMyNickName(name);
                color = new Color32(r, g, b, 255);
                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", 0, new object[]
                {
                color.r,
                color.g,
                color.b,
                false
                });
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE GOTO STUMP</color>", 2);
            }
        }
        public static void ColorLogger()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!antiRep)
                            {
                                string roundedRedValue = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(gjei).playerColor.r);
                                string roundedGreenValue = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(gjei).playerColor.g);
                                string roundedBlueValue = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(gjei).playerColor.b);
                                NotifiLib.SendWithCooldown($"[<color=cyan>{gjei.NickName}</color>'s] Color Code R: [<color=red>{roundedRedValue}</color>] G: [<color=green>{roundedGreenValue}</color>] B: [<color=blue>{roundedBlueValue}</color>]", 3);
                                antiRep = true;
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            antiRep = false;
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            antiRep = false;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!antiRep)
                            {
                                string roundedRedValue = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(gjei).playerColor.r);
                                string roundedGreenValue = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(gjei).playerColor.g);
                                string roundedBlueValue = NormalizeColor(GorillaGameManager.instance.FindPlayerVRRig(gjei).playerColor.b);
                                NotifiLib.SendWithCooldown($"[<color=cyan>{gjei.NickName}</color>'s] Color Code R: [<color=red>{roundedRedValue}</color>] G: [<color=green>{roundedGreenValue}</color>] B: [<color=blue>{roundedBlueValue}</color>]", 3);
                                antiRep = true;
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            antiRep = false;
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            antiRep = false;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void StaticFinger()
        {
            ControllerInputPoller.instance.leftControllerGripFloat = 0f;
            ControllerInputPoller.instance.rightControllerGripFloat = 0f;
            ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
            ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
            ControllerInputPoller.instance.leftControllerPrimaryButton = false;
            ControllerInputPoller.instance.leftControllerSecondaryButton = false;
            ControllerInputPoller.instance.rightControllerPrimaryButton = false;
            ControllerInputPoller.instance.rightControllerSecondaryButton = false;
        }
        public static void AntiModerator()
        {
            foreach (VRRig awd in GorillaParent.instance.vrrigs)
            {
                if (awd.concatStringOfCosmeticsAllowed.Contains("LBAAK") || awd.concatStringOfCosmeticsAllowed.Contains("LBAAK"))
                {
                    LobbyHop.Join();
                }
            }
        }
        public static void TP_To_Hunt_Target()
        {
            if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
            {
                foreach (VRRig awid in GorillaParent.instance.vrrigs)
                {
                    if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == awid)
                    {
                        if (ControllerInputPoller.instance.rightControllerPrimaryButton)
                        {
                            GorillaLocomotion.Player.Instance.transform.position = awid.transform.position + new Vector3(0f, 0.25f, 0f);
                        }
                    }
                }
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT IN [HUNT] GAMEMODE</color>", 3);
            }
        }
        public static void FakeOculusMenu()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (MenuSrc.Origin)
                {
                    MenuSrc.Reversed = !MenuSrc.Reversed;
                    MenuSrc.Origin = false;
                }
            }
            else
            {
                MenuSrc.Origin = true;
            }

            if (MenuSrc.Reversed)
            {
                StaticFinger();
                GorillaLocomotion.Player.Instance.leftControllerTransform.position = GorillaLocomotion.Player.Instance.transform.position;
                GorillaLocomotion.Player.Instance.rightControllerTransform.position = GorillaLocomotion.Player.Instance.transform.position;
            }
        }
        public static void HideOnLeaderboard()
        {
            NetworkSystemPUN.Instance.SetMyNickName("");
            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                awd = new Color32(1, 52, 2, 255);
                GorillaTagger.Instance.UpdateColor(awd.r, awd.g, awd.b);
                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                {
                    awd.r,
                    awd.g,
                    awd.b
                });
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>GOTO STUMP FOR QUICKER RESULTS</color>", 3);
            }
        }
    }
}
