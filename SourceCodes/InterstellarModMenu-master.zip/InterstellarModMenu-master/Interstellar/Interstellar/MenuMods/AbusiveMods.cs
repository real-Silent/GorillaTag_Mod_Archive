﻿using Interstellar.Utility;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using ExitGames.Client.Photon;
using Interstellar.Main;
using System.Collections.Generic;
using System.Linq;

namespace Interstellar.MenuMods
{
    //dont skid you fat fuck
    public class AbusiveMods : MonoBehaviour
    {
        static bool wwrhihaw = false;
        static float smth = 0; //MOST OF THIS IS JUST REPLICATED METHODS
        /*
        public static void FloatGun()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (MenuSrc.GunHand == 1)
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                AngryBeeSwarm.instance.currentState = AngryBeeSwarm.ChaseState.Grabbing;
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO LIFT:</color> [{player.NickName.ToUpper()}]", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 2)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                AngryBeeSwarm.instance.currentState = AngryBeeSwarm.ChaseState.Grabbing;
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO LIFT:</color> [{player.NickName.ToUpper()}]", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {

                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 3)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                AngryBeeSwarm.instance.currentState = AngryBeeSwarm.ChaseState.Grabbing;
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO LIFT:</color> [{player.NickName.ToUpper()}]", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {

                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                AngryBeeSwarm.instance.currentState = AngryBeeSwarm.ChaseState.Grabbing;
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO LIFT:</color> [{player.NickName.ToUpper()}]", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTERCLIENT</color>", 3);
            }
        }
        public static void StopMovement()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (MenuSrc.GunHand == 1)
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                List<AngryBeeSwarm.ChaseState> chaseStatesList = new List<AngryBeeSwarm.ChaseState>();

                                chaseStatesList.Add(AngryBeeSwarm.ChaseState.InitialEmerge);
                                chaseStatesList.Add(AngryBeeSwarm.ChaseState.Grabbing);
                                int Rando = new System.Random().Next(0, chaseStatesList.Count);
                                AngryBeeSwarm.instance.currentState = chaseStatesList[Rando];
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO JITTER: [<color=cyan>{player.NickName.ToUpper()}'s</color>] MOVEMENT</color>", 3);


                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 2)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                List<AngryBeeSwarm.ChaseState> ggggggg = new List<AngryBeeSwarm.ChaseState>();

                                ggggggg.Add(AngryBeeSwarm.ChaseState.InitialEmerge);
                                ggggggg.Add(AngryBeeSwarm.ChaseState.Grabbing);
                                int Rando = new System.Random().Next(0, ggggggg.Count);
                                AngryBeeSwarm.instance.currentState = ggggggg[Rando];
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO JITTER: [<color=cyan>{player.NickName.ToUpper()}'s</color>] MOVEMENT</color>", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {

                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 3)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                List<AngryBeeSwarm.ChaseState> gawfawf = new List<AngryBeeSwarm.ChaseState>();


                                gawfawf.Add(AngryBeeSwarm.ChaseState.InitialEmerge);
                                gawfawf.Add(AngryBeeSwarm.ChaseState.Grabbing);
                                gawfawf.Add(AngryBeeSwarm.ChaseState.InitialEmerge);
                                int Rando = new System.Random().Next(0, gawfawf.Count);
                                AngryBeeSwarm.instance.currentState = gawfawf[Rando];
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO JITTER: [<color=cyan>{player.NickName.ToUpper()}'s</color>] MOVEMENT</color>", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {

                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                                PhotonStream stream = new PhotonStream(true, null);
                                PhotonMessageInfo info = new PhotonMessageInfo(PhotonNetwork.LocalPlayer, PhotonNetwork.ServerTimestamp, GorillaTagger.Instance.myVRRig);
                                VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(player);
                                AngryBeeSwarm.instance.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                AngryBeeSwarm.instance.targetPlayer = vrrig.Creator;
                                List<AngryBeeSwarm.ChaseState> chaseStatesList = new List<AngryBeeSwarm.ChaseState>();

                                chaseStatesList.Add(AngryBeeSwarm.ChaseState.InitialEmerge);
                                chaseStatesList.Add(AngryBeeSwarm.ChaseState.Grabbing);
                                chaseStatesList.Add(AngryBeeSwarm.ChaseState.InitialEmerge);
                                int Rando = new System.Random().Next(0, chaseStatesList.Count);
                                AngryBeeSwarm.instance.currentState = chaseStatesList[Rando];
                                AngryBeeSwarm.instance.photonView.SerializeView(stream, info);
                                
                                NotifiLib.SendWithCooldown($"<color=green>ATTEMPTING TO JITTER: [<color=cyan>{player.NickName.ToUpper()}'s</color>] MOVEMENT</color>", 3);


                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 3);
            }
        }
        */
        public static void CrashGun()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (MenuSrc.GunHand == 1)
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                                if (Time.time > smth + 0.1f)
                                {
                                    for (int i = 0; i < 45; i++)
                                    {
                                        object[] array = new object[]
                                        {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                        };
                                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                    }
                                    smth = Time.time;
                                }
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH: [<color=blue>{gjei.Owner.NickName.ToUpper()}</color>]", 3);
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 2)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                                if (Time.time > smth + 0.1f)
                                {
                                    for (int i = 0; i < 25; i++)
                                    {
                                        object[] array = new object[]
                                        {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                        };
                                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                    }
                                    smth = Time.time;
                                }
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO CRASH: [<color=blue>{gjei.Owner.NickName.ToUpper()}</color>]", 3);

                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 2);
            }
        }
        public static void CrashAll()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (Time.time > smth + 0.1f)
                {
                    for (int i = 0; i < 45; i++)
                    {
                        object[] array = new object[]
                        {
                            999999999999f,
                            999999999999f,
                            999999999999f
                        };
                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.Others, array);
                    }
                    smth = Time.time;
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        }
        public static void TouchToCrash()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, vrrig.transform.position) <= 0.3 || Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position, vrrig.transform.position) <= 0.3 && !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                        {
                            PhotonView wad = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>());
                            if (Time.time > smth + 0.1f)
                            {
                                for (int i = 0; i < 45; i++)
                                {
                                    object[] array = new object[]
                                    {
                            999999999999f,
                            999999999999f,
                            999999999999f
                                    };
                                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", wad.Owner, array);
                                }
                                smth = Time.time;
                            }
                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        }

        public static void LagAll()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (Time.time > smth + 0.15f)
                {
                    for (int i = 0; i < 45; i++)
                    {
                        object[] array = new object[]
                        {
                            999999999999f,
                            999999999999f,
                            999999999999f
                        };
                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.Others, array);
                    }
                    smth = Time.time;
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 2);
            }
        }
        public static void LagGun()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (MenuSrc.GunHand == 1)
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO LAG: [<color=blue>{gjei.Owner.NickName.ToUpper()}</color>]", 3f);

                                if (Time.time > smth + 0.15f)
                                {
                                    for (int i = 0; i < 45; i++)
                                    {
                                        object[] array = new object[]
                                        {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                        };
                                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                    }
                                    smth = Time.time;
                                }

                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 2)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO LAG: [<color=blue>{gjei.Owner.NickName.ToUpper()}</color>]", 3f);
                                if (Time.time > smth + 0.15f)
                                {
                                    for (int i = 0; i < 45; i++)
                                    {
                                        object[] array = new object[]
                                        {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                        };
                                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                    }
                                    smth = Time.time;
                                }
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 2);
            }
        }
        public static void TouchToLag()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, vrrig.transform.position) <= 0.3 || Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position, vrrig.transform.position) <= 0.3 && !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                        {
                            PhotonView gjei = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>());
                            if (Time.time > smth + 0.15f)
                            {
                                for (int i = 0; i < 45; i++)
                                {
                                    object[] array = new object[]
                                    {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                    };
                                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                }
                                smth = Time.time;
                            }
                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        }

        public static void StutterGunV2()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (MenuSrc.GunHand == 1)
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO STUTTER: [<color=blue>{gjei.Owner.NickName.ToUpper()}</color>]", 3f);
                                if (Time.time > smth + 0.48f)
                                {
                                    for (int i = 0; i < 45; i++)
                                    {
                                        object[] array = new object[]
                                        {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                        };
                                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                    }
                                    smth = Time.time;
                                }
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 2)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);

                                if (Time.time > smth + 0.48f)
                                {
                                    for (int i = 0; i < 45; i++)
                                    {
                                        object[] array = new object[]
                                        {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                        };
                                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                    } 
                                    smth = Time.time;
                                }
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        }
        public static void StutterAllV2()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                Photon.Realtime.Player[] awd = PhotonNetwork.PlayerListOthers;
                System.Random rng = new System.Random();
                awd = awd.OrderBy(x => rng.Next()).ToArray();

                foreach (Photon.Realtime.Player player in awd)
                {
                    VRRig ojdaw = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (ojdaw != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Time.time > smth + 0.2f)
                        {
                            PhotonView gjei = InterstellarUtils.GetPhotonView(ojdaw.GetComponentInParent<VRRig>());
                            NotifiLib.SendWithCooldown($"ATTEMPTING TO STUTTER: [<color=cyan>{PhotonNetwork.CurrentRoom.Players.Count}</color>] PLAYERS", 3f);
                            if (Time.time > smth + 0.48f)
                            {
                                for (int i = 0; i < 45; i++)
                                {
                                    object[] array = new object[]
                                    {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                    };
                                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                } 
                                smth = Time.time;
                            }
                            smth = Time.time;
                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        }
        public static void StutterAuraV2()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    PhotonView gjei = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>());
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) <= 4)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            if (Time.time > smth + 0.48f)
                            {
                                for (int i = 0; i < 45; i++)
                                {
                                    object[] array = new object[]
                                    {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                    };
                                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                }
                                smth = Time.time;
                            }
                        }
                    }
                }
            }
            else
            {
                if (RoomMods.antibanReady == false)
                {
                    NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN!</color>", 3);
                }
            }
        }
        public static void TouchToStutterV2()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (vrrig != GorillaTagger.Instance.offlineVRRig || !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, vrrig.transform.position) <= 0.3 || Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position, vrrig.transform.position) <= 0.3 && !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                        {
                            PhotonView gjei = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>());
                            NotifiLib.SendWithCooldown($"ATTEMPTING TO STUTTER [<color=cyan>{gjei.Owner.NickName}</color>]", 3);
                            if (Time.time > smth + 0.48f)
                            {
                                for (int i = 0; i < 45; i++)
                                {
                                    object[] array = new object[]
                                    {
                                            999999999999f,
                                            999999999999f,
                                            999999999999f
                                    };
                                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", gjei.Owner, array);
                                }
                                smth = Time.time;
                            }
                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        }

        public static void StutterGun()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (MenuSrc.GunHand == 1)
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                                NotifiLib.SendWithCooldown($"ATTEMPTING TO STUTTER: [<color=blue>{gjei.Owner.NickName.ToUpper()}</color>]", 3f);
                                if (wwrhihaw == false)
                                {
                                    gjei.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                    gjei.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                    wwrhihaw = true;
                                }
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                wwrhihaw = false;
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
                else if (MenuSrc.GunHand == 2)
                {
                    if (ControllerInputPoller.instance.leftGrab)
                    {
                        RaycastHit rayPoint;
                        if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                        {
                            GameObject iuhe = new GameObject("ArchCore");
                            LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                            kmma.material.shader = Shader.Find("GUI/Text Shader");
                            kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            kmma.startWidth = 0.020f;
                            kmma.useWorldSpace = true;
                            kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                            UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                            if (MenuSrc.playerLock == null)
                            {
                                kmma.SetPosition(1, rayPoint.point);
                            }


                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                            {
                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = MenuSrc.playerLock.transform.position;
                                Object.Destroy(pointer, Time.deltaTime);
                                kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);

                                if (wwrhihaw == false)
                                {
                                    gjei.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                    gjei.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                    wwrhihaw = true;
                                }
                                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            }
                            else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                            {
                                MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                PhotonView gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock);
                            }
                            else
                            {
                                wwrhihaw = false;
                                MenuSrc.playerLock = null;
                                kmma.SetPosition(1, rayPoint.point);
                            }

                        }
                    }
                }
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 3);
            }
        } //UH-OH STUTTER GUN SRC

        public static void NameSpazAll()
        {
            if (RoomMods.antibanReady == true || InterstellarUtils.IsModded() == true)
            {
                if (Time.time > smth + 0.2f)
                {
                    foreach (Player p in PhotonNetwork.PlayerList)
                    {
                        string[] randomnames = new string[]
                            {
                    "BTC",
                    "NETFLIX",
                    PhotonNetwork.LocalPlayer.NickName
                            };
                        int Rando = new System.Random().Next(0, randomnames.Length);
                        Hashtable hashtable = new Hashtable();
                        hashtable[byte.MaxValue] = randomnames[Rando];
                        Dictionary<byte, object> dictionary = new Dictionary<byte, object>();
                        dictionary.Add(251, hashtable);
                        dictionary.Add(254, p.ActorNumber);
                        dictionary.Add(250, true);
                        PhotonNetwork.CurrentRoom.LoadBalancingClient.LoadBalancingPeer.SendOperation(252, dictionary, SendOptions.SendUnreliable);
                    }
                    smth = Time.time;
                }
                NotifiLib.SendWithCooldown("<color=green>CYCLING ALL PLAYERS NAMES</color>", 3);
            }
            else if (RoomMods.antibanReady == false)
            {
                NotifiLib.SendWithCooldown("<color=red>ENABLE ANTIBAN</color>", 2);
            }
        }


        /*
        public static void DestroyAll()
        {
            if (PhotonNetwork.InRoom)
            {
                foreach (Photon.Realtime.Player CachePlayer in PhotonNetwork.PlayerListOthers)
                {
                    PhotonNetwork.CurrentRoom.StorePlayer(CachePlayer);
                    PhotonNetwork.CurrentRoom.Players.Remove(CachePlayer.ActorNumber);
                    PhotonNetwork.OpRemoveCompleteCacheOfPlayer(CachePlayer.ActorNumber);
                    PhotonNetwork.OpCleanActorRpcBuffer(CachePlayer.ActorNumber);
                    NotifiLib.SendWithCooldown($"DESTROYED PLAYER COUNT OF: [<color=blue>{PhotonNetwork.CurrentRoom.PlayerCount}</color>]", 0);
                    
                }
            }
            else if (!PhotonNetwork.InRoom)
            {
                NotifiLib.SendWithCooldown("PLEASE JOIN A ROOM", 0);
            }
        }
        public static void DestroyGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                            if (stopDestroy)
                            {
                                NotifiLib.SendWithCooldown($"DESTROYED: [<color=blue>{player.NickName.ToUpper()}</color>", 1);
                                PhotonNetwork.CurrentRoom.StorePlayer(player);
                                PhotonNetwork.CurrentRoom.Players.Remove(player.ActorNumber);
                                PhotonNetwork.OpRemoveCompleteCacheOfPlayer(player.ActorNumber);
                                PhotonNetwork.OpCleanActorRpcBuffer(player.ActorNumber);
                                
                                stopDestroy = false;
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;

                            if (stopDestroy)
                            {
                                NotifiLib.SendWithCooldown($"DESTROYED: [<color=blue>{player.NickName.ToUpper()}</color>", 1);
                                PhotonNetwork.CurrentRoom.StorePlayer(player);
                                PhotonNetwork.CurrentRoom.Players.Remove(player.ActorNumber);
                                PhotonNetwork.OpRemoveCompleteCacheOfPlayer(player.ActorNumber);
                                PhotonNetwork.OpCleanActorRpcBuffer(player.ActorNumber);
                                
                                stopDestroy = false;
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {

                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        */
    }
}