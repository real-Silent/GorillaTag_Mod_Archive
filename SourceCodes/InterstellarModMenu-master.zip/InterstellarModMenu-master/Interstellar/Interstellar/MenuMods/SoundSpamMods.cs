﻿using Interstellar.Main;
using Interstellar.Utility;
using Photon.Pun;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class SoundSpamMods : MonoBehaviour
    {
        public static int smth = 1;
        public static void SSpamAll(int num, float volume)
        {
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
            {
                num,
                false,
                volume
            });
            
        }
        public static void SSpamGuns(int num, float volume)
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", gjei, new object[]
{
    num,
    false,
    volume
});
                            
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }
                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", gjei, new object[]
{
    num,
    false,
    volume
});
                            
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void CustomSound()
        {
            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f)
            {
                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                {
                    smth++;
                }
                PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
                {
                    smth,
                    false,
                    0.9f
                });
                
            }
        }
    }
}