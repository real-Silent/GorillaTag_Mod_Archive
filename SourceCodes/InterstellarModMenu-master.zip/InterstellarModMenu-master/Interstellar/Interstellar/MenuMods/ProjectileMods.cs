﻿using UnityEngine;
using Interstellar.Utility;
using Photon.Pun;
using Photon.Realtime;
using ExitGames.Client.Photon;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class ProjectileMods : MonoBehaviour
    {
        static float smth = 0f;
        public static object[] projectileSendData = new object[9];
        public static object[] sendEventData = new object[3];
        public static int localPlayerProjectileCounter = 0;

        public static int IncrementLocalPlayerProjectileCount()
        {
            localPlayerProjectileCounter++;
            return localPlayerProjectileCounter;
        }

        public static void ProjSpam()
        {
            if (Time.time > smth + 0.2f)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    projectileSendData[0] = GorillaTagger.Instance.rightHandTransform.position;
                    projectileSendData[1] = new Vector3(0f, 0f, 0f);
                    projectileSendData[2] = 2;
                    projectileSendData[3] = IncrementLocalPlayerProjectileCount();
                    projectileSendData[4] = false;
                    projectileSendData[5] = 1f;
                    projectileSendData[6] = 1f;
                    projectileSendData[7] = 1f;
                    projectileSendData[8] = 1f;
                    byte b2 = 0;
                    object obj = projectileSendData;
                    sendEventData[0] = PhotonNetwork.ServerTimestamp;
                    sendEventData[1] = b2;
                    sendEventData[2] = obj;
                    PhotonNetwork.RaiseEvent(3, sendEventData, new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.Others
                    }, SendOptions.SendUnreliable);
                    PhotonNetwork.SendAllOutgoingCommands();
                }
                smth = Time.time;
            }
        }
    }
}