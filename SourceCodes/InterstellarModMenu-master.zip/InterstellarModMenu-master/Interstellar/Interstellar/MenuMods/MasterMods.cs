﻿using ExitGames.Client.Photon;
using GorillaTag;
using HarmonyLib;
using Interstellar.Main;
using Interstellar.Utility;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class MasterMods : MonoBehaviour
    {
        static float smth = 0;
        
        public static void MatSpamAll()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 0.04)
                {
                    foreach (Photon.Realtime.Player awf in PhotonNetwork.PlayerListOthers)
                    {
                        if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(awf))
                        {
                            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(awf);
                        }
                        else if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(awf))
                        {
                            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(awf);
                        }
                    }
                    smth = Time.time;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 3);
            }
        }
        public static void MatSpamGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player thatGUY = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 0.04)
                                {
                                    if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(thatGUY))
                                    {
                                        GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(thatGUY);
                                    }
                                    else
                                    {
                                        if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(thatGUY))
                                        {
                                            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(thatGUY);
                                        }
                                    }
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player thatGUY = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 0.04)
                                {
                                    if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(notHim))
                                    {
                                        GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(notHim);
                                    }
                                    else
                                    {
                                        if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(notHim))
                                        {
                                            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(notHim);
                                        }
                                    }  
                                    smth = Time.time;
                                }
                            };
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void MatSpamSelf()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 0.04)
                {
                    if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(PhotonNetwork.LocalPlayer);
                    }
                    else if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(PhotonNetwork.LocalPlayer);
                    }
                    smth = Time.time;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 3);
            }
        }
        public static void MatSpamAura()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) <= 4)
                    {
                        Photon.Realtime.Player realtimePlayer = InterstellarUtils.GetPhotonView(vrrig).Owner;
                        if (Time.time > smth + 0.04)
                        {
                            if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(realtimePlayer))
                            {
                                GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(realtimePlayer);
                            }
                            else if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(realtimePlayer))
                            {
                                GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(realtimePlayer);
                            }
                            smth = Time.time;
                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 4);
            }
        }
        public static void MatSpamOnTouch()
        {
            foreach (VRRig awfa in GorillaParent.instance.vrrigs)
            {
                if (awfa != GorillaTagger.Instance.offlineVRRig || !awfa.isMyPlayer && !awfa.isOfflineVRRig)
                {
                    Vector3 rHand = GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position;
                    Vector3 lHand = GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position;
                    if (Vector3.Distance(lHand, awfa.transform.position) <= 0.35f || Vector3.Distance(rHand, awfa.transform.position) <= 0.35f)
                    {
                        Photon.Realtime.Player his = InterstellarUtils.GetPhotonView(awfa.GetComponentInParent<VRRig>()).Owner;
                        if (PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            if (Time.time > smth + 0.04)
                            {
                                if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(his))
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(his);
                                }
                                else if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(his))
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(his);
                                }
                                smth = Time.time;
                            }
                        }
                        else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 2);
                        }
                    }
                }
            }
        }


        public static void StatusManager(byte status)
        {
            //I actually remade from room sys, ts is weird asl lemming
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 1f)
                {
                    object[] statusSendData = new object[1];
                    statusSendData[0] = status;
                    object[] sendEventData = new object[3];
                    sendEventData[0] = PhotonNetwork.ServerTimestamp;
                    sendEventData[1] = (byte)2;
                    sendEventData[2] = statusSendData;
                    PhotonNetwork.RaiseEvent(3, sendEventData, new RaiseEventOptions { Receivers = ReceiverGroup.Others } , SendOptions.SendUnreliable);
                    smth = Time.time;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 2);
            }
        }
        public static void StatusGun(byte status)
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 1f)
                                {
                                    object[] statusSendData = new object[1];
                                    statusSendData[0] = status;
                                    object[] sendEventData = new object[3];
                                    sendEventData[0] = PhotonNetwork.ServerTimestamp;
                                    sendEventData[1] = (byte)2;
                                    sendEventData[2] = statusSendData;
                                    PhotonNetwork.RaiseEvent(3, sendEventData, new RaiseEventOptions { TargetActors = new int[1] { notHim.ActorNumber } }, SendOptions.SendUnreliable);
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 1f)
                                {
                                    object[] statusSendData = new object[1];
                                    statusSendData[0] = status;
                                    object[] sendEventData = new object[3];
                                    sendEventData[0] = PhotonNetwork.ServerTimestamp;
                                    sendEventData[1] = (byte)2;
                                    sendEventData[2] = statusSendData;
                                    PhotonNetwork.RaiseEvent(3, sendEventData, new RaiseEventOptions { TargetActors = new int[1] { notHim.ActorNumber } }, SendOptions.SendUnreliable); 
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void StatusAura(byte status)
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) <= 4)
                    {
                        Photon.Realtime.Player realtimePlayer = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                        if (Time.time > smth + 1f)
                        {
                            object[] statusSendData = new object[1];
                            statusSendData[0] = status;
                            object[] sendEventData = new object[3];
                            sendEventData[0] = PhotonNetwork.ServerTimestamp;
                            sendEventData[1] = (byte)2;
                            sendEventData[2] = statusSendData;
                            PhotonNetwork.RaiseEvent(3, statusSendData, new RaiseEventOptions { TargetActors = new int[1] { realtimePlayer.ActorNumber } }, SendOptions.SendUnreliable);
                            smth = Time.time;
                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }


        public static void SpamBalloonsAll()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 0.04)
                {
                    foreach (Photon.Realtime.Player pla in PhotonNetwork.PlayerListOthers)
                    {
                        GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[pla.ActorNumber] = Random.Range(0, 3);
                    }
                    smth = Time.time;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 2);
            }
        }
        public static void SpamBalloonsGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 0.04)
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[notHim.ActorNumber] = Random.Range(0, 3);
                                    
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 0.04)
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[notHim.ActorNumber] = Random.Range(0, 3);
                                    
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void SpamBalloonsSelf()
        {
            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 2);
            }
            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 0.04)
                {
                    GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[PhotonNetwork.LocalPlayer.ActorNumber] = Random.Range(0, 3);
                    smth = Time.time;
                }
            }
        }
        public static void SpamBalloonAura()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) <= 4)
                    {
                        Photon.Realtime.Player realtimePlayer = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                        if (Time.time > smth + 0.04)
                        {
                            GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[realtimePlayer.ActorNumber] = Random.Range(0, 3);
                            
                            smth = Time.time;
                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }
        public static void TouchSpamBalloons()
        {
            foreach (VRRig awfa in GorillaParent.instance.vrrigs)
            {
                if (awfa != GorillaTagger.Instance.offlineVRRig || !awfa.isMyPlayer && !awfa.isOfflineVRRig)
                {
                    Vector3 rHand = GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position;
                    Vector3 lHand = GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position;
                    if (Vector3.Distance(lHand, awfa.transform.position) <= 0.35f || Vector3.Distance(rHand, awfa.transform.position) <= 0.35f)
                    {
                        Photon.Realtime.Player his = InterstellarUtils.GetPhotonView(awfa.GetComponentInParent<VRRig>()).Owner;
                        if (PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            if (Time.time > smth + 0.04)
                            {
                                GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[his.ActorNumber] = Random.Range(0, 3);
                                smth = Time.time;
                            }
                        }
                        else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 2);
                        }
                    }
                }
            }
        }
        public static void GodModeAll()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (Photon.Realtime.Player awd in PhotonNetwork.PlayerList)
                {
                    GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().playerLives[awd.ActorNumber] = 2500;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }

        public static void ChangeTeamsAll()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 0.04)
                {
                    GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>().RandomizeTeams();
                    smth = Time.time;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 2);
            }
        }

        public static void AcidAll()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (Time.time > smth + 0.06f)
                    {
                        if (vrrig.mainSkin.material.name.Contains("SodaInfected"))
                        {
                            foreach (Photon.Realtime.Player ijseaf in PhotonNetwork.PlayerListOthers)
                            {
                                AcidPlayer(true, false, ijseaf.ActorNumber);
                            }
                        }
                        else if (!vrrig.mainSkin.material.name.Contains("SodaInfected"))
                        {
                            foreach (Photon.Realtime.Player ijseaf in PhotonNetwork.PlayerListOthers)
                            {
                                AcidPlayer(true, true, ijseaf.ActorNumber);
                            }
                        }
                        smth = Time.time;
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }
        public static void AcidSelf()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (Time.time > smth + 0.06f)
                {
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("SodaInfected"))
                    {
                        AcidPlayer(false, false, PhotonNetwork.LocalPlayer.ActorNumber);
                    }
                    else if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("SodaInfected"))
                    {
                        AcidPlayer(false, true, PhotonNetwork.LocalPlayer.ActorNumber);
                    }
                    smth = Time.time;
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }
        public static void AcidGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            VRRig wwedaw = GorillaGameManager.instance.FindPlayerVRRig(notHim);
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 0.06f)
                                {
                                    if (wwedaw.mainSkin.material.name.Contains("SodaInfected"))
                                    {
                                        AcidPlayer(false, false, notHim.ActorNumber);
                                    }
                                    else if (!wwedaw.mainSkin.material.name.Contains("SodaInfected"))
                                    {
                                        AcidPlayer(false, true, notHim.ActorNumber);
                                    }
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(notHim);
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (Time.time > smth + 0.06f)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("SodaInfected"))
                                    {
                                        AcidPlayer(false, false, notHim.ActorNumber);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("SodaInfected"))
                                    {
                                        AcidPlayer(false, true, notHim.ActorNumber);
                                    }
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player notHim = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void AcidAura()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) <= 4)
                    {
                        if (!vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                        {
                            Photon.Realtime.Player realtimePlayer = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                            if (Time.time > smth + 0.06f)
                            {
                                if (vrrig.mainSkin.material.name.Contains("SodaInfected"))
                                {
                                    AcidPlayer(false, false, realtimePlayer.ActorNumber);
                                }
                                else if (!vrrig.mainSkin.material.name.Contains("SodaInfected"))
                                {
                                    AcidPlayer(false, true, realtimePlayer.ActorNumber);
                                }
                                smth = Time.time;
                            }
                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }
        public static void TouchToAcid()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    Vector3 lHand = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                    Vector3 rHand = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                    if (Vector3.Distance(lHand, vrrig.transform.position) <= 0.35f || Vector3.Distance(rHand, vrrig.transform.position) <= 0.35f)
                    {
                        Photon.Realtime.Player realtimePlayer = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                        if (Time.time > smth + 0.06f)
                        {
                            Traverse.Create(ScienceExperimentManager.instance).Field("inGamePlayerCount").SetValue(10);
                            ScienceExperimentManager.PlayerGameState[] states = Traverse.Create(ScienceExperimentManager.instance).Field("inGamePlayerStates").GetValue<ScienceExperimentManager.PlayerGameState[]>();
                            for (int i = 0; i < 1; i++)
                            {
                                if (states[i].touchedLiquid)
                                {
                                    states[i].touchedLiquid = false;
                                }
                                if (!states[i].touchedLiquid)
                                {
                                    states[i].touchedLiquid = true;
                                }
                                states[i].playerId = realtimePlayer.ActorNumber;
                            }
                            Traverse.Create(ScienceExperimentManager.instance).Field("inGamePlayerStates").SetValue(states);
                            smth = Time.time;
                        }
                    }
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE <color=orange>NOT</color> MASTERCLIENT</color>", 2);
            }
        }
        static void AcidPlayer(bool all_players, bool isAcid, int actornum)
        {
            Traverse.Create(ScienceExperimentManager.instance).Field("inGamePlayerCount").SetValue(10);
            ScienceExperimentManager.PlayerGameState[] states = Traverse.Create(ScienceExperimentManager.instance).Field("inGamePlayerStates").GetValue<ScienceExperimentManager.PlayerGameState[]>();
            if (all_players == true)
            {
                for (int i = 0; i < PhotonNetwork.PlayerList.Length; i++)
                {
                    states[i].touchedLiquid = isAcid;
                    states[i].playerId = PhotonNetwork.PlayerList[i].ActorNumber;
                }
            }
            else if (all_players == false)
            {
                for (int i = 0; i < PhotonNetwork.PlayerList.Length; i++)
                {
                    states[i].touchedLiquid = isAcid;
                    states[i].playerId = actornum;
                }
            }
            Traverse.Create(ScienceExperimentManager.instance).Field("inGamePlayerStates").SetValue(states);
        }

        public static void BreakGliderAll()
        {
            if (PhotonNetwork.InRoom)
            {
                if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
                    {

                        if (gliderHoldable.photonView.Owner == PhotonNetwork.LocalPlayer)
                        {
                            gliderHoldable.gameObject.transform.position = gliderHoldable.gameObject.transform.position + new Vector3(0f, -10f, 0f);
                        }
                        else
                        {
                            gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                            gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                            gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                            gliderHoldable.OnGrab(null, null);
                            gliderHoldable.OnHover(null, null);
                        }
                    }
                }
                else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 2);
                }
            }
            else if (!PhotonNetwork.InRoom)
            {
                NotifiLib.SendWithCooldown("<color=red>JOIN A ROOM</color>", 2);
            }
        }
        public static void BreakGliderGun()
        {
            if (PhotonNetwork.InRoom)
            {
                if (PhotonNetwork.IsMasterClient)
                {
                    if (MenuSrc.GunHand == 1)
                    {
                        Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                        if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                        {
                            GameObject dw = new GameObject("StandPoint");
                            LineRenderer wwd = dw.AddComponent<LineRenderer>();
                            wwd.material.shader = Shader.Find("GUI/Text Shader");
                            wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.startWidth = 0.020f;
                            wwd.useWorldSpace = true;
                            wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                            wwd.SetPosition(1, hit.point);
                            UnityEngine.Object.Destroy(dw, Time.deltaTime);


                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                            {
                                foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
                                {
                                    Photon.Realtime.Player fjaweiu = InterstellarUtils.GetPhotonView(hit.collider.GetComponentInParent<VRRig>()).Owner;
                                    if (gliderHoldable.photonView.Owner == fjaweiu)
                                    {
                                        gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                        gliderHoldable.OnGrab(null, null);
                                        gliderHoldable.OnHover(null, null);
                                        gliderHoldable.gameObject.transform.position = gliderHoldable.gameObject.transform.position + new Vector3(0f, -10f, 0f);
                                        
                                    }
                                    else
                                    {
                                        Debug.Log("idk");
                                    }
                                }
                            }
                        }
                    }
                    else if (MenuSrc.GunHand == 2)
                    {
                        Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                        if (ControllerInputPoller.instance.leftGrab)
                        {
                            GameObject dw = new GameObject("StandPoint");
                            LineRenderer wwd = dw.AddComponent<LineRenderer>();
                            wwd.material.shader = Shader.Find("GUI/Text Shader");
                            wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.startWidth = 0.020f;
                            wwd.useWorldSpace = true;
                            wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.position);
                            wwd.SetPosition(1, hit.point);
                            UnityEngine.Object.Destroy(dw, Time.deltaTime);


                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                            {
                                foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
                                {
                                    Photon.Realtime.Player fjaweiu = InterstellarUtils.GetPhotonView(hit.collider.GetComponentInParent<VRRig>()).Owner;
                                    if (gliderHoldable.photonView.Owner == fjaweiu)
                                    {
                                        gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                        gliderHoldable.OnGrab(null, null);
                                        gliderHoldable.OnHover(null, null);
                                        gliderHoldable.gameObject.transform.position = gliderHoldable.gameObject.transform.position + new Vector3(0f, -10f, 0f);
                                        
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 3);
                }
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE JOIN A ROOM</color>", 3);
            }
        }
        public static void BringGlidersToMe()
        {
            if (PhotonNetwork.InRoom)
            {
                if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
                    {
                        if (gliderHoldable.photonView.Owner == PhotonNetwork.LocalPlayer)
                        {
                            gliderHoldable.gameObject.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position;
                        }
                        else
                        {
                            gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                            gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                            gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                            gliderHoldable.OnGrab(null, null);
                            gliderHoldable.OnHover(null, null);
                        }
                    }
                }
                else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 2);
                }
            }
            else if (!PhotonNetwork.InRoom)
            {
                NotifiLib.SendWithCooldown("<color=red>JOIN A ROOM</color>", 2);
            }
        }
        public static void GlidersToGun()
        {
            if (PhotonNetwork.InRoom)
            {
                if (PhotonNetwork.IsMasterClient)
                {
                    if (MenuSrc.GunHand == 1)
                    {
                        Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                        if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                        {
                            GameObject dw = new GameObject("StandPoint");
                            LineRenderer wwd = dw.AddComponent<LineRenderer>();
                            wwd.material.shader = Shader.Find("GUI/Text Shader");
                            wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.startWidth = 0.020f;
                            wwd.useWorldSpace = true;
                            wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                            wwd.SetPosition(1, hit.point);
                            UnityEngine.Object.Destroy(dw, Time.deltaTime);


                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                            {
                                foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
                                {
                                    if (gliderHoldable.photonView.Owner == PhotonNetwork.LocalPlayer)
                                    {
                                        gliderHoldable.gameObject.transform.position = hit.point;
                                    }
                                    else
                                    {
                                        gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                        gliderHoldable.OnGrab(null, null);
                                        gliderHoldable.OnHover(null, null);
                                    }
                                }
                            }
                        }
                    }
                    else if (MenuSrc.GunHand == 2)
                    {
                        Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                        if (ControllerInputPoller.instance.leftGrab)
                        {
                            GameObject dw = new GameObject("StandPoint");
                            LineRenderer wwd = dw.AddComponent<LineRenderer>();
                            wwd.material.shader = Shader.Find("GUI/Text Shader");
                            wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                            wwd.startWidth = 0.020f;
                            wwd.useWorldSpace = true;
                            wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.position);
                            wwd.SetPosition(1, hit.point);
                            UnityEngine.Object.Destroy(dw, Time.deltaTime);


                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = hit.point;
                            Object.Destroy(pointer, Time.deltaTime);
                            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                            {
                                foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
                                {
                                    if (gliderHoldable.photonView.Owner == PhotonNetwork.LocalPlayer)
                                    {
                                        gliderHoldable.gameObject.transform.position = hit.point;
                                    }
                                    else
                                    {
                                        gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                                        gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                                        gliderHoldable.OnGrab(null, null);
                                        gliderHoldable.OnHover(null, null);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 3);
                }
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE JOIN A ROOM</color>", 3);
            }
        }
        public static void GliderGod()
        {
            float orbitSpeed = 4f;
            float orbitAngle = Time.time * orbitSpeed;
            float orbitRadius = 11.2f;
            Vector3 POS = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2f, 0f);
            Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
            Vector3 vector = POS += Offset * Time.deltaTime * 5f;

            foreach (GliderHoldable gliderHoldable in Resources.FindObjectsOfTypeAll<GliderHoldable>())
            {
                if (gliderHoldable.photonView.Owner == PhotonNetwork.LocalPlayer)
                {
                    gliderHoldable.gameObject.transform.position = vector;
                }
                else
                {
                    gliderHoldable.photonView.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                    gliderHoldable.photonView.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
                    gliderHoldable.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                    gliderHoldable.OnGrab(null, null);
                    gliderHoldable.OnHover(null, null);;
                }
            }
        }
    }
}