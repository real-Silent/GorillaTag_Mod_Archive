﻿using ExitGames.Client.Photon;
using Interstellar.Main;
using Interstellar.Utility;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class ImpactMods : MonoBehaviour
    {
        static float smth = 0f;
        static Color impactColor;
        public static void ImpactColors()
        {
            if (MenuSrc.impactColor == 1)
            {
                impactColor = Color.red;
            }
            else if (MenuSrc.impactColor == 2)
            {
                impactColor = Color.green;
            }
            else if (MenuSrc.impactColor == 3)
            {
                impactColor = Color.blue;
            }
            else if (MenuSrc.impactColor == 4)
            {
                impactColor = Color.yellow;
            }
            else if (MenuSrc.impactColor == 5)
            {
                impactColor = Color.cyan;
            }
            else if (MenuSrc.impactColor == 6)
            {
                impactColor = Color.magenta;
            }
            else if (MenuSrc.impactColor == 7)
            {
                impactColor = Color.white;
            }
        }
        public static void SendImpactEffect(Vector3 position, float r, float g, float b, float a, int projectileCount)
        {
            object[] impactSendData = new object[6];
            object[] sendEventData = new object[3];
            impactSendData[0] = position;
            impactSendData[1] = r;
            impactSendData[2] = g;
            impactSendData[3] = b;
            impactSendData[4] = a;
            impactSendData[5] = projectileCount;
            object obj = impactSendData;
            sendEventData[0] = PhotonNetwork.ServerTimestamp;
            sendEventData[1] = (byte)1;
            sendEventData[2] = impactSendData;
            PhotonNetwork.RaiseEvent(3, sendEventData, new RaiseEventOptions { Receivers = ReceiverGroup.All }, SendOptions.SendUnreliable);
        }
        public static void ImpactSelf()
        {
            if (Time.time > smth + 0.1f)
            {
                SendImpactEffect(GorillaTagger.Instance.offlineVRRig.transform.position, impactColor.r, impactColor.g, impactColor.b, 5f, 1);
                
                smth = Time.time;
            }
        }
        public static void ImpactPomPoms()
        {
            if (Time.time > smth + 0.3f)
            {
                SendImpactEffect(GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                SendImpactEffect(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                
                smth = Time.time;
            }
        }
        public static void ImpactAura()
        {
            if (Time.time > smth + 0.1f)
            {
                float minDistance = 1f;
                float maxDistance = 2f;

                Vector3 randomOffset = Random.insideUnitSphere;
                randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

                Vector3 newPosition = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position + randomOffset;

                Vector3 directionToPlayer = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.LocalPlayer).transform.position - newPosition;
                SendImpactEffect(newPosition, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                
                smth = Time.time;
            }
        }
        public static void Impactorbit()
        {
            if (Time.time > smth + 0.1f)
            {
                float orbitSpeed = 4.5f;
                float orbitAngle = Time.time * orbitSpeed;
                float orbitRadius = 6f;
                Vector3 POS = GorillaTagger.Instance.offlineVRRig.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
                Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                SendImpactEffect(vector, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                
                smth = Time.time;
            }
        }
        public static void ImpactAll()
        {
            if (Time.time > smth + 0.3)
            {
                for (int w = 0; w < GorillaParent.instance.vrrigs.Count; w++)
                {
                    SendImpactEffect(GorillaParent.instance.vrrigs[w].transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                }
                
                smth = Time.time;
            }
        }
        public static void ImpactGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            if (MenuSrc.Pg36Active[0] == true)
                            {
                                if (Time.time > smth + 0.1f) //REGULAR
                                {
                                    SendImpactEffect(MenuSrc.playerLock.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[1] == true)
                            {
                                if (Time.time > smth + 0.3f) //POM POMS
                                {
                                    SendImpactEffect(MenuSrc.playerLock.leftHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    SendImpactEffect(MenuSrc.playerLock.rightHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[2] == true) //AURA
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float minDistance = 1f;
                                    float maxDistance = 2f;

                                    Vector3 randomOffset = Random.insideUnitSphere;
                                    randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

                                    Vector3 newPosition = MenuSrc.playerLock.transform.position + randomOffset;

                                    SendImpactEffect(newPosition, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[3] == true) //ORBIT
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float orbitSpeed = 4.5f;
                                    float orbitAngle = Time.time * orbitSpeed;
                                    float orbitRadius = 6f;
                                    Vector3 POS = MenuSrc.playerLock.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
                                    Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                                    Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                                    SendImpactEffect(vector, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            if (MenuSrc.Pg36Active[0] == true)
                            {
                                if (Time.time > smth + 0.1f) //REGULAR
                                {
                                    SendImpactEffect(MenuSrc.playerLock.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[1] == true)
                            {
                                if (Time.time > smth + 0.3f) //POM POMS
                                {
                                    SendImpactEffect(MenuSrc.playerLock.leftHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    SendImpactEffect(MenuSrc.playerLock.rightHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[2] == true) //AURA
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float minDistance = 1f;
                                    float maxDistance = 2f;

                                    Vector3 randomOffset = Random.insideUnitSphere;
                                    randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

                                    Vector3 newPosition = MenuSrc.playerLock.transform.position + randomOffset;

                                    SendImpactEffect(newPosition, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[3] == true) //ORBIT
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float orbitSpeed = 4.5f;
                                    float orbitAngle = Time.time * orbitSpeed;
                                    float orbitRadius = 6f;
                                    Vector3 POS = MenuSrc.playerLock.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
                                    Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                                    Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                                    SendImpactEffect(vector, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 3)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoints;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoints))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoints.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            if (MenuSrc.Pg36Active[0] == true)
                            {
                                if (Time.time > smth + 0.1f) //REGULAR
                                {
                                    SendImpactEffect(MenuSrc.playerLock.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[1] == true)
                            {
                                if (Time.time > smth + 0.3f) //POM POMS
                                {
                                    SendImpactEffect(MenuSrc.playerLock.leftHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    SendImpactEffect(MenuSrc.playerLock.rightHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[2] == true) //AURA
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float minDistance = 1f;
                                    float maxDistance = 2f;

                                    Vector3 randomOffset = Random.insideUnitSphere;
                                    randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

                                    Vector3 newPosition = MenuSrc.playerLock.transform.position + randomOffset;

                                    SendImpactEffect(newPosition, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[3] == true) //ORBIT
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float orbitSpeed = 4.5f;
                                    float orbitAngle = Time.time * orbitSpeed;
                                    float orbitRadius = 6f;
                                    Vector3 POS = MenuSrc.playerLock.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
                                    Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                                    Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                                    SendImpactEffect(vector, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoints.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoints.point);
                        }

                    }
                }
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            if (MenuSrc.Pg36Active[0] == true)
                            {
                                if (Time.time > smth + 0.1f) //REGULAR
                                {
                                    SendImpactEffect(MenuSrc.playerLock.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[1] == true)
                            {
                                if (Time.time > smth + 0.3f) //POM POMS
                                {
                                    SendImpactEffect(MenuSrc.playerLock.leftHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    SendImpactEffect(MenuSrc.playerLock.rightHandPlayer.transform.position, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[2] == true) //AURA
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float minDistance = 1f;
                                    float maxDistance = 2f;

                                    Vector3 randomOffset = Random.insideUnitSphere;
                                    randomOffset = randomOffset.normalized * Random.Range(minDistance, maxDistance);

                                    Vector3 newPosition = MenuSrc.playerLock.transform.position + randomOffset;

                                    SendImpactEffect(newPosition, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            else if (MenuSrc.Pg36Active[3] == true) //ORBIT
                            {
                                if (Time.time > smth + 0.1f)
                                {
                                    float orbitSpeed = 4.5f;
                                    float orbitAngle = Time.time * orbitSpeed;
                                    float orbitRadius = 6f;
                                    Vector3 POS = MenuSrc.playerLock.headConstraint.transform.position + new Vector3(0f, 0.6f, 0f);
                                    Vector3 Offset = new Vector3(Mathf.Cos(orbitAngle), 0f, Mathf.Sin(orbitAngle)) * orbitRadius;
                                    Vector3 vector = POS += Offset * Time.deltaTime * 5f;
                                    SendImpactEffect(vector, impactColor.r, impactColor.g, impactColor.b, 1f, 1);
                                    
                                    smth = Time.time;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
    }
}
