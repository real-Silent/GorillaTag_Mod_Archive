﻿using GorillaNetworking;
using Photon.Pun;
using PlayFab;
using PlayFab.ClientModels;
using System.Text.RegularExpressions;
using ExitGames.Client.Photon;
using Interstellar.Utility;
using UnityEngine;
using Interstellar.Patches;
using Interstellar.Main;
using Photon.Voice.PUN;

namespace Interstellar.MenuMods
{
    public class RoomMods : MonoBehaviour
    {
        public static bool antibanReady = false;
        public static bool alreadyUsed = true;
        public static void AntiBan() //Dont even think about yoinking my checks.
        {
            if (PhotonNetwork.InRoom && PhotonVoiceNetwork.Instance.PrimaryRecorder.IsInitialized && InterstellarUtils.AmICheckingGSD() == false)
            {
                if (MenuSrc.enableAntiBanSafety == false)
                {
                    if (Time.time > OnPlayerJoin.playerEntered + 6.5f)
                    {
                        if (Time.time > OnPlayerLeave.playerLeft + 4.5f)
                        {
                            if (alreadyUsed == true)
                            {
                                PlayFabClientAPI.ExecuteCloudScript(new ExecuteCloudScriptRequest
                                {
                                    FunctionName = "RoomClosed",
                                    FunctionParameter = new
                                    {
                                        GameId = PhotonNetwork.CurrentRoom.Name,
                                        Region = Regex.Replace(PhotonNetwork.CloudRegion, "[^a-zA-Z0-9]", "").ToUpper(),
                                        UserId = PhotonNetwork.LocalPlayer.UserId,
                                        ActorNr = PhotonNetwork.LocalPlayer,
                                        ActorCount = PhotonNetwork.ViewCount,
                                        AppVersion = PhotonNetwork.AppVersion
                                    }
                                }, delegate (ExecuteCloudScriptResult result)
                                {
                                    antibanReady = true;
                                    NotifiLib.SendWithCooldown("<color=green>ANTIBAN SUCCESSFULLY ENABLED</color>", 0);
                                    alreadyUsed = false;
                                    string value = PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString().Replace(GorillaComputer.instance.currentQueue, GorillaComputer.instance.currentQueue + "MODDEDMODDED");
                                    Hashtable gameMode = new Hashtable
                                        {
                                        {
                                            "gameMode",
                                            value
                                        }
                                        };
                                    PhotonNetwork.CurrentRoom.IsOpen = false;
                                    PhotonNetwork.CurrentRoom.IsVisible = false;
                                    PhotonNetwork.CurrentRoom.MaxPlayers = 0;
                                    PhotonNetwork.CurrentRoom.SetCustomProperties(gameMode, null, null);
                                }, null, null, null);
                            }
                            else if (alreadyUsed == false)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU CAN ONLY USE ONCE PER LOBBY</color>", 1);
                            }
                        }
                        else
                        {
                            NotifiLib.SendWithCooldown("<color=red>PLEASE WAIT A MOMENT FOR PLAYERS TO SYNC...</color>", 1);
                        }
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>A PLAYER HAS JOINED RECENTLY, PLEASE WAIT...</color>", 1);
                    }
                }
                else if (MenuSrc.enableAntiBanSafety == true)
                {
                    if (PhotonNetwork.CurrentRoom.PlayerCount == 10)
                    {
                        if (Time.time > OnPlayerJoin.playerEntered + 6.5f)
                        {
                            if (Time.time > OnPlayerLeave.playerLeft + 4.5f)
                            {
                                if (alreadyUsed == true)
                                {
                                    PlayFabClientAPI.ExecuteCloudScript(new ExecuteCloudScriptRequest
                                    {
                                        FunctionName = "RoomClosed",
                                        FunctionParameter = new
                                        {
                                            GameId = PhotonNetwork.CurrentRoom.Name,
                                            Region = Regex.Replace(PhotonNetwork.CloudRegion, "[^a-zA-Z0-9]", "").ToUpper(),
                                            UserId = PhotonNetwork.LocalPlayer.UserId,
                                            ActorNr = PhotonNetwork.LocalPlayer,
                                            ActorCount = PhotonNetwork.ViewCount,
                                            AppVersion = PhotonNetwork.AppVersion
                                        }
                                    }, delegate (ExecuteCloudScriptResult result)
                                    {
                                        antibanReady = true;
                                        NotifiLib.SendWithCooldown("<color=green>ANTIBAN SUCCESSFULLY ENABLED</color>", 0);
                                        alreadyUsed = false;
                                        string value = PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString().Replace(GorillaComputer.instance.currentQueue, GorillaComputer.instance.currentQueue + "MODDEDMODDED");
                                        Hashtable gameMode = new Hashtable
                                        {
                                        {
                                            "gameMode",
                                            value
                                        }
                                        };
                                        PhotonNetwork.CurrentRoom.IsOpen = false;
                                        PhotonNetwork.CurrentRoom.IsVisible = false;
                                        PhotonNetwork.CurrentRoom.MaxPlayers = 0;
                                        PhotonNetwork.CurrentRoom.SetCustomProperties(gameMode, null, null);
                                    }, null, null, null);
                                }
                                else if (alreadyUsed == false)
                                {
                                    NotifiLib.SendWithCooldown("<color=red>YOU CAN ONLY USE ONCE PER LOBBY</color>", 1);
                                }
                            }
                            else
                            {
                                NotifiLib.SendWithCooldown("<color=red>PLEASE WAIT A MOMENT FOR PLAYERS TO SYNC...</color>", 1);
                            }
                        }
                        else
                        {
                            NotifiLib.SendWithCooldown("<color=red>A PLAYER HAS JOINED RECENTLY, PLEASE WAIT...</color>", 1);
                        }
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>INSUFFICIENT PLAYER COUNT..</color>", 1);
                    }
                }
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE JOIN A ROOM AND WAIT A BIT</color>", 1);
            }
        }
        public static void SetMaster()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=orange>YOU ARE ALREADY MASTERCLIENT</color>", 0);
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient && InterstellarUtils.IsModded() == true || antibanReady == true)
            {
                PhotonNetwork.NetworkingClient.CurrentRoom.SetMasterClient(PhotonNetwork.LocalPlayer);
            }
            else if (antibanReady == false || InterstellarUtils.IsModded() == false)
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE JOIN A <color=orange>MODDED</color> ROOM OR USE <color=orange>ANTIBAN</color></color>", 0);
            }
        }
        public static void TrampStump()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient && InterstellarUtils.IsModded() == true || antibanReady == true)
            {
                Hashtable hashtable = new Hashtable();
                hashtable.Add("gameMode", "NONE");
                PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable);
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE SET MASTER</color>", 0);
            }
        }
        public static void RevokeNetTrigs()
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient && InterstellarUtils.IsModded() == true || antibanReady == true)
            {
                Hashtable hashtable = new Hashtable();
                hashtable.Add("gameMode", "forestcitybasementcanyonsmountainsbeachskycaves" + PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString());
                PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable);
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>PLEASE SET MASTER</color>", 0);
            }
        }
        public static void ChangeGamemode(string gamemode)
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient && InterstellarUtils.IsModded() == true || antibanReady == true)
            {
                Hashtable hashtable = new Hashtable();
                hashtable.Add("gameMode", gamemode);
                PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable, null, null);
            }
            else
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTERCLIENT</color>", 0);
            }
        }
    }
}