﻿using GorillaNetworking;
using Photon.Pun;
using UnityEngine;

namespace Interstellar.MenuMods
{
    public class LobbyHop : MonoBehaviour
    {
        static float smth = 0;
        static bool I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY = false;
        static GameObject clouds = GameObject.Find("Environment Objects/LocalObjects_Prefab/SkyJungleBottom");
        static GameObject basement = GameObject.Find("Basement"); //GOOD
        static GameObject forest = GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest"); //GOOD
        static GameObject city = GameObject.Find("Environment Objects/LocalObjects_Prefab/City"); //GOOD

        static GameObject canyons = GameObject.Find("Canyon");
        static GameObject mountain = GameObject.Find("Mountain");
        static GameObject beach = GameObject.Find("Beach");
        static GameObject caves = GameObject.Find("Cave_Main_Prefab"); //GOOD
        public static void LobbyJoiner()
        {
            if (PhotonNetwork.InRoom && I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY)
            {
                I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY = false;
            }
            if (!PhotonNetwork.InRoom && I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY)
            {
                Join();
            }
            if (ControllerInputPoller.instance.leftControllerPrimaryButton)
            {
                PhotonNetwork.Disconnect();
                I_WANT_TO_FUCKING_JOIN_A_NEW_LOBBY = true;
            }
        }
        public static void Join()
        {
            if (smth < Time.time)
            {
                smth = Time.time + 2.5f;
                //FOREST
                if (forest.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest, Tree Exit").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //City
                else if (city.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City Front").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //Caves
                else if (caves.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Cave").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //MOUNTAINS
                else if (mountain.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Mountain For Computer").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //BEACH
                else if (beach.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest from Beach").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //CANYONS
                else if (canyons.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Canyon").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //CLOUDS
                else if (clouds.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Clouds").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
                //BASEMENT
                else if (basement.activeSelf == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Basement For Computer").GetComponent<GorillaNetworkJoinTrigger>().Invoke("OnBoxTriggered", 0);
                }
            }
        }
    }
}