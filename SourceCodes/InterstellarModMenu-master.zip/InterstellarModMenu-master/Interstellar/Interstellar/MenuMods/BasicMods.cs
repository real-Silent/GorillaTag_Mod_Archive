﻿using GorillaNetworking;
using Interstellar.Main;
using Photon.Pun;
using System.Threading;
using UnityEngine;
using Interstellar.Utility;
using System.Linq;
using ExitGames.Client.Photon;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class BasicMods : MonoBehaviour
    {
        public static Camera camcomp;
        public static GameObject shouldercam;
        static bool LeftPlatie = true;
        static bool RightPlatie = true;
        static bool LeftPlatformInput = false;
        static bool RightPlatformInput = false;
        static GameObject LeftPlatform;
        static GameObject RightPlatform;
        static bool teleportGunAntiRepeat = false;
        public static GameObject pointer = null;
        public static bool CreatePublicRoom = false;
        public static GameObject clouds = GameObject.Find("skyjungle");
        public static GameObject basement = GameObject.Find("Basement");
        public static GameObject forest = GameObject.Find("Forest");
        public static GameObject city = GameObject.Find("ECity");

        public static GameObject canyons = GameObject.Find("Canyon");
        public static GameObject mountain = GameObject.Find("Mountain");
        public static GameObject beach = GameObject.Find("Beach");
        public static GameObject caves = GameObject.Find("Cave_Main_Prefab");
        static System.Random random = new System.Random();

        public static string GenerateRandomString(int length)
        {
            const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new System.Random();
            return new string(Enumerable.Repeat(chars, length)
                                      .Select(s => s[random.Next(s.Length)])
                                      .ToArray());
        }
        public static void SpeedType()
        {
            if (MenuSrc.SpeedType == 1)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 7.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.6f;
            }
            else if (MenuSrc.SpeedType == 2)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 8.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.6f;
            }
            else if (MenuSrc.SpeedType == 3)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 9.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.6f;
            }
            else if (MenuSrc.SpeedType == 4)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 10f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.8f;
            }
            else if (MenuSrc.SpeedType == 5)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 12.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.8f;
            }
            else if (MenuSrc.SpeedType == 6)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 13.5f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.8f;
            }
            else if (MenuSrc.SpeedType == 7)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 15f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.8f;
            }
            else if (MenuSrc.SpeedType == 8)
            {
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 18f;
                GorillaLocomotion.Player.Instance.jumpMultiplier = 1.8f;
            }
        }
        public static void LongArmType()
        {
            if (MenuSrc.LongArmType == 1)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.15f, 1.15f, 1.15f);
            }
            else if (MenuSrc.LongArmType == 2)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.25f, 1.25f, 1.25f);
            }
            else if (MenuSrc.LongArmType == 3)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.50f, 1.50f, 1.50f);
            }
            else if (MenuSrc.LongArmType == 4)
            {
                GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.75f, 1.75f, 1.75f);
            }
        }
        static string RandomStringPublic(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public static void CreatePub()
        {
            if (PhotonNetwork.InRoom)
            {
                NotifiLib.SendNotification("<color=red>YOU WERE DISCONNECTED, RUN THE MOD AGAIN</color>");
                CreatePublicRoom = true;
                PhotonNetwork.Disconnect();
            }
            else if (!PhotonNetwork.InRoom && CreatePublicRoom)
            {
                CreatePublicRoom = false;
                CreateRoom();
                NotifiLib.SendNotification("<color=green>CREATING ROOM.. PLEASE WAIT 5-10 SECONDS</color>");
            }
        }
        public static void LeaveLobby()
        {
            if (ControllerInputPoller.instance.leftControllerPrimaryButton)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void CreatePriv()
        {
            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(RandomStringPublic(8));
        }
        public static void CreateRoom(string CurrentMap = null, string roomName = null)
        {
            string gameModeName = PhotonNetworkController.Instance.currentJoinTrigger.gameModeName;
            string currentQueue = GorillaComputer.instance.currentQueue;
            string text = (PhotonNetworkController.Instance.currentJoinTrigger.gameModeName == "city" || PhotonNetworkController.Instance.currentJoinTrigger.gameModeName == "basement") ? "CASUAL" : GorillaComputer.instance.currentGameMode.Value;
            string value = gameModeName + currentQueue + ((text != null) ? text.ToString() : null);
            Hashtable customProps = new Hashtable
            {
            };
            if (CurrentMap != null)
            {
                customProps = new Hashtable
                {
                    {
                        "gameMode",
                        CurrentMap
                    }
                };
            }
            else
            {
                customProps = new Hashtable
                {
                    {
                        "gameMode",
                        value
                    }
                };
            }
            RoomConfig roomConfig = new RoomConfig();
            roomConfig.createIfMissing = true;
            roomConfig.isJoinable = true;
            roomConfig.isPublic = true;
            roomConfig.MaxPlayers = PhotonNetworkController.Instance.GetRoomSize(PhotonNetworkController.Instance.currentJoinTrigger.gameModeName);
            roomConfig.customProps = customProps;
            NetworkSystem.Instance.ConnectToRoom(GenerateRandomString(4), roomConfig);
        }
        public static void HandTapManager()
        {
            if (MenuSrc.handTap == 1)
            {
                GorillaTagger.Instance.handTapVolume = 0.9f;
            }
            else if (MenuSrc.handTap == 2)
            {
                GorillaTagger.Instance.handTapVolume = 0;
            }
            else if (MenuSrc.handTap == 3)
            {
                GorillaTagger.Instance.handTapVolume = 0.9f;
                GorillaTagger.Instance.tapCoolDown = 0;
            }
        }
        public static void FPC(int fpcVal)
        {
            shouldercam = GameObject.Find("Shoulder Camera");
            camcomp = shouldercam.GetComponent<Camera>();
            camcomp.fieldOfView = fpcVal;
            shouldercam.transform.SetParent(Camera.main.transform);
            shouldercam.transform.localPosition = new Vector3(0f, 0f, 0f);
            shouldercam.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
        }
        public static void TPGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    if (Mouse.current.rightButton.isPressed)
                    {
                        Ray ray = MenuSrc.TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                        Physics.Raycast(ray, out hit, 100);
                    }
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || Mouse.current.leftButton.isPressed)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            teleportGunAntiRepeat = true;
                        }
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        wwd.material = ColorManager.ColorScheme;
                    }
                }
                else
                {
                    
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.leftGrab)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            teleportGunAntiRepeat = true;
                        }
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        wwd.material = ColorManager.ColorScheme;
                    }
                }
                else
                {

                }
            }
            else if (MenuSrc.GunHand == 3)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hitw);
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.leftGrab)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            teleportGunAntiRepeat = true;
                        }
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        wwd.material = ColorManager.ColorScheme;
                    }
                }
                else
                {

                }
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                    wwd.SetPosition(1, hitw.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hitw.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                    {
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            teleportGunAntiRepeat = true;
                        }
                    }
                    else
                    {
                        teleportGunAntiRepeat = false;
                        wwd.material = ColorManager.ColorScheme;
                    }
                }
                else
                {

                }
            }
        }
        public static void Checkpoint()
        {
            bool iawd = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
            {
                if (pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.35f, 0.35f, 0.35f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                }
                if (pointer != null)
                {
                    pointer.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                }
            }
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && pointer != null)
            {
                foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    meshCollider.enabled = false;
                }
                GorillaLocomotion.Player.Instance.transform.position = pointer.transform.position;
                pointer.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
            }
            if (!iawd)
            {
                foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    meshCollider.enabled = true;
                }
                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
            }
        }
        public static void SpawnC4()
        {
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
            {
                if (pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.localScale = new Vector3(0.2f, 0.1f, 0.2f);
                }
                pointer.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;
            }
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
            {
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(20000, pointer.transform.position, 10, 10);
                Object.Destroy(pointer);
            }
        }
        public static void NoClip()
        {
            if (MenuSrc.NoClipPlats == 1)
            {
                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = false;
                    }
                }
                else
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = true;
                    }
                }
            }
            else if (MenuSrc.NoClipPlats == 2)
            {
                PlatformManager();
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed || ControllerInputPoller.instance.leftGrab)
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = false;
                    }
                }
                else
                {
                    foreach (MeshCollider mesh in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        mesh.enabled = true;
                    }
                }
            }
        }
        public static void PlatformManager()
        {
            if (MenuSrc.PlatInput == 1)
            {
                LeftPlatformInput = ControllerInputPoller.instance.leftGrab;
                RightPlatformInput = ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    //thick going down  //thick wideness //thick length forward backward
                    if (MenuSrc.PlatType == 1)
                    {
                        LeftPlatform.transform.position = new Vector3(0f, -0.04f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 2)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 3)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().enabled = false;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 4)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.9999f);
                    }
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    if (MenuSrc.PlatType == 1)
                    {
                        RightPlatform.transform.position = new Vector3(0f, -0.04f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 2)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 3)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = false;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 4)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.9999f);
                    }
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
            else if (MenuSrc.PlatInput == 2)
            {
                LeftPlatformInput = ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f;
                RightPlatformInput = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    //thick going down  //thick wideness //thick length forward backward
                    if (MenuSrc.PlatType == 1)
                    {
                        LeftPlatform.transform.position = new Vector3(0f, -0.04f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 2)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 3)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().enabled = false;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 4)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.9999f);
                    }
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    if (MenuSrc.PlatType == 1)
                    {
                        RightPlatform.transform.position = new Vector3(0f, -0.04f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 2)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 3)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = false;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 4)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.9999f);
                    }
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
            else if (MenuSrc.PlatInput == 3)
            {
                LeftPlatformInput = ControllerInputPoller.instance.leftControllerPrimaryButton;
                RightPlatformInput = ControllerInputPoller.instance.rightControllerPrimaryButton;
                if (LeftPlatformInput && LeftPlatie)
                {
                    LeftPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    //thick going down  //thick wideness //thick length forward backward
                    if (MenuSrc.PlatType == 1)
                    {
                        LeftPlatform.transform.position = new Vector3(0f, -0.04f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 2)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 3)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().enabled = false;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 4)
                    {
                        LeftPlatform.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position + new Vector3(0f, 0f, 0f);
                        LeftPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        LeftPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        LeftPlatform.GetComponent<Renderer>().enabled = true;
                        LeftPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.9999f);
                    }
                    LeftPlatform.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    LeftPlatie = false;
                }
                if (LeftPlatformInput && !LeftPlatie)
                {
                    LeftPlatie = false;
                }
                if (!LeftPlatformInput)
                {
                    GameObject.Destroy(LeftPlatform);
                    LeftPlatie = true;
                }
                if (RightPlatformInput && RightPlatie)
                {
                    RightPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    if (MenuSrc.PlatType == 1)
                    {
                        RightPlatform.transform.position = new Vector3(0f, -0.04f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 2)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 3)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = false;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                    }
                    else if (MenuSrc.PlatType == 4)
                    {
                        RightPlatform.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position + new Vector3(0f, 0f, 0f);
                        RightPlatform.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                        RightPlatform.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                        RightPlatform.GetComponent<Renderer>().enabled = true;
                        RightPlatform.transform.localScale = new Vector3(0.04f, 0.15f, 0.9999f);
                    }
                    RightPlatform.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;

                    RightPlatie = false;
                }
                if (RightPlatformInput && !RightPlatie)
                {
                    RightPlatie = false;
                }
                if (!RightPlatformInput)
                {
                    GameObject.Destroy(RightPlatform);
                    RightPlatie = true;
                }
            }
        }
        public static void FPSBoost()
        {
            if (MenuSrc.FPSType == 1)
            {
                QualitySettings.globalTextureMipmapLimit = 1;
            }
            else if (MenuSrc.FPSType == 2)
            {
                QualitySettings.globalTextureMipmapLimit = 2;
            }
            else if (MenuSrc.FPSType == 3)
            {
                QualitySettings.globalTextureMipmapLimit = 3;
            }
            else if (MenuSrc.FPSType == 4)
            {
                QualitySettings.globalTextureMipmapLimit = 4;
            }
            else if (MenuSrc.FPSType == 5)
            {
                QualitySettings.globalTextureMipmapLimit = 5;
            }
            else if (MenuSrc.FPSType == 6)
            {
                QualitySettings.globalTextureMipmapLimit = 6;
            }
            else if (MenuSrc.FPSType == 7)
            {
                QualitySettings.globalTextureMipmapLimit = 7;
            }
            else if (MenuSrc.FPSType == 8)
            {
                QualitySettings.globalTextureMipmapLimit = 8;
            }
            else if (MenuSrc.FPSType == 9)
            {
                QualitySettings.globalTextureMipmapLimit = 9;
            }
        }
        public static void Hertz45()
        {
            if (MenuSrc.hertzType == 1)
            {
                Thread.Sleep(5);
            }
            else if (MenuSrc.hertzType == 2)
            {
                Thread.Sleep(10);
            }
            else if (MenuSrc.hertzType == 3)
            {
                Thread.Sleep(15);
            }
        }
    }
}