﻿using Interstellar.Main;
using Photon.Pun;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Interstellar.MenuMods
{
    public class VisualMods : MonoBehaviour
    {
        static float smth = 0f;
        public static Text awdawdwdwdad;

        public static void Chams()
        {
            if (PhotonNetwork.InRoom)
            {
                if (MenuSrc.ESPType == 1)
                {
                    if (GorillaGameManager.instance.GameModeName().ToString().Contains("CASUAL"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                vrrig.mainSkin.material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), Mathf.PingPong(Time.time, 1f));
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("INFECTION"))
                    {
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                }
                            }
                        }
                        else if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("BATTLE"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("bluealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                }
                                else if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("orangealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    }
                                }
                                else
                                {
                                    vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.mainSkin.material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                                {
                                    vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.mainSkin.material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                }
                            }
                        }
                    }
                }
                else if (MenuSrc.ESPType == 2)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.mainSkin.material.color = Color.HSVToRGB(smth, 1f, 1f);
                            smth += 0.006f;
                            if (smth >= 1f)
                            {
                                smth = 0f;
                            }
                        }
                    }
                }
            }
            else
            {
                Debug.Log("Bro your not in a room...");
            }
        }
        public static void Tracers()
        {
            if (PhotonNetwork.InRoom)
            {
                if (MenuSrc.ESPType == 1)
                {
                    if (GorillaGameManager.instance.GameModeName().ToString().Contains("CASUAL"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                {
                                    vrrig.gameObject.AddComponent<LineRenderer>();
                                    vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                }
                                vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.35f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.35f), Mathf.PingPong(Time.time, 1));
                                vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("INFECTION"))
                    {
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                }
                            }
                        }
                        else if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("BATTLE"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("bluealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                }
                                else if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("orangealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                }
                                else
                                {
                                    if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                    {
                                        vrrig.gameObject.AddComponent<LineRenderer>();
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                    }
                                    vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                    vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                    vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            foreach (Photon.Realtime.Player plawd in PhotonNetwork.PlayerListOthers)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                                    {
                                        if (!vrrig.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.gameObject.AddComponent<LineRenderer>();
                                            vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        }
                                        vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                                        vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                                        vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                                    }
                                }
                            }
                        }
                    }
                }
                else if (MenuSrc.ESPType == 2)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            if (!vrrig.gameObject.GetComponent<LineRenderer>())
                            {
                                vrrig.gameObject.AddComponent<LineRenderer>();
                                vrrig.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                vrrig.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                            }
                            vrrig.gameObject.GetComponent<LineRenderer>().useWorldSpace = true;
                            vrrig.gameObject.GetComponent<LineRenderer>().material.color = Color.HSVToRGB(smth, 1f, 1f);
                            smth += 0.006f;
                            if (smth >= 1f)
                            {
                                smth = 0f;
                            }
                            vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(0, GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, -0.5f, 0f));
                            vrrig.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.gameObject.transform.position);
                        }
                    }
                }
            }
            else
            {
                Debug.Log("Bro your not in a room...");
            }
        }
        public static void BoneESP()
        {
            if (PhotonNetwork.InRoom)
            {
                if (MenuSrc.ESPType == 1)
                {
                    if (GorillaGameManager.instance.GameModeName().ToString().Contains("CASUAL"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                {
                                    vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                }
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), Mathf.PingPong(Time.time, 1f));
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                {
                                    if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                    {
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                    }
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("INFECTION"))
                    {
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                }
                            }
                        }
                        else if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("BATTLE"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("bluealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                }
                                else if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("orangealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                }
                                else
                                {
                                    if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                    {
                                        vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                    }
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                    for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                    {
                                        if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                        vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                    }
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            foreach (Photon.Realtime.Player plawd in PhotonNetwork.PlayerListOthers)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                                    {
                                        if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                                        vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                                        for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                                        {
                                            if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                            {
                                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                            }
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                            vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (MenuSrc.ESPType == 2)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                            {
                                vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                            }
                            vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                            vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                            vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                            vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material.color = Color.HSVToRGB(smth, 1f, 1f);
                            smth += 0.006f;
                            if (smth >= 1f)
                            {
                                smth = 0f;
                            }
                            vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0, 0.160f, 0));
                            vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0, 0.4f, 0));

                            for (int i = 0; i < MenuSrc.bones.Count(); i += 2)
                            {
                                if (!vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>())
                                {
                                    vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.AddComponent<LineRenderer>();
                                }
                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().endWidth = 0.025f;
                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().startWidth = 0.025f;
                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.shader = Shader.Find("GUI/Text Shader");
                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().material.color = Color.HSVToRGB(smth, 1f, 1f);
                                smth += 0.006f;
                                if (smth >= 1f)
                                {
                                    smth = 0f;
                                }
                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[MenuSrc.bones[i]].position);
                                vrrig.mainSkin.bones[MenuSrc.bones[i]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[MenuSrc.bones[i + 1]].position);
                            }
                        }
                    }
                }
            }
            else
            {
                Debug.Log("Bro your not in a room...");
            }
        }
        public static void Beaons()
        {
            if(PhotonNetwork.InRoom)
            {
                if (MenuSrc.ESPType == 1)
                {
                    if (GorillaGameManager.instance.GameModeName().ToString().Contains("CASUAL"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.30f), Mathf.PingPong(Time.time, 1f));
                                Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                GameObject.Destroy(Beacon.GetComponent<Collider>());
                                Object.Destroy(Beacon, Time.deltaTime);
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("INFECTION"))
                    {
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                }
                            }
                        }
                        else if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("BATTLE"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("bluealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                }
                                else if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("orangealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                }
                                else
                                {
                                    GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                    Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                    Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                    GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                    GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                    GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                    GameObject.Destroy(Beacon.GetComponent<Collider>());
                                    Object.Destroy(Beacon, Time.deltaTime);
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            foreach (Photon.Realtime.Player plawd in PhotonNetwork.PlayerListOthers)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                                    {
                                        GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                        Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        Beacon.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                                        Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                                        GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                                        GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                                        GameObject.Destroy(Beacon.GetComponent<Collider>());
                                        Object.Destroy(Beacon, Time.deltaTime);
                                    }
                                }
                            }
                        }
                    }
                }
                else if (MenuSrc.ESPType == 2)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            GameObject Beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                            Beacon.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            Beacon.GetComponent<Renderer>().material.color = Color.HSVToRGB(smth, 1f, 1f);
                            smth += 0.006f;
                            if (smth >= 1f)
                            {
                                smth = 0f;
                            }
                            Beacon.transform.position = vrrig.head.rigTarget.gameObject.transform.position;
                            Beacon.transform.localScale = new Vector3(0.06f, 999, 0.06f);
                            GameObject.Destroy(Beacon.GetComponent<SphereCollider>());
                            GameObject.Destroy(Beacon.GetComponent<Rigidbody>());
                            GameObject.Destroy(Beacon.GetComponent<MeshCollider>());
                            GameObject.Destroy(Beacon.GetComponent<Collider>());
                            Object.Destroy(Beacon, Time.deltaTime);
                        }
                    }
                }
            }
        }
        public static void BoxESP()
        {
            if (PhotonNetwork.InRoom)
            {
                if (MenuSrc.ESPType == 1)
                {
                    if (GorillaGameManager.instance.GameModeName().ToString().Contains("CASUAL"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                boxthuign.transform.position = vrrig.transform.position;
                                boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.3f), new Color(vrrig.playerColor.r, vrrig.playerColor.g, vrrig.playerColor.b, 0.3f), Mathf.PingPong(Time.time, 1f));
                                Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                Object.Destroy(boxthuign, Time.deltaTime);
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("INFECTION"))
                    {
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                }
                            }
                        }
                        else if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                        {
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                    else if (!vrrig.mainSkin.material.name.Contains("fected"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("BATTLE"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("bluealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                }
                                else if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("orangealive"))
                                {
                                    if (vrrig.mainSkin.material.name.Contains("bluealive"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                    else if (vrrig.mainSkin.material.name.Contains("orangealive"))
                                    {
                                        GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        boxthuign.transform.position = vrrig.transform.position;
                                        boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                        boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                        Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                        Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                        Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                        boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                        Object.Destroy(boxthuign, Time.deltaTime);
                                    }
                                }
                                else
                                {
                                    GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                    boxthuign.transform.position = vrrig.transform.position;
                                    boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(1f, 0f, 0f, 0.30f), new Color(1f, 0f, 0.4f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                    Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                    Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                    boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                    Object.Destroy(boxthuign, Time.deltaTime);
                                }
                            }
                        }
                    }
                    else if (GorillaGameManager.instance.GameModeName().ToString().Contains("HUNT"))
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (GorillaGameManager.instance.FindPlayerVRRig(GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer)) == vrrig)
                                {
                                    GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                                    boxthuign.transform.position = vrrig.transform.position;
                                    boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    boxthuign.GetComponent<Renderer>().material.color = Color.Lerp(new Color(0f, 1f, 0f, 0.30f), new Color(0f, 1f, 0.7f, 0.30f), Mathf.PingPong(Time.time, 1f));
                                    Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                                    Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                                    Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                                    boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                                    Object.Destroy(boxthuign, Time.deltaTime);
                                }
                            }
                        }
                    }
                }
                else if (MenuSrc.ESPType == 2)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            GameObject boxthuign = GameObject.CreatePrimitive(PrimitiveType.Cube);
                            boxthuign.transform.position = vrrig.transform.position;
                            boxthuign.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            boxthuign.GetComponent<Renderer>().material.color = Color.HSVToRGB(smth, 1f, 1f);
                            smth += 0.006f;
                            if (smth >= 1f)
                            {
                                smth = 0f;
                            }
                            Object.Destroy(boxthuign.GetComponent<BoxCollider>());
                            Object.Destroy(boxthuign.GetComponent<Rigidbody>());
                            Object.Destroy(boxthuign.GetComponent<MeshCollider>());
                            boxthuign.transform.localScale = new Vector3(0.55f, 1f, 0.55f);
                            Object.Destroy(boxthuign, Time.deltaTime);
                        }
                    }
                }
            }
            else
            {
                Debug.Log("Bro your not in a room...");
            }
        }
    }
}