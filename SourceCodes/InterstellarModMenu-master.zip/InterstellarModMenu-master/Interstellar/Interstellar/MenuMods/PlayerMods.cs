﻿using UnityEngine;
using Photon.Pun;
using Interstellar.Main;
using Interstellar.Utility;
using System.Linq;
using Interstellar.Patches;
using GorillaNetworking;
using System.Reflection;
using BepInEx;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class PlayerMods : MonoBehaviour
    {

        static Vector3 gravHandle;
        static Vector3 handHandler;
        static float rgbthingy;
        static float rgbcooldown;
        static Color rgbColor;
        static bool TPRandom = false;
        static float smth = 0;
        static bool teleportGunAntiRepeat = false;
        static Color color;
        public static Vector3[] lastLeft = new Vector3[]
        {
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero
        };
        public static Vector3[] lastRight = new Vector3[]
        {
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero
        };
        public static void IronMonke()
        {
            if (ControllerInputPoller.instance.leftGrab)
            {
                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(MenuSrc.ironMonkey * GorillaLocomotion.Player.Instance.leftControllerTransform.right.x * -1f, MenuSrc.ironMonkey * GorillaLocomotion.Player.Instance.leftControllerTransform.right.y * -1f, MenuSrc.ironMonkey * GorillaLocomotion.Player.Instance.leftControllerTransform.right.z * -1f), ForceMode.Acceleration);
            }
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
            {
                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(MenuSrc.ironMonkey * GorillaLocomotion.Player.Instance.rightControllerTransform.right.x, MenuSrc.ironMonkey * GorillaLocomotion.Player.Instance.rightControllerTransform.right.y, MenuSrc.ironMonkey * GorillaLocomotion.Player.Instance.rightControllerTransform.right.z), ForceMode.Acceleration);
            }
        }
        public static void Bees()
        {
            if (smth < Time.time + 0.2f)
            {
                GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                System.Random random = new System.Random();
                int funny = random.Next(1, GorillaParent.instance.vrrigDict.Count - 1);
                GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(-94.1266f, 9999f, -132.3289f);
                GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(-94.1266f, 9999f, -132.3289f);
                GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 8f, 0f);
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaParent.instance.vrrigs[funny].transform.position + new Vector3(0f, 0.8f, 0f);
            }
        }
        public static void UPNDOWN()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
            {
                GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(1500, GorillaLocomotion.Player.Instance.transform.position, 10, 10);
            }
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
            {
                GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddExplosionForce(-1800, GorillaLocomotion.Player.Instance.transform.position, 10, 10);
            }
        }
        public static void TPRandomW()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (!TPRandom)
                {
                    if (PhotonNetwork.PlayerListOthers.Count() > 3)
                    {
                        System.Random random = new System.Random();
                        int i = random.Next(1, GorillaParent.instance.vrrigDict.Count);
                        foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                        {
                            meshCollider.enabled = false;
                        }
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = GorillaParent.instance.vrrigs[i].transform.position + new Vector3(0f, 0.5f, 0f);
                        TPRandom = true;
                    }
                    else if (PhotonNetwork.PlayerListOthers.Count() < 3)
                    {
                        NotifiLib.SendWithCooldown("<color=red>PLAYER COUNT IS TOO LOW</color>", 3);
                    }
                }
                else
                {
                    foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                    {
                        meshCollider.enabled = true;
                    }
                    TPRandom = true;
                }
            }
            else
            {
                TPRandom = false;
            }
        }
        public static void PunchMod()
        {
            int rigs = -1;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    rigs++;
                    Vector3 others = vrrig.rightHandTransform.position;
                    Vector3 me = GorillaTagger.Instance.offlineVRRig.transform.position;
                    float distance = Vector3.Distance(others, me);
                    if (distance < 0.4)
                    {
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.rightHandTransform.position - lastRight[rigs]) * 10f;
                    }
                    lastRight[rigs] = vrrig.rightHandTransform.position;
                    if (distance < 0.4)
                    {
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.leftHandTransform.position - lastLeft[rigs]) * 10f;
                    }
                    lastLeft[rigs] = vrrig.leftHandTransform.position;
                }
            }
        }
        public static void AirStrike()
        {
            if (MenuSrc.GunHand == 1)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = new Vector3(0, 40, 0);
                            teleportGunAntiRepeat = true;
                            foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                            {
                                mawd.enabled = false;
                            }
                        }
                    }
                    else
                    {
                        foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                        {
                            mawd.enabled = true;
                        }
                        teleportGunAntiRepeat = false;
                    }
                }
                else
                {
                    
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.leftGrab)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        if (!teleportGunAntiRepeat)
                        {
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position = hit.point;
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = new Vector3(0, 45, 0);
                            teleportGunAntiRepeat = true;
                            foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                            {
                                mawd.enabled = false;
                            }
                            wwd.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                        }
                    }
                    else
                    {
                        foreach (MeshCollider mawd in Resources.FindObjectsOfTypeAll<MeshCollider>())
                        {
                            mawd.enabled = true;
                        }
                        teleportGunAntiRepeat = false;
                        wwd.material = ColorManager.ColorScheme;
                    }
                }
                else
                {
                    
                }
            }
            else if (MenuSrc.GunHand == 3)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hitw);
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.leftGrab)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        Vector3 awd = (hit.point - GorillaLocomotion.Player.Instance.transform.position).normalized * 4;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(awd, hit.point, ForceMode.VelocityChange);
                        wwd.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        wwd.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    }
                }
                else
                {

                }
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
                    wwd.SetPosition(1, hitw.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hitw.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        Vector3 awd = (hit.point - GorillaLocomotion.Player.Instance.transform.position).normalized * 4;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(awd, hit.point, ForceMode.VelocityChange);
                        wwd.GetComponent<Renderer>().material = ColorManager.OnTriggerGuns;
                    }
                    else
                    {
                        wwd.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    }
                }
                else
                {

                }
            }
        }
        public static void CarMonke()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
            {
                Vector3 wdirPos = GorillaLocomotion.Player.Instance.headCollider.transform.forward.normalized * -28.5f;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(wdirPos, GorillaLocomotion.Player.Instance.headCollider.transform.position, ForceMode.Acceleration);
            }
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
            {
                Vector3 dirPos = GorillaLocomotion.Player.Instance.headCollider.transform.forward.normalized * 28.5f;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(dirPos, GorillaLocomotion.Player.Instance.headCollider.transform.position, ForceMode.Acceleration);
            }
        }
        public static void BunnyHop()
        {
            if (GorillaLocomotion.Player.Instance.IsHandTouching(false))
            {
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(Vector3.up * 220f, ForceMode.Impulse);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.right * 170f, ForceMode.Impulse);
            }
            if (GorillaLocomotion.Player.Instance.IsHandTouching(true))
            {
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(Vector3.up * 220f, ForceMode.Impulse);
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(-GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.right * 170f, ForceMode.Impulse);
            }
        }
        public static void WASD()
        {
            GorillaLocomotion.Player player = GorillaLocomotion.Player.Instance;
            Transform headCollider = player.headCollider.transform;
            player.GetComponent<Rigidbody>().velocity = Vector3.zero;
            if (UnityInput.Current.GetKey(KeyCode.Space))
            {
                player.gameObject.transform.position += new Vector3(0f, 0.1f, 0);
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftShift))
            {
                player.gameObject.transform.position += new Vector3(0f, -0.1f, 0);
            }
            if (UnityInput.Current.GetKey(KeyCode.W))
            {
                player.transform.position += headCollider.forward * 0.1f;
            }
            if (UnityInput.Current.GetKey(KeyCode.S))
            {
                player.transform.position -= headCollider.forward * 0.1f;
            }
            if (UnityInput.Current.GetKey(KeyCode.A))
            {
                Vector3 leftMovement = Quaternion.Euler(0, -90, 0) * headCollider.forward * 0.1f;
                player.gameObject.transform.position += leftMovement;
            }
            if (UnityInput.Current.GetKey(KeyCode.D))
            {
                Vector3 rightMovement = Quaternion.Euler(0, 90, 0) * headCollider.forward * 0.1f;
                player.gameObject.transform.position += rightMovement;
            }
            if (UnityInput.Current.GetKey(KeyCode.Q))
            {
                headCollider.Rotate(new Vector3(0, -3, 0));
            }
            if (UnityInput.Current.GetKey(KeyCode.E))
            {
                headCollider.Rotate(new Vector3(0, 3, 0));
            }
        }
        public static void RainbowMonk(float num)
        {
            if (GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").activeSelf == true)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    color = Color.HSVToRGB(smth, 1f, 1f);
                    smth += num;
                    if (smth >= 1f)
                    {
                        smth = 0f;
                    } //RGB

                    GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                    {
                    color.r,
                    color.g,
                    color.b,
                    });
                    
                }
                else if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    NotifiLib.SendWithCooldown("PLEASE GOTO STUMP", 2);
                }
            }
            else
            {
                NotifiLib.SendWithCooldown("MAKE SURE YOU ARE NEAR STUMP", 2);
            }
        }
        public static void GrappleMonk()
        {
            if (MenuSrc.GunHand == 1)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        Vector3 awd = (hit.point - GorillaLocomotion.Player.Instance.transform.position).normalized * 4;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(awd, hit.point, ForceMode.VelocityChange);
                    }
                    else
                    {
                       
                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                if (ControllerInputPoller.instance.leftGrab)
                {
                    GameObject dw = new GameObject("StandPoint");
                    LineRenderer wwd = dw.AddComponent<LineRenderer>();
                    wwd.material.shader = Shader.Find("GUI/Text Shader");
                    wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                    wwd.startWidth = 0.020f;
                    wwd.useWorldSpace = true;
                    wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.position);
                    wwd.SetPosition(1, hit.point);
                    UnityEngine.Object.Destroy(dw, Time.deltaTime);


                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                    Object.Destroy(pointer.GetComponent<Collider>());
                    pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                    pointer.transform.position = hit.point;
                    Object.Destroy(pointer, Time.deltaTime);
                    if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                    {
                        GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        Vector3 awd = (hit.point - GorillaLocomotion.Player.Instance.transform.position).normalized * 4;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForceAtPosition(awd, hit.point, ForceMode.VelocityChange);
                    }
                    else
                    {
                        
                    }
                }
            }
        }
        public static void SetNameNothing()
        {
            NetworkSystemPUN.Instance.SetMyNickName("");
            PlayerPrefs.Save();
        }
        public static void StealPlayer()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        Debug.Log("line start");
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;

                            Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!teleportGunAntiRepeat)
                            {
                                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    color = GorillaGameManager.instance.FindPlayerVRRig(player).playerColor;
                                    GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                                    PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                                    {
    color.r,
    color.g,
    color.b,
                                    });
                                    NetworkSystemPUN.Instance.SetMyNickName(player.NickName);
                                    PlayerPrefs.Save();
                                    teleportGunAntiRepeat = true;
                                    NotifiLib.SendWithCooldown($"YOU HAVE STOLEN [<color=blue>{player.NickName}</color>]'s IDENTITY", 1);
                                }
                                else if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    VRRigMods.CheckNewRig();
                                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                                }
                                teleportGunAntiRepeat = true;
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(rayPoint.collider.GetComponentInParent<VRRig>()).Owner;
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            teleportGunAntiRepeat = false;
                            VRRigMods.vRrig.enabled = false;
                            VRRigMods.vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
                else
                {
                    teleportGunAntiRepeat = false;
                    VRRigMods.vRrig.enabled = false;
                    VRRigMods.vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        Debug.Log("line start");
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }

                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);
                            kmma.material = ColorManager.ColorScheme;


                            Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!teleportGunAntiRepeat)
                            {
                                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    color = GorillaGameManager.instance.FindPlayerVRRig(player).playerColor;
                                    GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                                    PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
                                    {
    color.r,
    color.g,
    color.b,
                                    });
                                    NetworkSystemPUN.Instance.SetMyNickName(player.NickName);
                                    PlayerPrefs.Save();
                                    teleportGunAntiRepeat = true;
                                    NotifiLib.SendWithCooldown($"YOU HAVE STOLEN [<color=blue>{player.NickName}</color>]'s IDENTITY", 2);
                                }
                                else if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                                {
                                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    VRRigMods.CheckNewRig();
                                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                                }
                                teleportGunAntiRepeat = true;
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            Photon.Realtime.Player player = InterstellarUtils.GetPhotonView(rayPoint.collider.GetComponentInParent<VRRig>()).Owner;
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                        }
                        else
                        {
                            teleportGunAntiRepeat = false;
                            VRRigMods.vRrig.enabled = false;
                            VRRigMods.vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
                else
                {
                    teleportGunAntiRepeat = false;
                    VRRigMods.vRrig.enabled = false;
                    VRRigMods.vRrig.transform.position = Vector3.zero;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }
        public static void Frozone()
        {
            if (ControllerInputPoller.instance.leftGrab)
            {
                GameObject adwad = GameObject.CreatePrimitive(PrimitiveType.Cube);
                adwad.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                adwad.transform.position = new Vector3(0f, -0.0625f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                adwad.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.transform.rotation;
                adwad.GetComponent<Renderer>().material = new Material(Shader.Find("GorillaTag/UberShader"));
                adwad.GetComponent<Renderer>().material.color = new Color(0.769f, 0.984f, 1f, 1f);
                adwad.AddComponent<GorillaSurfaceOverride>().overrideIndex = 59;

                UnityEngine.Object.Destroy(adwad, 0.85f);
            }
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
            {
                GameObject adwadw = GameObject.CreatePrimitive(PrimitiveType.Cube);
                adwadw.transform.localScale = new Vector3(0.04f, 0.15f, 0.25f);
                adwadw.transform.position = new Vector3(0f, -0.0625f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position;
                adwadw.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.transform.rotation;
                adwadw.GetComponent<Renderer>().material = new Material(Shader.Find("GorillaTag/UberShader"));
                adwadw.GetComponent<Renderer>().material.color = new Color(0.769f, 0.984f, 1f, 1f);
                adwadw.AddComponent<GorillaSurfaceOverride>().overrideIndex = 59;

                UnityEngine.Object.Destroy(adwadw, 0.85f);
            }
        }
        public static void SpoofPlayer()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    if (Time.time > smth + 0.5f)
                    {
                        RGBShit();
                        string[] randomnames = new string[]
                        {
                    "PHOTON",
                    "TICKLETIPJR",
                    "BTC",
                    "ETH",
                    "LTC",
                    "XMR",
                    "REV",
                    "OCT",
                    "JMANCURLY",
                    "ELLIOT",
                    "VMT",
                    "UNITYENGINE",
                    "GORILLA",
                    "RPCABUSER",
                    "CONNORVR",
                    "NETWORKING",
                    "TUNDRACLIENT",
                    "JELLOVR",
                    "INTERSTELLAR"
                        };
                        int Rando = new System.Random().Next(0, randomnames.Length - 1);
                        NetworkSystemPUN.Instance.SetMyNickName(randomnames[Rando]);
                        PlayerPrefs.Save();
                        smth = Time.time;
                    }
                }
                else if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                    NotifiLib.SendWithCooldown("<color=red>Please Goto Stump for better Results</color>", 2.5f);
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void SpoofName()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    if (Time.time > smth + 0.5f)
                    {
                        string[] randomnames = new string[]
                        {
                    "JOHN",
    "SARAH",
    "MICHAEL",
    "EMILY",
    "DAVID",
    "JESSICA",
    "MATTHEW",
    "OLIVIA",
    "CHRISTOPHER",
    "ELIZABETH",
    "ANDREW",
    "HANNAH",
    "JAMES",
    "SOPHIA",
    "DANIEL",
    "ALEXANDRA",
    "WILLIAM",
    "VICTORIA",
    "NICHOLAS",
    "CHARLOTTE",
    "RYAN",
    "MIA",
    "JOSHUA",
    "AVA",
    "JASON",
    "NATALIE",
    "KEVIN",
    "GRACE",
    "PATRICK",
    "CHLOE",
    "BRIAN",
    "ZOEY",
    "ERIC",
    "SAMANTHA",
    "STEVEN",
    "BaARTHOLOMEW"
                        };
                        int Rando = new System.Random().Next(0, randomnames.Length);
                        NetworkSystemPUN.Instance.SetMyNickName(randomnames[Rando]);
                        PlayerPrefs.Save();
                        smth = Time.time;
                    }
                }
                else if (!GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-66.9768f, 11.8297f, -83.3592f);
                    NotifiLib.SendWithCooldown("GOTO STUMP FOR IMPROVED RESULTS", 2);
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void WallWalk()
        {
            bool notRightGrab = ControllerInputPoller.instance.rightControllerGripFloat == 0;
            bool notLeftGrab = ControllerInputPoller.instance.leftControllerGripFloat == 0;
            bool rightGrab = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f;
            bool leftGrab = ControllerInputPoller.instance.leftControllerGripFloat > 0.1f;
            if (GorillaLocomotion.Player.Instance.wasLeftHandTouching || GorillaLocomotion.Player.Instance.wasRightHandTouching)
            {
                FieldInfo fieldInfo = typeof(GorillaLocomotion.Player).GetField("lastHitInfoHand", BindingFlags.NonPublic | BindingFlags.Instance);
                RaycastHit hit = (RaycastHit)fieldInfo.GetValue(GorillaLocomotion.Player.Instance);
                handHandler = hit.point;
                gravHandle = hit.normal;
            }
            if (notLeftGrab || notRightGrab)
            {
                rightGrab = false;
                leftGrab = false;
                handHandler = Vector3.zero;
                InterstellarUtils.GravityChanger("reset");
            }
            if (rightGrab || leftGrab)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(gravHandle * -9.81f, ForceMode.Acceleration);
                InterstellarUtils.GravityChanger("none");
            }
        }
        public static void AutoJuke()
        {
            foreach (VRRig wqad in GorillaParent.instance.vrrigs)
            {
                if (wqad != GorillaTagger.Instance.offlineVRRig)
                {
                    if (wqad.mainSkin.material.name.Contains("fected"))
                    {
                        if (Vector3.Distance(wqad.transform.position, GorillaLocomotion.Player.Instance.transform.position) < 3)
                        {
                            Quaternion awd = Quaternion.LookRotation(wqad.transform.position - GorillaLocomotion.Player.Instance.transform.position);
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().AddForce(awd * Vector3.forward * 20, ForceMode.Impulse);
                        }
                    }
                }
            }
        }


        public static void RGBReset()
        {
            float redValue = PlayerPrefs.GetFloat("redValue", 0f);
            float greenValue = PlayerPrefs.GetFloat("greenValue", 0f);
            float blueValue = PlayerPrefs.GetFloat("blueValue", 0f);
            GorillaTagger.Instance.UpdateColor(redValue, greenValue, blueValue);
            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("InitializeNoobMaterial", RpcTarget.All, redValue, greenValue, blueValue);
        }
        static void RGBShit()
        {
            if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
            {
                if (Time.time > rgbcooldown + 0.2f)
                {
                    rgbcooldown = Time.time;
                    rgbthingy += 0.2f;

                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                    {
                        if (rgbthingy >= 0.2f)
                        {
                            rgbColor = Color.red;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.3f)
                        {
                            rgbColor = Color.yellow;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.4f)
                        {
                            rgbColor = Color.green;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.5f)
                        {
                            rgbColor = Color.cyan;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);

                        }
                        if (rgbthingy >= 0.6f)
                        {
                            rgbColor = Color.blue;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);
                        }
                        if (rgbthingy >= 0.7f)
                        {
                            rgbColor = Color.magenta;
                            GorillaTagger.Instance.UpdateColor(rgbColor.r, rgbColor.g, rgbColor.b);
                            if (PhotonNetwork.InRoom)
                                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, rgbColor.r, rgbColor.g, rgbColor.b, false);
                        }


                        if (rgbthingy >= 0.7f)
                        {
                            rgbthingy = 0f;
                        }

                    }
                }
            }
        }
    }
}