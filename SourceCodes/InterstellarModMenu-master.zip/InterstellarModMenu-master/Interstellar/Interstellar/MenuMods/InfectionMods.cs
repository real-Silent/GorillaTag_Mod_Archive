﻿using Interstellar.Main;
using Interstellar.Patches;
using Interstellar.Utility;
using Photon.Pun;
using UnityEngine;
using GorillaGameModes;
using ExitGames.Client.Photon;
using UnityEngine.InputSystem;

namespace Interstellar.MenuMods
{
    public class InfectionMods : MonoBehaviour
    {
        public static float smth = 0f;
        static bool clickedOnce = false;

        public static void TagSelf()
        {
            if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer) && !PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig.mainSkin.material.name.Contains("infected") && !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.rightHandPlayer.transform.position;
                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = vrrig.headConstraint.transform.position;
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = vrrig.headConstraint.transform.position;
                    }
                }
            }
            else if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer) && PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().AddInfectedPlayer(PhotonNetwork.LocalPlayer);
            }
            else
            {
                MenuSrc.Pg56Active[1] = false;
                InterstellarUtils.ReDrawMenu();
                NotifiLib.SendWithCooldown("<color=green>YOU ARE TAGGED</color>", 3);
            }
        }
        public static void TagGun()
        {
            if (GorillaGameManager.instance.GameModeName().Contains("INFECTION") || (GorillaGameManager.instance.GameModeName().Contains("HUNT")) && PhotonNetwork.InRoom)
            {
                if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    if (MenuSrc.GunHand == 1)
                    {
                        if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                        {
                            RaycastHit rayPoint;
                            if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                            {
                                if (Mouse.current.rightButton.isPressed)
                                {
                                    Ray ray = MenuSrc.TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                                    Physics.Raycast(ray, out rayPoint, 100);
                                }

                                GameObject iuhe = new GameObject("ArchCore");
                                LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                                kmma.material.shader = Shader.Find("GUI/Text Shader");
                                kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                kmma.startWidth = 0.020f;
                                kmma.useWorldSpace = true;
                                kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                                Object.Destroy(iuhe, Time.deltaTime);
                                if (MenuSrc.playerLock == null)
                                {
                                    kmma.SetPosition(1, rayPoint.point);
                                }


                                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f  && MenuSrc.playerLock != null || Mouse.current.leftButton.isPressed && MenuSrc.playerLock != null)
                                {
                                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                                    Object.Destroy(pointer.GetComponent<Collider>());
                                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                    pointer.transform.position = MenuSrc.playerLock.transform.position;
                                    Object.Destroy(pointer, Time.deltaTime);
                                    kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                    Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                                    VRRig ijfaw = GorillaGameManager.instance.FindPlayerVRRig(gjei);
                                    if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(gjei) || !ijfaw.mainSkin.material.name.Contains("fected"))
                                    {
                                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                                        VRRigMods.CheckNewRig();
                                        GorillaTagger.Instance.offlineVRRig.transform.position = MenuSrc.playerLock.headConstraint.transform.position + new Vector3(0.8f, 0f, 0f);
                                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = MenuSrc.playerLock.transform.position;
                                        GorillaTagger.Instance.offlineVRRig.transform.LookAt(MenuSrc.playerLock.transform.position);

                                        GameMode.ReportTag(gjei);
                                    }
                                    else
                                    {
                                        Debug.Log($"{gjei.NickName} is TAGGED");
                                    }
                                    GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                }
                                else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                                {
                                    MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                    Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                                }
                                else
                                {
                                    kmma.SetPosition(1, rayPoint.point);
                                    VRRigMods.vRrig.enabled = false;
                                    VRRigMods.vRrig.transform.position = Vector3.zero;
                                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                                    MenuSrc.playerLock = null;
                                }
                            }
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            VRRigMods.vRrig.enabled = false;
                            VRRigMods.vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else if (MenuSrc.GunHand == 2)
                    {
                        if (ControllerInputPoller.instance.leftGrab)
                        {
                            RaycastHit rayPoint;
                            if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                            {
                                GameObject iuhe = new GameObject("ArchCore");
                                LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                                kmma.material.shader = Shader.Find("GUI/Text Shader");
                                kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                kmma.startWidth = 0.020f;
                                kmma.useWorldSpace = true;
                                kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                                UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                                if (MenuSrc.playerLock == null)
                                {
                                    kmma.SetPosition(1, rayPoint.point);
                                }


                                if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                                {
                                    GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                    Object.Destroy(pointer.GetComponent<Rigidbody>());
                                    Object.Destroy(pointer.GetComponent<SphereCollider>());
                                    Object.Destroy(pointer.GetComponent<MeshCollider>());
                                    Object.Destroy(pointer.GetComponent<Collider>());
                                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                    pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                    pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                    pointer.transform.position = MenuSrc.playerLock.transform.position;
                                    Object.Destroy(pointer, Time.deltaTime);
                                    kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                                    Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                                    VRRig ijfaw = GorillaGameManager.instance.FindPlayerVRRig(gjei);
                                    if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(gjei) || !ijfaw.mainSkin.material.name.Contains("fected"))
                                    {
                                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                                        VRRigMods.CheckNewRig();
                                        GorillaTagger.Instance.offlineVRRig.transform.position = MenuSrc.playerLock.headConstraint.transform.position + new Vector3(0.8f, 0f, 0f);
                                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = MenuSrc.playerLock.transform.position;
                                        GorillaTagger.Instance.offlineVRRig.transform.LookAt(MenuSrc.playerLock.transform.position);

                                        GameMode.ReportTag(gjei);
                                    }
                                    else
                                    {
                                        Debug.Log($"{gjei.NickName} is TAGGED");
                                    }

                                    GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                                }
                                else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                                {
                                    MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                                    Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                                }
                                else
                                {
                                    kmma.SetPosition(1, rayPoint.point);
                                    VRRigMods.vRrig.enabled = false;
                                    VRRigMods.vRrig.transform.position = Vector3.zero;
                                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                                    MenuSrc.playerLock = null;
                                }

                            }
                        }
                        else
                        {
                            MenuSrc.playerLock = null;
                            VRRigMods.vRrig.enabled = false;
                            VRRigMods.vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        NotifiLib.SendWithCooldown("<color=red>PLEASE GO TO AN INFECTION LOBBY</color>", 5);
                    }
                }
                else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    if (PhotonNetwork.IsMasterClient)
                    {
                        if (MenuSrc.GunHand == 1)
                        {
                            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
                            if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                            {
                                GameObject dw = new GameObject("StandPoint");
                                LineRenderer wwd = dw.AddComponent<LineRenderer>();
                                wwd.material.shader = Shader.Find("GUI/Text Shader");
                                wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                wwd.startWidth = 0.020f;
                                wwd.useWorldSpace = true;
                                wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                                wwd.SetPosition(1, hit.point);
                                UnityEngine.Object.Destroy(dw, Time.deltaTime);


                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = hit.point;
                                Object.Destroy(pointer, Time.deltaTime);
                                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
                                {
                                    Photon.Realtime.Player player = hit.collider.GetComponentInParent<VRRig>().Creator;
                                    GorillaTagManager gorillaTagManager = GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>();
                                    if (!gorillaTagManager.currentInfected.Contains(player))
                                    {
                                        gorillaTagManager.currentInfected.Add(player);
                                    }
                                    else
                                    {
                                        Debug.Log("<color=green>PLAYER IS TAGGED</color>");
                                    }
                                }
                            }
                        }
                        else if (MenuSrc.GunHand == 2)
                        {
                            Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out var hit);
                            if (ControllerInputPoller.instance.leftGrab)
                            {
                                GameObject dw = new GameObject("StandPoint");
                                LineRenderer wwd = dw.AddComponent<LineRenderer>();
                                wwd.material.shader = Shader.Find("GUI/Text Shader");
                                wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                                wwd.startWidth = 0.020f;
                                wwd.useWorldSpace = true;
                                wwd.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.position);
                                wwd.SetPosition(1, hit.point);
                                UnityEngine.Object.Destroy(dw, Time.deltaTime);


                                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                Object.Destroy(pointer.GetComponent<Rigidbody>());
                                Object.Destroy(pointer.GetComponent<SphereCollider>());
                                Object.Destroy(pointer.GetComponent<MeshCollider>());
                                Object.Destroy(pointer.GetComponent<Collider>());
                                pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                                pointer.transform.position = hit.point;
                                Object.Destroy(pointer, Time.deltaTime);
                                if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f)
                                {
                                    Photon.Realtime.Player player = hit.collider.GetComponentInParent<VRRig>().Creator;
                                    GorillaTagManager gorillaTagManager = GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>();
                                    if (!gorillaTagManager.currentInfected.Contains(player))
                                    {
                                        gorillaTagManager.currentInfected.Add(player);
                                    }
                                    else
                                    {
                                        Debug.Log("<color=green>PLAYER IS TAGGED</color>");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        public static void TagAura(bool GUI = false)
        {
            if (PhotonNetwork.InRoom)
            {
                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                {
                    if (ControllerInputPoller.instance.rightControllerGripFloat > 0f || GUI)
                    {
                        if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            if (Time.time > smth + 0.1)
                            {
                                foreach (Photon.Realtime.Player plawd in PhotonNetwork.PlayerListOthers)
                                {
                                    foreach (VRRig iajwfi in GorillaParent.instance.vrrigs)
                                    {
                                        if (iajwfi.mainSkin.material.name.Contains("fected"))
                                        {
                                            Debug.Log("PLAYER IS TAGGED");
                                        }
                                        else if (!iajwfi.mainSkin.material.name.Contains("fected"))
                                        {
                                            GameMode.ReportTag(plawd);
                                        }
                                    }
                                }
                                smth = Time.time;
                            }
                        }
                        else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                        {
                            foreach (Photon.Realtime.Player kawd in PhotonNetwork.PlayerListOthers)
                            {
                                VRRig rig = GorillaGameManager.instance.FindPlayerVRRig(kawd);
                                if (rig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, rig.transform.position) <= 5f || Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position, rig.transform.position) <= 5f)
                                    {
                                        Photon.Realtime.Player dfwa = InterstellarUtils.GetPhotonView(rig.GetComponentInParent<VRRig>()).Owner;
                                        if (Time.time > smth + 0.1f)
                                        {
                                            foreach (VRRig iajwfi in GorillaParent.instance.vrrigs)
                                            {
                                                if (iajwfi.mainSkin.material.name.Contains("fected"))
                                                {
                                                    Debug.Log("PLAYER IS TAGGED");
                                                }
                                                else if (!iajwfi.mainSkin.material.name.Contains("fected"))
                                                {
                                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Add(dfwa);
                                                }
                                            }
                                            smth = Time.time;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        public static void TagAll()
        {
            foreach (Photon.Realtime.Player plawd in PhotonNetwork.PlayerListOthers)
            {
                if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Count != GameMode.ParticipatingPlayers.Count && !PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (!vrrig.mainSkin.material.name.Contains("fected") && vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                            {
                                TagSelf();
                            }
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.rightHandPlayer.transform.position;
                            InterstellarUtils.EnableHands();
                            GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = vrrig.headConstraint.transform.position;
                            GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = vrrig.headConstraint.transform.position;
                            if (Vector3.Distance(GorillaTagger.Instance.offlineVRRig.transform.position, vrrig.transform.position) < 2)
                            {
                                GameMode.ReportTag(plawd);
                            }
                        }
                    }
                }
                else if (PhotonNetwork.IsMasterClient)
                {
                    if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || !GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        TagSelf();
                    }
                    else if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(plawd))
                        {
                            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Add(plawd);
                        }
                    }
                }
                else
                {
                    MenuSrc.Pg56Active[4] = false;
                    InterstellarUtils.ReDrawMenu();
                    NotifiLib.SendWithCooldown("<color=green>ALL PLAYERS ARE TAGGED</color>", 2);
                }
            }
        }
        public static void TagPlayer(Photon.Realtime.Player tagPlayer)
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(tagPlayer))
                {
                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Add(tagPlayer);
                }
                else
                {
                    Debug.Log($"{tagPlayer.NickName} is TAGGED");
                }
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(tagPlayer))
                {
                    VRRig aksjnf = GorillaGameManager.instance.FindPlayerVRRig(tagPlayer);
                    GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    VRRigMods.CheckNewRig();
                    GorillaTagger.Instance.offlineVRRig.transform.position = aksjnf.headConstraint.transform.position + new Vector3(0.8f, 0f, 0f);
                    GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = aksjnf.transform.position;
                    GorillaTagger.Instance.offlineVRRig.transform.LookAt(aksjnf.transform.position);

                    GameMode.ReportTag(tagPlayer);
                }
                else
                {
                    Debug.Log($"{tagPlayer.NickName} is TAGGED");
                }
            }
        }

        public static void NoTagOnJoin()
        {
            if (!PhotonNetwork.InRoom)
            {
                PlayerPrefs.SetString("didTutorial", "nope");
                PlayerPrefs.Save();
                Hashtable hashtable = new Hashtable();
                hashtable.Add("didTutorial", "nope");
                PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, null, null);
            }
            else if (PhotonNetwork.InRoom)
            {
                if (PlayerPrefs.GetString("didTutorial", "nope") == "done")
                {
                    NotifiLib.SendWithCooldown("<color=red>PLEASE LEAVE THIS ROOM FOR BETTER RESULTS</color>", 2);
                }
                else if (PlayerPrefs.GetString("didTutorial", "nope") == "nope")
                {
                    PlayerPrefs.SetString("didTutorial", "done");
                    PlayerPrefs.Save();
                    Hashtable hashtable = new Hashtable();
                    hashtable.Add("didTutorial", "done");
                    PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, null, null);
                    NotifiLib.SendWithCooldown("<color=green>MOD SUCCESSFUL</color>", 2);
                }
            }
        }

        public static void UntagAll()
        {
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            {
                UntagPlayer(player);
            }
        }
        public static void UntagGun()
        {
            if (MenuSrc.GunHand == 1)
            {
                if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (!clickedOnce)
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(gjei);
                                    clickedOnce = true;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: false, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            clickedOnce = false;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
            else if (MenuSrc.GunHand == 2)
            {
                if (ControllerInputPoller.instance.leftGrab)
                {
                    RaycastHit rayPoint;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.leftControllerTransform.position - GorillaLocomotion.Player.Instance.leftControllerTransform.up, -GorillaLocomotion.Player.Instance.leftControllerTransform.up, out rayPoint))
                    {
                        GameObject iuhe = new GameObject("ArchCore");
                        LineRenderer kmma = iuhe.AddComponent<LineRenderer>();
                        kmma.material.shader = Shader.Find("GUI/Text Shader");
                        kmma.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                        kmma.startWidth = 0.020f;
                        kmma.useWorldSpace = true;
                        kmma.SetPosition(0, GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position);
                        UnityEngine.Object.Destroy(iuhe, Time.deltaTime);
                        if (MenuSrc.playerLock == null)
                        {
                            kmma.SetPosition(1, rayPoint.point);
                        }


                        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock != null)
                        {
                            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            Object.Destroy(pointer.GetComponent<Rigidbody>());
                            Object.Destroy(pointer.GetComponent<SphereCollider>());
                            Object.Destroy(pointer.GetComponent<MeshCollider>());
                            Object.Destroy(pointer.GetComponent<Collider>());
                            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                            pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                            pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                            pointer.transform.position = MenuSrc.playerLock.transform.position;
                            Object.Destroy(pointer, Time.deltaTime);
                            kmma.SetPosition(1, MenuSrc.playerLock.transform.position);

                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                NotifiLib.SendWithCooldown("<color=red>{YOU ARE NOT MASTER}</color>", 3);
                            }
                            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                            {
                                if (!clickedOnce)
                                {
                                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(gjei);
                                    clickedOnce = true;
                                }
                            }
                            GorillaTagger.Instance.StartVibration(forLeftController: true, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration * 0.5f);
                        }
                        else if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && MenuSrc.playerLock == null)
                        {
                            MenuSrc.playerLock = rayPoint.collider.GetComponentInParent<VRRig>();
                            Photon.Realtime.Player gjei = InterstellarUtils.GetPhotonView(MenuSrc.playerLock).Owner;
                        }
                        else
                        {
                            clickedOnce = false;
                            MenuSrc.playerLock = null;
                            kmma.SetPosition(1, rayPoint.point);
                        }

                    }
                }
            }
        }
        public static void UntagAura()
        {
            if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 2);
            }
            else if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                for (int i = 0; i < GameMode.ParticipatingPlayers.Count; i++)
                {
                    VRRig rigs = GorillaGameManager.instance.FindPlayerVRRig(GameMode.ParticipatingPlayers[i]);
                    if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, rigs.transform.position) <= 4.5)
                    {
                        if (!rigs.isMyPlayer && !rigs.isOfflineVRRig && rigs != GorillaTagger.Instance.offlineVRRig)
                        {
                            Photon.Realtime.Player ihwad = InterstellarUtils.GetPhotonView(rigs.GetComponentInParent<VRRig>()).Owner;
                            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(ihwad);
                        }
                    }
                }
            }
        }
        public static void TouchToUntag()
        {
            if (PhotonNetwork.InRoom || PhotonNetwork.CurrentRoom != null)
            {
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                {
                    VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                    if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, vrrig.transform.position) <= 0.5f || Vector3.Distance(GorillaLocomotion.Player.Instance.leftControllerTransform.transform.position, vrrig.transform.position) <= 0.5f)
                        {
                            Photon.Realtime.Player ohsjer = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                            if (Time.time > smth + 0.1)
                            {
                                GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(ohsjer);
                                smth = Time.time;
                            }
                        }
                    }
                }
            }
        }
        public static void UntagPlayer(Photon.Realtime.Player untagPlayer)
        {
            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(untagPlayer);
            }
            else if (!PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                NotifiLib.SendWithCooldown("<color=red>YOU ARE NOT MASTER</color>", 2);
            }
        }

        public static void AntiTag()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (!PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    if (vrrig.mainSkin.material.name.Contains("infected") && !vrrig.isMyPlayer && !vrrig.isOfflineVRRig)
                    {
                        if (Vector3.Distance(GorillaLocomotion.Player.Instance.transform.position, vrrig.transform.position) <= 4)
                        {
                            GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            VRRigMods.CheckNewRig();
                            GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, -999f, 0f);
                        }
                        else if (Vector3.Distance(GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().transform.position, vrrig.transform.position) >= 5)
                        {
                            VRRigMods.vRrig.enabled = false;
                            VRRigMods.vRrig.transform.position = Vector3.zero;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
                else if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Remove(PhotonNetwork.LocalPlayer);
                }
                else
                {
                    NotifiLib.SendWithCooldown("<color=green>YOU ARE TAGGED</color>", 3);
                }
            }
        }
    }
}