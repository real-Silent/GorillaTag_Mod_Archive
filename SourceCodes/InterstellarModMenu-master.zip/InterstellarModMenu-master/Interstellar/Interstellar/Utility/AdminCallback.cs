﻿using Photon.Realtime;
using Photon.Pun;
using UnityEngine;
using ExitGames.Client.Photon;

namespace Interstellar.Utility
{
    public class AdminCallback : IOnEventCallback
    {
        void IOnEventCallback.OnEvent(EventData data)
        {
            byte eventCode = data.Code;
            object eventData = data.CustomData;
            if (eventCode == 194)
            {
                Debug.Log(data.Sender);
                object[] array = (object[])data.CustomData;
                PhotonMessageInfo messageInfo = (PhotonMessageInfo)array[1];
                if ((string)array[0] == "kick" && InterstellarUtils.webPageContent.Contains((string)array[1]) && InterstellarUtils.adminInRoom)
                {
                    PhotonNetwork.Disconnect();
                }
            }
        }

        /*
        public static void Test()
        {
            object[] array = new object[]
            {
                  "kick", // action
                  PhotonNetwork.LocalPlayer.UserId, // pass this UserID to see if it matches to an admin
                  PhotonNetwork.LocalPlayer // target (not needed / used in some cases)
            };
            RaiseEventOptions raiseEventOptions = new RaiseEventOptions
            {
                Receivers = ReceiverGroup.All
            };
            PhotonNetwork.RaiseEvent(194, array, raiseEventOptions, SendOptions.SendReliable);
        }
        */
    }
}