﻿using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using System.Net;
using Interstellar.Main;
using System;
using Interstellar.MenuMods;
using Interstellar.UI;

namespace Interstellar.Utility
{
    public class CustomBoards : MonoBehaviour
    {
        public static string motd = new WebClient().DownloadString("https://raw.githubusercontent.com/kingofnetflix/tundragame/main/interstellar.txt");
        static float checkTime = 0;
        static bool idk = true;
        static bool crashed = false;

        public static void Start()
        {
            Check();
        }
        public static void Check()
        {
            if (Time.time > checkTime + 60)
            {
                idk = true;
                checkTime = Time.time;
            }
            if (Time.time > 7 && crashed)
            {
                //Application.Quit();
            }
            try
            {
                if (idk)
                {
                    WebClient c = new WebClient();
                    var response = c.DownloadString("https://raw.githubusercontent.com/kingofnetflix/tundragame/main/interstellarstatus.txt").Trim();
                    Debug.Log($"VERSION TO CHECK: {response}, VERSION TO MATCH: {InterstellarLoader.version}");
                    if (response != InterstellarLoader.version.Trim() && response != "disabled")
                    {
                        //PhotonNetwork.Disconnect();
                        MenuSrc.init = false;
                        InterstellarUtils.ReDrawMenu();
                        Destroy(MenuSrc.MenuObj);
                        NotifiLib.SendWithCooldown("YOU ARE ON THE WRONG VERSION", 4);
                        NotifiLib.SendWithCooldown($"PLEASE UPDATE INTERSTELLAR MOD MENU. YOUR CURRENT MENU VERSION MAY BE OUTDATED!\nYOUR GAME WILL CLOSE SOON!\nVISIT OUR DISCORD FOR MORE HELP!\n\n<color=#3D03FC>discord.gg/interstellarmods</color>", 5f);
                        //GorillaComputer.instance.GeneralFailureMessage($"PLEASE UPDATE INT2ERSTELLAR MOD MENU. YOUR CURRENT MENU VERSION MAY BE OUTDATED!\nYOUR GAME WILL CLOSE SOON!\nVISIT OUR DISCORD FOR MORE HELP!\n\n<color=#3D03FC>discord.gg/interstellarmods</color>");
                    }
                    if (response == "disabled")
                    {
                        //PhotonNetwork.Disconnect();
                        NotifiLib.SendWithCooldown("THE MENU HAS BEEN SHUTDOWN", 4);
                        MenuSrc.init = false;
                        InterstellarUtils.ReDrawMenu();
                        Destroy(MenuSrc.MenuObj);
                        NotifiLib.SendWithCooldown($"INTERSTELLAR MOD MENU IS CURRENT NOT ABLE TO BE USED.\n\nVISIT OUR DISCORD FOR MORE INFORMATION.\n\n<color=#3D03FC>discord.gg/interstellarmods</color>", 5f);
                        //GorillaComputer.instance.GeneralFailureMessage($"INTERSTELLAR MOD MENU IS CURRENT NOT ABLE TO BE USED.\n\nVISIT OUR DISCORD FOR MORE INFORMATION.\n\n<color=#3D03FC>discord.gg/interstellarmods</color>");
                    }
                    idk = false;
                }
            }
            catch (Exception ex)
            {
                Debug.Log($"AN ERROR IS OCCURING: {ex.ToString()}");
            }
        }
        public static void LateUpdate()
        {
            for (int w = 0; w < GorillaComputer.instance.levelScreens.Length; w++)
            {
                GorillaComputer.instance.levelScreens[w].goodMaterial = ColorManager.ColorScheme;
                GorillaComputer.instance.levelScreens[w].badMaterial = ColorManager.ColorScheme;
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/StaticUnlit/motdscreen").GetComponent<Renderer>().material = ColorManager.ColorScheme;
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/StaticUnlit/screen").GetComponent<Renderer>().material = ColorManager.ColorScheme;    //COC Board
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/-- PhysicalComputer UI --/monitor").GetComponent<Renderer>().material = ColorManager.ColorScheme;  //MONITOR
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct").GetComponent<UnityEngine.UI.Text>().text = "-INTERSTELLAR-";  //COC TOP TEXT
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd").GetComponent<UnityEngine.UI.Text>().text = " - INTERSTELLAR MODS - ";    //MOTD TOP TEXT
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd/motdtext").GetComponent<UnityEngine.UI.Text>().text = "OWNER NOTICE-\n[-] WE (NETFLIX & I) AS THE OWNERS ARE NOT RESPONISBLE FOR ANY PURPOSEFUL BANS USING THIS MENU\n\n[-] ANTI-REPORT ONLY WORKS IN (<color=cyan>FOREST, CITY, AND CLOUDS</color>)\n\n\nMADE BY BTC AND NETFLIX                     <color=orange>[BE AWARE OF BUGS]</color>";
                GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct/COC Text").GetComponent<UnityEngine.UI.Text>().text = motd;    //COC BOTTOM TEXT

                if (PhotonNetwork.InRoom)
                {
                    GorillaComputer.instance.levelScreens[w].UpdateText($"[-] CURRENT MASTERCLIENT: [{PhotonNetwork.MasterClient.NickName.ToUpper()}]\n[-] CURRENT NAME: [{PhotonNetwork.LocalPlayer.NickName}]\n[-] CURRENT PLAYER COUNT: [{PhotonNetwork.CurrentRoom.PlayerCount}]\n[-] ROOM CODE: [{PhotonNetwork.CurrentRoom.Name}]\n[-] <color=cyan>ANTIBAN-STATUS</color>: [{RoomMods.antibanReady.ToString().ToUpper()}]", true);
                }
                else if (!PhotonNetwork.InRoom)
                {
                    GorillaComputer.instance.levelScreens[w].UpdateText($"WANDERING AROUND THE DEPTHS OF INTERSTELLAR AGAIN, [<color=#03FCA1>{PhotonNetwork.LocalPlayer.NickName}</color>]?\n\n\n\nUSER ID: {PhotonNetwork.LocalPlayer.UserId}.", true);
                }
            }
        }
    }
}
