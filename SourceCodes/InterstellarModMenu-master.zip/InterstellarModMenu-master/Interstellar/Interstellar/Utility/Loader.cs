﻿using System.Reflection;
using UnityEngine;
using BepInEx;
using HarmonyLib;
using Interstellar.Main;
using Interstellar.UI;

namespace Interstellar.Utility
{
    [BepInPlugin(GUI_guid, GUI_title, GUI_version)]
    public class InterstellarLoader : BaseUnityPlugin
    {
        public const string guid = "org.interstellar.menu";
        public const string title = "InterstellarMenu";
        public const string version = "2.0.1";
        public const string GUI_guid = "org.interstellar.gui";
        public const string GUI_title = "InterstellarGUI";
        public const string GUI_version = "1.0.0";
        public static InterstellarLoader instance;
        InterstellarLoader() { new Harmony(GUI_guid).PatchAll(Assembly.GetExecutingAssembly()); instance = this; }

        public void OnGameInitialised()
        {
            if (!GameObject.Find("InterstellarGUI"))
            {
                new GameObject().AddComponent<GUIMain>().gameObject.name = "InterstellarGUI";
                new GameObject().AddComponent<MenuSrc>().gameObject.name = "InterstellarMenu";
            }
        }
    }
}
