﻿using Photon.Realtime;
using Photon.Pun;
using UnityEngine;
using ExitGames.Client.Photon;

namespace Interstellar.Utility
{
    public class AdminFeatures : MonoBehaviour
    {
        static ControllerInputPoller input;
        public static void AdminKickGun()
        {
            input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hit);
            if (input.rightControllerGripFloat > 0.1f)
            {
                GameObject dw = new GameObject("StandPoint");
                LineRenderer wwd = dw.AddComponent<LineRenderer>();
                wwd.material.shader = Shader.Find("GUI/Text Shader");
                wwd.startColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                wwd.endColor = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                wwd.startWidth = 0.020f;
                wwd.useWorldSpace = true;
                wwd.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
                wwd.SetPosition(1, hit.point);
                UnityEngine.Object.Destroy(dw, Time.deltaTime);


                GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(pointer.GetComponent<Rigidbody>());
                Object.Destroy(pointer.GetComponent<SphereCollider>());
                Object.Destroy(pointer.GetComponent<MeshCollider>());
                Object.Destroy(pointer.GetComponent<Collider>());
                pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                pointer.GetComponent<Renderer>().material = ColorManager.ColorScheme;
                pointer.transform.position = hit.point;
                Object.Destroy(pointer, Time.deltaTime);
                if (input.rightControllerIndexFloat > 0.1f)
                {
                    object[] array = new object[]
                        {
                            "kick", // action
                            PhotonNetwork.LocalPlayer.UserId, // pass this UserID to see if it matches to an admin
                            //PhotonNetwork.LocalPlayer // target (not needed / used in some cases)
                        };
                    RaiseEventOptions raiseEventOptions = new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.All
                    };
                    PhotonNetwork.RaiseEvent(194, array, raiseEventOptions, SendOptions.SendReliable);
                }
                else
                {
                    
                }
            }
        }
    }
}