﻿using HarmonyLib;
using Interstellar.Main;
using Photon.Pun;
using UnityEngine;
using System.Net;
using System.Collections.Generic;
using System;
using System.Reflection;
using System.Linq;

namespace Interstellar.Utility
{
    public class InterstellarUtils : MonoBehaviour
    {
        public static List<Photon.Realtime.Player> adminList = new List<Photon.Realtime.Player>();
        public static string adminURL = "https://raw.githubusercontent.com/kingofnetflix/tundragame/main/interstellarids.txt";
        public static string webPageContent;
        public static bool once = false;
        public static bool adminInRoom = false;
        public static void CheckSafetyMode()
        {
            if (MenuSrc.abusiveMods > 3)
            {
                MenuSrc.abusiveMods = 1;
            }
            if (MenuSrc.abusiveMods == 1)
            {
                MenuSrc.enableAbusive = false;
                MenuSrc.Pg7Active[4] = false;
                MenuSrc.Pg7[4] = "Safe Mode: {Enabled}";
                InterstellarUtils.ReDrawMenu();
            }
            else if (MenuSrc.abusiveMods == 2)
            {
                MenuSrc.enableAbusive = true;
                MenuSrc.Pg7Active[4] = false;
                MenuSrc.Pg7[4] = "Safe Mode: {Disabled}";
                InterstellarUtils.ReDrawMenu();
            }
        }
        public static void CheckAntibanSafety()
        {
            if (MenuSrc.enableAbusive == false)
            {
                NotifiLib.SendWithCooldown("<color=red>SAFE MODE IS ENABLED.. TURN IT OFF TO ENABLE THIS SETTING</color>", 3);
            }
            if (MenuSrc.antiBanSafety > 3)
            {
                MenuSrc.antiBanSafety = 1;
            }
            if (MenuSrc.antiBanSafety == 1)
            {
                MenuSrc.enableAntiBanSafety = false;
                MenuSrc.Pg7Active[5] = false;
                MenuSrc.Pg7[5] = "Anti Ban Safety: {Disabled}";
                InterstellarUtils.ReDrawMenu();
            }
            else if (MenuSrc.abusiveMods == 2)
            {
                MenuSrc.enableAntiBanSafety = true;
                MenuSrc.Pg7Active[5] = false;
                MenuSrc.Pg7[5] = "Anti Ban Safety: {Enabled}";
                InterstellarUtils.ReDrawMenu();
            }
        }
        public static PhotonView GetPhotonView(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }
        public static void HeadSpinner(string localAxis)
        {
            if (localAxis == "X" || localAxis == "x")
            {
                GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x += 7;
            }
            if (localAxis == "Y" || localAxis == "y")
            {
                GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y += 7;
            }
            if (localAxis == "Z" || localAxis == "z")
            {
                GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z += 7;
            }
        }
        public static void GravityChanger(string type)
        {
            if (type == "moon" || type == "low")
            {
                Physics.gravity = new Vector3(0f, -4f, 0f);
            }
            if (type == "none")
            {
                Physics.gravity = new Vector3(0f, -0f, 0f);
            }
            if (type == "high" || type == "sun")
            {
                Physics.gravity = new Vector3(0f, -28f, 0f);
            }
            if (type == "reset")
            {
                Physics.gravity = new Vector3(0f, -9.81f, 0f);
            }
        }
        public static void ReDrawMenu()
        {
            GameObject.Destroy(MenuSrc.MenuObj);
            MenuSrc.MenuObj = null;
            GameObject.Destroy(MenuSrc.canvasPrevObj); MenuSrc.canvasPrevObj = null;
            GameObject.Destroy(MenuSrc.canvasDiscObj); MenuSrc.canvasDiscObj = null;
            GameObject.Destroy(MenuSrc.canvasNextObj); MenuSrc.canvasNextObj = null;
            MenuSrc.DrawMenu();
            MenuSrc.AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
            MenuSrc.AddCustomButton("PrevPage", 0.03f, false, 0.160f, 0.985f, 0.13f);
            MenuSrc.AddCustomButton("NextPage", 0.03f, false, 0.160f, 0.985f, -0.13f);
        }

        public static void GrabWebContent()
        {
            using (WebClient client = new WebClient())
            {
                webPageContent = client.DownloadString(adminURL);
            }
        }
        public static void DetectAdmins()
        {
            if (!once)
            {
                GrabWebContent();
                once = true;
            }
            foreach (Photon.Realtime.Player p in PhotonNetwork.PlayerList)
            {
                if (webPageContent.Contains(p.UserId) && webPageContent != null)
                {
                    VRRig adminVRRig = GorillaGameManager.instance.FindPlayerVRRig(p);

                    adminVRRig.playerText.color = new Color(0.416f, 0f, 1f, 1f);
                    adminVRRig.playerText.text = $"{p.NickName} [OWNER]";
                    adminInRoom = true;
                }
                else if (p.CustomProperties.ContainsKey("Interstellar") && !webPageContent.Contains(p.UserId) && webPageContent != null)
                {
                    VRRig awdww = GorillaGameManager.instance.FindPlayerVRRig(p);

                    awdww.playerText.color = new Color(0f, 1f, 0.678f, 1f);
                    awdww.playerText.text = $"{p.NickName} [USER]";
                }
                if (!webPageContent.Contains(p.UserId))
                {
                    adminInRoom = false;
                }
            }
        }

        public static bool AmICheckingGSD()
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            Assembly targetAssembly = assemblies.FirstOrDefault(a => a.GetName().Name == "Assembly-CSharp");

            if (targetAssembly != null)
            {
                Type projectileTrackerType = targetAssembly.GetTypes().FirstOrDefault(t => t.Name == "PlayerCosmeticsSystem");

                if (projectileTrackerType != null)
                {
                    FieldInfo field = projectileTrackerType.GetField("isLookingUp", BindingFlags.Instance | BindingFlags.NonPublic);

                    if (field != null)
                    {
                        object defaultValue = field.GetValue(Activator.CreateInstance(projectileTrackerType));
                        bool isLookingUp = (bool)defaultValue;
                        return isLookingUp;
                    }
                    else
                    {
                        Debug.Log("Field 'isLookingUp' not found in PlayerCosmeticsSystem.");
                        return false;
                    }
                }
                else
                {
                    Debug.Log("PlayerCosmeticsSystem class not found in Assembly-CSharp.");
                    return false;
                }
            }
            else
            {
                Debug.Log("Assembly-CSharp not found.");
                return false;
            }
        }
        public static bool IsModded()
        {
            if (PhotonNetwork.InRoom && PhotonNetwork.CurrentRoom.CustomProperties.ToString().Contains("MODDED"))
            {
                return true;
            }
            else if (!PhotonNetwork.CurrentRoom.CustomProperties.ToString().Contains("MODDED") || !PhotonNetwork.InRoom)
            {
                Debug.Log("Modded Lobby Validation Unsuccesful...");
                return false;
            }
            return false;
        }

        public static void QualityChanger(int quality)
        {
            QualitySettings.globalTextureMipmapLimit = quality;
        }

        public static void EnableHands()
        {
            System.Type type = GorillaLocomotion.Player.Instance.GetType();
            FieldInfo fieldInfo = type.GetField("leftHandHolding", BindingFlags.NonPublic | BindingFlags.Instance);
            fieldInfo.SetValue(GorillaLocomotion.Player.Instance, false);
            type = GorillaLocomotion.Player.Instance.GetType();
            fieldInfo = type.GetField("rightHandHolding", BindingFlags.NonPublic | BindingFlags.Instance);
            fieldInfo.SetValue(GorillaLocomotion.Player.Instance, false);
            GorillaLocomotion.Player.Instance.InReportMenu = false;
        }

        public static void FixPCGun()
        {
            if (MenuSrc.TPC == null)
            {
                try
                {
                    MenuSrc.TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch
                {
                    MenuSrc.TPC = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                }
            }
        }

    }
}