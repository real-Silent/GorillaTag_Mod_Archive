﻿using Interstellar.Main;
using UnityEngine;

namespace Interstellar.Utility
{
    public class ColorManager : MonoBehaviour
    {
        public static float smth = 0f;
        public static float MenuR = 31f / 255f;       //Else Statemtn for buttons
        public static float MenuG = 31f / 255f;
        public static float MenuB = 31f / 255f;
        public static float MenuA = 0.85f;

        public static float ButtonR;          //Button off Color
        public static float ButtonG;
        public static float ButtonB;

        public static float ButtonOnR;   //buttons on colors
        public static float ButtonOnG;
        public static float ButtonOnB;

        public static float ButtonTextR;   //button off text color
        public static float ButtonTextG;
        public static float ButtonTextB;

        public static float ButtonOnTextR;
        public static float ButtonOnTextG;   //button on text color
        public static float ButtonOnTextB;

        public static float CustomButtonTextColorR = 255f / 255f;
        public static float CustomButtonTextColorG = 255f / 255f;
        public static float CustomButtonTextColorB = 255f / 255f;
        public static Material ColorScheme = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material OnTriggerGuns = new Material(Shader.Find("GUI/Text Shader"));

        public static void OnTriggeredGuns()
        {
            OnTriggerGuns.color = Color.Lerp(new Color(0f, 0f, 0f, 1f), new Color(1f, 1f, 1f, 1f), Mathf.PingPong(Time.time, 1f));
        }

        public static void InterstellarScheme()
        {
            if (MenuSrc.ColorScheme == 1)  //PURPLE
            {
                ColorScheme.color = Color.Lerp(new Color(0.333f, 0f, 0.859f, 1f), new Color(0f, 0f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                ButtonR = 0f / 255f;
                ButtonG = 0f / 255f;  //BUTTONS OFF
                ButtonB = 0f / 255f;   //BLACK BUTTONS

                ButtonOnR = 85f / 255f;
                ButtonOnG = 0f / 255f;  //BUTTONS ON
                ButtonOnB = 219f / 255f;  //GREY BUTTONS

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 0f / 255f;
                ButtonOnTextG = 0f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 0f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 2) //MANGO
            {
                ColorScheme.color = new Color(0f, 0f, 15f / 255f);
                ButtonR = 20f / 255f;
                ButtonG = 25f / 255f;  //BUTTONS OFF
                ButtonB = 252f / 255f;   //BLUE

                ButtonOnR = 248f / 255f;
                ButtonOnG = 26f / 255f;  //BUTTONS ON
                ButtonOnB = 254f / 255f;  //PINK

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 0f / 255f;
                ButtonOnTextG = 0f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 0f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 3) //HORPON COLOR SCHEME
            {
                ColorScheme.color = Color.black;
                ButtonR = 0f / 255f;
                ButtonG = 0f / 255f;
                ButtonB = 0f / 255f;

                ButtonOnR = 0f / 255f;
                ButtonOnG = 0f / 255f;
                ButtonOnB = 255f / 255f;

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 255f / 255f;
                ButtonOnTextG = 255f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 255f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 4) //SHIBA GOLD
            {
                ColorScheme.color = Color.Lerp(Color.black, Color.yellow, Mathf.PingPong(Time.time, 1f));
                ButtonR = 255f / 255f;
                ButtonG = 255f / 255f;  //BUTTONS OFF
                ButtonB = 0f / 255f;   //BLUE

                ButtonOnR = 255f / 255f;
                ButtonOnG = 0f / 255f;  //BUTTONS ON
                ButtonOnB = 255f / 255f;  //PINK

                ButtonTextR = 0f / 255f;
                ButtonTextG = 0f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 0f / 255f; //WHITE TEXT

                ButtonOnTextR = 0f / 255f;
                ButtonOnTextG = 0f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 0f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 5) //STEAL COLORS SCHEME
            {
                ColorScheme.color = Color.Lerp(new Color(0.7f, 0f, 1f, 1f), new Color(0.8f, 0f, 1f, 1f), Mathf.PingPong(Time.time, 1f));
                ButtonR = 85f / 255f;
                ButtonG = 34f / 255f;  //BUTTONS OFF
                ButtonB = 119f / 255f;   //BLUE

                ButtonOnR = 144f / 255f;
                ButtonOnG = 69f / 255f;  //BUTTONS ON
                ButtonOnB = 195f / 255f;  //PINK

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 255f / 255f;
                ButtonOnTextG = 255f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 255f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 6) //iiDk Color Scheme
            {
                ColorScheme.color = Color.Lerp(new Color(1f, 0.5f, 0f, 1f), new Color(1f, 0.4f, 0f, 1f), Mathf.PingPong(Time.time, 1f));
                ButtonR = 170f / 255f;
                ButtonG = 85f / 255f;  //BUTTONS OFF
                ButtonB = 0f / 255f;   //BLUE

                ButtonOnR = 85f / 255f;
                ButtonOnG = 42f / 255f;  //BUTTONS ON
                ButtonOnB = 0f / 255f;  //PINK

                ButtonTextR = 255f / 255f;
                ButtonTextG = 190f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 125f / 255f; //WHITE TEXT

                ButtonOnTextR = 255f / 255f;
                ButtonOnTextG = 190f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 125f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 7) //WYVERN.LOL
            {
                ColorScheme.color = Color.Lerp(new Color(0.635f, 0.317f, 0.949f, 1f), new Color(0.635f, 0.317f, 0.949f, 1f), Mathf.PingPong(Time.time, 1f));
                ButtonR = 75f / 255f;
                ButtonG = 36f / 255f;  //BUTTONS OFF
                ButtonB = 113f / 255f;   //BLUE

                ButtonOnR = 75f / 255f;
                ButtonOnG = 36f / 255f;  //BUTTONS ON
                ButtonOnB = 113f / 255f;  //PINK

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 56f / 255f;
                ButtonOnTextG = 204f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 80f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 8) //FLIMCY
            {
                ColorScheme.color = Color.cyan;
                ButtonR = 125f / 255f;
                ButtonG = 125f / 255f;  //BUTTONS OFF
                ButtonB = 125f / 255f;   //BLUE

                ButtonOnR = 255f / 255f;
                ButtonOnG = 0f / 255f;  //BUTTONS ON
                ButtonOnB = 255f / 255f;  //PINK

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 255f / 255f;
                ButtonOnTextG = 255f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 255f / 255f; //BLACK TEXT
            }
            else if (MenuSrc.ColorScheme == 9) //CYCLONE
            {
                ColorScheme.color = Color.cyan;
                ButtonR = 2f / 255f;
                ButtonG = 148f / 255f;  //BUTTONS OFF
                ButtonB = 232f / 255f;   //BLUE

                ButtonOnR = 0f / 255f;
                ButtonOnG = 94f / 255f;  //BUTTONS ON
                ButtonOnB = 255f / 255f;  //PINK

                ButtonTextR = 255f / 255f;
                ButtonTextG = 255f / 255f;  //BUTTONTEXT OFF
                ButtonTextB = 255f / 255f; //WHITE TEXT

                ButtonOnTextR = 255f / 255f;
                ButtonOnTextG = 255f / 255f;  //BUTTONTEXT ON
                ButtonOnTextB = 255f / 255f; //BLACK TEXT
            }
        }
    }
}
