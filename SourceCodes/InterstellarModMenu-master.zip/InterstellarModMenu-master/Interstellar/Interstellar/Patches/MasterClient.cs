﻿using Photon.Realtime;
using HarmonyLib;
using Interstellar.Utility;
using Photon.Pun;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(RequestableOwnershipGuard), "OnMasterClientSwitched")]
    public class MasterClientChanged : MonoBehaviourPunCallbacks
    {
        public static bool Prefix(Player newMasterClient)
        {
            if (newMasterClient != null && newMasterClient != PhotonNetwork.LocalPlayer)
            {
                NotifiLib.SendWithCooldown($"<color=grey>[<color=purple>INTERSTELLAR</color>]</color>: [<color=#03FCC2>{newMasterClient.NickName.ToUpper()}</color>] IS NOW MASTERCLIENT", 2);
            }
            else if (newMasterClient != null && newMasterClient == PhotonNetwork.LocalPlayer)
            {
                NotifiLib.SendWithCooldown("<color=#00FBFF>YOU ARE NOW MASTERCLIENT</color>", 2);
            }
            return false;
        }
    }
}
