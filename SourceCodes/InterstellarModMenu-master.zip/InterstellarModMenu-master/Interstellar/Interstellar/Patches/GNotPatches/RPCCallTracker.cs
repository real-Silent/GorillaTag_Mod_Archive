﻿using HarmonyLib;
using Photon.Pun;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "GetRPCCallTracker")]
    public class RPCTracker : MonoBehaviourPunCallbacks
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
