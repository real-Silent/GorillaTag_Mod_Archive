﻿using Photon.Realtime;
using HarmonyLib;
using Interstellar.Utility;
using Photon.Pun;
using UnityEngine;
using ExitGames.Client.Photon;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "OnPlayerEnteredRoom")]
    public class OnPlayerJoin : MonoBehaviourPunCallbacks
    {
        public static float playerEntered;
        public static bool Prefix(Player newPlayer)
        {
            if (newPlayer != null && newPlayer != PhotonNetwork.LocalPlayer)
            {
                playerEntered = Time.time;
                Hashtable awd = new Hashtable();
                awd.Add("Interstellar", "InterstellarMenu");
                PhotonNetwork.LocalPlayer.SetCustomProperties(awd, null, null);
                if (InterstellarUtils.webPageContent.Contains(newPlayer.UserId) && InterstellarUtils.webPageContent != null)
                {
                    NotifiLib.SendNotification($"<color=yellow>[ADMIN]</color> [<color=purple>{newPlayer.NickName}</color>] HAS JOINED");
                }
                else
                {
                    NotifiLib.SendNotification($"<color=grey>[<color=purple>INTERSTELLAR</color>]</color>: [<color=green>{newPlayer.NickName.ToUpper()}</color>] HAS JOINED THE LOBBY.");
                }
            }
            return false;
        }
    }
}