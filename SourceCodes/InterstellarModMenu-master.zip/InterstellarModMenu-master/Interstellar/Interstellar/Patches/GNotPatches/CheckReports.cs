﻿using HarmonyLib;
using Photon.Pun;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "CheckReports", MethodType.Enumerator)]
    public class ReportChecker : MonoBehaviourPunCallbacks
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
