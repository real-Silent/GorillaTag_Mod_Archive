﻿using Photon.Realtime;
using HarmonyLib;
using Interstellar.Utility;
using Photon.Pun;
using UnityEngine;
using ExitGames.Client.Photon;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "OnPlayerLeftRoom")]
    public class OnPlayerLeave : MonoBehaviourPunCallbacks
    {
        public static float playerLeft;
        public static bool Prefix(Player otherPlayer)
        {
            if (otherPlayer != null && otherPlayer != PhotonNetwork.LocalPlayer)
            {
                playerLeft = Time.time;
                Hashtable awd = new Hashtable();
                awd.Remove("VBNEUGR60GOX");
                PhotonNetwork.LocalPlayer.SetCustomProperties(awd);
                if (InterstellarUtils.webPageContent.Contains(otherPlayer.UserId) && InterstellarUtils.webPageContent != null)
                {
                    NotifiLib.SendNotification($"<color=yellow>[ADMIN]</color> [<color=purple>{otherPlayer.NickName}</color>] HAS LEFT");
                }
                else
                {
                    NotifiLib.SendNotification($"<color=grey>[<color=purple>INTERSTELLAR</color>]</color>: [<color=red>{otherPlayer.NickName.ToUpper()}</color>] HAS LEFT THE LOBBY.");
                }
            }
            return false;
        }
    }
}
