﻿using HarmonyLib;
using Photon.Pun;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "LogErrorCount")]
    public class LogErrorCount : MonoBehaviourPunCallbacks
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
