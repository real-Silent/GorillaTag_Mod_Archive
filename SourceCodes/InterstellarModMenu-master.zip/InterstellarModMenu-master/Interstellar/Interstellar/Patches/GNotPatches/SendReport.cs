﻿using HarmonyLib;
using Photon.Pun;
using Interstellar.Utility;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "SendReport")]
    public class GorillaNotReports : MonoBehaviourPunCallbacks
    {
        public static bool Prefix(string susReason, string susId, string susNick)
        {
            if (susId == PhotonNetwork.LocalPlayer.UserId)
            {
                NotifiLib.SendWithCooldown($"[<color=blue>ANTI-CHEAT</color>] REPORT FOR: [<color=yellow>{susReason}</color>]", 3);
                susId.Remove(PhotonNetwork.LocalPlayer.UserId.Length);
                susNick.Remove(PhotonNetwork.LocalPlayer.NickName.Length);
            }
            return false;
        }
    }
}