﻿using HarmonyLib;
using Photon.Pun;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "IncrementRPCCallLocal")]
    public class IncrementRPCCall : MonoBehaviourPunCallbacks
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
