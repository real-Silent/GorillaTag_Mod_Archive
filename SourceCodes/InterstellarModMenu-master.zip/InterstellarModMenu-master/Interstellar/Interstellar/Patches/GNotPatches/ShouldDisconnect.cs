﻿using HarmonyLib;
using Photon.Pun;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNot), "ShouldDisconnectFromRoom")]
    public class ShouldLeave : MonoBehaviourPunCallbacks
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
