﻿using HarmonyLib;
using UnityEngine;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("AntiTeleportTechnology", 0)]
    public class BypassTP : MonoBehaviour
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
