﻿using HarmonyLib;
using Interstellar.Utility;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player), "Awake")]
    public class GUIAwake
    {
        public static void Postfix()
        {
            InterstellarLoader.instance.OnGameInitialised();
        }
    }
}
