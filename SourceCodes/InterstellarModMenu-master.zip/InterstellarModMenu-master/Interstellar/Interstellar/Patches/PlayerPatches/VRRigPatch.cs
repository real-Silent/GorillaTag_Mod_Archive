﻿using HarmonyLib;
using UnityEngine;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(VRRig))]
    [HarmonyPatch("OnDisable", 0)]
    public class GhostPatch : MonoBehaviour
    {
        public static bool Prefix(VRRig __instance)
        {
            if (__instance == GorillaTagger.Instance.offlineVRRig)
            {
                return false;
            }
            return true;
        }
    }
}
