﻿using HarmonyLib;
using UnityEngine;

namespace Interstellar.Patches
{
    [HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
    [HarmonyPatch("GracePeriod", 0)]
    public class GraceBypass : MonoBehaviour
    {
        public static bool Prefix()
        {
            return false;
        }
    }
}
