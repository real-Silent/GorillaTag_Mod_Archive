﻿using UnityEngine;

namespace Interstellar.UI
{
    public class GUIUtils
    {
        private static Color textColor;
        private static Texture2D toggleButtonBackground = null;


        public static Texture2D CustomTexture(int width, int height, Color32 color)
        {
            Texture2D texture = new Texture2D(width, height);

            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    texture.SetPixel(x, y, color);
                }
            }

            texture.Apply();
            return texture;
        }

        public static void Button(string content, System.Action onClickAction)
        {
            GUIStyle style = new GUIStyle(GUI.skin.button);
            style.normal.textColor = Color.white;
            style.hover.textColor = Color.white;
            style.active.textColor = Color.white;
            style.normal.background = GUIMain.normalButtonBackground;
            style.hover.background = style.normal.background;
            style.active.background = style.normal.background;
            style.focused.background = style.normal.background;
            style.onNormal.background = style.normal.background;
            style.onHover.background = style.normal.background;
            style.onActive.background = style.normal.background;
            style.onFocused.background = style.normal.background;

            if (GUILayout.Button(content, style))
            {
                onClickAction?.Invoke();
            }
        }

        public static bool ToggleButton(string content, bool state)
        {
            textColor = state ? Color.white : Color.white;
            toggleButtonBackground = state ? GUIMain.toggledButtonBackground : GUIMain.normalButtonBackground;

            GUIStyle style = new GUIStyle(GUI.skin.button);
            style.normal.textColor = textColor;
            style.hover.textColor = textColor;
            style.active.textColor = textColor;
            style.normal.background = toggleButtonBackground;
            style.hover.background = style.normal.background;
            style.active.background = style.normal.background;
            style.focused.background = style.normal.background;
            style.onNormal.background = style.normal.background;
            style.onHover.background = style.normal.background;
            style.onActive.background = style.normal.background;
            style.onFocused.background = style.normal.background;

            if (GUILayout.Button(content, style))
            {
                state = !state;
            }

            return state;
        }
    }
}
