﻿using UnityEngine;
using BepInEx;
using Photon.Pun;
using GorillaNetworking;
using Interstellar.MenuMods;
using Interstellar.Main;
using Interstellar.Utility;
using Meta.WitAi.Data;

namespace Interstellar.UI
{
    public class GUIMain : MonoBehaviour //THIS TEMP WAS ALL MADE BY @pixrce. ----------
    {
        private bool GUIToggled = false;
        private bool OpenedGUIBefore = false;
        private Texture2D guiBackground = new Texture2D(530, 370);
        private Texture2D guiTabsBackground = new Texture2D(140, 370);
        public static Texture2D normalButtonBackground = new Texture2D(350, 20);
        public static Texture2D toggledButtonBackground = new Texture2D(350, 20);
        public static Color guiBackgroundColor = Color.black;
        public static Color guiTabsBackgroundColor = new Color32(6, 6, 6, 255);
        public static Color normalButtonBackgroundColor = new Color32(12, 12, 12, 255);
        public static Color toggledButtonBackgroundColor = new Color32(23, 23, 23, 255);
        private Rect guiBase = new Rect(20, 20, 530, 370); //530, 370
        private Vector2 dragOffset;
        private Vector2 scrollPosition = Vector2.zero;
        private bool isDragging = false;

        private KeyCode ToggleKey = KeyCode.Tab;
        private int selection = 3;
        private GUIStyle normalButtonStyle = new GUIStyle(GUI.skin.button);


        // enabled bools view with caution (autisim below)

        public static bool syncTheme = false;
        public static bool initLoop = false;
        public static bool antiReport = false;
        public static bool wasdEnabled = false;
        public static bool tpGun = false;
        public static bool chams = false;
        public static bool tracers = false;
        public static bool boneESP = false;
        public static bool beacons = false;
        public static bool boxESP = false;
        public static bool tagSelf = false;
        public static bool tagGun = false;
        public static bool tagAll = false;
        public static bool tagAura = false;
        public static bool untagGun = false;
        public static bool untagAura = false;
        public static bool touchToUntag = false;
        public static bool antiTag = false;
        public static bool stutterGun = false;
        public static bool stutterAll = false;
        public static bool stutterAura = false;
        public static bool touchToStutter = false;
        public static bool nameSpazAll = false;
        public static bool lagAll = false;
        public static bool lagGun = false;
        public static bool touchToLag = false;
        public static bool crashAll = false;
        public static bool crashGun = false;
        public static bool touchToCrash = false;
        public static bool GhostMonk = false;
        public static bool ImpactSelf = false;
        public static bool ImpactAura = false;
        public static bool ImpactOrbit = false;
        public static bool ImpactAll = false;

        public static string textBox = "Input Here";
        public static string roomBox = "Input Here";

        public void Start()
        {
            guiBackground = GUIUtils.CustomTexture(guiBackground.width, guiBackground.height, guiBackgroundColor);
            guiTabsBackground = GUIUtils.CustomTexture(guiTabsBackground.width, guiTabsBackground.height, guiTabsBackgroundColor);
            normalButtonBackground = GUIUtils.CustomTexture(guiTabsBackground.width, guiTabsBackground.height, normalButtonBackgroundColor);
            toggledButtonBackground = GUIUtils.CustomTexture(toggledButtonBackground.width, toggledButtonBackground.height, toggledButtonBackgroundColor);

            normalButtonStyle.normal.textColor = Color.white;
            normalButtonStyle.hover.textColor = Color.white;
            normalButtonStyle.active.textColor = Color.white;
            normalButtonStyle.normal.background = normalButtonBackground;
            normalButtonStyle.hover.background = normalButtonStyle.normal.background;
            normalButtonStyle.active.background = normalButtonStyle.normal.background;
            normalButtonStyle.focused.background = normalButtonStyle.normal.background;
            normalButtonStyle.onNormal.background = normalButtonStyle.normal.background;
            normalButtonStyle.onHover.background = normalButtonStyle.normal.background;
            normalButtonStyle.onActive.background = normalButtonStyle.normal.background;
            normalButtonStyle.onFocused.background = normalButtonStyle.normal.background;
        }

        public void OnGUI()
        {
            if (!GUIToggled)
            {
                if (!OpenedGUIBefore)
                {
                    GUI.Label(new Rect(20, 20, 320, 30), $"Press [<color=cyan>{ToggleKey.ToString().ToUpper()}</color>] to Open GUI");
                }
            }
            else
            {
                GUI.BeginGroup(new Rect(guiBase.x, guiBase.y, guiBase.width, guiBase.height));
                DrawWindow(0);
                GUI.EndGroup();
                ProcessDrag();
            }
        }
        private void DrawWindow(int windowID)
        {
            GUI.DrawTexture(new Rect(0, 0, 530, 370), guiBackground);
            GUI.DrawTexture(new Rect(0, 0, 140, 370), guiTabsBackground);

            GUI.Label(new Rect(35, 10, 530, 20), $"Interstellar V{InterstellarLoader.version}");





            GUILayout.BeginArea(new Rect(10, 40, 120, 345));
            GUILayout.BeginVertical();

            GUIUtils.Button("Settings", () => selection = 0);
            GUIUtils.Button("Player List", () => selection = 1);
            GUIUtils.Button("Room Mods", () => selection = 2);
            GUIUtils.Button("Basic Mods", () => selection = 3);
            GUIUtils.Button("Player Mods", () => selection = 4);
            GUIUtils.Button("Impact Mods", () => selection = 5);
            GUIUtils.Button("VRRig Mods", () => selection = 6);
            GUIUtils.Button("Visual Mods", () => selection = 7);
            GUIUtils.Button("Sound Mods", () => selection = 8);
            GUIUtils.Button("Infection Mods", () => selection = 9);
            GUIUtils.Button("Master Mods", () => selection = 10);
            GUIUtils.Button("Misc Mods", () => selection = 11);
            GUIUtils.Button("Abusive Mods", () => selection = 12);

            GUILayout.EndVertical();
            GUILayout.EndArea();

            scrollPosition = GUI.BeginScrollView(new Rect(10, 10, Screen.width - 20, Screen.height - 20), scrollPosition,
            new Rect(0, 0, Screen.width - 30, Screen.height + 20));
            GUILayout.BeginArea(new Rect(150, 10, 370, 350));
            GUILayout.BeginVertical();
            switch (selection)
            {
                // Settings
                case 0:
                    antiReport = GUIUtils.ToggleButton("Anti Report", antiReport);
                    MenuSrc.enableAntiBanSafety = GUIUtils.ToggleButton($"AntiBan Safety: {MenuSrc.enableAntiBanSafety}", MenuSrc.enableAntiBanSafety);
                    syncTheme = GUIUtils.ToggleButton($"Sync GUI Theme with Menu: {syncTheme}", syncTheme);
                    textBox = GUILayout.TextField(textBox);
                    GUIUtils.Button("Set Fly Speed", () => int.TryParse(textBox, out MenuSrc.flyingSpeed));
                    GUIUtils.Button("Set Velocity Fly Speed", () => int.TryParse(textBox, out MenuSrc.velflyspeed));
                    GUIUtils.Button("Set Iron Monke Value", () => int.TryParse(textBox, out MenuSrc.ironMonkey));
                    GUIUtils.Button("Set Quality Value", () => InterstellarUtils.QualityChanger(int.Parse(textBox)));
                    GUIUtils.Button("Reset Quality Value", () => QualitySettings.globalTextureMipmapLimit = 0);
                    GUIUtils.Button("Set Custom Sound ID", () => int.TryParse(textBox, out SoundSpamMods.smth));
                    break;
                // Player List
                case 1:
                    foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
                    {
                        VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                        GorillaTagManager tag = GorillaGameManager.instance.GetComponent<GorillaTagManager>();
                        GUILayout.BeginHorizontal();
                        if (tag.currentInfected.Contains(player))
                        {
                            GUILayout.Box(vrrig.mainSkin.material.mainTexture, GUILayout.Width(40), GUILayout.Height(40));
                        }
                        else
                        {
                            GUIStyle coloredBoxStyle = new GUIStyle(GUI.skin.box);
                            coloredBoxStyle.normal.background = MakeTexture(vrrig.playerColor);
                            GUILayout.Box("", coloredBoxStyle, GUILayout.Width(30), GUILayout.Height(30));
                        } 
                        GUILayout.Label($"{player.NickName}");
                        GUIUtils.Button("Teleport", () => GorillaLocomotion.Player.Instance.transform.position = vrrig.transform.position);
                        GUILayout.EndHorizontal();
                    }
                    break;
                // Basic Mods
                case 2:
                    GUILayout.Label($"Welcome to the Interstellar, [<color=cyan>{PhotonNetwork.LocalPlayer.NickName.ToUpper()}</color>]");
                    GUILayout.Label("");
                    GUIUtils.Button("Disconnect", () => PhotonNetwork.Disconnect());
                    GUIUtils.Button("Join Random Room", () => PhotonNetwork.JoinRandomRoom());
                    GUIUtils.Button("AntiBan", () => RoomMods.AntiBan());
                    GUIUtils.Button("Set Master", () => RoomMods.SetMaster());
                    GUIUtils.Button("Trap Stump", () => RoomMods.TrampStump());
                    GUIUtils.Button("Break Net Triggers", () => RoomMods.RevokeNetTrigs());
                    GUIUtils.Button("GameMode ==> Casual <color=red>{M}</color>", () => RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_CASUALCASUAL"));
                    GUIUtils.Button("GameMode ==> Infection <color=red>{M}</color>", () => RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_INFECTION"));
                    GUIUtils.Button("GameMode ==> Hunt <color=red>{M}</color>", () => RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_HUNTHUNT"));
                    GUIUtils.Button("GameMode ==> Battle <color=red>{M}</color>", () => RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_BATTLEPAINTBRAWL"));
                    roomBox = GUILayout.TextField(roomBox);
                    GUIUtils.Button("Join Code", () => PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(roomBox.ToUpper()));
                    roomBox = GUILayout.TextField(roomBox);
                    GUIUtils.Button("Set Name", () => NetworkSystem.Instance.SetMyNickName(roomBox));
                    break;
                // Room Mods
                case 3:
                    tpGun = GUIUtils.ToggleButton("TP Gun", tpGun);
                    break;
                // Player Mods
                case 4:
                    wasdEnabled = GUIUtils.ToggleButton("WASD Flight", wasdEnabled);
                    break;
                // Impact Mods
                case 5:
                    ImpactSelf = GUIUtils.ToggleButton("Impact Self", ImpactSelf);
                    ImpactAura = GUIUtils.ToggleButton("Impact Aura", ImpactAura);
                    ImpactOrbit = GUIUtils.ToggleButton("Impact Orbit", ImpactOrbit);
                    ImpactAll = GUIUtils.ToggleButton("Impact All", ImpactAll);
                    break;
                // VRRig Mods
                case 6:
                    GhostMonk = GUIUtils.ToggleButton("Ghost Monk [<color=cyan>F</color>]", GhostMonk);
                    break;
                // Visual Mods
                case 7:
                    chams = GUIUtils.ToggleButton("Chams", chams);
                    tracers = GUIUtils.ToggleButton("Tracers", tracers);
                    boneESP = GUIUtils.ToggleButton("Bone ESP", boneESP);
                    beacons = GUIUtils.ToggleButton("Beacons", beacons);
                    boxESP = GUIUtils.ToggleButton("Box ESP", boxESP);
                    break;
                // Sound Mods
                case 8:
                    break;
                // Infection Mods
                case 9:
                    tagSelf = GUIUtils.ToggleButton("Tag Self", tagSelf);
                    tagGun = GUIUtils.ToggleButton("Tag Gun", tagGun);
                    GUIUtils.Button("Tag Aura", () => InfectionMods.TagAura(true));
                    tagAll = GUIUtils.ToggleButton("Tag All", tagAll);
                    GUIUtils.Button("Untag Self", () => InfectionMods.UntagPlayer(PhotonNetwork.LocalPlayer));
                    untagGun = GUIUtils.ToggleButton("Untag Gun", untagGun);
                    untagAura = GUIUtils.ToggleButton("Untag Aura", untagAura);
                    touchToUntag = GUIUtils.ToggleButton("Touch to Untag", touchToUntag);
                    GUIUtils.Button("Untag All", () => InfectionMods.UntagAll());
                    antiTag = GUIUtils.ToggleButton("Anti-Tag", antiTag);
                    GUIUtils.Button("No Tag On Join", () => InfectionMods.NoTagOnJoin());
                    break;
                // Master Mods
                case 10:
                    break;
                // Misc Mods
                case 11:
                    break;
                // Abusive Mods
                case 12:
                    stutterGun = GUIUtils.ToggleButton("Stutter Gun", stutterGun);
                    stutterAll = GUIUtils.ToggleButton("Stutter All", stutterAll);
                    stutterAura = GUIUtils.ToggleButton("Stutter Aura", stutterAura);
                    touchToStutter = GUIUtils.ToggleButton("Touch To Stutter", touchToStutter);
                    lagAll = GUIUtils.ToggleButton("Lag All", lagAll);
                    lagGun = GUIUtils.ToggleButton("Lag Gun", lagGun);
                    touchToLag = GUIUtils.ToggleButton("Touch To Lag", touchToLag);
                    crashAll = GUIUtils.ToggleButton("Crash All", crashAll);
                    crashGun = GUIUtils.ToggleButton("Crash Gun", crashGun);
                    touchToCrash = GUIUtils.ToggleButton("Touch To Crash", touchToCrash);

                    break;

            }
            GUILayout.EndVertical();
            GUILayout.EndArea();
            GUI.EndScrollView();
        }

        private void ProcessDrag()
        {
            Event currentEvent = Event.current;
            switch (currentEvent.type)
            {
                case EventType.MouseDown:
                    if (currentEvent.button == 0 && guiBase.Contains(currentEvent.mousePosition))
                    {
                        isDragging = true;
                        dragOffset = currentEvent.mousePosition - guiBase.position;
                    }
                    break;
                case EventType.MouseUp:
                    if (currentEvent.button == 0)
                    {
                        isDragging = false;
                    }
                    break;
            }

            if (isDragging)
            {
                guiBase.position = currentEvent.mousePosition - dragOffset;
            }
        }

        public void Update()
        {
            if (UnityInput.Current.GetKeyDown(KeyCode.Tab))
            {
                GUIToggled = !GUIToggled;
                if (GUIToggled)
                {
                    OpenedGUIBefore = true;
                }
            }

            if (syncTheme)
            {
                guiBackgroundColor = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);
                guiTabsBackgroundColor = new Color(ColorManager.ButtonR, ColorManager.ButtonG, ColorManager.ButtonB);
                normalButtonBackgroundColor = new Color(ColorManager.ButtonR, ColorManager.ButtonG, ColorManager.ButtonB);
                toggledButtonBackgroundColor = new Color(ColorManager.ButtonOnR, ColorManager.ButtonOnG, ColorManager.ButtonOnB);
                //init
                if (initLoop == false)
                {
                    guiBackground = GUIUtils.CustomTexture(guiBackground.width, guiBackground.height, guiBackgroundColor);
                    guiTabsBackground = GUIUtils.CustomTexture(guiTabsBackground.width, guiTabsBackground.height, guiTabsBackgroundColor);
                    normalButtonBackground = GUIUtils.CustomTexture(guiTabsBackground.width, guiTabsBackground.height, normalButtonBackgroundColor);
                    toggledButtonBackground = GUIUtils.CustomTexture(toggledButtonBackground.width, toggledButtonBackground.height, toggledButtonBackgroundColor);
                    initLoop = true;
                }
            }
            else if (!syncTheme)
            {
                guiBackgroundColor = Color.black;
                guiTabsBackgroundColor = new Color32(6, 6, 6, 255);
                normalButtonBackgroundColor = new Color32(12, 12, 12, 255);
                toggledButtonBackgroundColor = new Color32(23, 23, 23, 255);
                //init
                if (initLoop == true)
                {
                    guiBackground = GUIUtils.CustomTexture(guiBackground.width, guiBackground.height, guiBackgroundColor);
                    guiTabsBackground = GUIUtils.CustomTexture(guiTabsBackground.width, guiTabsBackground.height, guiTabsBackgroundColor);
                    normalButtonBackground = GUIUtils.CustomTexture(guiTabsBackground.width, guiTabsBackground.height, normalButtonBackgroundColor);
                    toggledButtonBackground = GUIUtils.CustomTexture(toggledButtonBackground.width, toggledButtonBackground.height, toggledButtonBackgroundColor);
                    initLoop = false;
                }
            }

            if (antiReport)
            {
                if (MenuSrc.lineButtons == null)
                {
                    MenuSrc.lineButtons = Resources.FindObjectsOfTypeAll<GorillaPlayerScoreboardLine>();
                }
                foreach (GorillaPlayerScoreboardLine iawf in MenuSrc.lineButtons)
                {
                    if (iawf.linePlayer == NetworkSystem.Instance.LocalPlayer)
                    {
                        GameObject rBtn = iawf.reportButton.gameObject;
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (vrrig != GorillaTagger.Instance.offlineVRRig)
                            {
                                if (Vector3.Distance(vrrig.rightHandTransform.transform.position, rBtn.transform.position) < 0.5f || Vector3.Distance(vrrig.leftHandTransform.transform.position, rBtn.transform.position) < 0.5f)
                                {
                                    Photon.Realtime.Player okfgaw = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                                    NotifiLib.SendWithCooldown($"[<color=purple>ANTI-REPORT</color>]: [<color=cyan>{okfgaw.NickName}</color>] ATTEMPTED TO REPORT YOU...", 1);
                                    PhotonNetwork.Disconnect();
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                MenuSrc.lineButtons = null;
            }

            if (wasdEnabled)
            {
                PlayerMods.WASD();
            }

            if (tpGun)
            {
                BasicMods.TPGun();
            }

            if (chams)
            {
                VisualMods.Chams();
            }

            if (tracers)
            {
                VisualMods.Tracers();
            }

            if (boneESP)
            {
                VisualMods.BoneESP();
            }

            if (beacons)
            {
                VisualMods.Beaons();
            }

            if (boxESP)
            {
                VisualMods.BoxESP();
            }

            if (tagSelf)
            {
                InfectionMods.TagSelf();
                if (GorillaGameManager.instance.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                {
                    tagSelf = false;
                }
            }

            if (tagAll)
            {
                if (PhotonNetwork.IsMasterClient)
                {
                    if (!GorillaGameManager.instance.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        InfectionMods.TagSelf();
                    }
                    InfectionMods.TagAll();
                    tagAll = false;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
                else
                {
                    InfectionMods.TagAll();
                    if (GorillaGameManager.instance.GetComponent<GorillaTagManager>().currentInfected.Count == 10)
                    {
                        tagAll = false;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }

            if (!tagAll)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            if (tagGun)
            {
                InfectionMods.TagGun();
            }

            if (untagGun)
            {
                InfectionMods.UntagGun();
            }

            if (untagAura)
            {
                InfectionMods.UntagAura();
            }

            if (touchToUntag)
            {
                InfectionMods.TouchToUntag();
            }

            if (antiTag)
            {
                InfectionMods.AntiTag();
            }

            if (stutterGun)
            {
                AbusiveMods.StutterGunV2();
            }

            if (stutterAll)
            {
                AbusiveMods.StutterAllV2();
            }

            if (stutterAura)
            {
                AbusiveMods.StutterAuraV2();
            }

            if (touchToStutter)
            {
                AbusiveMods.TouchToStutterV2();
            }

            if (nameSpazAll)
            {
                AbusiveMods.NameSpazAll();
            }

            if (lagAll)
            {
                AbusiveMods.LagAll();
            }

            if (lagGun)
            {
                AbusiveMods.LagGun();
            }

            if (touchToLag)
            {
                AbusiveMods.TouchToLag();
            }

            if (crashAll)
            {
                AbusiveMods.CrashAll();
            }

            if (crashGun)
            {
                AbusiveMods.CrashGun();
            }

            if (touchToCrash)
            {
                AbusiveMods.TouchToCrash();
            }

            if (GhostMonk)
            {
                VRRigMods.GhostMonke();
            }
            
            if (ImpactSelf)
            {
                ImpactMods.ImpactSelf();
            }

            if (ImpactAura)
            {
                ImpactMods.ImpactAura();
            }

            if (ImpactOrbit)
            {
                ImpactMods.Impactorbit();
            }
            if (ImpactAll)
            {
                ImpactMods.ImpactAll();
            }
        }

        Texture2D MakeTexture(Color color)
        {
            Texture2D texture = new Texture2D(1, 1);
            texture.SetPixel(0, 0, color);
            texture.Apply();
            return texture;
        }
    }
}