﻿using HarmonyLib;
using BepInEx;
using UnityEngine.InputSystem;
using System;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using Interstellar.Patches;
using Interstellar.Utility;
using Interstellar.MenuMods;
using GorillaNetworking;
using Photon.Pun;
using System.Linq;
using ExitGames.Client.Photon;
using Interstellar.UI;

namespace Interstellar.Main
{     
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]

    //this template wasnt good at ALL but it had its time, 
    public class MenuSrc : MonoBehaviour
    {
        //MAIN DECLARATIONS
        public static GameObject referenceObj = null;
        public static GameObject MenuObj = null;
        public static GameObject canvasObj = null;
        public static GameObject canvasSettingsObj = null;
        public static GameObject canvasPrevObj = null;
        public static GameObject canvasNextObj = null; 
        public static GameObject canvasDiscObj = null;
        public static int pageNumber = 1;
        public static int FramePressCooldown = 0;
        public static bool init = true;
        public static Camera TPC = null;


        //MENU INPUT VARS
        static bool OnceLTrig;  //Page Input
        static bool OnceRTrig;  //Page Input
        static bool LeftTrigger = false; //Page Input Bool
        static bool RightTrigger = false;//Page Input Bool
        static ControllerInputPoller input;

        //PAGE VARS
        public static bool CategorieList = pageNumber == 1;
        public static bool Settings = pageNumber == 2;
        public static bool MenuSettings = pageNumber == 3;
        public static bool ModSettings = pageNumber == 4;
        public static bool RoomCategory = pageNumber == 5;
        public static bool BasicCategory = pageNumber == 6;
        public static bool PlayerCategory = pageNumber == 7;
        public static bool ImpactCategory = pageNumber == 8;
        public static bool VRRigCategory = pageNumber == 9;
        public static bool VisualCategory = pageNumber == 10;
        public static bool SoundCategory = pageNumber == 11;
        public static bool InfectionCategory = pageNumber == 12;
        public static bool MasterCategory = pageNumber == 13; 
        public static bool MiscCategory = pageNumber == 14;
        public static bool AbusiveCategory = pageNumber == 15;
        public static bool ProjCategory = pageNumber == 16;
        public static bool AdminCategory = pageNumber == 17;


        //PRIMARY INT DECLARATION
        public static int GunHand = 1; 
        public static int PageType = 1;
        public static int FPSType = 1; 
        public static int SpeedType = 1;
        public static int LongArmType = 1;
        public static int ESPType = 1;
        public static int ColorScheme = 1;
        public static int openButton = 1; 
        public static int NotifResult = 1;
        public static int PlatInput = 1;
        public static int flyNoClip = 1; 
        public static int NoClipPlats = 1;
        public static int PlatType = 1;
        public static int handTap = 1;
        public static int hertzType = 1;
        public static float shrinkSpeed = 0.9f;
        public static int weatherType = 1;
        public static int menuSounds = 1;
        public static int impactColor = 1;
        public static int abusiveMods = 1;
        public static int antiBanSafety = 1;





        //PRESETS
        public static int flyingSpeed = 15;
        public static int velflyspeed = 20;
        public static int ironMonkey = 20;
        public static int qualtitty = 0;



        //RANDOM BOOLS
        public static bool Reversed = false;
        public static bool Origin = false;
        public static bool righthand = false;
        public static bool RGBBool = false;
        public static bool RGBloob = false;
        public static bool resetArms = false;
        public static bool RGBProj = false;
        public static bool fastThrow = true;
        public static bool enableAbusive = false;
        public static bool enableAntiBanSafety = false;
        public static bool resetTagJoin = false;
        public static bool checkPointReset = false;
        public static bool ghostModsReset = false;
        public static bool rigModReset = true;
        public static bool resettexts = true;


        //MAIN LISTS
        static string[] Buttons = new string[] { };
        static bool?[] ButtonsActive = new bool?[] { };
        public static int[] bones = { 4, 3, 5, 4, 19, 18, 20, 19, 3, 18, 21, 20, 22, 21, 25, 21, 29, 21, 31, 29, 27, 25, 24, 22, 6, 5, 7, 6, 10, 6, 14, 6, 16, 14, 12, 10, 9, 7 };
        public static VRRig playerLock = null;
        public static GorillaPlayerScoreboardLine[] lineButtons;


        //MENU SCALING
        static float MenuWidth = 0.20f;
        static float MenuHeight = 0.33f;


        public static string[] Pg123456789 = new string[] { "{Go Home}", "Menu Settings", "Mod Settings", "Anti-Report", "Coming Soon", "More Soon" };
        public static bool?[] Pg123456789Active = new bool?[] { false, false, false, false, false, false };





        //CATEGORY NAMES
        public static string[] Pg1 = new string[] { "Settings", "Room Mods", "Basic Mods", "Player Mods", "Impact Mods", "VRRig Mods" };
        public static bool?[] Pg1Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg2 = new string[] { "Visual Mods", "SoundSpam Mods", "Infection Mods", "Master Mods", "Misc Mods", "Abusive Mods [<color=red>Anti-Ban</color>]" };
        public static bool?[] Pg2Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg3 = new string[] { "Projectile Mods", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Admin Only" };
        public static bool?[] Pg3Active = new bool?[] { false, false, false, false, false, false };



        //EXTRA CATEGORIES
        public static string[] Pg4 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg4Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg5 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg5Active = new bool?[] { false, false, false, false, false, false };
        //===================================================================================================================================================



        //MENU SETTINGS
        public static string[] Pg6 = new string[] { "{Go Home}", "Menu Hand: {Left}", "Menu Input: {Secondary}", "Second Input: {Trigger}", "Color Scheme: {Galactic}", "Gun Hand: {Right}" };
        public static bool?[] Pg6Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg7 = new string[] { "Notifications: {ON}", "Font Type: {NW}", "Time Of Day: {Current}", "SS Button Sounds: {OFF}", "Safe Mode: {Enabled}", "Anti Ban Safety: {Disabled}" };
        public static bool?[] Pg7Active = new bool?[] { false, false, false, false, false, false };



        //MENU SETTINGS EXTERNAL PAGES
        
        public static string[] Pg8 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg8Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg9 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg9Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg10 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg10Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg11 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg11Active = new bool?[] { false, false, false, false, false, false };
        //===================================================================================================================================================



        //MOD SETTINGS
        public static string[] Pg12 = new string[] { "{Go Home}", "First Person Camera", "Speed Value: {Mosa}", "Game Quality: {1}", "Long Arm Value: {1.15}", "Fly With NoClip: {OFF}" };
        public static bool?[] Pg12Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg13 = new string[] { "ESP Color: {GameMode}", "Platforms W/ NoClip: {OFF}", "Platforms Type: {Normal}", "HandTap Value: {Loud}", "Hertz Value: {5}", "Impact Color: {Red}" };
        public static bool?[] Pg13Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg14 = new string[] { "Platforms Input: {Grip}", "FOV: {60}", "Coming Soon", "Coming Soon", "Coming Soon", "More Soon" };
        public static bool?[] Pg14Active = new bool?[] { false, false, false, false, false, false };


        //MOD SETTINGS EXTERNAL PAGES
        public static string[] Pg15 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg15Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg16 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg16Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg17 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg17Active = new bool?[] { false, false, false, false, false, false };
        //===================================================================================================================================================






        //ROOM MODS CATEGORY
        //===================================================================================================================================================
        public static string[] Pg2500 = new string[] { "{Go Home}", "AntiBan", "Set Master", "Trap All Stump", "Break Net Triggers", "GameMode ==> Casual <color=red>{M}</color>" };
        public static bool?[] Pg2500Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg2501 = new string[] { "GameMode ==> Infection <color=red>{M}</color>", "GameMode ==> Hunt <color=red>{M}</color>", "GameMode ==> Battle <color=red>{M}</color>", "Coming Soon", "Coming Soon", "More Soon" };
        public static bool?[] Pg2501Active = new bool?[] { false, false, false, false, false, false };
        //===================================================================================================================================================









        //BASIC MODS CATEGORY
        public static string[] Pg18 = new string[] { "{Go Home}", "Create Public", "Create Private", "No Lobby Leave", "Lobby Hop", "Disconnect {X/Y}" };
        public static bool?[] Pg18Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg19 = new string[] { "Unlock Comp", "FPS Boost", "Speed Boost", "Long Arms", "Low Gravity", "No Gravity" };
        public static bool?[] Pg19Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg20 = new string[] { "Slide Control", "Big Monke {X/Y}", "Small Monke {X/Y}", "Fly {A/B}", "No Clip {RT}", "Hand Tap {Settings}" };
        public static bool?[] Pg20Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg21 = new string[] { "Teleport Gun", "Check Point {RG/RT}", "C4 {RG/RT}", "Disable Tag Freeze", "45 Hertz", "Platforms" };
        public static bool?[] Pg21Active = new bool?[] { false, false, false, false, false, false };



        //BASIC MODS EXTERNAL PAGES
        
        public static string[] Pg22 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg22Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg23 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg23Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg24 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg24Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg25 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg25Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg26 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg26Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg27 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg27Active = new bool?[] { false, false, false, false, false, false };
        //===================================================================================================================================================


        
        //PLAYER MODS CATEGORY
        public static string[] Pg28 = new string[] { "{Go Home}", "Bees", "Iron Monke {LG/RG}", "Up & Down {LT/RT}", "TP 2 Random {A/B}", "AirStrike {RG}" };
        public static bool?[] Pg28Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg29 = new string[] { "Velocity Fly {A}", "Car Monke {LT/RT}", "Bunny Hop", "Speedy Brr", "Frozone {LG/RG}", "Invis Name" };
        public static bool?[] Pg29Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg30 = new string[] { "RGB Monke", "Strobe Monke", "Steal Identity Gun", "Spoof Identity {A/B}", "Spoof Name {A/B}", "Grapple Monke" };
        public static bool?[] Pg30Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg31 = new string[] { "Punch Mod", "Wall Walk {LG + RG}", "Coming Soon", "Coming Soon", "Coming Soon", "More Soon" };
        public static bool?[] Pg31Active = new bool?[] { false, false, false, false, false, false };



        //PLAYER MODS EXTENDED PAGES
        public static string[] Pg32 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg32Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg33 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg33Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg34 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg34Active = new bool?[] { false, false, false, false, false, false };
        //====================================================================================================================================================


        //IMPACT MODS CATEGORY
        public static string[] Pg35 = new string[] { "{Go Home}", "Impact Self", "Impact Pom Poms {LG/RG}", "Impact Aura", "Impact Orbit", "Impact All" };
        public static bool?[] Pg35Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg36 = new string[] { "Impact Gun", "Give Pom Poms", "Give Impact Aura", "Give Impact Orbit", "Coming Soon", "More Soon" };
        public static bool?[] Pg36Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg37 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg37Active = new bool?[] { false, false, false, false, false, false };



        //IMPACT MODS EXTENDED PAGES
        public static string[] Pg38 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg38Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg39 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg39Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg40 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg40Active = new bool?[] { false, false, false, false, false, false };
        //====================================================================================================================================================



        //VRRIG MODS CATEGORY
        public static string[] Pg41 = new string[] { "{Go Home}", "Ghost Monke {A/B}", "Invis Monke {A/B}", "Look At Nearest {A/B}", "Rig Gun", "Hold Rig" };
        public static bool?[] Pg41Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg42 = new string[] { "Ghost Walk {A/B}", "Frozen Ghost Walk {A/B}", "Copy Gun", "Spinny Monke", "Helicopter Monke {A/B}", "Head Spin X" };
        public static bool?[] Pg42Active = new bool?[] { false, false, false, false, false, false };
        
        public static string[] Pg43 = new string[] { "Head Spin Y", "Head Spin Z", "Spaz Monke", "Follow Player Gun", "Coming Soon", "More Soon" };
        public static bool?[] Pg43Active = new bool?[] { false, false, false, false, false, false };



        //VRRIG MODS EXTENDED PAGES
        public static string[] Pg44 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg44Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg45 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg45Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg46 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg46Active = new bool?[] { false, false, false, false, false, false };
        //=====================================================================================================================================================
        



        //VISUAL MODS CATEGORY
        public static string[] Pg47 = new string[] { "{Go Home}", "Chams", "Tracers", "Bone ESP", "Beacons", "Boxes" };
        public static bool?[] Pg47Active = new bool?[] { false, false, false, false, false, false };



        //VISUAL MODS EXTENDED PAGES
        public static string[] Pg48 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg48Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg49 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg49Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg50 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg50Active = new bool?[] { false, false, false, false, false, false };



        //SOUNDSPAM MODS CATEGORY
        public static string[] Pg51 = new string[] { "{Go Home}", "Annoy All", "Annoy Gun", "Earrape All", "Earrape Gun", "Custom Sound {RG + RT}" };
        public static bool?[] Pg51Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg52 = new string[] { "Break SFX All", "Break SFX Gun", "Coming Soon", "Coming Soon", "Coming Soon", "More Soon" };
        public static bool?[] Pg52Active = new bool?[] { false, false, false, false, false, false };



        //SOUND SPAM EXTERNAL PAGES
        public static string[] Pg53 = new string[] { "eirhjirhj", "srhbuirjb", "ishgu", "Cawojdfwai", "awdawdaawwww", "adawdawawd" };
        public static bool?[] Pg53Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg54 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg54Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg55 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg55Active = new bool?[] { false, false, false, false, false, false };
        //======================================================================================================================================================





        //INFECTION MODS CATEGORY
        public static string[] Pg56 = new string[] { "{Go Home}", "Tag Self", "Tag Gun", "Tag Aura {RG}", "Tag All", "Untag Self" };
        public static bool?[] Pg56Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg57 = new string[] { "Untag Gun", "Untag Aura", "Touch To Untag", "Untag All", "Anti-Tag", "No Tag On Join" };
        public static bool?[] Pg57Active = new bool?[] { false, false, false, false, false, false };




        //INFECTION MODS EXTENDED PAGES
        public static string[] Pg58 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg58Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg59 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg59Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg60 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg60Active = new bool?[] { false, false, false, false, false, false };
        //=====================================================================================================================================================




        //MASTER MODS CATEGORY
        public static string[] Pg61 = new string[] { "{Go Home}", "Mat Spam All", "Mat Spam Gun", "Mat Spam Self", "Mat Spam Aura", "Touch Mat Spam" };
        public static bool?[] Pg61Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg62 = new string[] { "Slow All", "Slow Gun", "Slow Aura", "Vibrate All", "Vibrate Gun", "Vibrate Aura" };
        public static bool?[] Pg62Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg63 = new string[] { "Spam Balloons All", "Spam Balloons Gun", "Spam Balloons Self", "Spam Balloons Aura", "Touch Spam Balloons", "God Mode All" };
        public static bool?[] Pg63Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg64 = new string[] { "Spaz Teams {Battle}", "Acid All", "Acid Gun", "Acid Self", "Acid Aura", "Touch Acid Player" };
        public static bool?[] Pg64Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg65 = new string[] { "Break All Gliders", "Break Glider Gun", "Bring All Gliders {Clouds}", "Bring Gliders Gun {Clouds}", "Glider God {Clouds}", "More Soon" };
        public static bool?[] Pg65Active = new bool?[] { false, false, false, false, false, false };



        //MASTER MOPDS EXTERNAL PAGES
        public static string[] Pg66 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg66Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg67 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg67Active = new bool?[] { false, false, false, false, false, false };
        //=======================================================================================================================================================



        //MISC MODS CATEGORY
        public static string[] Pg68 = new string[] { "{Go Home}", "Disable Quit Box", "Cosmetic Spam 1", "Cosmetic Spam 2", "Cosmetic Spam 3", "Cosmetic Spam All" };
        public static bool?[] Pg68Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg69 = new string[] { "TP To Stump {A/B}", "Become J3VU", "Become Daisy09", "Become PBBV", "Become BTC", "Become KingOfNetflix" };
        public static bool?[] Pg69Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg70 = new string[] { "Color Logger {RG}", "Anti AFK Kick", "Colored Projectiles", "Fast Thrower", "Anti-Moderator", "Static Fingers" };
        public static bool?[] Pg70Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg71 = new string[] { "TP To Hunt-Target {A/B}", "Fake Oculus Menu {A/B}", "Hide on LeaderBoard", "Hold Rocket {RG}", "Coming Soon", "More Soon" };
        public static bool?[] Pg71Active = new bool?[] { false, false, false, false, false, false };



        //MICS MODS EXTERNAL PAGES
        public static string[] Pg72 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg72Active = new bool?[] { false, false, false, false, false, false };





        //ABUSIVE MODS CATEGORY
        public static string[] Pg73 = new string[] { "{Go Home}", "Stutter Gun", "Stutter All", "Stutter Aura", "Touch To Stutter", "Name Spaz All" };
        public static bool?[] Pg73Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg74 = new string[] { "Lag All", "Lag Gun", "Touch To Lag", "Crash All", "Crash Gun", "Touch To Crash" };
        public static bool?[] Pg74Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg75 = new string[] { "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "Coming Soon", "More Soon" };
        public static bool?[] Pg75Active = new bool?[] { false, false, false, false, false, false };


        //ABUSIVE MODS EXTENDED PAGES
        public static string[] Pg76 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg76Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg77 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg77Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg78 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg78Active = new bool?[] { false, false, false, false, false, false };
        //====================================================================================================================================================






        //ADMIN MODS
        public static string[] Pg3000 = new string[] { "{Go Home}", "kick test", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg3000Active = new bool?[] { false, false, false, false, false, false };

        public static string[] Pg3001 = new string[] { "Placeholder21", "Placeholder22", "Placeholder23", "Placeholder24", "Placeholder25", "PLACEHOLDER38" };
        public static bool?[] Pg3001Active = new bool?[] { false, false, false, false, false, false };

        
        private static void Prefix(GorillaLocomotion.Player __instance)
        {
            try
            {
                if (!PhotonNetwork.InRoom)
                {
                    RoomMods.antibanReady = false;
                    RoomMods.alreadyUsed = true;
                }
                PageManager.PageUtility();
                ColorManager.InterstellarScheme();
                NotifiLib.FixedUpdate();
                CustomBoards.LateUpdate();
                ColorManager.OnTriggeredGuns();
                CustomBoards.Check();
                InterstellarUtils.DetectAdmins();
                InterstellarUtils.FixPCGun();
                ImpactMods.ImpactColors();
                if (init)
                {
                    input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();

                    //PAGE PRESETS
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;



                    righthand = false;
                    Reversed = false;

                    init = false;
                }
                if (righthand)
                {
                    if (openButton == 1)
                    {
                        if (input.rightControllerSecondaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null && righthand)
                        {
                            DrawMenu();
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);   //offset is how much up and down   reg 0.22f          // width is how big left to right
                            AddCustomButton("PrevPage", 0.03f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.03f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.leftControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.rightControllerSecondaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null && righthand)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                            MenuObj.transform.RotateAround(MenuObj.transform.position, MenuObj.transform.forward, 180f);
                        }
                        if (input.rightControllerSecondaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {

                            }
                        }
                        if (!input.rightControllerSecondaryButton && MenuObj != null)
                        {
                            MenuObj.transform.localScale -= new Vector3(shrinkSpeed, shrinkSpeed, shrinkSpeed) * Time.deltaTime;
                            if (MenuObj.transform.localScale.x <= 0.1f && MenuObj.transform.localScale.y <= 0.1f && MenuObj.transform.localScale.z <= 0.1f)
                            {
                                GameObject.Destroy(MenuObj);
                                MenuObj = null;
                                GameObject.Destroy(referenceObj);
                                referenceObj = null;
                                GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                                GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                                GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                                if (MenuSrc.menuSounds == 1)
                                {
                                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                }
                                else if (MenuSrc.menuSounds == 2)
                                {
                                    if (PhotonNetwork.InRoom && GorillaGameManager.instance != null)
                                    {
                                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
                                        {
                                84,
                                false,
                                0.9f
                                        });
                                    }
                                    else if (!PhotonNetwork.InRoom)
                                    {
                                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                    }
                                }
                            }
                        }
                    }
                    else if (openButton == 2)
                    {
                        if (input.rightControllerPrimaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null && righthand)
                        {
                            DrawMenu();
                            // Add Custom Buttons Here
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);
                            AddCustomButton("PrevPage", 0.03f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.03f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.leftControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.rightControllerPrimaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null && righthand)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                            MenuObj.transform.RotateAround(MenuObj.transform.position, MenuObj.transform.forward, 180f);
                        }
                        if (input.rightControllerPrimaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {

                            }
                        }
                        if (!input.rightControllerPrimaryButton && MenuObj != null)
                        {
                            MenuObj.transform.localScale -= new Vector3(shrinkSpeed, shrinkSpeed, shrinkSpeed) * Time.deltaTime;
                            if (MenuObj.transform.localScale.x <= 0.1f && MenuObj.transform.localScale.y <= 0.1f && MenuObj.transform.localScale.z <= 0.1f)
                            {
                                GameObject.Destroy(MenuObj);
                                MenuObj = null;
                                GameObject.Destroy(referenceObj);
                                referenceObj = null;
                                GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                                GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                                GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                                if (MenuSrc.menuSounds == 1)
                                {
                                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                }
                                else if (MenuSrc.menuSounds == 2)
                                {
                                    if (PhotonNetwork.InRoom && GorillaGameManager.instance != null)
                                    {
                                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
                                        {
                                84,
                                false,
                                0.9f
                                        });
                                    }
                                    else if (!PhotonNetwork.InRoom)
                                    {
                                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                    }
                                }
                            }
                        }
                    }
                }
                else if (!righthand)
                {
                    if (openButton == 1)
                    {
                        if (input.leftControllerSecondaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null && !righthand)
                        {
                            DrawMenu();
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);
                            AddCustomButton("PrevPage", 0.03f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.03f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && !righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.leftControllerSecondaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null && !righthand)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                        }
                        if (input.leftControllerSecondaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {

                            }
                        }
                        if (!input.leftControllerSecondaryButton && MenuObj != null)
                        {
                            MenuObj.transform.localScale -= new Vector3(shrinkSpeed, shrinkSpeed, shrinkSpeed) * Time.deltaTime;
                            if (MenuObj.transform.localScale.x <= 0.1f && MenuObj.transform.localScale.y <= 0.1f && MenuObj.transform.localScale.z <= 0.1f)
                            {
                                GameObject.Destroy(MenuObj);
                                MenuObj = null;
                                GameObject.Destroy(referenceObj);
                                referenceObj = null;
                                GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                                GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                                GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                                if (MenuSrc.menuSounds == 1)
                                {
                                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                }
                                else if (MenuSrc.menuSounds == 2)
                                {
                                    if (PhotonNetwork.InRoom && GorillaGameManager.instance != null)
                                    {
                                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
                                        {
                                84,
                                false,
                                0.9f
                                        });
                                    }
                                    else if (!PhotonNetwork.InRoom)
                                    {
                                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                    }
                                }
                            }
                        }
                    }
                    else if (openButton == 2)
                    {
                        if (input.leftControllerPrimaryButton && MenuObj == null && canvasNextObj == null && canvasDiscObj == null && canvasPrevObj == null && !righthand)
                        {
                            DrawMenu();
                            AddCustomButton("Disconnect", 0.19f, false, 1f, 0.10f, 0f);
                            AddCustomButton("PrevPage", 0.03f, false, 0.160f, 0.985f, 0.13f);
                            AddCustomButton("NextPage", 0.03f, false, 0.160f, 0.985f, -0.13f);
                            if (referenceObj == null && !righthand)
                            {
                                referenceObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                referenceObj.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                                referenceObj.GetComponent<Renderer>().material.color = Color.green;
                                referenceObj.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                                referenceObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                                referenceObj.transform.localScale = new Vector3(0.0085f, 0.0085f, 0.0085f);
                            }
                        }
                        if (input.leftControllerPrimaryButton && MenuObj != null && canvasPrevObj != null && canvasNextObj != null && canvasDiscObj != null && !righthand)
                        {
                            MenuObj.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                            MenuObj.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                        }
                        if (input.leftControllerPrimaryButton)
                        {
                            if (PageType == 1)
                            {
                                LeftTrigger = input.leftControllerIndexFloat > 0.1f;
                                RightTrigger = input.rightControllerIndexFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 2)
                            {
                                LeftTrigger = input.leftControllerGripFloat > 0.1f;
                                RightTrigger = input.rightControllerGripFloat > 0.1f;
                                if (OnceLTrig && LeftTrigger)
                                {
                                    pageNumber--;
                                    OnceLTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceLTrig && LeftTrigger)
                                {
                                    OnceLTrig = false;
                                }
                                if (!LeftTrigger)
                                {
                                    OnceLTrig = true;
                                }
                                if (OnceRTrig && RightTrigger)
                                {
                                    pageNumber++;
                                    OnceRTrig = false;
                                    InterstellarUtils.ReDrawMenu();
                                }
                                if (!OnceRTrig && RightTrigger)
                                {
                                    OnceRTrig = false;
                                }
                                if (!RightTrigger)
                                {
                                    OnceRTrig = true;
                                }
                            }
                            else if (PageType == 3)
                            {

                            }
                        }
                        if (!input.leftControllerPrimaryButton && MenuObj != null)
                        {
                            MenuObj.transform.localScale -= new Vector3(shrinkSpeed, shrinkSpeed, shrinkSpeed) * Time.deltaTime;
                            if (MenuObj.transform.localScale.x <= 0.1f && MenuObj.transform.localScale.y <= 0.1f && MenuObj.transform.localScale.z <= 0.1f)
                            {
                                GameObject.Destroy(MenuObj);
                                MenuObj = null;
                                GameObject.Destroy(referenceObj);
                                referenceObj = null;
                                GameObject.Destroy(canvasPrevObj); canvasPrevObj = null;
                                GameObject.Destroy(canvasDiscObj); canvasDiscObj = null;
                                GameObject.Destroy(canvasNextObj); canvasNextObj = null;
                                if (MenuSrc.menuSounds == 1)
                                {
                                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                }
                                else if (MenuSrc.menuSounds == 2)
                                {
                                    if (PhotonNetwork.InRoom && GorillaGameManager.instance != null)
                                    {
                                        PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
                                        {
                                84,
                                false,
                                0.9f
                                        });
                                    }
                                    else if (!PhotonNetwork.InRoom)
                                    {
                                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(84, false, 0.25f);
                                    }
                                }
                            }
                        }
                    }
                }




                if (Pg2500Active[0] == true)
                {
                    Pg2500Active[0] = false;
                    pageNumber = 1;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2500Active[1] == true)
                {
                    RoomMods.AntiBan();
                    Pg2500Active[1] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2500Active[2] == true)
                {
                    RoomMods.SetMaster();
                    Pg2500Active[2] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2500Active[3] == true)
                {
                    RoomMods.TrampStump();
                    Pg2500Active[3] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2500Active[4] == true)
                {
                    RoomMods.RevokeNetTrigs();
                    Pg2500Active[4] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2500Active[5] == true)
                {
                    RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_CASUALCASUAL");
                    Pg2500Active[5] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2501Active[0] == true)
                {
                    RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_INFECTION");
                    Pg2501Active[0] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2501Active[1] == true)
                {
                    RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_HUNTHUNT");
                    Pg2501Active[1] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2501Active[2] == true)
                {
                    RoomMods.ChangeGamemode("DEFAULTMODDED_MODDED_BATTLEPAINTBRAWL");
                    Pg2501Active[2] = false;
                    InterstellarUtils.ReDrawMenu();
                }








                if (Pg123456789Active[0] == true)
                {
                    Pg123456789Active[0] = false;
                    pageNumber = 1;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg123456789Active[1] == true)
                {
                    Pg123456789Active[1] = false;
                    pageNumber = 6;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = true;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg123456789Active[2] == true)
                {
                    Pg123456789Active[2] = false;
                    pageNumber = 12;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = true;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg123456789Active[3] == true)
                {
                    if (lineButtons == null)
                    {
                        lineButtons = Resources.FindObjectsOfTypeAll<GorillaPlayerScoreboardLine>();
                    }
                    foreach (GorillaPlayerScoreboardLine iawf in lineButtons)
                    {
                        if (iawf.linePlayer == NetworkSystem.Instance.LocalPlayer)
                        {
                            GameObject rBtn = iawf.reportButton.gameObject;
                            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    if (Vector3.Distance(vrrig.rightHandTransform.transform.position, rBtn.transform.position) < 0.5f || Vector3.Distance(vrrig.leftHandTransform.transform.position, rBtn.transform.position) < 0.5f)
                                    {
                                        Photon.Realtime.Player okfgaw = InterstellarUtils.GetPhotonView(vrrig.GetComponentInParent<VRRig>()).Owner;
                                        NotifiLib.SendWithCooldown($"[<color=purple>ANTI-REPORT</color>]: [<color=cyan>{okfgaw.NickName}</color>] ATTEMPTED TO REPORT YOU...", 1);
                                        PhotonNetwork.Disconnect();
                                    }
                                }
                            }
                        }
                    }
                }



                //================================================================================================



                if (Pg1Active[0] == true)
                {
                    Pg1Active[0] = false;
                    pageNumber = 123456789;
                    CategorieList = false;
                    Settings = true;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg1Active[1] == true)
                {
                    if (enableAbusive == true)
                    {
                        Pg1Active[1] = false;
                        pageNumber = 2500;
                        CategorieList = false;
                        Settings = false;
                        MenuSettings = false;
                        ModSettings = false;
                        RoomCategory = true;
                        BasicCategory = false;
                        PlayerCategory = false;
                        ImpactCategory = false;
                        VRRigCategory = false;
                        VisualCategory = false;
                        SoundCategory = false;
                        InfectionCategory = false;
                        MasterCategory = false;
                        MiscCategory = false;
                        AbusiveCategory = false;
                        ProjCategory = false;
                        AdminCategory = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (enableAbusive == false)
                    {
                        NotifiLib.SendWithCooldown("<color=white>THIS CATEGORY IS DISABLED, ENABLE IT IN MENU SETTINGS!</color>", 2);
                        Pg1Active[1] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg1Active[2] == true)
                {
                    Pg1Active[2] = false;
                    pageNumber = 18;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = true;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg1Active[3] == true)
                {
                    Pg1Active[3] = false;
                    pageNumber = 28;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = true;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg1Active[4] == true)
                {
                    Pg1Active[4] = false;
                    pageNumber = 35;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = true;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg1Active[5] == true)
                {
                    Pg1Active[5] = false;
                    pageNumber = 45;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = true;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2Active[0] == true)
                {
                    Pg2Active[0] = false;
                    pageNumber = 47;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = true;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2Active[1] == true)
                {
                    Pg2Active[1] = false;
                    pageNumber = 51;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = true;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2Active[2] == true)
                {
                    Pg2Active[2] = false;
                    pageNumber = 56;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = true;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2Active[3] == true)
                {
                    Pg2Active[3] = false;
                    pageNumber = 61;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = true;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2Active[4] == true)
                {
                    Pg2Active[4] = false;
                    pageNumber = 68;
                    CategorieList = false;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = true;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg2Active[5] == true)
                {
                    if (enableAbusive == true)
                    {
                        Pg2Active[5] = false;
                        pageNumber = 73;
                        CategorieList = false;
                        Settings = false;
                        MenuSettings = false;
                        ModSettings = false;
                        RoomCategory = false;
                        BasicCategory = false;
                        PlayerCategory = false;
                        ImpactCategory = false;
                        VRRigCategory = false;
                        VisualCategory = false;
                        SoundCategory = false;
                        InfectionCategory = false;
                        MasterCategory = false;
                        MiscCategory = false;
                        AbusiveCategory = true;
                        ProjCategory = false;
                        AdminCategory = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (enableAbusive == false)
                    {
                        NotifiLib.SendWithCooldown("<color=red>THIS CATEGORY IS DISABLED, ENABLE IT IN MENU SETTINGS</color>", 2);
                        Pg2Active[5] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg3Active[0] == true)
                {
                    Pg3Active[0] = false;
                    InterstellarUtils.ReDrawMenu();
                    NotifiLib.SendWithCooldown("CATEGORY UNDER MAINTENANCE", 0);
                }
                if (Pg3Active[5] == true)
                {
                    foreach (Photon.Realtime.Player p in PhotonNetwork.PlayerList)
                    {
                        if (InterstellarUtils.webPageContent.Contains(p.UserId) && InterstellarUtils.webPageContent != null)
                        {
                            Pg3Active[5] = false;
                            pageNumber = 3000;
                            CategorieList = false;
                            Settings = false;
                            MenuSettings = false;
                            ModSettings = false;
                            RoomCategory = false;
                            BasicCategory = false;
                            PlayerCategory = false;
                            ImpactCategory = false; 
                            VRRigCategory = false;
                            VisualCategory = false;
                            SoundCategory = false;
                            InfectionCategory = false;
                            MasterCategory = false;
                            MiscCategory = false;
                            AbusiveCategory = false;
                            ProjCategory = false;
                            AdminCategory = true;
                            InterstellarUtils.ReDrawMenu();
                        }
                        else
                        {
                            Pg3Active[5] = false;
                            InterstellarUtils.ReDrawMenu();
                            NotifiLib.SendWithCooldown("<color=red>It's not for you..</color>", 0);
                        }
                    }
                }








                if (Pg6Active[0] == true)
                {
                    Pg6Active[0] = false;
                    pageNumber = 123456789;
                    CategorieList = false;
                    Settings = true;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg6Active[1] == true)
                {
                    Pg6[1] = "Menu Hand: {Right}";
                    righthand = true;
                } 
                else
                {
                    Pg6[1] = "Menu Hand: {Left}";
                    righthand = false;
                }
                if (Pg6Active[2] == true)
                {
                    openButton++;
                    if (openButton > 3) 
                    {
                        openButton = 1;
                    }
                    if (openButton == 1)
                    {
                        Pg6[2] = "Menu Input: {Secondary}";
                        Pg6Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (openButton == 2)
                    {
                        Pg6[2] = "Menu Input: {Primary}";
                        Pg6Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg6Active[3] == true)
                {
                    PageType++;
                    if (PageType > 4)
                    {
                        PageType = 1;
                    }
                    if (PageType == 1)
                    {
                        Pg6[3] = "Second Input: {Trigger}";
                        Pg6Active[3] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PageType == 2)
                    {
                        Pg6[3] = "Second Input: {Grip}";
                        Pg6Active[3] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PageType == 3)
                    {
                        Pg6[3] = "Second Input: {NONE}";
                        Pg6Active[3] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg6Active[4] == true)
                {
                    ColorScheme++;
                    if (ColorScheme > 10)
                    {
                        ColorScheme = 1;
                    }
                    if (ColorScheme == 1)
                    {
                        Pg6[4] = "Color Scheme: {Galactic}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 2)
                    {
                        Pg6[4] = "Color Scheme: {Mango}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 3)
                    {
                        Pg6[4] = "Color Scheme: {Horpon}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 4)
                    {
                        Pg6[4] = "Color Scheme: {ShibaGT Gold}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 5)
                    {
                        Pg6[4] = "Color Scheme: {Steal}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 6)
                    {
                        Pg6[4] = "Color Scheme: {iiDk}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 7)
                    {
                        Pg6[4] = "Color Scheme: {Wyvern}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 8)
                    {
                        Pg6[4] = "Color Scheme: {Flimcy}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ColorScheme == 9)
                    {
                        Pg6[4] = "Color Scheme: {Cyclone}";
                        Pg6Active[4] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg6Active[5] == true)
                {
                    GunHand++;
                    if (GunHand > 4)
                    {
                        GunHand = 1;
                    }
                    if (GunHand == 1)
                    {
                        Pg6[5] = "Gun Hand: {Right}";
                        Pg6Active[5] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (GunHand == 2)
                    {
                        Pg6[5] = "Gun Hand: {Left}";
                        Pg6Active[5] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (GunHand == 3)
                    {
                        Pg6[5] = "Gun Hand: {Both}";
                        Pg6Active[5] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg7Active[0] == true)
                {
                    NotifResult++;
                    if (NotifResult > 3)
                    {
                        NotifResult = 1;
                    }
                    if (NotifResult == 1)
                    {
                        Pg7[0] = "Notifications: {ON}";
                        Pg7Active[0] = false;
                        GameObject.Find("NOTIFICATIONLIB_HUD_OBJ").SetActive(true);
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (NotifResult == 2)
                    {
                        Pg7[0] = "Notifications: {OFF}";
                        Pg7Active[0] = false;
                        GameObject.Find("NOTIFICATIONLIB_HUD_OBJ").SetActive(false);
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg7Active[1] == true)
                {
                    //FONT TYPE
                }
                if (Pg7Active[2] == true)
                {
                    weatherType++;
                    if (weatherType > 7)
                    {
                        weatherType = 1;
                    }
                    if (weatherType == 1)
                    {
                        Pg7[2] = "Time Of Day: {Night}";
                        Pg7Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                        BetterDayNightManager.instance.SetTimeOfDay(0);
                    }
                    else if (weatherType == 2)
                    {
                        Pg7[2] = "Time Of Day: {Dawn}";
                        Pg7Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                        BetterDayNightManager.instance.SetTimeOfDay(1);
                    }
                    else if (weatherType == 3)
                    {
                        Pg7[2] = "Time Of Day: {Day}";
                        Pg7Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                        BetterDayNightManager.instance.SetTimeOfDay(3);
                    }
                    else if (weatherType == 4)
                    {
                        Pg7[2] = "Time Of Day: {Bright Day}";
                        Pg7Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                        BetterDayNightManager.instance.SetTimeOfDay(4);
                    }
                    else if (weatherType == 5)
                    {
                        Pg7[2] = "Time Of Day: {Sunny}";
                        Pg7Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                        BetterDayNightManager.instance.SetTimeOfDay(5);
                    }
                    else if (weatherType == 6)
                    {
                        Pg7[2] = "Time Of Day: {Dusk}";
                        Pg7Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                        BetterDayNightManager.instance.SetTimeOfDay(6);
                    }
                }
                if (Pg7Active[3] == true)
                {
                    menuSounds++;
                    if (menuSounds > 3)
                    {
                        menuSounds = 1;
                    }
                    if (menuSounds == 1)
                    {
                        Pg7[3] = "SS Button Sounds: {OFF}";
                        Pg7Active[3] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (menuSounds == 2)
                    {
                        Pg7[3] = "SS Button Sounds: {ON}";
                        Pg7Active[3] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg7Active[4] == true)
                {
                    abusiveMods++;
                    InterstellarUtils.CheckSafetyMode();
                }
                if (Pg7Active[5] == true)
                {
                    antiBanSafety++;
                    InterstellarUtils.CheckAntibanSafety();
                }





















                if (Pg12Active[0] == true)
                {
                    Pg12Active[0] = false;
                    pageNumber = 123456789;
                    CategorieList = false;
                    Settings = true;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg12Active[1] == true)
                {
                   
                }
                if (Pg12Active[2] == true)
                {
                    SpeedType++;
                    if (SpeedType > 9)
                    {
                        SpeedType = 1;
                    }
                    if (SpeedType == 1)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {Mosa}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 2)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {Coke}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 3)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {Pixi}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 4)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {BTC}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 5)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {12.5}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 6)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {13.5}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 7)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {15}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (SpeedType == 8)
                    {
                        Pg12Active[2] = false;
                        Pg12[2] = "Speed Value: {18}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg12Active[3] == true)
                {
                    FPSType++;
                    if (FPSType > 11)
                    {
                        FPSType = 1;
                    }
                    if (FPSType == 1)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {1}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 2)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {2}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 3)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {3}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 4)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {4}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 5)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {5}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 6)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {6}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 7)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {7}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 8)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {8}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 9)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {9}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (FPSType == 10)
                    {
                        Pg12Active[3] = false;
                        Pg12[3] = "Game Quality: {10}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg12Active[4] == true)
                {
                    LongArmType++;
                    if (LongArmType > 5)
                    {
                        LongArmType = 1;
                    }
                    if (LongArmType == 1)
                    {
                        Pg12Active[4] = false;
                        Pg12[4] = "Long Arm Value: {1.15}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (LongArmType == 2)
                    {
                        Pg12Active[4] = false;
                        Pg12[4] = "Long Arm Value: {1.25}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (LongArmType == 3)
                    {
                        Pg12Active[4] = false;
                        Pg12[4] = "Long Arm Value: {1.50}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (LongArmType == 4)
                    {
                        Pg12Active[4] = false;
                        Pg12[4] = "Long Arm Value: {1.75}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg12Active[5] == true)
                {
                    flyNoClip++;
                    if (flyNoClip > 3)
                    {
                        flyNoClip = 1;
                    }
                    if (flyNoClip == 1)
                    {
                        Pg12[5] = "Fly With NoClip: {OFF}";
                        Pg12Active[5] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (flyNoClip == 2)
                    {
                        Pg12[5] = "Fly With NoClip: {ON}";
                        Pg12Active[5] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg13Active[0] == true)
                {
                    ESPType++;
                    if (ESPType > 3)
                    {
                        ESPType = 1;
                    }
                    if (ESPType == 1)
                    {
                        Pg13Active[0] = false;
                        Pg13[0] = "ESP Color: {GameMode}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (ESPType == 2)
                    {
                        Pg13Active[0] = false;
                        Pg13[0] = "ESP Color: {RGB}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg13Active[1] == true)
                {
                    NoClipPlats++;
                    if (NoClipPlats > 3)
                    {
                        NoClipPlats = 1;
                    }
                    if (NoClipPlats == 1)
                    {
                        Pg13Active[1] = false;
                        Pg13[1] = "Platforms W/ NoClip: {OFF}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (NoClipPlats == 2)
                    {
                        Pg13Active[1] = false;
                        Pg13[1] = "Platforms W/ NoClip: {ON}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg13Active[2] == true)
                {
                    PlatType++;
                    if (PlatType > 4)
                    {
                        PlatType = 1;
                    }
                    if (PlatType == 1)
                    {
                        Pg13Active[2] = false;
                        Pg13[2] = "Platforms Type: {Normal}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PlatType == 2)
                    {
                        Pg13Active[2] = false;
                        Pg13[2] = "Platforms Type: {Sticky}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PlatType == 3)
                    {
                        Pg13Active[2] = false;
                        Pg13[2] = "Platforms Type: {Invis}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PlatType == 4)
                    {
                        Pg13Active[2] = false;
                        Pg13[2] = "Platforms Type: {Plank}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg13Active[3] == true)
                {
                    handTap++;
                    if (handTap > 4)
                    {
                        handTap = 1;
                    }
                    if (handTap == 1)
                    {
                        Pg13Active[3] = false;
                        Pg13[3] = "HandTap Value: {Loud}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (handTap == 2)
                    {
                        Pg13Active[3] = false;
                        Pg13[3] = "HandTap Value: {Silent}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (handTap == 3)
                    {
                        Pg13Active[3] = false;
                        Pg13[3] = "HandTap Value: {No Cooldown}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg13Active[4] == true)
                {
                    hertzType++;
                    if (hertzType > 4)
                    {
                        hertzType = 1;
                    }
                    if (hertzType == 1)
                    {
                        Pg13Active[4] = false;
                        Pg13[4] = "Hertz Value: {5}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (hertzType == 2)
                    {
                        Pg13Active[4] = false;
                        Pg13[4] = "Hertz Value: {10}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (hertzType == 3)
                    {
                        Pg13Active[4] = false;
                        Pg13[4] = "Hertz Value: {15}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg13Active[5] == true)
                {
                    impactColor++;
                    if (impactColor > 8)
                    {
                        impactColor = 1;
                    }
                    if (impactColor == 1)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {Red}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (impactColor == 2)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {Green}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (impactColor == 3)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {Blue}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (impactColor == 4)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {Yellow}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (impactColor == 5)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {Cyan}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (impactColor == 6)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {Magenta}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (impactColor == 2)
                    {
                        Pg13Active[5] = false;
                        Pg13[5] = "Impact Color: {White}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg14Active[0] == true)
                {
                    PlatInput++;
                    if (PlatInput > 4)
                    {
                        PlatInput = 1;
                    }
                    if (PlatInput == 1)
                    {
                        Pg14Active[0] = false;
                        Pg14[0] = "Platforms Input: {Grip}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PlatInput == 2)
                    {
                        Pg14Active[0] = false;
                        Pg14[0] = "Platforms Input: {Trigger}";
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (PlatInput == 3)
                    {
                        Pg14Active[0] = false;
                        Pg14[0] = "Platforms Input: {Primarys}";
                        InterstellarUtils.ReDrawMenu();
                    }
                }








                if (Pg18Active[0] == true)
                {
                    Pg18Active[0] = false;
                    pageNumber = 1;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg18Active[1] == true)
                {
                    BasicMods.CreatePub();
                    Pg18Active[1] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg18Active[2] == true)
                {
                    if (PhotonNetwork.InRoom)
                    {
                        NotifiLib.SendWithCooldown("<color=red>YOU ARE ALREADY IN A ROOM</color>", 2);
                        Pg18Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                    else if (!PhotonNetwork.InRoom)
                    {
                        BasicMods.CreatePriv();
                        Pg18Active[2] = false;
                        InterstellarUtils.ReDrawMenu();
                    }
                }
                if (Pg18Active[3] == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
                }
                else if (Pg18Active[3] == false)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
                }
                if (Pg18Active[4] == true)
                {
                    LobbyHop.LobbyJoiner();
                }
                if (Pg18Active[5] == true)
                {
                    BasicMods.LeaveLobby();
                }
                if (Pg19Active[0] == true)
                {
                    GorillaComputer.instance.CompQueueUnlockButtonPress();
                    Pg19Active[0] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg19Active[1] == true)
                {
                    BasicMods.FPSBoost();
                    resettexts = true;
                }
                else if (Pg19Active[1] == false)
                {
                    if (resettexts == true)
                    {
                        QualitySettings.globalTextureMipmapLimit = 0;
                        resettexts = false;
                    }
                }
                if (Pg19Active[2] == true)
                {
                    BasicMods.SpeedType();
                }
                if (Pg19Active[3] == true)
                {
                    BasicMods.LongArmType();
                    resetArms = true;
                }
                else if (Pg19Active[3] == false)
                {
                    if (resetArms)
                    {
                        GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
                        resetArms = false;
                    }
                }
                if (Pg19Active[4] == true)
                {
                    InterstellarUtils.GravityChanger("low");
                }
                else
                {
                    if (Pg19Active[4] == false)
                    {
                        Physics.gravity = new Vector3(0f, -9.81f, 0f);
                    }
                }
                if (Pg19Active[5] == true)
                {
                    InterstellarUtils.GravityChanger("none");
                }
                else
                {
                    if (Pg19Active[4] == false)
                    {

                    }
                }
                if (Pg20Active[0] == true)
                {
                    GorillaLocomotion.Player.Instance.slideControl = 1f;
                }
                else
                {
                    GorillaLocomotion.Player.Instance.slideControl = 0.00425f;
                }
                if (Pg20Active[1] == true)
                {
                    if (input.rightControllerPrimaryButton)
                    {
                        if (Origin)
                        {
                            Reversed = !Reversed;
                            Origin = false;
                        }
                    }
                    else
                    {
                        Origin = true;
                    }
                    if (Reversed)
                    {
                        GorillaLocomotion.Player.Instance.scale = 4f;
                    }
                    else
                    {
                        GorillaLocomotion.Player.Instance.scale = 1f;
                    }
                }
                if (Pg20Active[2] == true)
                {
                    if (input.rightControllerPrimaryButton)
                    {
                        if (Origin)
                        {
                            Reversed = !Reversed;
                            Origin = false;
                        }
                    }
                    else
                    {
                        Origin = true;
                    }
                    if (Reversed)
                    {
                        GorillaLocomotion.Player.Instance.scale = 0.6f;
                    }
                    else
                    {
                        GorillaLocomotion.Player.Instance.scale = 1f;
                    }
                }
                if (Pg20Active[3] == true)
                {
                    if (input.rightControllerPrimaryButton)
                    {
                        GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * flyingSpeed;
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                    }
                }
                if (Pg20Active[4] == true)
                {
                    BasicMods.NoClip();
                }
                if (Pg20Active[5] == true)
                {
                    BasicMods.HandTapManager();
                }
                else
                {
                    GorillaTagger.Instance.handTapVolume = 0.1f;
                    GorillaTagger.Instance.tapCoolDown = 0.15f;
                }
                if (Pg21Active[0] == true)
                {
                    BasicMods.TPGun();
                }
                if (Pg21Active[1] == true)
                {
                    BasicMods.Checkpoint();
                    checkPointReset = true;
                }
                else if (Pg21Active[1] == false)
                {
                    if (checkPointReset == true)
                    {
                        UnityEngine.Object.Destroy(BasicMods.pointer);
                        checkPointReset = false;
                    }
                }
                if (Pg21Active[2] == true)
                {
                    BasicMods.SpawnC4();
                }
                if (Pg21Active[3] == true)
                {
                    GorillaLocomotion.Player.Instance.disableMovement = false;
                }
                if (Pg21Active[4] == true)
                {
                    BasicMods.Hertz45();
                }
                if (Pg21Active[5] == true)
                {
                    BasicMods.PlatformManager();
                }






                //=====================================================
                if (Pg28Active[0] == true)
                {
                    Pg28Active[0] = false;
                    pageNumber = 1;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg28Active[1] == true)
                {
                    if (GorillaTagger.Instance.offlineVRRig.enabled == true)
                    {
                        PlayerMods.Bees();
                    }
                    else if (GorillaTagger.Instance.offlineVRRig.enabled == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg28Active[2] == true)
                {
                    PlayerMods.IronMonke();
                }
                if (Pg28Active[3] == true)
                {
                    PlayerMods.UPNDOWN();
                }
                if (Pg28Active[4] == true)
                {
                    PlayerMods.TPRandomW();
                }
                if (Pg28Active[5] == true)
                {
                    PlayerMods.AirStrike();
                }
                if (Pg29Active[0] == true)
                {
                    if (input.rightControllerPrimaryButton)
                    {
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * velflyspeed;
                    }
                }
                if (Pg29Active[1] == true)
                {
                    PlayerMods.CarMonke();
                }
                if (Pg29Active[2] == true)
                {
                    PlayerMods.BunnyHop();
                }
                if (Pg29Active[3] == true)
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().drag = -2f;
                }
                else
                {
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().drag = 0f;
                }
                if (Pg29Active[4] == true)
                {
                    PlayerMods.Frozone();
                }
                if (Pg29Active[5] == true)
                {
                    PlayerMods.SetNameNothing();
                    Pg29Active[5] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg30Active[0] == true)
                {
                    PlayerMods.RainbowMonk(0.006f);
                    RGBBool = true;
                }
                else if (Pg30Active[0] == false)
                {
                    if (RGBBool)
                    {
                        if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            PlayerMods.RGBReset();
                            RGBBool = false;
                        }
                    }
                }
                if (Pg30Active[1] == true)
                {
                    PlayerMods.RainbowMonk(0.06f);
                    RGBloob = true;
                }
                else if (Pg30Active[1] == false)
                {
                    if (RGBloob)
                    {
                        if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            PlayerMods.RGBReset();
                            RGBloob = false;
                        }
                    }
                }
                if (Pg30Active[2] == true)
                {
                    PlayerMods.StealPlayer();
                    RGBBool = false;
                }
                if (Pg30Active[3] == true)
                {
                    PlayerMods.SpoofPlayer();
                    RGBBool = false;
                }
                if (Pg30Active[4] == true)
                {
                    PlayerMods.SpoofName();
                }
                if (Pg30Active[5] == true)
                {
                    PlayerMods.GrappleMonk();
                }
                if (Pg31Active[0] == true)
                {
                    PlayerMods.PunchMod();
                }
                if (Pg31Active[1] == true)
                {
                    PlayerMods.WallWalk();
                }








                if (Pg35Active[0] == true)
                {
                    Pg35Active[0] = false;
                    pageNumber = 1;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg35Active[1] == true)
                {
                    ImpactMods.ImpactSelf();
                }
                if (Pg35Active[2] == true)
                {
                    ImpactMods.ImpactPomPoms();
                }
                if (Pg35Active[3] == true)
                {
                    ImpactMods.ImpactAura();
                }
                if (Pg35Active[4] == true)
                {
                    ImpactMods.Impactorbit();
                }
                if (Pg35Active[5] == true)
                {
                    ImpactMods.ImpactAll();
                }
                if (Pg36Active[0] == true)
                {
                    ImpactMods.ImpactGun();
                }
                if (Pg36Active[1] == true)
                {
                    ImpactMods.ImpactGun();
                }
                if (Pg36Active[2] == true)
                {
                    ImpactMods.ImpactGun();
                }
                if (Pg36Active[3] == true)
                {
                    ImpactMods.ImpactGun();
                }













                if (Pg41Active[0] == true)
                {
                    Pg41Active[0] = false;
                    pageNumber = 1;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg41Active[1] == true)
                {
                    VRRigMods.GhostMonke();
                }
                if (Pg41Active[2] == true)
                {
                    VRRigMods.InvisMonke();
                }
                if (Pg41Active[3] == true)
                {
                    VRRigMods.LookAtClosest();
                }
                if (Pg41Active[4] == true)
                {
                    VRRigMods.RigGun();
                }
                if (Pg41Active[5] == true)
                {
                    VRRigMods.HoldRig();
                }
                if (Pg42Active[0] == true)
                {
                    VRRigMods.GhostWalk();
                }
                if (Pg42Active[1] == true)
                {
                    VRRigMods.FrozenGhostWalk();
                }
                if (Pg42Active[2] == true)
                {
                    VRRigMods.CopyPlayer();
                }
                if (Pg42Active[3] == true)
                {
                    if (GorillaTagger.Instance.offlineVRRig.enabled == true)
                    {
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.Rotate(0f, 9.5f, 0f);
                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(0, -999, 0);
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(0, -999, 0);
                    }
                    else if (GorillaTagger.Instance.offlineVRRig.enabled == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }

                }
                if (Pg42Active[4] == true)
                {
                    VRRigMods.Helicopter();
                }
                if (Pg42Active[5] == true)
                {
                    InterstellarUtils.HeadSpinner("X");
                }
                else
                {
                    if (Pg42Active[5] == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0;
                    }
                }
                if (Pg43Active[0] == true)
                {
                    InterstellarUtils.HeadSpinner("Y");
                }
                else
                {
                    if (Pg43Active[0] == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0;
                    }
                }
                if (Pg43Active[1] == true)
                {
                    InterstellarUtils.HeadSpinner("Z");
                }
                else
                {
                    if (Pg43Active[1] == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0;
                    }
                }
                if (Pg43Active[2] == true)
                {
                    if (GorillaTagger.Instance.offlineVRRig.enabled == true)
                    {
                        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.position = new Vector3(0f, 0f, 999f);
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.position = new Vector3(0f, 0f, -999f);
                        GorillaTagger.Instance.offlineVRRig.leftHandPlayer.transform.eulerAngles = new Vector3((float)UnityEngine.Random.Range(120, 480), (float)UnityEngine.Random.Range(1, 612), (float)UnityEngine.Random.Range(12, 612));
                        GorillaTagger.Instance.offlineVRRig.rightHandPlayer.transform.eulerAngles = new Vector3((float)UnityEngine.Random.Range(120, 480), (float)UnityEngine.Random.Range(1, 612), (float)UnityEngine.Random.Range(12, 612));
                        GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(120, 480), (float)UnityEngine.Random.Range(1, 612), (float)UnityEngine.Random.Range(12, 612));
                    }
                    else if (GorillaTagger.Instance.offlineVRRig.enabled == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg43Active[3] == true)
                {
                    VRRigMods.FollowPlayer();
                }





                if (Pg47Active[0] == true)
                {
                    Pg47Active[0] = false;
                    pageNumber = 2;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg47Active[1] == true)
                {
                    VisualMods.Chams();
                }
                if (Pg47Active[1] == false && GUIMain.chams == false)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                        {
                            vrrig.mainSkin.material = vrrig.materialsToChangeTo[vrrig.setMatIndex];
                        }
                    }
                }
                if (Pg47Active[2] == true)
                {
                    VisualMods.Tracers();
                }
                if (Pg47Active[2] == false && GUIMain.tracers == false)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        GameObject.Destroy(vrrig.gameObject.GetComponent<LineRenderer>());
                    }
                }
                if (Pg47Active[3] == true)
                {
                    VisualMods.BoneESP();
                }
                if (Pg47Active[3] == false && GUIMain.boneESP == false)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        for (int i = 0; i < bones.Count(); i += 2)
                        {
                            GameObject.Destroy(vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>());
                            GameObject.Destroy(vrrig.mainSkin.bones[bones[i]].gameObject.GetComponent<LineRenderer>());
                        }
                    }
                }
                if (Pg47Active[4] == true && GUIMain.beacons == false)
                {
                    VisualMods.Beaons();
                }
                if (Pg47Active[5] == true && GUIMain.boxESP == false)
                {
                    VisualMods.BoxESP();
                }









                if (Pg51Active[0] == true)
                {
                    Pg51Active[0] = false;
                    pageNumber = 2;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg51Active[1] == true)
                {
                    SoundSpamMods.SSpamAll(213, 0.9f);
                }
                if (Pg51Active[2] == true)
                {
                    SoundSpamMods.SSpamGuns(213, 0.9f);
                }
                if (Pg51Active[3] == true)
                {
                    SoundSpamMods.SSpamAll(215, 0.9f);
                }
                if (Pg51Active[4] == true)
                {
                    SoundSpamMods.SSpamGuns(215, 0.9f);
                }
                if (Pg51Active[5] == true)
                {
                    SoundSpamMods.CustomSound();
                }
                if (Pg52Active[0] == true)
                {
                    SoundSpamMods.SSpamAll(94, 0.9f);
                }
                if (Pg52Active[1] == true)
                {
                    SoundSpamMods.SSpamGuns(94, 0.9f);
                }



                if (Pg56Active[0] == true)
                {
                    Pg56Active[0] = false;
                    pageNumber = 2;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg56Active[1] == true)
                {
                    if (GorillaTagger.Instance.offlineVRRig.enabled == true)
                    {
                        InfectionMods.TagSelf();
                    }
                    else if (GorillaTagger.Instance.offlineVRRig.enabled == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg56Active[2] == true)
                {
                    InfectionMods.TagGun();
                }
                if (Pg56Active[3] == true)
                {
                    InfectionMods.TagAura();
                }
                if (Pg56Active[4] == true)
                {
                    if (GorillaTagger.Instance.offlineVRRig.enabled == true)
                    {
                        InfectionMods.TagAll();
                        foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerListOthers)
                        {
                            if (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Count == 10 || (GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Count == 9 && GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Contains(PhotonNetwork.LocalPlayer)))
                            {
                                Pg56Active[4] = false;
                                InterstellarUtils.ReDrawMenu();
                                NotifiLib.SendWithCooldown("<color=green>ALL PLAYERS ARE TAGGED</color>", 2);
                            }
                        }
                    }
                    else if (GorillaTagger.Instance.offlineVRRig.enabled == false)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
                if (Pg56Active[5] == true)
                {
                    InfectionMods.UntagPlayer(PhotonNetwork.LocalPlayer);
                    Pg56Active[5] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg57Active[0] == true)
                {
                    InfectionMods.UntagGun();
                }
                if (Pg57Active[1] == true)
                {
                    InfectionMods.UntagAura();
                }
                if (Pg57Active[2] == true)
                {
                    InfectionMods.TouchToUntag();
                }
                if (Pg57Active[3] == true)
                {
                    foreach (Photon.Realtime.Player awd in PhotonNetwork.PlayerList)
                    {
                        InfectionMods.UntagPlayer(awd);
                    }
                    Pg57Active[3] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg57Active[4] == true)
                {
                    InfectionMods.AntiTag();
                }
                if (Pg57Active[5] == true)
                {
                    if (!PhotonNetwork.InRoom)
                    {
                        PlayerPrefs.SetString("didTutorial", "nope");
                        PlayerPrefs.Save();
                        Hashtable hashtable = new Hashtable();
                        hashtable.Add("didTutorial", "nope");
                        PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, null, null);
                    }
                    else if (PhotonNetwork.InRoom)
                    {
                        if (PlayerPrefs.GetString("didTutorial", "nope") == "done")
                        {
                            NotifiLib.SendWithCooldown("<color=red>PLEASE LEAVE THIS ROOM FOR BETTER RESULTS</color>", 2);
                            Pg57Active[5] = false;
                            InterstellarUtils.ReDrawMenu();
                        }
                        else if (PlayerPrefs.GetString("didTutorial", "nope") == "nope")
                        {
                            PlayerPrefs.SetString("didTutorial", "done");
                            PlayerPrefs.Save();
                            Hashtable hashtable = new Hashtable();
                            hashtable.Add("didTutorial", "done");
                            PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, null, null);
                            NotifiLib.SendWithCooldown("<color=green>MOD SUCCESSFUL</color>", 2);
                            Pg57Active[5] = false;
                            InterstellarUtils.ReDrawMenu();
                        }
                    }
                }






                if (Pg61Active[0] == true)
                {
                    Pg61Active[0] = false;
                    pageNumber = 2;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg61Active[1] == true)
                {
                    MasterMods.MatSpamAll();
                }
                if (Pg61Active[2] == true)
                {
                    MasterMods.MatSpamGun();
                }
                if (Pg61Active[3] == true)
                {
                    MasterMods.MatSpamSelf();
                }
                if (Pg61Active[4] == true)
                {
                    MasterMods.MatSpamAura();
                }
                if (Pg61Active[5] == true)
                {
                    MasterMods.MatSpamOnTouch();
                }
                if (Pg62Active[0] == true)
                {
                    MasterMods.StatusManager(0);
                }
                if (Pg62Active[1] == true)
                {
                    MasterMods.StatusGun(0);
                }
                if (Pg62Active[2] == true)
                {
                    MasterMods.StatusAura(0);
                }
                if (Pg62Active[3] == true)
                {
                    MasterMods.StatusManager(1);
                }
                if (Pg62Active[4] == true)
                {
                    MasterMods.StatusGun(1);
                }
                if (Pg62Active[5] == true)
                {
                    MasterMods.StatusAura(1);
                }
                if (Pg63Active[0] == true)
                {
                    MasterMods.SpamBalloonsAll();
                }
                if (Pg63Active[1] == true)
                {
                    MasterMods.SpamBalloonsGun();
                }
                if (Pg63Active[2] == true)
                {
                    MasterMods.SpamBalloonsSelf();
                }
                if (Pg63Active[3] == true)
                {
                    MasterMods.SpamBalloonAura();
                }
                if (Pg63Active[4] == true)
                {
                    MasterMods.TouchSpamBalloons();
                }
                if (Pg63Active[5] == true)
                {
                    MasterMods.GodModeAll();
                    Pg63Active[5] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg64Active[0] == true)
                {
                    MasterMods.ChangeTeamsAll();
                }
                if (Pg64Active[1] == true)
                {
                    MasterMods.AcidAll();
                }
                if (Pg64Active[2] == true)
                {
                    MasterMods.AcidGun();
                }
                if (Pg64Active[3] == true)
                {
                    MasterMods.AcidSelf();
                }
                if (Pg64Active[4] == true)
                {
                    MasterMods.AcidAura();
                }
                if (Pg64Active[5] == true)
                {
                    MasterMods.TouchToAcid();
                }
                if (Pg65Active[0] == true)
                {
                    MasterMods.BreakGliderAll();
                }
                if (Pg65Active[1] == true)
                {
                    MasterMods.BreakGliderGun();
                }
                if (Pg65Active[2] == true)
                {
                    MasterMods.BringGlidersToMe();
                    Pg65Active[2] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg65Active[3] == true)
                {
                    MasterMods.GlidersToGun();
                }
                if (Pg65Active[4] == true)
                {
                    MasterMods.GliderGod();
                }





                if (Pg68Active[0] == true)
                {
                    Pg68Active[0] = false;
                    pageNumber = 2;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg68Active[1] == true)
                {
                    GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(false);
                    Pg68Active[1] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg68Active[2] == true)
                {
                    MiscMods.CosmetSpam();
                }
                if (Pg68Active[3] == true)
                {
                    MiscMods.CosmetSlotSpam(1);
                }
                if (Pg68Active[4] == true)
                {
                    MiscMods.CosmetSlotSpam(2);
                }
                if (Pg68Active[5] == true)
                {
                    float awdwwd = 0f;
                    if (Time.time > awdwwd + 0.04f)
                    {
                        MiscMods.CosmetSpam();
                        MiscMods.CosmetSlotSpam(1);
                        MiscMods.CosmetSlotSpam(2);
                        awdwwd = Time.time;
                    }
                }
                if (Pg69Active[0] == true)
                {
                    MiscMods.TPToStump();
                }
                if (Pg69Active[1] == true)
                {
                    MiscMods.Become("J3VU", 0, 255, 0);
                    Pg69Active[1] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg69Active[2] == true)
                {
                    MiscMods.Become("DAISY09", 245, 115, 255);
                    Pg69Active[2] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg69Active[3] == true)
                {
                    MiscMods.Become("PBBV", 0, 0, 0);
                    Pg69Active[3] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg69Active[4] == true)
                {
                    MiscMods.Become("BTC", 115, 0, 255);
                    Pg69Active[4] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg69Active[5] == true)
                {
                    MiscMods.Become("TICKLETIPJR", 169, 111, 38);
                    Pg69Active[5] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg70Active[0] == true)
                {
                    MiscMods.ColorLogger();
                }
                if (Pg70Active[1] == true)
                {
                    if (PhotonNetworkController.Instance.disableAFKKick == false)
                    {
                        PhotonNetworkController.Instance.disableAFKKick = true; 
                    }
                }
                else
                {
                    if (PhotonNetworkController.Instance.disableAFKKick == true)
                    {
                        PhotonNetworkController.Instance.disableAFKKick = false;
                    }
                }
                if (Pg70Active[2] == true)
                {
                    if (!RGBProj)
                    {
                        foreach (SnowballThrowable awd in Resources.FindObjectsOfTypeAll<SnowballThrowable>())
                        {
                            awd.randomizeColor = true;
                        }
                        RGBProj = true;
                    }
                }
                else
                {
                    if (RGBProj)
                    {
                        foreach (SnowballThrowable awd in Resources.FindObjectsOfTypeAll<SnowballThrowable>())
                        {
                            awd.randomizeColor = false;
                        }
                        RGBProj = false;
                    }
                }
                if (Pg70Active[3] == true)
                {
                    if (fastThrow)
                    {
                        foreach (SnowballThrowable snowballThrowable in Resources.FindObjectsOfTypeAll<SnowballThrowable>())
                        {
                            snowballThrowable.linSpeedMultiplier = 10f;
                            snowballThrowable.maxWristSpeed = 30f;
                            snowballThrowable.maxLinSpeed = 2000f;
                        }
                        fastThrow = false;
                    }
                }
                else
                {
                    if (!fastThrow)
                    {
                        foreach (SnowballThrowable snowballThrowable in Resources.FindObjectsOfTypeAll<SnowballThrowable>())
                        {
                            snowballThrowable.linSpeedMultiplier = 1f;
                            snowballThrowable.maxWristSpeed = 4f;
                            snowballThrowable.maxLinSpeed = 12f;
                        }
                        fastThrow = true;
                    }
                }
                if (Pg70Active[4] == true)
                {
                    MiscMods.AntiModerator();
                }
                if (Pg70Active[5] == true)
                {
                    MiscMods.StaticFinger();
                }
                if (Pg71Active[0] == true)
                {
                    MiscMods.TP_To_Hunt_Target();
                }
                if (Pg71Active[1] == true)
                {
                    MiscMods.FakeOculusMenu();
                }
                if (Pg71Active[2] == true)
                {
                    MiscMods.HideOnLeaderboard();
                    Pg71Active[2] = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg71Active[3] == true)
                {
                    if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
                    {
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/RocketShip_Prefab").transform.Rotate(0f, 14f, 0f);
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/RocketShip_Prefab").transform.localScale = new Vector3(0.02f, 0.01f, 0.02f);
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/RocketShip_Prefab").transform.localPosition = new Vector3(0f, -0.0075f, 0f) + GorillaTagger.Instance.rightHandTransform.position;
                    }
                    else
                    {
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/RocketShip_Prefab").transform.Rotate(0f, 0f, 0f);
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/RocketShip_Prefab").transform.localScale = new Vector3(1f, 1f, 1f);
                        GameObject.Find("Environment Objects/PersistentObjects_Prefab/RocketShip_Prefab").transform.position = new Vector3(-10.79f, 9.73f, -134.07f);
                    }
                }





                if (Pg73Active[0] == true)
                {
                    Pg73Active[0] = false;
                    pageNumber = 2;
                    CategorieList = true;
                    Settings = false;
                    MenuSettings = false;
                    ModSettings = false;
                    RoomCategory = false;
                    BasicCategory = false;
                    PlayerCategory = false;
                    ImpactCategory = false;
                    VRRigCategory = false;
                    VisualCategory = false;
                    SoundCategory = false;
                    InfectionCategory = false;
                    MasterCategory = false;
                    MiscCategory = false;
                    AbusiveCategory = false;
                    ProjCategory = false;
                    AdminCategory = false;
                    InterstellarUtils.ReDrawMenu();
                }
                if (Pg73Active[1] == true)
                {
                    AbusiveMods.StutterGunV2();
                }
                if (Pg73Active[2] == true)
                {
                    AbusiveMods.StutterAllV2();
                }
                if (Pg73Active[3] == true)
                {
                    AbusiveMods.StutterAuraV2();
                }
                if (Pg73Active[4] == true)
                {
                    AbusiveMods.TouchToStutterV2();
                }
                if (Pg73Active[5] == true)
                {
                    AbusiveMods.NameSpazAll();
                }
                if (Pg74Active[0] == true)
                {
                    AbusiveMods.LagAll();
                }
                if (Pg74Active[1] == true)
                {
                    AbusiveMods.LagGun();
                }
                if (Pg74Active[2] == true)
                {
                    AbusiveMods.TouchToLag();
                }
                if (Pg74Active[3] == true)
                {
                    AbusiveMods.CrashAll();
                }
                if (Pg74Active[4] == true)
                {
                    AbusiveMods.CrashGun();
                }
                if (Pg74Active[5] == true)
                {
                    AbusiveMods.TouchToCrash();
                }




            }
            catch (Exception ex)
            {
                File.WriteAllText("Interstellar.log", ex.ToString());
            }
        }


        public static void DrawMenu()
        {

            MenuObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            MenuObj.transform.localScale = new Vector3(0.01f, MenuWidth, MenuHeight);

            GameObject.Destroy(MenuObj.GetComponent<BoxCollider>());
            GameObject.Destroy(MenuObj.GetComponent<Collider>());
            GameObject.Destroy(MenuObj.GetComponent<Rigidbody>());
            GameObject.Destroy(MenuObj.GetComponent<Renderer>());


            GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
            bg.transform.parent = MenuObj.transform;
            bg.transform.localScale = new Vector3(1.2f, 1f, 1f);
            bg.transform.position = new Vector3(0.05f, 0f, 0f);
            bg.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            bg.GetComponent<MeshRenderer>().material.color = Color.black;
            bg.GetComponent<Renderer>().material = ColorManager.ColorScheme;

            GameObject.Destroy(bg.GetComponent<BoxCollider>());
            GameObject.Destroy(bg.GetComponent<Collider>());
            GameObject.Destroy(bg.GetComponent<Rigidbody>());

            canvasObj = new GameObject();
            canvasObj.transform.parent = MenuObj.transform;
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            CanvasScaler canvasScale = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScale.dynamicPixelsPerUnit = 1000;

            GameObject titleObj = new GameObject();
            titleObj.transform.parent = canvasObj.transform;
            Text title = titleObj.AddComponent<Text>();
            title.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            title.fontSize = 1;
            title.alignment = TextAnchor.MiddleCenter;
            title.resizeTextForBestFit = true;
            title.resizeTextMinSize = 0;

            title.text = $"Interstellar";
            title.color = Color.white;

            RectTransform titleTransform = title.GetComponent<RectTransform>();
            titleTransform.localPosition = Vector3.zero;
            titleTransform.sizeDelta = new Vector2(0.6f, 0.0225f);
            titleTransform.position = new Vector3(0.06f, 0, 0.144f);
            titleTransform.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            canvasSettingsObj = new GameObject();
            canvasSettingsObj.transform.parent = MenuObj.transform;
            Canvas canvas1 = canvasSettingsObj.AddComponent<Canvas>();
            CanvasScaler canvasScale1 = canvasSettingsObj.AddComponent<CanvasScaler>();
            canvasSettingsObj.AddComponent<GraphicRaycaster>();
            canvas1.renderMode = RenderMode.WorldSpace;
            canvasScale1.dynamicPixelsPerUnit = 1000;

            GameObject titleObj1 = new GameObject();
            titleObj1.transform.parent = canvasSettingsObj.transform;
            Text title1 = titleObj1.AddComponent<Text>();
            title1.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            title1.fontSize = 1;
            title1.alignment = TextAnchor.MiddleCenter;
            title1.resizeTextForBestFit = true;
            title1.resizeTextMinSize = 0;

            title1.text = "Owner | BTC\n\nOwner | KingOfNetflix\n\nTemp Creator | JokerGT\n\n";

            title1.color = Color.white;
            title1.fontStyle = FontStyle.Bold;

            RectTransform titleTransform1 = title1.GetComponent<RectTransform>();
            titleTransform1.localPosition = Vector3.zero;
            titleTransform1.sizeDelta = new Vector2(0.28f, 0.06f);
            titleTransform1.position = new Vector3(0.04f, 0, 0.07f);
            titleTransform1.rotation = Quaternion.Euler(new Vector3(0, 90, 90));

            canvasPrevObj = new GameObject();
            canvasPrevObj.transform.parent = MenuObj.transform;
            Canvas canvas2 = canvasPrevObj.AddComponent<Canvas>();
            CanvasScaler canvasScale2 = canvasPrevObj.AddComponent<CanvasScaler>();
            canvasPrevObj.AddComponent<GraphicRaycaster>();
            canvas2.renderMode = RenderMode.WorldSpace;
            canvasScale2.dynamicPixelsPerUnit = 1000;

            GameObject titleObj2 = new GameObject();
            titleObj2.transform.parent = canvasPrevObj.transform;
            Text prev = titleObj2.AddComponent<Text>();
            prev.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            prev.fontSize = 1;
            prev.alignment = TextAnchor.MiddleCenter;
            prev.resizeTextForBestFit = true;
            prev.resizeTextMinSize = 0;

            prev.text = "<<";

            prev.color = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);

            RectTransform titleTransform2 = prev.GetComponent<RectTransform>();
            titleTransform2.localPosition = Vector3.zero;
            titleTransform2.sizeDelta = new Vector2(0.5f, 0.02f);
            titleTransform2.position = new Vector3(0.057f, 0.13f, 0.03f);
            titleTransform2.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            canvasNextObj = new GameObject();
            canvasNextObj.transform.parent = MenuObj.transform;
            Canvas canvas3 = canvasNextObj.AddComponent<Canvas>();
            CanvasScaler canvasScale3 = canvasNextObj.AddComponent<CanvasScaler>();
            canvasNextObj.AddComponent<GraphicRaycaster>();
            canvas3.renderMode = RenderMode.WorldSpace;
            canvasScale3.dynamicPixelsPerUnit = 1000;

            GameObject titleObj3 = new GameObject();
            titleObj3.transform.parent = canvasNextObj.transform;
            Text next = titleObj3.AddComponent<Text>();
            next.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            next.fontSize = 1;
            next.alignment = TextAnchor.MiddleCenter;
            next.resizeTextForBestFit = true;
            next.resizeTextMinSize = 0;

            next.text = ">>";

            next.color = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);

            RectTransform titleTransform3 = next.GetComponent<RectTransform>();
            titleTransform3.localPosition = Vector3.zero;
            titleTransform3.sizeDelta = new Vector2(0.5f, 0.02f);
            titleTransform3.position = new Vector3(0.057f, -0.13f, 0.03f);
            titleTransform3.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

            canvasDiscObj = new GameObject();
            canvasDiscObj.transform.parent = MenuObj.transform;
            Canvas canvas4 = canvasDiscObj.AddComponent<Canvas>();
            CanvasScaler canvasScale4 = canvasDiscObj.AddComponent<CanvasScaler>();
            canvasDiscObj.AddComponent<GraphicRaycaster>();
            canvas4.renderMode = RenderMode.WorldSpace;
            canvasScale4.dynamicPixelsPerUnit = 1000;

            GameObject titleObj4 = new GameObject();
            titleObj4.transform.parent = canvasDiscObj.transform;
            Text disc = titleObj4.AddComponent<Text>();
            disc.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            disc.fontSize = 1;
            disc.alignment = TextAnchor.MiddleCenter;
            disc.resizeTextForBestFit = true;
            disc.resizeTextMinSize = 0;

            disc.text = "Disconnect";

            disc.color = new Color(ColorManager.CustomButtonTextColorR, ColorManager.CustomButtonTextColorG, ColorManager.CustomButtonTextColorB);

            RectTransform titleTransform4 = disc.GetComponent<RectTransform>();
            titleTransform4.localPosition = Vector3.zero;
            titleTransform4.sizeDelta = new Vector2(0.2f, 0.04f);
            titleTransform4.position = new Vector3(0.057f, 0, 0.19f);  //z is title up and down
            titleTransform4.rotation = Quaternion.Euler(new Vector3(180, 90, 90));


            if (pageNumber == 1)
            {
                for (int i = 0; i < Pg1.Length; i++)
                {
                    AddButton(i * 0.13f, Pg1[i], Pg1, Pg1Active);
                }
            }
            else if (pageNumber == 2)
            {
                for (int i = 0; i < Pg2.Length; i++)
                {
                    AddButton(i * 0.13f, Pg2[i], Pg2, Pg2Active);
                }
            }
            else if (pageNumber == 3)
            {
                for (int i = 0; i < Pg3.Length; i++)
                {
                    AddButton(i * 0.13f, Pg3[i], Pg3, Pg3Active);
                }
            }
            else if (pageNumber == 4)
            {
                for (int i = 0; i < Pg4.Length; i++)
                {
                    AddButton(i * 0.13f, Pg4[i], Pg4, Pg4Active);
                }
            }
            else if (pageNumber == 5)
            {
                for (int i = 0; i < Pg5.Length; i++)
                {
                    AddButton(i * 0.13f, Pg5[i], Pg5, Pg5Active);
                }
            }
            else if (pageNumber == 6)
            {
                for (int i = 0; i < Pg6.Length; i++)
                {
                    AddButton(i * 0.13f, Pg6[i], Pg6, Pg6Active);
                }
            }
            else if (pageNumber == 7)
            {
                for (int i = 0; i < Pg7.Length; i++)
                {
                    AddButton(i * 0.13f, Pg7[i], Pg7, Pg7Active);
                }
            }
            else if (pageNumber == 8)
            {
                for (int i = 0; i < Pg8.Length; i++)
                {
                    AddButton(i * 0.13f, Pg8[i], Pg8, Pg8Active);
                }
            }
            else if (pageNumber == 9)
            {
                for (int i = 0; i < Pg9.Length; i++)
                {
                    AddButton(i * 0.13f, Pg9[i], Pg9, Pg9Active);
                }
            }
            else if (pageNumber == 10)
            {
                for (int i = 0; i < Pg10.Length; i++)
                {
                    AddButton(i * 0.13f, Pg10[i], Pg10, Pg10Active);
                }
            }
            else if (pageNumber == 11)
            {
                for (int i = 0; i < Pg11.Length; i++)
                {
                    AddButton(i * 0.13f, Pg11[i], Pg11, Pg11Active);
                }
            }
            else if (pageNumber == 12)
            {
                for (int i = 0; i < Pg12.Length; i++)
                {
                    AddButton(i * 0.13f, Pg12[i], Pg12, Pg12Active);
                }
            }
            else if (pageNumber == 13)
            {
                for (int i = 0; i < Pg13.Length; i++)
                {
                    AddButton(i * 0.13f, Pg13[i], Pg13, Pg13Active);
                }
            }
            else if (pageNumber == 14)
            {
                for (int i = 0; i < Pg14.Length; i++)
                {
                    AddButton(i * 0.13f, Pg14[i], Pg14, Pg14Active);
                }
            }
            else if (pageNumber == 15)
            {
                for (int i = 0; i < Pg15.Length; i++)
                {
                    AddButton(i * 0.13f, Pg15[i], Pg15, Pg15Active);
                }
            }
            else if (pageNumber == 16)
            {
                for (int i = 0; i < Pg16.Length; i++)
                {
                    AddButton(i * 0.13f, Pg16[i], Pg16, Pg16Active);
                }
            }
            else if (pageNumber == 17)
            {
                for (int i = 0; i < Pg17.Length; i++)
                {
                    AddButton(i * 0.13f, Pg17[i], Pg17, Pg17Active);
                }
            }
            else if (pageNumber == 18)
            {
                for (int i = 0; i < Pg18.Length; i++)
                {
                    AddButton(i * 0.13f, Pg18[i], Pg18, Pg18Active);
                }
            }
            else if (pageNumber == 19)
            {
                for (int i = 0; i < Pg19.Length; i++)
                {
                    AddButton(i * 0.13f, Pg19[i], Pg19, Pg19Active);
                }
            }
            else if (pageNumber == 20)
            {
                for (int i = 0; i < Pg20.Length; i++)
                {
                    AddButton(i * 0.13f, Pg20[i], Pg20, Pg20Active);
                }
            }
            else if (pageNumber == 21)
            {
                for (int i = 0; i < Pg21.Length; i++)
                {
                    AddButton(i * 0.13f, Pg21[i], Pg21, Pg21Active);
                }
            }
            else if (pageNumber == 22)
            {
                for (int i = 0; i < Pg22.Length; i++)
                {
                    AddButton(i * 0.13f, Pg22[i], Pg22, Pg22Active);
                }
            }
            else if (pageNumber == 23)
            {
                for (int i = 0; i < Pg23.Length; i++)
                {
                    AddButton(i * 0.13f, Pg23[i], Pg23, Pg23Active);
                }
            }
            else if (pageNumber == 24)
            {
                for (int i = 0; i < Pg24.Length; i++)
                {
                    AddButton(i * 0.13f, Pg24[i], Pg24, Pg24Active);
                }
            }
            else if (pageNumber == 25)
            {
                for (int i = 0; i < Pg25.Length; i++)
                {
                    AddButton(i * 0.13f, Pg25[i], Pg25, Pg25Active);
                }
            }
            else if (pageNumber == 26)
            {
                for (int i = 0; i < Pg26.Length; i++)
                {
                    AddButton(i * 0.13f, Pg26[i], Pg26, Pg26Active);
                }
            }
            else if (pageNumber == 27)
            {
                for (int i = 0; i < Pg27.Length; i++)
                {
                    AddButton(i * 0.13f, Pg27[i], Pg27, Pg27Active);
                }
            }
            else if (pageNumber == 28)
            {
                for (int i = 0; i < Pg28.Length; i++)
                {
                    AddButton(i * 0.13f, Pg28[i], Pg28, Pg28Active);
                }
            }
            else if (pageNumber == 29)
            {
                for (int i = 0; i < Pg29.Length; i++)
                {
                    AddButton(i * 0.13f, Pg29[i], Pg29, Pg29Active);
                }
            }
            else if (pageNumber == 30)
            {
                for (int i = 0; i < Pg30.Length; i++)
                {
                    AddButton(i * 0.13f, Pg30[i], Pg30, Pg30Active);
                }
            }
            else if (pageNumber == 31)
            {
                for (int i = 0; i < Pg31.Length; i++)
                {
                    AddButton(i * 0.13f, Pg31[i], Pg31, Pg31Active);
                }
            }
            else if (pageNumber == 32)
            {
                for (int i = 0; i < Pg32.Length; i++)
                {
                    AddButton(i * 0.13f, Pg32[i], Pg32, Pg32Active);
                }
            }
            else if (pageNumber == 33)
            {
                for (int i = 0; i < Pg33.Length; i++)
                {
                    AddButton(i * 0.13f, Pg33[i], Pg33, Pg33Active);
                }
            }
            else if (pageNumber == 34)
            {
                for (int i = 0; i < Pg34.Length; i++)
                {
                    AddButton(i * 0.13f, Pg34[i], Pg34, Pg34Active);
                }
            }
            else if (pageNumber == 35)
            {
                for (int i = 0; i < Pg35.Length; i++)
                {
                    AddButton(i * 0.13f, Pg35[i], Pg35, Pg35Active);
                }
            }
            else if (pageNumber == 36)
            {
                for (int i = 0; i < Pg36.Length; i++)
                {
                    AddButton(i * 0.13f, Pg36[i], Pg36, Pg36Active);
                }
            }
            else if (pageNumber == 37)
            {
                for (int i = 0; i < Pg37.Length; i++)
                {
                    AddButton(i * 0.13f, Pg37[i], Pg37, Pg37Active);
                }
            }
            else if (pageNumber == 38)
            {
                for (int i = 0; i < Pg38.Length; i++)
                {
                    AddButton(i * 0.13f, Pg38[i], Pg38, Pg38Active);
                }
            }
            else if (pageNumber == 39)
            {
                for (int i = 0; i < Pg39.Length; i++)
                {
                    AddButton(i * 0.13f, Pg39[i], Pg39, Pg39Active);
                }
            }
            else if (pageNumber == 40)
            {
                for (int i = 0; i < Pg40.Length; i++)
                {
                    AddButton(i * 0.13f, Pg40[i], Pg40, Pg40Active);
                }
            }
            else if (pageNumber == 41)
            {
                for (int i = 0; i < Pg41.Length; i++)
                {
                    AddButton(i * 0.13f, Pg41[i], Pg41, Pg41Active);
                }
            }
            else if (pageNumber == 42)
            {
                for (int i = 0; i < Pg42.Length; i++)
                {
                    AddButton(i * 0.13f, Pg42[i], Pg42, Pg42Active);
                }
            }
            else if (pageNumber == 43)
            {
                for (int i = 0; i < Pg43.Length; i++)
                {
                    AddButton(i * 0.13f, Pg43[i], Pg43, Pg43Active);
                }
            }
            else if (pageNumber == 44)
            {
                for (int i = 0; i < Pg44.Length; i++)
                {
                    AddButton(i * 0.13f, Pg44[i], Pg44, Pg44Active);
                }
            }
            else if (pageNumber == 45)
            {
                for (int i = 0; i < Pg45.Length; i++)
                {
                    AddButton(i * 0.13f, Pg45[i], Pg45, Pg45Active);
                }
            }
            else if (pageNumber == 46)
            {
                for (int i = 0; i < Pg46.Length; i++)
                {
                    AddButton(i * 0.13f, Pg46[i], Pg46, Pg46Active);
                }
            }
            else if (pageNumber == 47)
            {
                for (int i = 0; i < Pg47.Length; i++)
                {
                    AddButton(i * 0.13f, Pg47[i], Pg47, Pg47Active);
                }
            }
            else if (pageNumber == 48)
            {
                for (int i = 0; i < Pg48.Length; i++)
                {
                    AddButton(i * 0.13f, Pg48[i], Pg48, Pg48Active);
                }
            }
            else if (pageNumber == 49)
            {
                for (int i = 0; i < Pg49.Length; i++)
                {
                    AddButton(i * 0.13f, Pg49[i], Pg49, Pg49Active);
                }
            }
            else if (pageNumber == 50)
            {
                for (int i = 0; i < Pg50.Length; i++)
                {
                    AddButton(i * 0.13f, Pg50[i], Pg50, Pg50Active);
                }
            }
            else if (pageNumber == 51)
            {
                for (int i = 0; i < Pg51.Length; i++)
                {
                    AddButton(i * 0.13f, Pg51[i], Pg51, Pg51Active);
                }
            }
            else if (pageNumber == 52)
            {
                for (int i = 0; i < Pg52.Length; i++)
                {
                    AddButton(i * 0.13f, Pg52[i], Pg52, Pg52Active);
                }
            }
            else if (pageNumber == 53)
            {
                for (int i = 0; i < Pg53.Length; i++)
                {
                    AddButton(i * 0.13f, Pg53[i], Pg53, Pg53Active);
                }
            }
            else if (pageNumber == 54)
            {
                for (int i = 0; i < Pg54.Length; i++)
                {
                    AddButton(i * 0.13f, Pg54[i], Pg54, Pg54Active);
                }
            }
            else if (pageNumber == 55)
            {
                for (int i = 0; i < Pg55.Length; i++)
                {
                    AddButton(i * 0.13f, Pg55[i], Pg55, Pg5Active);
                }
            }
            else if (pageNumber == 56)
            {
                for (int i = 0; i < Pg56.Length; i++)
                {
                    AddButton(i * 0.13f, Pg56[i], Pg56, Pg56Active);
                }
            }
            else if (pageNumber == 57)
            {
                for (int i = 0; i < Pg57.Length; i++)
                {
                    AddButton(i * 0.13f, Pg57[i], Pg57, Pg57Active);
                }
            }
            else if (pageNumber == 58)
            {
                for (int i = 0; i < Pg58.Length; i++)
                {
                    AddButton(i * 0.13f, Pg58[i], Pg58, Pg58Active);
                }
            }
            else if (pageNumber == 59)
            {
                for (int i = 0; i < Pg59.Length; i++)
                {
                    AddButton(i * 0.13f, Pg59[i], Pg59, Pg59Active);
                }
            }
            else if (pageNumber == 60)
            {
                for (int i = 0; i < Pg60.Length; i++)
                {
                    AddButton(i * 0.13f, Pg60[i], Pg60, Pg60Active);
                }
            }
            else if (pageNumber == 61)
            {
                for (int i = 0; i < Pg61.Length; i++)
                {
                    AddButton(i * 0.13f, Pg61[i], Pg61, Pg61Active);
                }
            }
            else if (pageNumber == 62)
            {
                for (int i = 0; i < Pg62.Length; i++)
                {
                    AddButton(i * 0.13f, Pg62[i], Pg62, Pg62Active);
                }
            }
            else if (pageNumber == 63)
            {
                for (int i = 0; i < Pg63.Length; i++)
                {
                    AddButton(i * 0.13f, Pg63[i], Pg63, Pg63Active);
                }
            }
            else if (pageNumber == 64)
            {
                for (int i = 0; i < Pg64.Length; i++)
                {
                    AddButton(i * 0.13f, Pg64[i], Pg64, Pg64Active);
                }
            }
            else if (pageNumber == 65)
            {
                for (int i = 0; i < Pg65.Length; i++)
                {
                    AddButton(i * 0.13f, Pg65[i], Pg65, Pg65Active);
                }
            }
            else if (pageNumber == 66)
            {
                for (int i = 0; i < Pg66.Length; i++)
                {
                    AddButton(i * 0.13f, Pg66[i], Pg66, Pg66Active);
                }
            }
            else if (pageNumber == 67)
            {
                for (int i = 0; i < Pg67.Length; i++)
                {
                    AddButton(i * 0.13f, Pg67[i], Pg67, Pg67Active);
                }
            }
            else if (pageNumber == 68)
            {
                for (int i = 0; i < Pg68.Length; i++)
                {
                    AddButton(i * 0.13f, Pg68[i], Pg68, Pg68Active);
                }
            }
            else if (pageNumber == 69)
            {
                for (int i = 0; i < Pg69.Length; i++)
                {
                    AddButton(i * 0.13f, Pg69[i], Pg69, Pg69Active);
                }
            }
            else if (pageNumber == 70)
            {
                for (int i = 0; i < Pg70.Length; i++)
                {
                    AddButton(i * 0.13f, Pg70[i], Pg70, Pg70Active);
                }
            }
            else if (pageNumber == 71)
            {
                for (int i = 0; i < Pg71.Length; i++)
                {
                    AddButton(i * 0.13f, Pg71[i], Pg71, Pg71Active);
                }
            }
            else if (pageNumber == 72)
            {
                for (int i = 0; i < Pg72.Length; i++)
                {
                    AddButton(i * 0.13f, Pg72[i], Pg72, Pg72Active);
                }
            }
            else if (pageNumber == 73)
            {
                for (int i = 0; i < Pg73.Length; i++)
                {
                    AddButton(i * 0.13f, Pg73[i], Pg73, Pg73Active);
                }
            }
            else if (pageNumber == 74)
            {
                for (int i = 0; i < Pg74.Length; i++)
                {
                    AddButton(i * 0.13f, Pg74[i], Pg74, Pg74Active);
                }
            }
            else if (pageNumber == 75)
            {
                for (int i = 0; i < Pg75.Length; i++)
                {
                    AddButton(i * 0.13f, Pg75[i], Pg75, Pg75Active);
                }
            }
            /*
            else if (pageNumber == 76)
            {
                for (int i = 0; i < Pg76.Length; i++)
                {
                    AddButton(i * 0.13f, Pg76[i], Pg76, Pg76Active);
                }
            }
            else if (pageNumber == 77)
            {
                for (int i = 0; i < Pg77.Length; i++)
                {
                    AddButton(i * 0.13f, Pg77[i], Pg77, Pg77Active);
                }
            }
            else if (pageNumber == 78)
            {
                for (int i = 0; i < Pg78.Length; i++)
                {
                    AddButton(i * 0.13f, Pg78[i], Pg78, Pg78Active);
                }
            }
            else if (pageNumber == 79)
            {
                for (int i = 0; i < Pg79.Length; i++)
                {
                    AddButton(i * 0.13f, Pg79[i], Pg79, Pg79Active);
                }
            }
            else if (pageNumber == 80)
            {
                for (int i = 0; i < Pg80.Length; i++)
                {
                    AddButton(i * 0.13f, Pg80[i], Pg80, Pg80Active);
                }
            }
            else if (pageNumber == 81)
            {
                for (int i = 0; i < Pg81.Length; i++)
                {
                    AddButton(i * 0.13f, Pg81[i], Pg81, Pg81Active);
                }
            }
            else if (pageNumber == 82)
            {
                for (int i = 0; i < Pg82.Length; i++)
                {
                    AddButton(i * 0.13f, Pg82[i], Pg82, Pg82Active);
                }
            }
            else if (pageNumber == 83)
            {
                for (int i = 0; i < Pg83.Length; i++)
                {
                    AddButton(i * 0.13f, Pg83[i], Pg83, Pg83Active);
                }
            }
            else if (pageNumber == 84)
            {
                for (int i = 0; i < Pg84.Length; i++)
                {
                    AddButton(i * 0.13f, Pg84[i], Pg84, Pg84Active);
                }
            }
            else if (pageNumber == 85)
            {
                for (int i = 0; i < Pg85.Length; i++)
                {
                    AddButton(i * 0.13f, Pg85[i], Pg85, Pg85Active);
                }
            }
            else if (pageNumber == 86)
            {
                for (int i = 0; i < Pg86.Length; i++)
                {
                    AddButton(i * 0.13f, Pg86[i], Pg86, Pg86Active);
                }
            }
            else if (pageNumber == 87)
            {
                for (int i = 0; i < Pg87.Length; i++)
                {
                    AddButton(i * 0.13f, Pg87[i], Pg87, Pg87Active);
                }
            }
            else if (pageNumber == 88)
            {
                for (int i = 0; i < Pg88.Length; i++)
                {
                    AddButton(i * 0.13f, Pg88[i], Pg88, Pg88Active);
                }
            }
            else if (pageNumber == 89)
            {
                for (int i = 0; i < Pg89.Length; i++)
                {
                    AddButton(i * 0.13f, Pg89[i], Pg89, Pg89Active);
                }
            }
            else if (pageNumber == 90)
            {
                for (int i = 0; i < Pg90.Length; i++)
                {
                    AddButton(i * 0.13f, Pg90[i], Pg90, Pg90Active);
                }
            }
            else if (pageNumber == 91)
            {
                for (int i = 0; i < Pg91.Length; i++)
                {
                    AddButton(i * 0.13f, Pg91[i], Pg91, Pg91Active);
                }
            }
            else if (pageNumber == 92)
            {
                for (int i = 0; i < Pg92.Length; i++)
                {
                    AddButton(i * 0.13f, Pg92[i], Pg92, Pg92Active);
                }
            }
            else if (pageNumber == 93)
            {
                for (int i = 0; i < Pg93.Length; i++)
                {
                    AddButton(i * 0.13f, Pg93[i], Pg93, Pg93Active);
                }
            }
            else if (pageNumber == 94)
            {
                for (int i = 0; i < Pg94.Length; i++)
                {
                    AddButton(i * 0.13f, Pg94[i], Pg94, Pg94Active);
                }
            }
            else if (pageNumber == 95)
            {
                for (int i = 0; i < Pg95.Length; i++)
                {
                    AddButton(i * 0.13f, Pg95[i], Pg95, Pg95Active);
                }
            }
            else if (pageNumber == 96)
            {
                for (int i = 0; i < Pg96.Length; i++)
                {
                    AddButton(i * 0.13f, Pg96[i], Pg96, Pg96Active);
                }
            }
            else if (pageNumber == 97)
            {
                for (int i = 0; i < Pg97.Length; i++)
                {
                    AddButton(i * 0.13f, Pg97[i], Pg97, Pg97Active);
                }
            }
            else if (pageNumber == 98)
            {
                for (int i = 0; i < Pg98.Length; i++)
                {
                    AddButton(i * 0.13f, Pg98[i], Pg98, Pg98Active);
                }
            }
            else if (pageNumber == 99)
            {
                for (int i = 0; i < Pg99.Length; i++)
                {
                    AddButton(i * 0.13f, Pg99[i], Pg99, Pg99Active);
                }
            }
            else if (pageNumber == 100)
            {
                for (int i = 0; i < Pg100.Length; i++)
                {
                    AddButton(i * 0.13f, Pg100[i], Pg100, Pg100Active);
                }
            }
            else if (pageNumber == 101)
            {
                for (int i = 0; i < Pg101.Length; i++)
                {
                    AddButton(i * 0.13f, Pg101[i], Pg101, Pg101Active);
                }
            }
            else if (pageNumber == 102)
            {
                for (int i = 0; i < Pg102.Length; i++)
                {
                    AddButton(i * 0.13f, Pg102[i], Pg102, Pg102Active);
                }
            }
            else if (pageNumber == 103)
            {
                for (int i = 0; i < Pg103.Length; i++)
                {
                    AddButton(i * 0.13f, Pg103[i], Pg103, Pg103Active);
                }
            }
            else if (pageNumber == 104)
            {
                for (int i = 0; i < Pg104.Length; i++)
                {
                    AddButton(i * 0.13f, Pg104[i], Pg104, Pg104Active);
                }
            }
            else if (pageNumber == 105)
            {
                for (int i = 0; i < Pg105.Length; i++)
                {
                    AddButton(i * 0.13f, Pg105[i], Pg105, Pg105Active);
                }
            }
            else if (pageNumber == 106)
            {
                for (int i = 0; i < Pg106.Length; i++)
                {
                    AddButton(i * 0.13f, Pg106[i], Pg106, Pg106Active);
                }
            }
            else if (pageNumber == 107)
            {
                for (int i = 0; i < Pg107.Length; i++)
                {
                    AddButton(i * 0.13f, Pg107[i], Pg107, Pg107Active);
                }
            }
            else if (pageNumber == 108)
            {
                for (int i = 0; i < Pg108.Length; i++)
                {
                    AddButton(i * 0.13f, Pg108[i], Pg108, Pg108Active);
                }
            }
            else if (pageNumber == 109)
            {
                for (int i = 0; i < Pg109.Length; i++)
                {
                    AddButton(i * 0.13f, Pg109[i], Pg109, Pg109Active);
                }
            }
            else if (pageNumber == 110)
            {
                for (int i = 0; i < Pg110.Length; i++)
                {
                    AddButton(i * 0.13f, Pg110[i], Pg110, Pg110Active);
                }
            }
            else if (pageNumber == 111)
            {
                for (int i = 0; i < Pg111.Length; i++)
                {
                    AddButton(i * 0.13f, Pg111[i], Pg111, Pg111Active);
                }
            }
            else if (pageNumber == 112)
            {
                for (int i = 0; i < Pg112.Length; i++)
                {
                    AddButton(i * 0.13f, Pg112[i], Pg112, Pg112Active);
                }
            }
            else if (pageNumber == 113)
            {
                for (int i = 0; i < Pg113.Length; i++)
                {
                    AddButton(i * 0.13f, Pg113[i], Pg113, Pg113Active);
                }
            }
            else if (pageNumber == 114)
            {
                for (int i = 0; i < Pg114.Length; i++)
                {
                    AddButton(i * 0.13f, Pg114[i], Pg114, Pg114Active);
                }
            }
            else if (pageNumber == 115)
            {
                for (int i = 0; i < Pg115.Length; i++)
                {
                    AddButton(i * 0.13f, Pg115[i], Pg115, Pg115Active);
                }
            }
            else if (pageNumber == 116)
            {
                for (int i = 0; i < Pg116.Length; i++)
                {
                    AddButton(i * 0.13f, Pg116[i], Pg116, Pg116Active);
                }
            }
            else if (pageNumber == 117)
            {
                for (int i = 0; i < Pg117.Length; i++)
                {
                    AddButton(i * 0.13f, Pg117[i], Pg117, Pg117Active);
                }
            }
            else if (pageNumber == 118)
            {
                for (int i = 0; i < Pg118.Length; i++)
                {
                    AddButton(i * 0.13f, Pg118[i], Pg118, Pg118Active);
                }
            }
            else if (pageNumber == 119)
            {
                for (int i = 0; i < Pg119.Length; i++)
                {
                    AddButton(i * 0.13f, Pg119[i], Pg119, Pg119Active);
                }
            }
            else if (pageNumber == 120)
            {
                for (int i = 0; i < Pg120.Length; i++)
                {
                    AddButton(i * 0.13f, Pg120[i], Pg120, Pg120Active);
                }
            }

            else if (pageNumber == 121)
            {
                for (int i = 0; i < Pg121.Length; i++)
                {
                    AddButton(i * 0.13f, Pg121[i], Pg121, Pg121Active);
                }
            }
            else if (pageNumber == 122)
            {
                for (int i = 0; i < Pg122.Length; i++)
                {
                    AddButton(i * 0.13f, Pg122[i], Pg122, Pg122Active);
                }
            }
            else if (pageNumber == 123)
            {
                for (int i = 0; i < Pg123.Length; i++)
                {
                    AddButton(i * 0.13f, Pg123[i], Pg123, Pg123Active);
                }
            }
            else if (pageNumber == 124)
            {
                for (int i = 0; i < Pg124.Length; i++)
                {
                    AddButton(i * 0.13f, Pg124[i], Pg124, Pg124Active);
                }
            }
            else if (pageNumber == 125)
            {
                for (int i = 0; i < Pg125.Length; i++)
                {
                    AddButton(i * 0.13f, Pg125[i], Pg125, Pg125Active);
                }
            }
            else if (pageNumber == 126)
            {
                for (int i = 0; i < Pg126.Length; i++)
                {
                    AddButton(i * 0.13f, Pg126[i], Pg126, Pg126Active);
                }
            }
            else if (pageNumber == 127)
            {
                for (int i = 0; i < Pg127.Length; i++)
                {
                    AddButton(i * 0.13f, Pg127[i], Pg127, Pg127Active);
                }
            }
            else if (pageNumber == 128)
            {
                for (int i = 0; i < Pg128.Length; i++)
                {
                    AddButton(i * 0.13f, Pg128[i], Pg128, Pg128Active);
                }
            }
            else if (pageNumber == 129)
            {
                for (int i = 0; i < Pg129.Length; i++)
                {
                    AddButton(i * 0.13f, Pg129[i], Pg129, Pg129Active);
                }
            }
            else if (pageNumber == 130)
            {
                for (int i = 0; i < Pg130.Length; i++)
                {
                    AddButton(i * 0.13f, Pg130[i], Pg130, Pg130Active);
                }
            }

            else if (pageNumber == 131)
            {
                for (int i = 0; i < Pg131.Length; i++)
                {
                    AddButton(i * 0.13f, Pg131[i], Pg131, Pg131Active);
                }
            }
            else if (pageNumber == 132)
            {
                for (int i = 0; i < Pg132.Length; i++)
                {
                    AddButton(i * 0.13f, Pg132[i], Pg132, Pg132Active);
                }
            }
            else if (pageNumber == 133)
            {
                for (int i = 0; i < Pg133.Length; i++)
                {
                    AddButton(i * 0.13f, Pg133[i], Pg133, Pg133Active);
                }
            }
            else if (pageNumber == 134)
            {
                for (int i = 0; i < Pg134.Length; i++)
                {
                    AddButton(i * 0.13f, Pg134[i], Pg134, Pg134Active);
                }
            }
            else if (pageNumber == 135)
            {
                for (int i = 0; i < Pg135.Length; i++)
                {
                    AddButton(i * 0.13f, Pg135[i], Pg135, Pg135Active);
                }
            }
            else if (pageNumber == 136)
            {
                for (int i = 0; i < Pg136.Length; i++)
                {
                    AddButton(i * 0.13f, Pg136[i], Pg136, Pg136Active);
                }
            }
            else if (pageNumber == 137)
            {
                for (int i = 0; i < Pg137.Length; i++)
                {
                    AddButton(i * 0.13f, Pg137[i], Pg137, Pg137Active);
                }
            }

            else if (pageNumber == 138)
            {
                for (int i = 0; i < Pg138.Length; i++)
                {
                    AddButton(i * 0.13f, Pg138[i], Pg138, Pg138Active);
                }
            }
            else if (pageNumber == 139)
            {
                for (int i = 0; i < Pg139.Length; i++)
                {
                    AddButton(i * 0.13f, Pg139[i], Pg139, Pg139Active);
                }
            }
            else if (pageNumber == 140)
            {
                for (int i = 0; i < Pg140.Length; i++)
                {
                    AddButton(i * 0.13f, Pg140[i], Pg140, Pg140Active);
                }
            }
            else if (pageNumber == 141)
            {
                for (int i = 0; i < Pg141.Length; i++)
                {
                    AddButton(i * 0.13f, Pg141[i], Pg141, Pg141Active);
                }
            }
            else if (pageNumber == 142)
            {
                for (int i = 0; i < Pg142.Length; i++)
                {
                    AddButton(i * 0.13f, Pg142[i], Pg142, Pg142Active);
                }
            }
            else if (pageNumber == 143)
            {
                for (int i = 0; i < Pg143.Length; i++)
                {
                    AddButton(i * 0.13f, Pg143[i], Pg143, Pg143Active);
                }
            }
            else if (pageNumber == 144)
            {
                for (int i = 0; i < Pg144.Length; i++)
                {
                    AddButton(i * 0.13f, Pg144[i], Pg144, Pg144Active);
                }
            }
            else if (pageNumber == 145)
            {
                for (int i = 0; i < Pg145.Length; i++)
                {
                    AddButton(i * 0.13f, Pg145[i], Pg145, Pg145Active);
                }
            }
            else if (pageNumber == 146)
            {
                for (int i = 0; i < Pg146.Length; i++)
                {
                    AddButton(i * 0.13f, Pg146[i], Pg146, Pg146Active);
                }
            }
            else if (pageNumber == 147)
            {
                for (int i = 0; i < Pg147.Length; i++)
                {
                    AddButton(i * 0.13f, Pg147[i], Pg147, Pg147Active);
                }
            }
            else if (pageNumber == 148)
            {
                for (int i = 0; i < Pg148.Length; i++)
                {
                    AddButton(i * 0.13f, Pg148[i], Pg148, Pg148Active);
                }
            }
            else if (pageNumber == 149)
            {
                for (int i = 0; i < Pg149.Length; i++)
                {
                    AddButton(i * 0.13f, Pg149[i], Pg149, Pg149Active);
                }
            }
            else if (pageNumber == 150)
            {
                for (int i = 0; i < Pg150.Length; i++)
                {
                    AddButton(i * 0.13f, Pg150[i], Pg150, Pg150Active);
                }
            }
            else if (pageNumber == 151)
            {
                for (int i = 0; i < Pg151.Length; i++)
                {
                    AddButton(i * 0.13f, Pg151[i], Pg151, Pg151Active);
                }
            }
            else if (pageNumber == 152)
            {
                for (int i = 0; i < Pg152.Length; i++)
                {
                    AddButton(i * 0.13f, Pg152[i], Pg152, Pg152Active);
                }
            }
            else if (pageNumber == 153)
            {
                for (int i = 0; i < Pg153.Length; i++)
                {
                    AddButton(i * 0.13f, Pg153[i], Pg153, Pg153Active);
                }
            }
            else if (pageNumber == 154)
            {
                for (int i = 0; i < Pg154.Length; i++)
                {
                    AddButton(i * 0.13f, Pg154[i], Pg154, Pg154Active);
                }
            }
            else if (pageNumber == 155)
            {
                for (int i = 0; i < Pg155.Length; i++)
                {
                    AddButton(i * 0.13f, Pg155[i], Pg155, Pg155Active);
                }
            }
            else if (pageNumber == 156)
            {
                for (int i = 0; i < Pg156.Length; i++)
                {
                    AddButton(i * 0.13f, Pg156[i], Pg156, Pg156Active);
                }
            }
            else if (pageNumber == 157)
            {
                for (int i = 0; i < Pg157.Length; i++)
                {
                    AddButton(i * 0.13f, Pg157[i], Pg157, Pg157Active);
                }
            }
            else if (pageNumber == 158)
            {
                for (int i = 0; i < Pg158.Length; i++)
                {
                    AddButton(i * 0.13f, Pg158[i], Pg158, Pg158Active);
                }
            }
            else if (pageNumber == 159)
            {
                for (int i = 0; i < Pg159.Length; i++)
                {
                    AddButton(i * 0.13f, Pg159[i], Pg159, Pg159Active);
                }
            }
            else if (pageNumber == 160)
            {
                for (int i = 0; i < Pg160.Length; i++)
                {
                    AddButton(i * 0.13f, Pg160[i], Pg160, Pg160Active);
                }
            }
            else if (pageNumber == 161)
            {
                for (int i = 0; i < Pg161.Length; i++)
                {
                    AddButton(i * 0.13f, Pg161[i], Pg161, Pg161Active);
                }
            }
            else if (pageNumber == 162)
            {
                for (int i = 0; i < Pg162.Length; i++)
                {
                    AddButton(i * 0.13f, Pg162[i], Pg162, Pg162Active);
                }
            }
            else if (pageNumber == 163)
            {
                for (int i = 0; i < Pg163.Length; i++)
                {
                    AddButton(i * 0.13f, Pg163[i], Pg163, Pg163Active);
                }
            }
            else if (pageNumber == 164)
            {
                for (int i = 0; i < Pg164.Length; i++)
                {
                    AddButton(i * 0.13f, Pg164[i], Pg164, Pg164Active);
                }
            }
            else if (pageNumber == 165)
            {
                for (int i = 0; i < Pg165.Length; i++)
                {
                    AddButton(i * 0.13f, Pg165[i], Pg165, Pg165Active);
                }
            }
            else if (pageNumber == 166)
            {
                for (int i = 0; i < Pg166.Length; i++)
                {
                    AddButton(i * 0.13f, Pg166[i], Pg166, Pg166Active);
                }
            }
            else if (pageNumber == 167)
            {
                for (int i = 0; i < Pg167.Length; i++)
                {
                    AddButton(i * 0.13f, Pg167[i], Pg167, Pg167Active);
                }
            }
            else if (pageNumber == 168)
            {
                for (int i = 0; i < Pg168.Length; i++)
                {
                    AddButton(i * 0.13f, Pg168[i], Pg168, Pg168Active);
                }
            }
            else if (pageNumber == 169)
            {
                for (int i = 0; i < Pg169.Length; i++)
                {
                    AddButton(i * 0.13f, Pg169[i], Pg169, Pg169Active);
                }
            }
            else if (pageNumber == 170)
            {
                for (int i = 0; i < Pg170.Length; i++)
                {
                    AddButton(i * 0.13f, Pg170[i], Pg170, Pg170Active);
                }
            }
            else if (pageNumber == 171)
            {
                for (int i = 0; i < Pg171.Length; i++)
                {
                    AddButton(i * 0.13f, Pg171[i], Pg171, Pg171Active);
                }
            }
            else if (pageNumber == 172)
            {
                for (int i = 0; i < Pg172.Length; i++)
                {
                    AddButton(i * 0.13f, Pg172[i], Pg172, Pg172Active);
                }
            }
            else if (pageNumber == 173)
            {
                for (int i = 0; i < Pg173.Length; i++)
                {
                    AddButton(i * 0.13f, Pg173[i], Pg173, Pg173Active);
                }
            }
            else if (pageNumber == 174)
            {
                for (int i = 0; i < Pg174.Length; i++)
                {
                    AddButton(i * 0.13f, Pg174[i], Pg174, Pg174Active);
                }
            }
            else if (pageNumber == 175)
            {
                for (int i = 0; i < Pg175.Length; i++)
                {
                    AddButton(i * 0.13f, Pg175[i], Pg175, Pg175Active);
                }
            }
            else if (pageNumber == 176)
            {
                for (int i = 0; i < Pg176.Length; i++)
                {
                    AddButton(i * 0.13f, Pg176[i], Pg176, Pg176Active);
                }
            }
            else if (pageNumber == 177)
            {
                for (int i = 0; i < Pg177.Length; i++)
                {
                    AddButton(i * 0.13f, Pg177[i], Pg177, Pg177Active);
                }
            }
            else if (pageNumber == 178)
            {
                for (int i = 0; i < Pg178.Length; i++)
                {
                    AddButton(i * 0.13f, Pg178[i], Pg178, Pg178Active);
                }
            }
            else if (pageNumber == 179)
            {
                for (int i = 0; i < Pg179.Length; i++)
                {
                    AddButton(i * 0.13f, Pg179[i], Pg179, Pg179Active);
                }
            }
            else if (pageNumber == 180)
            {
                for (int i = 0; i < Pg180.Length; i++)
                {
                    AddButton(i * 0.13f, Pg180[i], Pg180, Pg180Active);
                }
            }
            else if (pageNumber == 181)
            {
                for (int i = 0; i < Pg181.Length; i++)
                {
                    AddButton(i * 0.13f, Pg181[i], Pg181, Pg181Active);
                }
            }
            else if (pageNumber == 182)
            {
                for (int i = 0; i < Pg182.Length; i++)
                {
                    AddButton(i * 0.13f, Pg182[i], Pg182, Pg182Active);
                }
            }
            else if (pageNumber == 183)
            {
                for (int i = 0; i < Pg183.Length; i++)
                {
                    AddButton(i * 0.13f, Pg183[i], Pg183, Pg183Active);
                }
            }
            else if (pageNumber == 184)
            {
                for (int i = 0; i < Pg184.Length; i++)
                {
                    AddButton(i * 0.13f, Pg184[i], Pg184, Pg184Active);
                }
            }
            else if (pageNumber == 185)
            {
                for (int i = 0; i < Pg185.Length; i++)
                {
                    AddButton(i * 0.13f, Pg185[i], Pg185, Pg185Active);
                }
            }
            else if (pageNumber == 186)
            {
                for (int i = 0; i < Pg186.Length; i++)
                {
                    AddButton(i * 0.13f, Pg186[i], Pg186, Pg186Active);
                }
            }
            else if (pageNumber == 187)
            {
                for (int i = 0; i < Pg187.Length; i++)
                {
                    AddButton(i * 0.13f, Pg187[i], Pg187, Pg187Active);
                }
            }
            else if (pageNumber == 188)
            {
                for (int i = 0; i < Pg18.Length; i++)
                {
                    AddButton(i * 0.13f, Pg188[i], Pg188, Pg188Active);
                }
            }
            else if (pageNumber == 189)
            {
                for (int i = 0; i < Pg189.Length; i++)
                {
                    AddButton(i * 0.13f, Pg189[i], Pg189, Pg189Active);
                }
            }
            else if (pageNumber == 190)
            {
                for (int i = 0; i < Pg190.Length; i++)
                {
                    AddButton(i * 0.13f, Pg190[i], Pg190, Pg190Active);
                }
            }
            else if (pageNumber == 191)
            {
                for (int i = 0; i < Pg191.Length; i++)
                {
                    AddButton(i * 0.13f, Pg191[i], Pg191, Pg191Active);
                }
            }
            else if (pageNumber == 192)
            {
                for (int i = 0; i < Pg192.Length; i++)
                {
                    AddButton(i * 0.13f, Pg192[i], Pg192, Pg192Active);
                }
            }
            else if (pageNumber == 193)
            {
                for (int i = 0; i < Pg193.Length; i++)
                {
                    AddButton(i * 0.13f, Pg193[i], Pg193, Pg193Active);
                }
            }
            */
            else if (pageNumber == 123456789)
            {
                for (int i = 0; i < Pg123456789.Length; i++)
                {
                    AddButton(i * 0.13f, Pg123456789[i], Pg123456789, Pg123456789Active);
                }
            }
            else if (pageNumber == 2500)
            {
                for (int i = 0; i < Pg2500.Length; i++)
                {
                    AddButton(i * 0.13f, Pg2500[i], Pg2500, Pg2500Active);
                }
            }
            else if (pageNumber == 2501)
            {
                for (int i = 0; i < Pg2501.Length; i++)
                {
                    AddButton(i * 0.13f, Pg2501[i], Pg2501, Pg2501Active);
                }
            }
            else if (pageNumber == 3000)
            {
                for (int i = 0; i < Pg3000.Length; i++)
                {
                    AddButton(i * 0.13f, Pg3000[i], Pg3000, Pg3000Active);
                }
            }
        }

        static void AddButton(float offset, string text, string[] btns, bool?[] btnsActive)
        {
            GameObject newBtn = GameObject.CreatePrimitive(PrimitiveType.Cube);

            newBtn.transform.SetParent(MenuObj.transform, true);
            newBtn.transform.rotation = Quaternion.identity;
            newBtn.transform.localScale = new Vector3(0.78f, 0.9f, 0.08f);      //y axis is how slim the buttons are
            newBtn.transform.localPosition = new Vector3(6f, 0f, 0.285f - offset);   //y axis is left and right // X axis is forward and backward // z axis is

            GameObject.Destroy(newBtn.GetComponent<Rigidbody>());
            newBtn.GetComponent<BoxCollider>().isTrigger = true;
            newBtn.AddComponent<ButtonCollision>().Identity = text;

            int index = -1;

            for (int i = 0; i < btns.Length; i++)
            {
                if (text == btns[i])
                {
                    index = i;
                    break;
                }
            }


            if (btnsActive[index] == false)
            {
                newBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                newBtn.GetComponent<Renderer>().material.color = new Color(ColorManager.ButtonR, ColorManager.ButtonG, ColorManager.ButtonB);
            }


            // BTN ON

            else if (btnsActive[index] == true)
            {
                newBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                newBtn.GetComponent<Renderer>().material.color = new Color(ColorManager.ButtonOnR, ColorManager.ButtonOnG, ColorManager.ButtonOnB);
            }


            // BTN ELSE

            else
            {
                newBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                newBtn.GetComponent<Renderer>().material.color = new Color(ColorManager.MenuR, ColorManager.MenuG, ColorManager.MenuB);
            }


            GameObject titleObj = new GameObject();
            titleObj.transform.parent = canvasObj.transform;
            Text title = titleObj.AddComponent<Text>();
            title.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            title.fontSize = 1;
            title.alignment = TextAnchor.MiddleCenter;
            title.resizeTextForBestFit = true;
            title.resizeTextMinSize = 0;

            title.text = text;
            title.color = new Color(ColorManager.ButtonTextR, ColorManager.ButtonTextG, ColorManager.ButtonTextB);

            if (btnsActive[index] == true)
            {
                title.color = new Color(ColorManager.ButtonOnTextR, ColorManager.ButtonOnTextG, ColorManager.ButtonOnTextB);
            }



            RectTransform titleTransform = title.GetComponent<RectTransform>();
            titleTransform.localPosition = Vector3.zero;
            titleTransform.sizeDelta = new Vector2(0.175f, 0.028f);
            titleTransform.position = new Vector3(0.064f, 0, 0.0965f - (offset / 3f));
            titleTransform.rotation = Quaternion.Euler(new Vector3(180, 90, 90));

        }

        public static void AddCustomButton(string text, float offset, bool btnActive, float width, float height, float LR)
        {
            GameObject addBtn = GameObject.CreatePrimitive(PrimitiveType.Cube);
            addBtn.transform.parent = MenuObj.transform;
            addBtn.transform.localScale = new Vector3(1.2f, width, height);
            addBtn.transform.position = new Vector3(0.05f, LR, offset);
            addBtn.AddComponent<ButtonCollision>().Identity = text;
            addBtn.GetComponent<BoxCollider>().isTrigger = true;
            addBtn.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            addBtn.GetComponent<MeshRenderer>().material.color = Color.grey;
            addBtn.GetComponent<Renderer>().material = ColorManager.ColorScheme;

            Buttons.AddItem(text);
            ButtonsActive.AddItem(btnActive);

            GameObject.Destroy(addBtn.GetComponent<Rigidbody>());
        }
        public static void ToggleButton(string btnIdentity, string[] btns, bool?[] btnsActive)
        {
            int index = -1;
            for (int i = 0; i < btns.Length; i++)
            {
                if (btnIdentity == btns[i])
                {
                    index = i;
                    break;
                }
            }
            if (btnsActive[index] != null)
            {
                btnsActive[index] = !btnsActive[index];

                InterstellarUtils.ReDrawMenu();
            }
        }
    }
}