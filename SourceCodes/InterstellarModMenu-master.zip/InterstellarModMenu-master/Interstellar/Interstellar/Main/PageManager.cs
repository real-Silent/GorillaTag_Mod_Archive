﻿using Interstellar.Utility;
using UnityEngine;

namespace Interstellar.Main
{
    public class PageManager : MonoBehaviour
    {
        public static void PageUtility()
        {
            if (MenuSrc.CategorieList)
            {
                if (MenuSrc.pageNumber > 3)
                {
                    MenuSrc.pageNumber = 1;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 1)
                {
                    MenuSrc.pageNumber = 3;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.Settings)
            {
                if (MenuSrc.pageNumber > 123456789)
                {
                    MenuSrc.pageNumber = 123456789;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 123456789)
                {
                    MenuSrc.pageNumber = 123456789;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.MenuSettings)
            {
                if (MenuSrc.pageNumber > 7)
                {
                    MenuSrc.pageNumber = 6;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 6)
                {
                    MenuSrc.pageNumber = 7;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.ModSettings)
            {
                if (MenuSrc.pageNumber > 14)
                {
                    MenuSrc.pageNumber = 12;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 12)
                {
                    MenuSrc.pageNumber = 14;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.RoomCategory)
            {
                if (MenuSrc.pageNumber > 2501)
                {
                    MenuSrc.pageNumber = 2500;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 2500)
                {
                    MenuSrc.pageNumber = 2501;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.BasicCategory)
            {
                if (MenuSrc.pageNumber > 21)
                {
                    MenuSrc.pageNumber = 18;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 18)
                {
                    MenuSrc.pageNumber = 21;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.PlayerCategory)
            {
                if (MenuSrc.pageNumber > 31)
                {
                    MenuSrc.pageNumber = 28;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 28)
                {
                    MenuSrc.pageNumber = 31;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.ImpactCategory)
            {
                if (MenuSrc.pageNumber > 36)
                {
                    MenuSrc.pageNumber = 35;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 35)
                {
                    MenuSrc.pageNumber = 36;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.VRRigCategory)
            {
                if (MenuSrc.pageNumber > 43)
                {
                    MenuSrc.pageNumber = 41;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 41)
                {
                    MenuSrc.pageNumber = 43;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.VisualCategory)
            {
                if (MenuSrc.pageNumber > 47)
                {
                    MenuSrc.pageNumber = 47;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 47)
                {
                    MenuSrc.pageNumber = 47;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.SoundCategory)
            {
                if (MenuSrc.pageNumber > 52)
                {
                    MenuSrc.pageNumber = 51;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 51)
                {
                    MenuSrc.pageNumber = 52;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.InfectionCategory)
            {
                if (MenuSrc.pageNumber > 57)
                {
                    MenuSrc.pageNumber = 56;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 56)
                {
                    MenuSrc.pageNumber = 57;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.MasterCategory)
            {
                if (MenuSrc.pageNumber > 65)
                {
                    MenuSrc.pageNumber = 61;
                     
                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 61)
                {
                    MenuSrc.pageNumber = 65;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.MiscCategory)
            {
                if (MenuSrc.pageNumber > 71)
                {
                    MenuSrc.pageNumber = 68;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 68)
                {
                    MenuSrc.pageNumber = 71;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.AbusiveCategory)
            {
                if (MenuSrc.pageNumber > 74)
                {
                    MenuSrc.pageNumber = 73;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 73)
                {
                    MenuSrc.pageNumber = 74;

                    // DONT CHANGE UNDER THIS

                    InterstellarUtils.ReDrawMenu();
                }
            }
            if (MenuSrc.AdminCategory)
            {
                if (MenuSrc.pageNumber > 3000)
                {
                    MenuSrc.pageNumber = 3000;
                    InterstellarUtils.ReDrawMenu();
                }
                if (MenuSrc.pageNumber < 3000)
                {
                    MenuSrc.pageNumber = 3000;
                    InterstellarUtils.ReDrawMenu();
                }
            }
        }
    }
}
