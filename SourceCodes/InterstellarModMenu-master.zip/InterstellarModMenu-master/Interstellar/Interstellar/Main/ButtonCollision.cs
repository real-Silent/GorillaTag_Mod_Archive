﻿using HarmonyLib;
using Photon.Pun;
using UnityEngine;
using Interstellar.Utility;

namespace Interstellar.Main
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class ButtonCollision : MonoBehaviour
    {
        public string Identity;
        public void OnTriggerEnter(Collider other)
        {
            if (Time.frameCount > MenuSrc.FramePressCooldown + 15)
            {
                if (other == MenuSrc.referenceObj.GetComponent<Collider>())
                {
                    if (MenuSrc.menuSounds == 1)
                    {
                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(67, false, 0.25f);
                    }
                    else if (MenuSrc.menuSounds == 2)
                    {
                        if (PhotonNetwork.InRoom && GorillaGameManager.instance != null)
                        {
                            PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlayHandTap", 0, new object[]
                            {
                                67,
                                false,
                                0.9f
                            });
                        }
                        else if (!PhotonNetwork.InRoom)
                        {
                            GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(67, false, 0.25f);
                        }
                    }
                    GorillaTagger.Instance.StartVibration(false, 0.2f, 0.2f);
                    if (Identity == "Disconnect")
                    {
                        PhotonNetwork.Disconnect();
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (Identity == "PrevPage")
                    {
                        MenuSrc.pageNumber--;
                        InterstellarUtils.ReDrawMenu();
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }

                    if (Identity == "NextPage")
                    {
                        MenuSrc.pageNumber++;
                        InterstellarUtils.ReDrawMenu();
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 1)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg1, MenuSrc.Pg1Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 2)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg2, MenuSrc.Pg2Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 3)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg3, MenuSrc.Pg3Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 4)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg4, MenuSrc.Pg4Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 5)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg5, MenuSrc.Pg5Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 6)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg6, MenuSrc.Pg6Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 7)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg7, MenuSrc.Pg7Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 8)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg8, MenuSrc.Pg8Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 9)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg9, MenuSrc.Pg9Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 10)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg10, MenuSrc.Pg10Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 11)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg11, MenuSrc.Pg11Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 12)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg12, MenuSrc.Pg12Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 13)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg13, MenuSrc.Pg13Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 14)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg14, MenuSrc.Pg14Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 15)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg15, MenuSrc.Pg15Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 16)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg16, MenuSrc.Pg16Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 17)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg17, MenuSrc.Pg17Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 18)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg18, MenuSrc.Pg18Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 19)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg19, MenuSrc.Pg19Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 20)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg20, MenuSrc.Pg20Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 21)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg21, MenuSrc.Pg21Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 22)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg22, MenuSrc.Pg22Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 23)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg23, MenuSrc.Pg23Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 24)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg24, MenuSrc.Pg24Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 25)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg25, MenuSrc.Pg25Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 26)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg26, MenuSrc.Pg26Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 27)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg27, MenuSrc.Pg27Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 28)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg28, MenuSrc.Pg28Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 29)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg29, MenuSrc.Pg29Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 30)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg30, MenuSrc.Pg30Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 31)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg31, MenuSrc.Pg31Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 32)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg32, MenuSrc.Pg32Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 33)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg33, MenuSrc.Pg33Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 34)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg34, MenuSrc.Pg34Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 35)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg35, MenuSrc.Pg35Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 36)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg36, MenuSrc.Pg36Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 37)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg37, MenuSrc.Pg37Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 38)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg38, MenuSrc.Pg38Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 39)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg39, MenuSrc.Pg39Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 40)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg40, MenuSrc.Pg40Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 41)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg41, MenuSrc.Pg41Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 42)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg42, MenuSrc.Pg42Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 43)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg43, MenuSrc.Pg43Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 44)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg44, MenuSrc.Pg44Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 45)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg45, MenuSrc.Pg45Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 46)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg46, MenuSrc.Pg46Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 47)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg47, MenuSrc.Pg47Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 48)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg48, MenuSrc.Pg48Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 49)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg49, MenuSrc.Pg49Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 50)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg50, MenuSrc.Pg50Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 51)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg51, MenuSrc.Pg51Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 52)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg52, MenuSrc.Pg52Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 53)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg53, MenuSrc.Pg53Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 54)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg54, MenuSrc.Pg54Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 55)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg55, MenuSrc.Pg55Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 56)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg56, MenuSrc.Pg56Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 57)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg57, MenuSrc.Pg57Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 58)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg58, MenuSrc.Pg58Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 59)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg59, MenuSrc.Pg59Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 60)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg60, MenuSrc.Pg60Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 61)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg61, MenuSrc.Pg61Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 62)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg62, MenuSrc.Pg62Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 63)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg63, MenuSrc.Pg63Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 64)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg64, MenuSrc.Pg64Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 65)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg65, MenuSrc.Pg65Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 66)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg66, MenuSrc.Pg66Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 67)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg67, MenuSrc.Pg67Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 68)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg68, MenuSrc.Pg68Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 69)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg69, MenuSrc.Pg69Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 70)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg70, MenuSrc.Pg70Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 71)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg71, MenuSrc.Pg71Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 72)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg72, MenuSrc.Pg72Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 73)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg73, MenuSrc.Pg73Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 74)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg74, MenuSrc.Pg74Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 75)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg75, MenuSrc.Pg75Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    /*
                    if (MenuSrc.pageNumber == 76)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg76, MenuSrc.Pg76Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 77)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg77, MenuSrc.Pg77Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 78)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg78, MenuSrc.Pg78Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 79)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg79, MenuSrc.Pg79Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 80)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg80, MenuSrc.Pg80Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 81)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg81, MenuSrc.Pg81Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 82)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg82, MenuSrc.Pg82Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 83)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg83, MenuSrc.Pg83Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 84)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg84, MenuSrc.Pg84Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 85)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg85, MenuSrc.Pg85Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 86)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg86, MenuSrc.Pg86Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 87)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg87, MenuSrc.Pg87Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 88)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg88, MenuSrc.Pg88Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 89)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg89, MenuSrc.Pg89Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 90)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg90, MenuSrc.Pg90Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 91)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg91, MenuSrc.Pg91Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 92)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg92, MenuSrc.Pg92Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 93)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg93, MenuSrc.Pg93Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 94)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg94, MenuSrc.Pg94Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 95)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg95, MenuSrc.Pg95Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 96)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg96, MenuSrc.Pg96Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 97)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg97, MenuSrc.Pg97Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 98)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg98, MenuSrc.Pg98Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 99)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg99, MenuSrc.Pg99Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 100)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg100, MenuSrc.Pg100Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 101)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg101, MenuSrc.Pg101Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 102)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg102, MenuSrc.Pg102Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 103)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg103, MenuSrc.Pg103Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 104)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg104, MenuSrc.Pg104Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 105)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg105, MenuSrc.Pg105Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 106)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg106, MenuSrc.Pg106Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 107)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg107, MenuSrc.Pg107Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 108)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg108, MenuSrc.Pg108Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 109)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg109, MenuSrc.Pg109Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 110)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg110, MenuSrc.Pg110Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 111)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg111, MenuSrc.Pg111Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 112)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg112, MenuSrc.Pg112Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 113)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg113, MenuSrc.Pg113Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 114)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg114, MenuSrc.Pg114Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 115)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg115, MenuSrc.Pg115Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 116)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg116, MenuSrc.Pg116Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 117)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg117, MenuSrc.Pg117Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 118)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg118, MenuSrc.Pg118Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 119)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg119, MenuSrc.Pg119Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 120)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg120, MenuSrc.Pg120Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 121)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg121, MenuSrc.Pg121Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 122)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg122, MenuSrc.Pg122Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 123)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg123, MenuSrc.Pg123Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 124)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg124, MenuSrc.Pg124Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 125)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg125, MenuSrc.Pg125Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 126)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg126, MenuSrc.Pg126Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 127)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg127, MenuSrc.Pg127Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 128)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg128, MenuSrc.Pg128Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 129)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg129, MenuSrc.Pg129Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 130)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg130, MenuSrc.Pg130Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 131)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg131, MenuSrc.Pg131Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 132)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg132, MenuSrc.Pg132Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 133)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg133, MenuSrc.Pg133Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 134)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg134, MenuSrc.Pg134Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 135)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg135, MenuSrc.Pg135Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 136)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg136, MenuSrc.Pg136Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 137)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg137, MenuSrc.Pg137Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 138)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg138, MenuSrc.Pg138Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 139)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg139, MenuSrc.Pg139Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 140)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg140, MenuSrc.Pg140Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 141)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg141, MenuSrc.Pg141Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 142)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg142, MenuSrc.Pg142Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 143)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg143, MenuSrc.Pg143Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 144)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg144, MenuSrc.Pg144Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 145)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg145, MenuSrc.Pg145Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 146)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg146, MenuSrc.Pg146Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 147)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg147, MenuSrc.Pg147Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 148)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg148, MenuSrc.Pg148Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 149)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg149, MenuSrc.Pg149Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 150)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg150, MenuSrc.Pg150Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 151)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg151, MenuSrc.Pg151Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 152)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg152, MenuSrc.Pg152Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 153)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg153, MenuSrc.Pg153Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 154)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg154, MenuSrc.Pg154Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 155)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg155, MenuSrc.Pg155Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 156)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg156, MenuSrc.Pg156Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 157)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg157, MenuSrc.Pg157Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 158)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg158, MenuSrc.Pg158Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 159)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg159, MenuSrc.Pg159Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 160)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg160, MenuSrc.Pg160Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 161)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg161, MenuSrc.Pg161Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 162)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg162, MenuSrc.Pg162Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 163)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg163, MenuSrc.Pg163Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 164)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg164, MenuSrc.Pg165Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 165)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg165, MenuSrc.Pg165Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 166)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg166, MenuSrc.Pg166Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 167)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg167, MenuSrc.Pg167Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 168)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg168, MenuSrc.Pg168Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 169)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg169, MenuSrc.Pg169Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 170)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg170, MenuSrc.Pg170Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 171)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg171, MenuSrc.Pg171Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 172)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg172, MenuSrc.Pg172Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 173)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg173, MenuSrc.Pg173Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 174)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg174, MenuSrc.Pg174Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 175)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg175, MenuSrc.Pg175Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 176)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg176, MenuSrc.Pg176Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 177)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg177, MenuSrc.Pg177Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 178)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg178, MenuSrc.Pg178Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 179)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg179, MenuSrc.Pg179Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 180)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg180, MenuSrc.Pg180Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 181)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg181, MenuSrc.Pg181Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 182)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg182, MenuSrc.Pg182Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 183)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg183, MenuSrc.Pg183Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 184)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg184, MenuSrc.Pg184Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 185)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg185, MenuSrc.Pg185Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 186)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg186, MenuSrc.Pg186Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 187)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg187, MenuSrc.Pg187Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 188)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg188, MenuSrc.Pg188Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 189)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg189, MenuSrc.Pg189Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 190)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg190, MenuSrc.Pg190Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 191)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg191, MenuSrc.Pg191Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 192)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg192, MenuSrc.Pg192Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 193)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg193, MenuSrc.Pg193Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    */
                    if (MenuSrc.pageNumber == 123456789)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg123456789, MenuSrc.Pg123456789Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 2500)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg2500, MenuSrc.Pg2500Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 2501)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg2501, MenuSrc.Pg2501Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                    if (MenuSrc.pageNumber == 3000)
                    {
                        MenuSrc.ToggleButton(Identity, MenuSrc.Pg3000, MenuSrc.Pg3000Active);
                        MenuSrc.FramePressCooldown = Time.frameCount;
                    }
                }
            }
        }
    }
}